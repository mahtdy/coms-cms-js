import { Route } from "./application";
import { Plugin } from "./plugin";




export class Cors extends Plugin{
    async init(): Promise<any> {
        return 
    }
    serve(...args: any[]): Route[] {
        return []
    }

}