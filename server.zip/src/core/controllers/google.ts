import Controller, { Response } from "../controller";
import { Get, Post } from "../decorators/method";
import { Body, Query } from "../decorators/parameters";
import BaseController from "../mongoose-controller/controller";
import { styles } from "../mongoose-controller/style";
import SeoServices from "../services/seo";
import { z } from "zod"





export class GoogleAPI extends Controller {

    // @Get("/pagespeed")
    async pagespeed(
        @Query({
            destination: "page",
            schema: z.string().url()
        }) page: string,
        @Query({
            destination: "device",
            schema: z.enum(["desktop", "mobile"])
        }) device: string
    ): Promise<Response> {
        try {

            // let data = await SeoServices.getPageSpeed(page,device)
            const data = {
                "captchaResult": "CAPTCHA_NOT_NEEDED",
                "kind": "pagespeedonline#result",
                "id": "https://www.google.com/",
                "loadingExperience": {
                    "id": "https://www.google.com/",
                    "metrics": {
                        "CUMULATIVE_LAYOUT_SHIFT_SCORE": {
                            "percentile": 0,
                            "distributions": [
                                {
                                    "min": 0,
                                    "max": 10,
                                    "proportion": 0.9737042682926814
                                },
                                {
                                    "min": 10,
                                    "max": 25,
                                    "proportion": 0.01943597560975607
                                },
                                {
                                    "min": 25,
                                    "proportion": 0.006859756097560968
                                }
                            ],
                            "category": "FAST"
                        },
                        "EXPERIMENTAL_TIME_TO_FIRST_BYTE": {
                            "percentile": 1038,
                            "distributions": [
                                {
                                    "min": 0,
                                    "max": 800,
                                    "proportion": 0.6749399519615654
                                },
                                {
                                    "min": 800,
                                    "max": 1800,
                                    "proportion": 0.20136108887109574
                                },
                                {
                                    "min": 1800,
                                    "proportion": 0.12369895916733291
                                }
                            ],
                            "category": "AVERAGE"
                        },
                        "FIRST_CONTENTFUL_PAINT_MS": {
                            "percentile": 1349,
                            "distributions": [
                                {
                                    "min": 0,
                                    "max": 1800,
                                    "proportion": 0.8284161490683584
                                },
                                {
                                    "min": 1800,
                                    "max": 3000,
                                    "proportion": 0.08695652173913414
                                },
                                {
                                    "min": 3000,
                                    "proportion": 0.08462732919255167
                                }
                            ],
                            "category": "FAST"
                        },
                        "FIRST_INPUT_DELAY_MS": {
                            "percentile": 8,
                            "distributions": [
                                {
                                    "min": 0,
                                    "max": 100,
                                    "proportion": 0.9446735395189001
                                },
                                {
                                    "min": 100,
                                    "max": 300,
                                    "proportion": 0.03195876288659793
                                },
                                {
                                    "min": 300,
                                    "proportion": 0.023367697594501628
                                }
                            ],
                            "category": "FAST"
                        },
                        "INTERACTION_TO_NEXT_PAINT": {
                            "percentile": 107,
                            "distributions": [
                                {
                                    "min": 0,
                                    "max": 200,
                                    "proportion": 0.8654736192533141
                                },
                                {
                                    "min": 200,
                                    "max": 500,
                                    "proportion": 0.08114779389077419
                                },
                                {
                                    "min": 500,
                                    "proportion": 0.05337858685590848
                                }
                            ],
                            "category": "FAST"
                        },
                        "LARGEST_CONTENTFUL_PAINT_MS": {
                            "percentile": 1454,
                            "distributions": [
                                {
                                    "min": 0,
                                    "max": 2500,
                                    "proportion": 0.8747156937073912
                                },
                                {
                                    "min": 2500,
                                    "max": 4000,
                                    "proportion": 0.06122062168309587
                                },
                                {
                                    "min": 4000,
                                    "proportion": 0.06406368460955622
                                }
                            ],
                            "category": "FAST"
                        }
                    },
                    "overall_category": "AVERAGE",
                    "initial_url": "https://www.google.com/"
                },
                "originLoadingExperience": {
                    "id": "https://www.google.com",
                    "metrics": {
                        "CUMULATIVE_LAYOUT_SHIFT_SCORE": {
                            "percentile": 0,
                            "distributions": [
                                {
                                    "min": 0,
                                    "max": 10,
                                    "proportion": 0.9809746328437922
                                },
                                {
                                    "min": 10,
                                    "max": 25,
                                    "proportion": 0.014018691588785055
                                },
                                {
                                    "min": 25,
                                    "proportion": 0.005006675567423237
                                }
                            ],
                            "category": "FAST"
                        },
                        "EXPERIMENTAL_TIME_TO_FIRST_BYTE": {
                            "percentile": 274,
                            "distributions": [
                                {
                                    "min": 0,
                                    "max": 800,
                                    "proportion": 0.9565217391304336
                                },
                                {
                                    "min": 800,
                                    "max": 1800,
                                    "proportion": 0.033017325923504384
                                },
                                {
                                    "min": 1800,
                                    "proportion": 0.010460934946060747
                                }
                            ],
                            "category": "FAST"
                        },
                        "FIRST_CONTENTFUL_PAINT_MS": {
                            "percentile": 501,
                            "distributions": [
                                {
                                    "min": 0,
                                    "max": 1800,
                                    "proportion": 0.9725752508361177
                                },
                                {
                                    "min": 1800,
                                    "max": 3000,
                                    "proportion": 0.016053511705685572
                                },
                                {
                                    "min": 3000,
                                    "proportion": 0.011371237458193888
                                }
                            ],
                            "category": "FAST"
                        },
                        "FIRST_INPUT_DELAY_MS": {
                            "percentile": 3,
                            "distributions": [
                                {
                                    "min": 0,
                                    "max": 100,
                                    "proportion": 0.9669195751138128
                                },
                                {
                                    "min": 100,
                                    "max": 300,
                                    "proportion": 0.022761760242792205
                                },
                                {
                                    "min": 300,
                                    "proportion": 0.010318664643399101
                                }
                            ],
                            "category": "FAST"
                        },
                        "INTERACTION_TO_NEXT_PAINT": {
                            "percentile": 69,
                            "distributions": [
                                {
                                    "min": 0,
                                    "max": 200,
                                    "proportion": 0.9285922471582612
                                },
                                {
                                    "min": 200,
                                    "max": 500,
                                    "proportion": 0.053045759253861735
                                },
                                {
                                    "min": 500,
                                    "proportion": 0.018361993587875134
                                }
                            ],
                            "category": "FAST"
                        },
                        "LARGEST_CONTENTFUL_PAINT_MS": {
                            "percentile": 838,
                            "distributions": [
                                {
                                    "min": 0,
                                    "max": 2500,
                                    "proportion": 0.9692204750752805
                                },
                                {
                                    "min": 2500,
                                    "max": 4000,
                                    "proportion": 0.01773168283706934
                                },
                                {
                                    "min": 4000,
                                    "proportion": 0.013047842087654846
                                }
                            ],
                            "category": "FAST"
                        }
                    },
                    "overall_category": "FAST",
                    "initial_url": "https://www.google.com/"
                },
                "lighthouseResult": {
                    "requestedUrl": "https://google.com/",
                    "finalUrl": "https://www.google.com/",
                    "mainDocumentUrl": "https://www.google.com/",
                    "finalDisplayedUrl": "https://www.google.com/",
                    "lighthouseVersion": "11.4.0",
                    "userAgent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/121.0.6167.85 Safari/537.36",
                    "fetchTime": "2024-02-13T10:57:55.837Z",
                    "environment": {
                        "networkUserAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
                        "hostUserAgent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/121.0.6167.85 Safari/537.36",
                        "benchmarkIndex": 387,
                        "credits": {
                            "axe-core": "4.8.1"
                        }
                    },
                    "runWarnings": [
                        "The page may not be loading as expected because your test URL (https://google.com/) was redirected to https://www.google.com/. Try testing the second URL directly."
                    ],
                    "configSettings": {
                        "emulatedFormFactor": "desktop",
                        "formFactor": "desktop",
                        "locale": "en-US",
                        "onlyCategories": [
                            "performance",
                            "accessibility",
                            "best-practices",
                            "seo"
                        ],
                        "channel": "lr"
                    },
                    "audits": {
                        "aria-valid-attr-value": {
                            "id": "aria-valid-attr-value",
                            "title": "`[aria-*]` attributes have valid values",
                            "description": "Assistive technologies, like screen readers, can't interpret ARIA attributes with invalid values. [Learn more about valid values for ARIA attributes](https://dequeuniversity.com/rules/axe/4.8/aria-valid-attr-value).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "type": "table",
                                "items": [],
                                "headings": []
                            }
                        },
                        "focus-traps": {
                            "id": "focus-traps",
                            "title": "User focus is not accidentally trapped in a region",
                            "description": "A user can tab into and out of any control or region without accidentally trapping their focus. [Learn how to avoid focus traps](https://developer.chrome.com/docs/lighthouse/accessibility/focus-traps/).",
                            "score": null,
                            "scoreDisplayMode": "manual"
                        },
                        "preload-fonts": {
                            "id": "preload-fonts",
                            "title": "Fonts with `font-display: optional` are preloaded",
                            "description": "Preload `optional` fonts so first-time visitors may use them. [Learn more about preloading fonts](https://web.dev/articles/preload-optional-fonts)",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "server-response-time": {
                            "id": "server-response-time",
                            "title": "Reduce initial server response time",
                            "description": "Keep the server response time for the main document short because all other requests depend on it. [Learn more about the Time to First Byte metric](https://developer.chrome.com/docs/lighthouse/performance/time-to-first-byte/).",
                            "score": 0,
                            "scoreDisplayMode": "metricSavings",
                            "displayValue": "Root document took 900 ms",
                            "details": {
                                "overallSavingsMs": 803,
                                "items": [
                                    {
                                        "responseTime": 903,
                                        "url": "https://www.google.com/"
                                    }
                                ],
                                "type": "opportunity",
                                "headings": [
                                    {
                                        "key": "url",
                                        "label": "URL",
                                        "valueType": "url"
                                    },
                                    {
                                        "valueType": "timespanMs",
                                        "key": "responseTime",
                                        "label": "Time Spent"
                                    }
                                ]
                            },
                            "numericValue": 903,
                            "numericUnit": "millisecond"
                        },
                        "aria-allowed-role": {
                            "id": "aria-allowed-role",
                            "title": "Values assigned to `role=\"\"` are valid ARIA roles.",
                            "description": "ARIA `role`s enable assistive technologies to know the role of each element on the web page. If the `role` values are misspelled, not existing ARIA `role` values, or abstract roles, then the purpose of the element will not be communicated to users of assistive technologies. [Learn more about ARIA roles](https://dequeuniversity.com/rules/axe/4.8/aria-allowed-role).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "type": "table",
                                "items": [],
                                "headings": []
                            }
                        },
                        "non-composited-animations": {
                            "id": "non-composited-animations",
                            "title": "Avoid non-composited animations",
                            "description": "Animations which are not composited can be janky and increase CLS. [Learn how to avoid non-composited animations](https://developer.chrome.com/docs/lighthouse/performance/non-composited-animations/)",
                            "score": null,
                            "scoreDisplayMode": "notApplicable",
                            "details": {
                                "items": [],
                                "headings": [],
                                "type": "table"
                            }
                        },
                        "total-byte-weight": {
                            "id": "total-byte-weight",
                            "title": "Avoids enormous network payloads",
                            "description": "Large network payloads cost users real money and are highly correlated with long load times. [Learn how to reduce payload sizes](https://developer.chrome.com/docs/lighthouse/performance/total-byte-weight/).",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "displayValue": "Total size was 741 KiB",
                            "details": {
                                "headings": [
                                    {
                                        "valueType": "url",
                                        "label": "URL",
                                        "key": "url"
                                    },
                                    {
                                        "label": "Transfer Size",
                                        "key": "totalBytes",
                                        "valueType": "bytes"
                                    }
                                ],
                                "type": "table",
                                "items": [
                                    {
                                        "url": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/ed=1/dg=2/br=1/rs=ACT90oEcAGSwfSNPLyn9LHwQv0bYDA_7PQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf,FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe,KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=cdos,hsm,jsa,mb4ZUb,d,csi,cEt90b,SNUn3,qddgKe,sTsDMc,dtl0hd,eHDfl",
                                        "totalBytes": 279247
                                    },
                                    {
                                        "url": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/exm=SNUn3,cEt90b,cdos,csi,d,dtl0hd,eHDfl,hsm,jsa,mb4ZUb,qddgKe,sTsDMc/ed=1/dg=2/br=1/ujg=1/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=B2qlPe,DhPYme,GU4Gab,MpJwZc,NzU6V,UUJqVe,Wo3n8,aa,abd,async,epYOx,ifl,ms4mZb,pHXghd,q0xTif,s39S4,sOXFj,sb_wiz,sf,sonic,spch?xjs=s1",
                                        "totalBytes": 148771
                                    },
                                    {
                                        "url": "https://www.google.com/xjs/_/js/md=1/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ",
                                        "totalBytes": 90879
                                    },
                                    {
                                        "url": "https://www.google.com/",
                                        "totalBytes": 78453
                                    },
                                    {
                                        "url": "https://www.gstatic.com/og/_/js/k=og.qtm.en_US.u8Ti_iwBwEs.2019.O/rt=j/m=qabr,q_dnp,qcwid,qapid,qald,q_dg/exm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/rs=AA2YrTsL4HiE1bvJV-MS9_mgAxWPHzXqxw",
                                        "totalBytes": 78352
                                    },
                                    {
                                        "totalBytes": 42045,
                                        "url": "https://apis.google.com/_/scs/abc-static/_/js/k=gapi.gapi.en.GsbA68hXs80.O/m=gapi_iframes,googleapis_client/rt=j/sv=1/d=1/ed=1/rs=AHpOoo899t-H8Lxb3OqzMDuPn6TV_i36ag/cb=gapi.loaded_0"
                                    },
                                    {
                                        "url": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=0/dg=2/br=1/ujg=1/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ/m=sy1bb,P10Owf,synp,sy1a1,sy1a2,gSZvdb,sys8,sysa,sysb,WlNQGd,synn,syyj,syyl,nabPbb,syno,synq,synr,syns,synu,DPreE,sylj,sys7,sys9,CnSW2d,kQvlef,syyk,fXO0xe?xjs=s3",
                                        "totalBytes": 8614
                                    },
                                    {
                                        "url": "https://www.google.com/complete/search?q&cp=0&client=gws-wiz&xssi=t&gs_pcrt=2&hl=de&authuser=0&psi=NEvLZYTrK5KxqtsP4d-0oA0.1707821877526&dpr=1&nolsbt=1",
                                        "totalBytes": 7142
                                    },
                                    {
                                        "totalBytes": 6616,
                                        "url": "https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png"
                                    },
                                    {
                                        "url": "https://www.google.com/images/hpp/spark-42x42px.png",
                                        "totalBytes": 3237
                                    }
                                ],
                                "sortedBy": [
                                    "totalBytes"
                                ]
                            },
                            "numericValue": 758567,
                            "numericUnit": "byte"
                        },
                        "diagnostics": {
                            "id": "diagnostics",
                            "title": "Diagnostics",
                            "description": "Collection of useful page vitals.",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "details": {
                                "type": "debugdata",
                                "items": [
                                    {
                                        "numStylesheets": 1,
                                        "numRequests": 35,
                                        "numTasksOver100ms": 2,
                                        "numTasksOver25ms": 9,
                                        "throughput": 32219500742.76787,
                                        "maxServerLatency": 5.5,
                                        "totalTaskTime": 971.2469999999998,
                                        "numTasks": 546,
                                        "numTasksOver500ms": 0,
                                        "rtt": 0,
                                        "numFonts": 0,
                                        "maxRtt": 0,
                                        "numTasksOver50ms": 3,
                                        "mainDocumentTransferSize": 78453,
                                        "numScripts": 7,
                                        "totalByteWeight": 758567,
                                        "numTasksOver10ms": 14
                                    }
                                ]
                            }
                        },
                        "aria-hidden-focus": {
                            "id": "aria-hidden-focus",
                            "title": "`[aria-hidden=\"true\"]` elements do not contain focusable descendents",
                            "description": "Focusable descendents within an `[aria-hidden=\"true\"]` element prevent those interactive elements from being available to users of assistive technologies like screen readers. [Learn how `aria-hidden` affects focusable elements](https://dequeuniversity.com/rules/axe/4.8/aria-hidden-focus).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "headings": [],
                                "items": [],
                                "type": "table"
                            }
                        },
                        "long-tasks": {
                            "id": "long-tasks",
                            "title": "Avoid long main-thread tasks",
                            "description": "Lists the longest tasks on the main thread, useful for identifying worst contributors to input delay. [Learn how to avoid long main-thread tasks](https://web.dev/articles/long-tasks-devtools)",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "displayValue": "3 long tasks found",
                            "details": {
                                "headings": [
                                    {
                                        "label": "URL",
                                        "key": "url",
                                        "valueType": "url"
                                    },
                                    {
                                        "valueType": "ms",
                                        "key": "startTime",
                                        "granularity": 1,
                                        "label": "Start Time"
                                    },
                                    {
                                        "key": "duration",
                                        "valueType": "ms",
                                        "granularity": 1,
                                        "label": "Duration"
                                    }
                                ],
                                "sortedBy": [
                                    "duration"
                                ],
                                "skipSumming": [
                                    "startTime"
                                ],
                                "items": [
                                    {
                                        "duration": 242,
                                        "startTime": 1027.5,
                                        "url": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/ed=1/dg=2/br=1/rs=ACT90oEcAGSwfSNPLyn9LHwQv0bYDA_7PQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf,FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe,KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=cdos,hsm,jsa,mb4ZUb,d,csi,cEt90b,SNUn3,qddgKe,sTsDMc,dtl0hd,eHDfl"
                                    },
                                    {
                                        "startTime": 1509.5,
                                        "url": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/exm=SNUn3,cEt90b,cdos,csi,d,dtl0hd,eHDfl,hsm,jsa,mb4ZUb,qddgKe,sTsDMc/ed=1/dg=2/br=1/ujg=1/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=B2qlPe,DhPYme,GU4Gab,MpJwZc,NzU6V,UUJqVe,Wo3n8,aa,abd,async,epYOx,ifl,ms4mZb,pHXghd,q0xTif,s39S4,sOXFj,sb_wiz,sf,sonic,spch?xjs=s1",
                                        "duration": 99
                                    },
                                    {
                                        "url": "Unattributable",
                                        "duration": 85,
                                        "startTime": 232
                                    }
                                ],
                                "debugData": {
                                    "tasks": [
                                        {
                                            "parseHTML": 0,
                                            "startTime": 1027.5,
                                            "other": 242,
                                            "urlIndex": 0,
                                            "duration": 242,
                                            "scriptEvaluation": 0
                                        },
                                        {
                                            "duration": 99,
                                            "other": 99,
                                            "scriptEvaluation": 0,
                                            "startTime": 1509.5,
                                            "urlIndex": 1
                                        },
                                        {
                                            "other": 85,
                                            "urlIndex": 2,
                                            "startTime": 232,
                                            "scriptEvaluation": 0,
                                            "duration": 85
                                        }
                                    ],
                                    "type": "debugdata",
                                    "urls": [
                                        "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/ed=1/dg=2/br=1/rs=ACT90oEcAGSwfSNPLyn9LHwQv0bYDA_7PQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf,FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe,KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=cdos,hsm,jsa,mb4ZUb,d,csi,cEt90b,SNUn3,qddgKe,sTsDMc,dtl0hd,eHDfl",
                                        "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/exm=SNUn3,cEt90b,cdos,csi,d,dtl0hd,eHDfl,hsm,jsa,mb4ZUb,qddgKe,sTsDMc/ed=1/dg=2/br=1/ujg=1/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=B2qlPe,DhPYme,GU4Gab,MpJwZc,NzU6V,UUJqVe,Wo3n8,aa,abd,async,epYOx,ifl,ms4mZb,pHXghd,q0xTif,s39S4,sOXFj,sb_wiz,sf,sonic,spch?xjs=s1",
                                        "Unattributable"
                                    ]
                                },
                                "type": "table"
                            }
                        },
                        "accesskeys": {
                            "id": "accesskeys",
                            "title": "`[accesskey]` values are unique",
                            "description": "Access keys let users quickly focus a part of the page. For proper navigation, each access key must be unique. [Learn more about access keys](https://dequeuniversity.com/rules/axe/4.8/accesskeys).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "third-party-facades": {
                            "id": "third-party-facades",
                            "title": "Lazy load third-party resources with facades",
                            "description": "Some third-party embeds can be lazy loaded. Consider replacing them with a facade until they are required. [Learn how to defer third-parties with a facade](https://developer.chrome.com/docs/lighthouse/performance/third-party-facades/).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "aria-required-parent": {
                            "id": "aria-required-parent",
                            "title": "`[role]`s are contained by their required parent element",
                            "description": "Some ARIA child roles must be contained by specific parent roles to properly perform their intended accessibility functions. [Learn more about ARIA roles and required parent element](https://dequeuniversity.com/rules/axe/4.8/aria-required-parent).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "valid-lang": {
                            "id": "valid-lang",
                            "title": "`[lang]` attributes have a valid value",
                            "description": "Specifying a valid [BCP 47 language](https://www.w3.org/International/questions/qa-choosing-language-tags#question) on elements helps ensure that text is pronounced correctly by a screen reader. [Learn how to use the `lang` attribute](https://dequeuniversity.com/rules/axe/4.8/valid-lang).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "identical-links-same-purpose": {
                            "id": "identical-links-same-purpose",
                            "title": "Identical links have the same purpose.",
                            "description": "Links with the same destination should have the same description, to help users understand the link's purpose and decide whether to follow it. [Learn more about identical links](https://dequeuniversity.com/rules/axe/4.8/identical-links-same-purpose).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "notification-on-start": {
                            "id": "notification-on-start",
                            "title": "Avoids requesting the notification permission on page load",
                            "description": "Users are mistrustful of or confused by sites that request to send notifications without context. Consider tying the request to user gestures instead. [Learn more about responsibly getting permission for notifications](https://developer.chrome.com/docs/lighthouse/best-practices/notification-on-start/).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "headings": [],
                                "type": "table",
                                "items": []
                            }
                        },
                        "metrics": {
                            "id": "metrics",
                            "title": "Metrics",
                            "description": "Collects all available metrics.",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "details": {
                                "type": "debugdata",
                                "items": [
                                    {
                                        "observedLargestContentfulPaintTs": 763798706723,
                                        "observedFirstVisualChange": 1280,
                                        "observedLargestContentfulPaint": 1357,
                                        "observedFirstVisualChangeTs": 763798629720,
                                        "observedSpeedIndexTs": 763798681497,
                                        "observedLargestContentfulPaintAllFrames": 1357,
                                        "observedFirstContentfulPaintTs": 763798642556,
                                        "totalBlockingTime": 217,
                                        "observedDomContentLoadedTs": 763798493061,
                                        "observedLastVisualChange": 2013,
                                        "cumulativeLayoutShift": 0.056904628389224526,
                                        "observedCumulativeLayoutShift": 0.056904628389224526,
                                        "observedLastVisualChangeTs": 763799362720,
                                        "observedFirstContentfulPaint": 1293,
                                        "observedFirstMeaningfulPaintTs": 763798642556,
                                        "firstMeaningfulPaint": 541,
                                        "speedIndex": 1297,
                                        "largestContentfulPaint": 1190,
                                        "interactive": 1573,
                                        "observedDomContentLoaded": 1143,
                                        "observedNavigationStartTs": 763797349720,
                                        "observedFirstContentfulPaintAllFramesTs": 763798642556,
                                        "firstContentfulPaint": 525,
                                        "observedLoadTs": 763799555470,
                                        "observedNavigationStart": 0,
                                        "observedSpeedIndex": 1332,
                                        "observedTraceEndTs": 763802016767,
                                        "observedTraceEnd": 4667,
                                        "observedTimeOriginTs": 763797349720,
                                        "maxPotentialFID": 242,
                                        "timeToFirstByte": 166,
                                        "observedCumulativeLayoutShiftMainFrame": 0.056904628389224526,
                                        "observedTimeOrigin": 0,
                                        "observedFirstMeaningfulPaint": 1293,
                                        "observedLargestContentfulPaintAllFramesTs": 763798706723,
                                        "cumulativeLayoutShiftMainFrame": 0.056904628389224526,
                                        "observedLoad": 2206,
                                        "observedFirstPaint": 1293,
                                        "observedFirstContentfulPaintAllFrames": 1293,
                                        "observedFirstPaintTs": 763798642556
                                    },
                                    {
                                        "lcpInvalidated": false
                                    }
                                ]
                            },
                            "numericValue": 1573,
                            "numericUnit": "millisecond"
                        },
                        "uses-responsive-images": {
                            "id": "uses-responsive-images",
                            "title": "Properly size images",
                            "description": "Serve images that are appropriately-sized to save cellular data and improve load time. [Learn how to size images](https://developer.chrome.com/docs/lighthouse/performance/uses-responsive-images/).",
                            "score": 1,
                            "scoreDisplayMode": "metricSavings",
                            "details": {
                                "overallSavingsMs": 0,
                                "type": "opportunity",
                                "items": [],
                                "sortedBy": [
                                    "wastedBytes"
                                ],
                                "debugData": {
                                    "type": "debugdata",
                                    "metricSavings": {
                                        "FCP": 0,
                                        "LCP": 0
                                    }
                                },
                                "overallSavingsBytes": 0,
                                "headings": []
                            },
                            "numericValue": 0,
                            "numericUnit": "millisecond"
                        },
                        "script-treemap-data": {
                            "id": "script-treemap-data",
                            "title": "Script Treemap Data",
                            "description": "Used for treemap app",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "details": {
                                "nodes": [
                                    {
                                        "resourceBytes": 133730,
                                        "children": [
                                            {
                                                "name": "(inline) (function(){var…",
                                                "unusedBytes": 2018,
                                                "resourceBytes": 18595
                                            },
                                            {
                                                "name": "(inline) (function(){goo…",
                                                "resourceBytes": 812,
                                                "unusedBytes": 0
                                            },
                                            {
                                                "name": "(inline) (function(){goo…",
                                                "unusedBytes": 48,
                                                "resourceBytes": 5916
                                            },
                                            {
                                                "name": "(inline) (function(){win…",
                                                "resourceBytes": 22866,
                                                "unusedBytes": 5775
                                            },
                                            {
                                                "unusedBytes": 23823,
                                                "resourceBytes": 38143,
                                                "name": "(inline) (function(){var…"
                                            },
                                            {
                                                "name": "(inline) this.gbar_=this…",
                                                "unusedBytes": 1927,
                                                "resourceBytes": 8276
                                            },
                                            {
                                                "name": "(inline) (function(){var…",
                                                "resourceBytes": 39122,
                                                "unusedBytes": 1586
                                            }
                                        ],
                                        "name": "https://www.google.com/",
                                        "unusedBytes": 35177
                                    },
                                    {
                                        "resourceBytes": 857288,
                                        "name": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/ed=1/dg=2/br=1/rs=ACT90oEcAGSwfSNPLyn9LHwQv0bYDA_7PQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf,FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe,KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=cdos,hsm,jsa,mb4ZUb,d,csi,cEt90b,SNUn3,qddgKe,sTsDMc,dtl0hd,eHDfl",
                                        "unusedBytes": 423746
                                    },
                                    {
                                        "unusedBytes": 155849,
                                        "resourceBytes": 215735,
                                        "name": "https://www.gstatic.com/og/_/js/k=og.qtm.en_US.u8Ti_iwBwEs.2019.O/rt=j/m=qabr,q_dnp,qcwid,qapid,qald,q_dg/exm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/rs=AA2YrTsL4HiE1bvJV-MS9_mgAxWPHzXqxw"
                                    },
                                    {
                                        "unusedBytes": 75685,
                                        "resourceBytes": 121630,
                                        "name": "https://apis.google.com/_/scs/abc-static/_/js/k=gapi.gapi.en.GsbA68hXs80.O/m=gapi_iframes,googleapis_client/rt=j/sv=1/d=1/ed=1/rs=AHpOoo899t-H8Lxb3OqzMDuPn6TV_i36ag/cb=gapi.loaded_0"
                                    },
                                    {
                                        "name": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/exm=SNUn3,cEt90b,cdos,csi,d,dtl0hd,eHDfl,hsm,jsa,mb4ZUb,qddgKe,sTsDMc/ed=1/dg=2/br=1/ujg=1/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=B2qlPe,DhPYme,GU4Gab,MpJwZc,NzU6V,UUJqVe,Wo3n8,aa,abd,async,epYOx,ifl,ms4mZb,pHXghd,q0xTif,s39S4,sOXFj,sb_wiz,sf,sonic,spch?xjs=s1",
                                        "unusedBytes": 290295,
                                        "resourceBytes": 492952
                                    },
                                    {
                                        "resourceBytes": 24360,
                                        "name": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=0/dg=2/br=1/ujg=1/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ/m=sy1bb,P10Owf,synp,sy1a1,sy1a2,gSZvdb,sys8,sysa,sysb,WlNQGd,synn,syyj,syyl,nabPbb,syno,synq,synr,syns,synu,DPreE,sylj,sys7,sys9,CnSW2d,kQvlef,syyk,fXO0xe?xjs=s3",
                                        "unusedBytes": 18499
                                    },
                                    {
                                        "name": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=0/dg=2/br=1/ujg=1/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ/m=syef,aLUfP?xjs=s3",
                                        "resourceBytes": 1573,
                                        "unusedBytes": 457
                                    },
                                    {
                                        "unusedBytes": 1026,
                                        "resourceBytes": 1672,
                                        "name": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=0/dg=2/br=1/ujg=1/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ/m=kMFpHd,sy8b,bm51tf?xjs=s3"
                                    }
                                ],
                                "type": "treemap-data"
                            }
                        },
                        "critical-request-chains": {
                            "id": "critical-request-chains",
                            "title": "Avoid chaining critical requests",
                            "description": "The Critical Request Chains below show you what resources are loaded with a high priority. Consider reducing the length of chains, reducing the download size of resources, or deferring the download of unnecessary resources to improve page load. [Learn how to avoid chaining critical requests](https://developer.chrome.com/docs/lighthouse/performance/critical-request-chains/).",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "displayValue": "1 chain found",
                            "details": {
                                "type": "criticalrequestchain",
                                "longestChain": {
                                    "duration": 1332.6419999599457,
                                    "transferSize": 1472,
                                    "length": 3
                                },
                                "chains": {
                                    "D898F4A75AD99AAF41CC43AA7D311F62": {
                                        "request": {
                                            "url": "https://google.com/",
                                            "endTime": 763797.370544,
                                            "startTime": 763797.351245,
                                            "responseReceivedTime": 763797.3678990001,
                                            "transferSize": 1410
                                        },
                                        "children": {
                                            "D898F4A75AD99AAF41CC43AA7D311F62:redirect": {
                                                "request": {
                                                    "startTime": 763797.371338,
                                                    "transferSize": 78453,
                                                    "endTime": 763798.462993,
                                                    "url": "https://www.google.com/",
                                                    "responseReceivedTime": 763798.4629840001
                                                },
                                                "children": {
                                                    "66.22": {
                                                        "request": {
                                                            "transferSize": 1472,
                                                            "startTime": 763798.677711,
                                                            "responseReceivedTime": 763798.68388,
                                                            "endTime": 763798.683887,
                                                            "url": "https://www.gstatic.com/og/_/ss/k=og.qtm.zz20CdIDKVg.L.W.O/m=qcwid/excm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/ct=zgms/rs=AA2YrTvwL5uXLldqnwtu49O3C0adR0c4Jg"
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        "main-thread-tasks": {
                            "id": "main-thread-tasks",
                            "title": "Tasks",
                            "description": "Lists the toplevel main thread tasks that executed during page load.",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "details": {
                                "items": [
                                    {
                                        "duration": 6.627,
                                        "startTime": 1140.854
                                    },
                                    {
                                        "duration": 24.65,
                                        "startTime": 1152.49
                                    },
                                    {
                                        "startTime": 1184.753,
                                        "duration": 27.802
                                    },
                                    {
                                        "startTime": 1226.079,
                                        "duration": 10.898
                                    },
                                    {
                                        "startTime": 1242.155,
                                        "duration": 24.5
                                    },
                                    {
                                        "startTime": 1270.37,
                                        "duration": 42.113
                                    },
                                    {
                                        "duration": 7.798,
                                        "startTime": 1313.315
                                    },
                                    {
                                        "startTime": 1323.123,
                                        "duration": 13.544
                                    },
                                    {
                                        "duration": 242.338,
                                        "startTime": 1344.424
                                    },
                                    {
                                        "duration": 27.886,
                                        "startTime": 1590.962
                                    },
                                    {
                                        "duration": 37.855,
                                        "startTime": 1619.57
                                    },
                                    {
                                        "duration": 6.472,
                                        "startTime": 1671.595
                                    },
                                    {
                                        "duration": 85.009,
                                        "startTime": 1686.819
                                    },
                                    {
                                        "duration": 29.333,
                                        "startTime": 1772.691
                                    },
                                    {
                                        "duration": 197.794,
                                        "startTime": 1802.104
                                    },
                                    {
                                        "duration": 11.456,
                                        "startTime": 2003.405
                                    },
                                    {
                                        "duration": 6.764,
                                        "startTime": 2016.828
                                    },
                                    {
                                        "duration": 45.521,
                                        "startTime": 2086.022
                                    },
                                    {
                                        "duration": 7.952,
                                        "startTime": 2136.073
                                    },
                                    {
                                        "duration": 5.231,
                                        "startTime": 2196.652
                                    },
                                    {
                                        "startTime": 2201.897,
                                        "duration": 8.442
                                    }
                                ],
                                "type": "table",
                                "headings": [
                                    {
                                        "label": "Start Time",
                                        "key": "startTime",
                                        "valueType": "ms",
                                        "granularity": 1
                                    },
                                    {
                                        "key": "duration",
                                        "granularity": 1,
                                        "valueType": "ms",
                                        "label": "End Time"
                                    }
                                ]
                            }
                        },
                        "aria-required-attr": {
                            "id": "aria-required-attr",
                            "title": "`[role]`s have all required `[aria-*]` attributes",
                            "description": "Some ARIA roles have required attributes that describe the state of the element to screen readers. [Learn more about roles and required attributes](https://dequeuniversity.com/rules/axe/4.8/aria-required-attr).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "headings": [],
                                "type": "table",
                                "items": []
                            }
                        },
                        "errors-in-console": {
                            "id": "errors-in-console",
                            "title": "Browser errors were logged to the console",
                            "description": "Errors logged to the console indicate unresolved problems. They can come from network request failures and other browser concerns. [Learn more about this errors in console diagnostic audit](https://developer.chrome.com/docs/lighthouse/best-practices/errors-in-console/)",
                            "score": 0,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "headings": [
                                    {
                                        "valueType": "source-location",
                                        "label": "Source",
                                        "key": "sourceLocation"
                                    },
                                    {
                                        "label": "Description",
                                        "key": "description",
                                        "valueType": "code"
                                    }
                                ],
                                "items": [
                                    {
                                        "description": "Permissions policy violation: unload is not allowed in this document.",
                                        "sourceLocation": {
                                            "column": 246,
                                            "url": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/ed=1/dg=2/br=1/rs=ACT90oEcAGSwfSNPLyn9LHwQv0bYDA_7PQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf,FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe,KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=cdos,hsm,jsa,mb4ZUb,d,csi,cEt90b,SNUn3,qddgKe,sTsDMc,dtl0hd,eHDfl",
                                            "urlProvider": "network",
                                            "type": "source-location",
                                            "line": 411
                                        },
                                        "source": "violation"
                                    }
                                ],
                                "type": "table"
                            }
                        },
                        "duplicate-id-aria": {
                            "id": "duplicate-id-aria",
                            "title": "ARIA IDs are unique",
                            "description": "The value of an ARIA ID must be unique to prevent other instances from being overlooked by assistive technologies. [Learn how to fix duplicate ARIA IDs](https://dequeuniversity.com/rules/axe/4.8/duplicate-id-aria).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "form-field-multiple-labels": {
                            "id": "form-field-multiple-labels",
                            "title": "No form fields have multiple labels",
                            "description": "Form fields with multiple labels can be confusingly announced by assistive technologies like screen readers which use either the first, the last, or all of the labels. [Learn how to use form labels](https://dequeuniversity.com/rules/axe/4.8/form-field-multiple-labels).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "efficient-animated-content": {
                            "id": "efficient-animated-content",
                            "title": "Use video formats for animated content",
                            "description": "Large GIFs are inefficient for delivering animated content. Consider using MPEG4/WebM videos for animations and PNG/WebP for static images instead of GIF to save network bytes. [Learn more about efficient video formats](https://developer.chrome.com/docs/lighthouse/performance/efficient-animated-content/)",
                            "score": 1,
                            "scoreDisplayMode": "metricSavings",
                            "details": {
                                "debugData": {
                                    "type": "debugdata",
                                    "metricSavings": {
                                        "FCP": 0,
                                        "LCP": 0
                                    }
                                },
                                "overallSavingsBytes": 0,
                                "items": [],
                                "type": "opportunity",
                                "headings": [],
                                "sortedBy": [
                                    "wastedBytes"
                                ],
                                "overallSavingsMs": 0
                            },
                            "numericValue": 0,
                            "numericUnit": "millisecond"
                        },
                        "largest-contentful-paint-element": {
                            "id": "largest-contentful-paint-element",
                            "title": "Largest Contentful Paint element",
                            "description": "This is the largest contentful element painted within the viewport. [Learn more about the Largest Contentful Paint element](https://developer.chrome.com/docs/lighthouse/performance/lighthouse-largest-contentful-paint/)",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "displayValue": "1,190 ms",
                            "details": {
                                "items": [
                                    {
                                        "type": "table",
                                        "headings": [
                                            {
                                                "label": "Element",
                                                "key": "node",
                                                "valueType": "node"
                                            }
                                        ],
                                        "items": [
                                            {
                                                "node": {
                                                    "selector": "div.dbsFrd > div.GZ7xNe > div.AG96lb > div.yS1nld",
                                                    "lhId": "page-0-DIV",
                                                    "nodeLabel": "Nicht personalisierte Inhalte werden u. a. von Inhalten, die Sie sich gerade an…",
                                                    "path": "1,HTML,1,BODY,3,DIV,4,DIV,2,DIV,1,SPAN,0,DIV,0,DIV,0,DIV,1,DIV,1,DIV,2,DIV",
                                                    "boundingRect": {
                                                        "left": 307,
                                                        "width": 736,
                                                        "right": 1043,
                                                        "height": 120,
                                                        "top": 550,
                                                        "bottom": 670
                                                    },
                                                    "snippet": "<div class=\"yS1nld\">",
                                                    "type": "node"
                                                }
                                            }
                                        ]
                                    },
                                    {
                                        "type": "table",
                                        "headings": [
                                            {
                                                "label": "Phase",
                                                "valueType": "text",
                                                "key": "phase"
                                            },
                                            {
                                                "valueType": "text",
                                                "label": "% of LCP",
                                                "key": "percent"
                                            },
                                            {
                                                "label": "Timing",
                                                "valueType": "ms",
                                                "key": "timing"
                                            }
                                        ],
                                        "items": [
                                            {
                                                "percent": "14%",
                                                "phase": "TTFB",
                                                "timing": 165.5
                                            },
                                            {
                                                "phase": "Load Delay",
                                                "percent": "0%",
                                                "timing": 0
                                            },
                                            {
                                                "phase": "Load Time",
                                                "timing": 0,
                                                "percent": "0%"
                                            },
                                            {
                                                "percent": "86%",
                                                "phase": "Render Delay",
                                                "timing": 1024
                                            }
                                        ]
                                    }
                                ],
                                "type": "list"
                            }
                        },
                        "aria-text": {
                            "id": "aria-text",
                            "title": "Elements with the `role=text` attribute do not have focusable descendents.",
                            "description": "Adding `role=text` around a text node split by markup enables VoiceOver to treat it as one phrase, but the element's focusable descendents will not be announced. [Learn more about the `role=text` attribute](https://dequeuniversity.com/rules/axe/4.8/aria-text).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "managed-focus": {
                            "id": "managed-focus",
                            "title": "The user's focus is directed to new content added to the page",
                            "description": "If new content, such as a dialog, is added to the page, the user's focus is directed to it. [Learn how to direct focus to new content](https://developer.chrome.com/docs/lighthouse/accessibility/managed-focus/).",
                            "score": null,
                            "scoreDisplayMode": "manual"
                        },
                        "link-name": {
                            "id": "link-name",
                            "title": "Links have a discernible name",
                            "description": "Link text (and alternate text for images, when used as links) that is discernible, unique, and focusable improves the navigation experience for screen reader users. [Learn how to make links accessible](https://dequeuniversity.com/rules/axe/4.8/link-name).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "type": "table",
                                "items": [],
                                "headings": []
                            }
                        },
                        "interactive-element-affordance": {
                            "id": "interactive-element-affordance",
                            "title": "Interactive elements indicate their purpose and state",
                            "description": "Interactive elements, such as links and buttons, should indicate their state and be distinguishable from non-interactive elements. [Learn how to decorate interactive elements with affordance hints](https://developer.chrome.com/docs/lighthouse/accessibility/interactive-element-affordance/).",
                            "score": null,
                            "scoreDisplayMode": "manual"
                        },
                        "color-contrast": {
                            "id": "color-contrast",
                            "title": "Background and foreground colors do not have a sufficient contrast ratio.",
                            "description": "Low-contrast text is difficult or impossible for many users to read. [Learn how to provide sufficient color contrast](https://dequeuniversity.com/rules/axe/4.8/color-contrast).",
                            "score": 0,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "debugData": {
                                    "type": "debugdata",
                                    "impact": "serious",
                                    "tags": [
                                        "cat.color",
                                        "wcag2aa",
                                        "wcag143",
                                        "TTv5",
                                        "TT13.c",
                                        "EN-301-549",
                                        "EN-9.1.4.3",
                                        "ACT"
                                    ]
                                },
                                "type": "table",
                                "headings": [
                                    {
                                        "subItemsHeading": {
                                            "valueType": "node",
                                            "key": "relatedNode"
                                        },
                                        "valueType": "node",
                                        "label": "Failing Elements",
                                        "key": "node"
                                    }
                                ],
                                "items": [
                                    {
                                        "subItems": {
                                            "type": "subitems",
                                            "items": [
                                                {
                                                    "relatedNode": {
                                                        "selector": "body.EM1Mrb",
                                                        "boundingRect": {
                                                            "bottom": 940,
                                                            "left": 0,
                                                            "width": 1350,
                                                            "right": 1350,
                                                            "height": 940,
                                                            "top": 0
                                                        },
                                                        "path": "1,HTML,1,BODY",
                                                        "snippet": "<body jsmodel=\"hspDDf \" class=\"EM1Mrb\" jsaction=\"xjhTIf:.CLIENT;O2vyse:.CLIENT;IVKTfe:.CLIENT;Ez7VMc:.CLIENT;YUC7He:.CLIENT…\">",
                                                        "type": "node",
                                                        "lhId": "1-1-BODY",
                                                        "nodeLabel": "body.EM1Mrb"
                                                    }
                                                }
                                            ]
                                        },
                                        "node": {
                                            "boundingRect": {
                                                "left": 471,
                                                "height": 15,
                                                "top": 516,
                                                "width": 31,
                                                "right": 502,
                                                "bottom": 531
                                            },
                                            "type": "node",
                                            "path": "1,HTML,1,BODY,2,DIV,3,DIV,1,DIV,1,DIV,1,SPAN",
                                            "snippet": "<span style=\"color:red\">",
                                            "selector": "div.o3j99 > div.vcVZ7d > div.szppmdbYutt__middle-slot-promo > span",
                                            "nodeLabel": "Neu! ",
                                            "explanation": "Fix any of the following:\n  Element has insufficient color contrast of 3.99 (foreground color: #ff0000, background color: #ffffff, font size: 9.8pt (13px), font weight: normal). Expected contrast ratio of 4.5:1",
                                            "lhId": "1-0-SPAN"
                                        }
                                    }
                                ]
                            }
                        },
                        "network-server-latency": {
                            "id": "network-server-latency",
                            "title": "Server Backend Latencies",
                            "description": "Server latencies can impact web performance. If the server latency of an origin is high, it's an indication the server is overloaded or has poor backend performance. [Learn more about server response time](https://hpbn.co/primer-on-web-performance/#analyzing-the-resource-waterfall).",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "displayValue": "10 ms",
                            "details": {
                                "type": "table",
                                "headings": [
                                    {
                                        "label": "URL",
                                        "key": "origin",
                                        "valueType": "text"
                                    },
                                    {
                                        "valueType": "ms",
                                        "label": "Time Spent",
                                        "granularity": 1,
                                        "key": "serverResponseTime"
                                    }
                                ],
                                "sortedBy": [
                                    "serverResponseTime"
                                ],
                                "items": [
                                    {
                                        "serverResponseTime": 5.5,
                                        "origin": "https://www.google.com"
                                    },
                                    {
                                        "origin": "https://www.gstatic.com",
                                        "serverResponseTime": 1
                                    },
                                    {
                                        "origin": "https://apis.google.com",
                                        "serverResponseTime": 1
                                    },
                                    {
                                        "origin": "https://fonts.gstatic.com",
                                        "serverResponseTime": 0
                                    }
                                ]
                            },
                            "numericValue": 5.5,
                            "numericUnit": "millisecond"
                        },
                        "unminified-css": {
                            "id": "unminified-css",
                            "title": "Minify CSS",
                            "description": "Minifying CSS files can reduce network payload sizes. [Learn how to minify CSS](https://developer.chrome.com/docs/lighthouse/performance/unminified-css/).",
                            "score": 1,
                            "scoreDisplayMode": "metricSavings",
                            "details": {
                                "overallSavingsMs": 0,
                                "items": [],
                                "sortedBy": [
                                    "wastedBytes"
                                ],
                                "debugData": {
                                    "metricSavings": {
                                        "LCP": 0,
                                        "FCP": 0
                                    },
                                    "type": "debugdata"
                                },
                                "headings": [],
                                "type": "opportunity",
                                "overallSavingsBytes": 0
                            },
                            "numericValue": 0,
                            "numericUnit": "millisecond"
                        },
                        "logical-tab-order": {
                            "id": "logical-tab-order",
                            "title": "The page has a logical tab order",
                            "description": "Tabbing through the page follows the visual layout. Users cannot focus elements that are offscreen. [Learn more about logical tab ordering](https://developer.chrome.com/docs/lighthouse/accessibility/logical-tab-order/).",
                            "score": null,
                            "scoreDisplayMode": "manual"
                        },
                        "geolocation-on-start": {
                            "id": "geolocation-on-start",
                            "title": "Avoids requesting the geolocation permission on page load",
                            "description": "Users are mistrustful of or confused by sites that request their location without context. Consider tying the request to a user action instead. [Learn more about the geolocation permission](https://developer.chrome.com/docs/lighthouse/best-practices/geolocation-on-start/).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "type": "table",
                                "items": [],
                                "headings": []
                            }
                        },
                        "video-caption": {
                            "id": "video-caption",
                            "title": "`<video>` elements contain a `<track>` element with `[kind=\"captions\"]`",
                            "description": "When a video provides a caption it is easier for deaf and hearing impaired users to access its information. [Learn more about video captions](https://dequeuniversity.com/rules/axe/4.8/video-caption).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "structured-data": {
                            "id": "structured-data",
                            "title": "Structured data is valid",
                            "description": "Run the [Structured Data Testing Tool](https://search.google.com/structured-data/testing-tool/) and the [Structured Data Linter](http://linter.structured-data.org/) to validate structured data. [Learn more about Structured Data](https://developer.chrome.com/docs/lighthouse/seo/structured-data/).",
                            "score": null,
                            "scoreDisplayMode": "manual"
                        },
                        "valid-source-maps": {
                            "id": "valid-source-maps",
                            "title": "Missing source maps for large first-party JavaScript",
                            "description": "Source maps translate minified code to the original source code. This helps developers debug in production. In addition, Lighthouse is able to provide further insights. Consider deploying source maps to take advantage of these benefits. [Learn more about source maps](https://developer.chrome.com/docs/devtools/javascript/source-maps/).",
                            "score": 0,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "type": "table",
                                "items": [
                                    {
                                        "scriptUrl": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/ed=1/dg=2/br=1/rs=ACT90oEcAGSwfSNPLyn9LHwQv0bYDA_7PQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf,FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe,KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=cdos,hsm,jsa,mb4ZUb,d,csi,cEt90b,SNUn3,qddgKe,sTsDMc,dtl0hd,eHDfl",
                                        "subItems": {
                                            "type": "subitems",
                                            "items": [
                                                {
                                                    "error": "Large JavaScript file is missing a source map"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "headings": [
                                    {
                                        "label": "URL",
                                        "key": "scriptUrl",
                                        "subItemsHeading": {
                                            "key": "error"
                                        },
                                        "valueType": "url"
                                    },
                                    {
                                        "label": "Map URL",
                                        "key": "sourceMapUrl",
                                        "valueType": "url"
                                    }
                                ]
                            }
                        },
                        "custom-controls-roles": {
                            "id": "custom-controls-roles",
                            "title": "Custom controls have ARIA roles",
                            "description": "Custom interactive controls have appropriate ARIA roles. [Learn how to add roles to custom controls](https://developer.chrome.com/docs/lighthouse/accessibility/custom-control-roles/).",
                            "score": null,
                            "scoreDisplayMode": "manual"
                        },
                        "speed-index": {
                            "id": "speed-index",
                            "title": "Speed Index",
                            "description": "Speed Index shows how quickly the contents of a page are visibly populated. [Learn more about the Speed Index metric](https://developer.chrome.com/docs/lighthouse/performance/speed-index/).",
                            "score": 0.9,
                            "scoreDisplayMode": "numeric",
                            "displayValue": "1.3 s",
                            "numericValue": 1297.1534019317323,
                            "numericUnit": "millisecond"
                        },
                        "inspector-issues": {
                            "id": "inspector-issues",
                            "title": "No issues in the `Issues` panel in Chrome Devtools",
                            "description": "Issues logged to the `Issues` panel in Chrome Devtools indicate unresolved problems. They can come from network request failures, insufficient security controls, and other browser concerns. Open up the Issues panel in Chrome DevTools for more details on each issue.",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "type": "table",
                                "headings": [],
                                "items": []
                            }
                        },
                        "visual-order-follows-dom": {
                            "id": "visual-order-follows-dom",
                            "title": "Visual order on the page follows DOM order",
                            "description": "DOM order matches the visual order, improving navigation for assistive technology. [Learn more about DOM and visual ordering](https://developer.chrome.com/docs/lighthouse/accessibility/visual-order-follows-dom/).",
                            "score": null,
                            "scoreDisplayMode": "manual"
                        },
                        "doctype": {
                            "id": "doctype",
                            "title": "Page has the HTML doctype",
                            "description": "Specifying a doctype prevents the browser from switching to quirks-mode. [Learn more about the doctype declaration](https://developer.chrome.com/docs/lighthouse/best-practices/doctype/).",
                            "score": 1,
                            "scoreDisplayMode": "binary"
                        },
                        "hreflang": {
                            "id": "hreflang",
                            "title": "Document has a valid `hreflang`",
                            "description": "hreflang links tell search engines what version of a page they should list in search results for a given language or region. [Learn more about `hreflang`](https://developer.chrome.com/docs/lighthouse/seo/hreflang/).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "items": [],
                                "headings": [],
                                "type": "table"
                            }
                        },
                        "html-lang-valid": {
                            "id": "html-lang-valid",
                            "title": "`<html>` element has a valid value for its `[lang]` attribute",
                            "description": "Specifying a valid [BCP 47 language](https://www.w3.org/International/questions/qa-choosing-language-tags#question) helps screen readers announce text properly. [Learn how to use the `lang` attribute](https://dequeuniversity.com/rules/axe/4.8/html-lang-valid).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "type": "table",
                                "items": [],
                                "headings": []
                            }
                        },
                        "empty-heading": {
                            "id": "empty-heading",
                            "title": "All heading elements contain content.",
                            "description": "A heading with no content or inaccessible text prevent screen reader users from accessing information on the page's structure. [Learn more about headings](https://dequeuniversity.com/rules/axe/4.8/empty-heading).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "largest-contentful-paint": {
                            "id": "largest-contentful-paint",
                            "title": "Largest Contentful Paint",
                            "description": "Largest Contentful Paint marks the time at which the largest text or image is painted. [Learn more about the Largest Contentful Paint metric](https://developer.chrome.com/docs/lighthouse/performance/lighthouse-largest-contentful-paint/)",
                            "score": 0.9,
                            "scoreDisplayMode": "numeric",
                            "displayValue": "1.2 s",
                            "numericValue": 1189.5,
                            "numericUnit": "millisecond"
                        },
                        "table-fake-caption": {
                            "id": "table-fake-caption",
                            "title": "Tables use `<caption>` instead of cells with the `[colspan]` attribute to indicate a caption.",
                            "description": "Screen readers have features to make navigating tables easier. Ensuring that tables use the actual caption element instead of cells with the `[colspan]` attribute may improve the experience for screen reader users. [Learn more about captions](https://dequeuniversity.com/rules/axe/4.8/table-fake-caption).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "th-has-data-cells": {
                            "id": "th-has-data-cells",
                            "title": "`<th>` elements and elements with `[role=\"columnheader\"/\"rowheader\"]` have data cells they describe.",
                            "description": "Screen readers have features to make navigating tables easier. Ensuring table headers always refer to some set of cells may improve the experience for screen reader users. [Learn more about table headers](https://dequeuniversity.com/rules/axe/4.8/th-has-data-cells).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "listitem": {
                            "id": "listitem",
                            "title": "List items (`<li>`) are contained within `<ul>`, `<ol>` or `<menu>` parent elements",
                            "description": "Screen readers require list items (`<li>`) to be contained within a parent `<ul>`, `<ol>` or `<menu>` to be announced properly. [Learn more about proper list structure](https://dequeuniversity.com/rules/axe/4.8/listitem).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "type": "table",
                                "headings": [],
                                "items": []
                            }
                        },
                        "aria-hidden-body": {
                            "id": "aria-hidden-body",
                            "title": "`[aria-hidden=\"true\"]` is not present on the document `<body>`",
                            "description": "Assistive technologies, like screen readers, work inconsistently when `aria-hidden=\"true\"` is set on the document `<body>`. [Learn how `aria-hidden` affects the document body](https://dequeuniversity.com/rules/axe/4.8/aria-hidden-body).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "items": [],
                                "type": "table",
                                "headings": []
                            }
                        },
                        "aria-tooltip-name": {
                            "id": "aria-tooltip-name",
                            "title": "ARIA `tooltip` elements have accessible names",
                            "description": "When a tooltip element doesn't have an accessible name, screen readers announce it with a generic name, making it unusable for users who rely on screen readers. [Learn how to name `tooltip` elements](https://dequeuniversity.com/rules/axe/4.8/aria-tooltip-name).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "dlitem": {
                            "id": "dlitem",
                            "title": "Definition list items are wrapped in `<dl>` elements",
                            "description": "Definition list items (`<dt>` and `<dd>`) must be wrapped in a parent `<dl>` element to ensure that screen readers can properly announce them. [Learn how to structure definition lists correctly](https://dequeuniversity.com/rules/axe/4.8/dlitem).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "uses-text-compression": {
                            "id": "uses-text-compression",
                            "title": "Enable text compression",
                            "description": "Text-based resources should be served with compression (gzip, deflate or brotli) to minimize total network bytes. [Learn more about text compression](https://developer.chrome.com/docs/lighthouse/performance/uses-text-compression/).",
                            "score": 1,
                            "scoreDisplayMode": "metricSavings",
                            "details": {
                                "overallSavingsBytes": 0,
                                "items": [],
                                "sortedBy": [
                                    "wastedBytes"
                                ],
                                "overallSavingsMs": 0,
                                "debugData": {
                                    "type": "debugdata",
                                    "metricSavings": {
                                        "LCP": 0,
                                        "FCP": 0
                                    }
                                },
                                "type": "opportunity",
                                "headings": []
                            },
                            "numericValue": 0,
                            "numericUnit": "millisecond"
                        },
                        "total-blocking-time": {
                            "id": "total-blocking-time",
                            "title": "Total Blocking Time",
                            "description": "Sum of all time periods between FCP and Time to Interactive, when task length exceeded 50ms, expressed in milliseconds. [Learn more about the Total Blocking Time metric](https://developer.chrome.com/docs/lighthouse/performance/lighthouse-total-blocking-time/).",
                            "score": 0.76,
                            "scoreDisplayMode": "numeric",
                            "displayValue": "220 ms",
                            "numericValue": 216.5,
                            "numericUnit": "millisecond"
                        },
                        "aria-valid-attr": {
                            "id": "aria-valid-attr",
                            "title": "`[aria-*]` attributes are valid and not misspelled",
                            "description": "Assistive technologies, like screen readers, can't interpret ARIA attributes with invalid names. [Learn more about valid ARIA attributes](https://dequeuniversity.com/rules/axe/4.8/aria-valid-attr).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "headings": [],
                                "items": [],
                                "type": "table"
                            }
                        },
                        "mainthread-work-breakdown": {
                            "id": "mainthread-work-breakdown",
                            "title": "Minimizes main-thread work",
                            "description": "Consider reducing the time spent parsing, compiling and executing JS. You may find delivering smaller JS payloads helps with this. [Learn how to minimize main-thread work](https://developer.chrome.com/docs/lighthouse/performance/mainthread-work-breakdown/)",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "displayValue": "1.0 s",
                            "details": {
                                "headings": [
                                    {
                                        "valueType": "text",
                                        "label": "Category",
                                        "key": "groupLabel"
                                    },
                                    {
                                        "granularity": 1,
                                        "key": "duration",
                                        "valueType": "ms",
                                        "label": "Time Spent"
                                    }
                                ],
                                "items": [
                                    {
                                        "duration": 616.1319999999985,
                                        "groupLabel": "Script Evaluation",
                                        "group": "scriptEvaluation"
                                    },
                                    {
                                        "group": "other",
                                        "duration": 167.87400000000017,
                                        "groupLabel": "Other"
                                    },
                                    {
                                        "group": "scriptParseCompile",
                                        "duration": 55.32800000000001,
                                        "groupLabel": "Script Parsing & Compilation"
                                    },
                                    {
                                        "groupLabel": "Style & Layout",
                                        "group": "styleLayout",
                                        "duration": 52.22500000000001
                                    },
                                    {
                                        "groupLabel": "Garbage Collection",
                                        "duration": 42.16400000000001,
                                        "group": "garbageCollection"
                                    },
                                    {
                                        "group": "parseHTML",
                                        "duration": 27.645,
                                        "groupLabel": "Parse HTML & CSS"
                                    },
                                    {
                                        "groupLabel": "Rendering",
                                        "group": "paintCompositeRender",
                                        "duration": 9.879000000000001
                                    }
                                ],
                                "type": "table",
                                "sortedBy": [
                                    "duration"
                                ]
                            },
                            "numericValue": 971.2469999999987,
                            "numericUnit": "millisecond"
                        },
                        "no-unload-listeners": {
                            "id": "no-unload-listeners",
                            "title": "Avoids `unload` event listeners",
                            "description": "The `unload` event does not fire reliably and listening for it can prevent browser optimizations like the Back-Forward Cache. Use `pagehide` or `visibilitychange` events instead. [Learn more about unload event listeners](https://web.dev/articles/bfcache#never_use_the_unload_event)",
                            "score": 1,
                            "scoreDisplayMode": "binary"
                        },
                        "screenshot-thumbnails": {
                            "id": "screenshot-thumbnails",
                            "title": "Screenshot Thumbnails",
                            "description": "This is what the load of your site looked like.",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "details": {
                                "items": [
                                    {
                                        "data": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2MBERISGBUYLxoaL2NCOEJjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY//AABEIAVwB9AMBEQACEQEDEQH/xAGiAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgsQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+gEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoLEQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/APQKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoA//9k=",
                                        "timing": 375,
                                        "timestamp": 763797724720
                                    },
                                    {
                                        "timestamp": 763798099720,
                                        "timing": 750,
                                        "data": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2MBERISGBUYLxoaL2NCOEJjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY//AABEIAVwB9AMBEQACEQEDEQH/xAGiAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgsQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+gEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoLEQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/APQKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoA//9k="
                                    },
                                    {
                                        "data": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2MBERISGBUYLxoaL2NCOEJjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY//AABEIAVwB9AMBEQACEQEDEQH/xAGiAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgsQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+gEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoLEQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/APQKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoA//9k=",
                                        "timing": 1125,
                                        "timestamp": 763798474720
                                    },
                                    {
                                        "timestamp": 763798849720,
                                        "data": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAFcAfQDASIAAhEBAxEB/8QAHAABAAICAwEAAAAAAAAAAAAAAAQFAgMBBggH/8QATRAAAQMCBAIECgcHBAIAAwkAAQACAwQRBRIhMQZBEyJRYQcUMjdUcXKBkbMVFheTodHSI0JVkpSx8DNSYsEk4SU08SY1RFNjgoOiwv/EABoBAQADAQEBAAAAAAAAAAAAAAABAgMFBAb/xAAvEQEAAgECAggFBAMAAAAAAAAAAQIDBBEhkQUSFBVRUoHwMUFTYtETInGhMkJh/9oADAMBAAIRAxEAPwDriIq+op6t073wSNaLkjrdw0It3H4oLBFBjhrSyYTTMJI6gbp+Nrha2w4i1tmyxga2FyfVqQT/AJ70FkirKePEjOHyyMbHcAtNiSOdrbc/wU+oa58EjYyQ8tIBBtY+tBsRVkVPiDTYzsyk9tyBbvCmUbZ2w2qntfJfdosEG9ERAREQERW9NwzjtVAyamwbEZYni7Xtp3kOHaDZBUIrz6o8R/wLE/6Z/wCSfVHiP+BYn/TP/JBRorz6o8R/wLE/6Z/5J9UeI/4Fif8ATP8AyQUaK8+qPEf8CxP+mf8Akn1R4j/gWJ/0z/yQUaK8+qPEf8CxP+mf+SfVHiP+BYn/AEz/AMkFGivPqjxH/AsT/pn/AJJ9UeI/4Fif9M/8kFGivPqjxH/AsT/pn/kn1R4j/gWJ/wBM/wDJBRorz6o8R/wLE/6Z/wCSfVHiP+BYn/TP/JBRorz6o8R/wLE/6Z/5J9UeI/4Fif8ATP8AyQUaK8+qPEf8CxP+mf8Akn1R4j/gWJ/0z/yQUaK8+qPEf8CxP+mf+SfVHiP+BYn/AEz/AMkFGivPqjxH/AsT/pn/AJJ9UeI/4Fif9M/8kFGivPqjxH/AsT/pn/kn1R4j/gWJ/wBM/wDJBRorz6o8R/wLE/6Z/wCSfVHiP+BYn/TP/JBRorz6o8R/wLE/6Z/5J9UeI/4Fif8ATP8AyQUaK8+qPEf8CxP+mf8Akn1R4j/gWJ/0z/yQUaK8+qPEf8CxP+mf+SfVHiP+BYn/AEz/AMkFGivPqjxH/AsT/pn/AJJ9UeI/4Fif9M/8kFGivPqjxH/AsT/pn/kqHGMJxOhr2x1cM9HJlHUmY5hA11AIsd/wQZIq8U9cZIs9S0xtsXaWLjfuC34hDNPGxsEhjcHXJzEaWPZ32+CCSirG0uINyWqmm173F7g+5WMYc2Noc7M4DU9pQZIoeJwvmjaGMzkZuQO7SOZHatlDG6ON4e3KS9xtYf8ARQQ8ZxmPDJI2PidIXgnQ2sq762Q+iyfzBReN/wD5um9g/wB11+ndG0u6VpdcWFuXeulh0+O2OLTHF4Mue9bzWJdq+tkPosn8wT62Q+iyfzBda6Sl1/Yu1J57dnNZdJSXP7J+XT++vNadmxeWVO0ZPF2P62Q+iyfzBTcJx2PEaowNhex2UuuTddJndE63QsLdTudxyVtwd/8Ae/8A/G7/AKVMumx1pNohbHnvN4iZd4REXMdAREQEREBERAREQEREBERB2rwXUFPiXHuFU1ZGJIcz5Cx2oJaxzhf3gL1ENBovM/gb84+F+zN8py9MICLqPFmK4ycUpsI4djY2olGaSpkALYx+f+erXw5U4vRYpLDjuOYbVU4FgAWtkD77WFrfisaZ4yWmtImduEzHwiXptpupijJe8RvxiN+M/wBbc5dyREWzzCIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAi4ccrSVpqZIqenkqKqTJFG0ve8kgNA3KHwb0VJgeP4XjcssVBO90kWpa7MCR2jtGo+KmitojIYxUAvDsuUOJN7kf9H4FXtjvWeraNpUrkraN4ngnIsCOjFwTYbgm65cSXZQbcyVRdki0SPgjlZHJKGveCWtLyCbb2TPB/+aNr/wCodvip2Ru3oozZqZzw1szS4306Q8jbt7dFtYGubmjeSORDrhNtjfdsXQ/DXh9PVcB1lTNG0z0jmSRPtq0l7Wn3EFd7Ybt132K6d4YPNzjHsx/NYoS8yjZEGyICIiAiIgi1uH0taWmqhEhboCSRb4KN9A4b6K3+Z35qzRXjJeI2iZVmlZ4zCs+gcN9Fb/M780+gcN9Fb/M781Zop/VyeaeaP06eEKz6Bw30Vv8AM781vo8Mo6OUyU0AY8i17k6e9TEUTkvMbTMpilY4xAiIqLCIiAiIgIiICIiAiIgIiIO6eBvzj4X7M3ynL0wvM/gb84+F+zN8py9MIOkcYOxnB8cpsZwmiNdSZTHUwM/1OwEfhsOS6lHhY4s4mp56Dh+pwyAT9PV1VS515De5AB07du3kvsiJpZtpLTbBO2++/wD3f4vNm0857b3tvHDhw+Xh4CIiPSIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIOHjM0jnuo1dDFW0U1LM5zGysLHWNnC/MHtUpEiduMImN+DrfDXDcWC1MlQ+vlqpC3IzOTZjdNALn/AGjXuU12DUTphK57i9rzI0kg5SSTYAjtce9W9kstLZr2t1pnipXFSsdWI4NbnB4LWm99CuT1X5uRFis0WbRX1+HUdfIJKjrODcrSH2sNb/EGxUWXAMNkaQWkElpuHa9W9v7q6SyvGS8cIlScdZ+MKP6u4bna4ZhlfnAzaX2P4KyooKeip2wU9gxuzQbqVZEtktaNrSVpWvGIYsBA13Oq6f4YPNzjHsx/NYu5Lpvhg83OMezH81iou8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO6eBvzj4X7M3ynL0wvM/gb84+F+zN8py9MICIiAiIgIiIC63x5i1Xg+F0ktA4tlmrIqcuFO6dwa4m9mAguK7IoGNYRSYzSsgrRLkjkbMx0UzonNe3YhzSCPig6TReENtJSmLFmiWu8YmjY0sFG4xxtY4ueyR3UcekbZt9QQdATa2k4+wyOkdUPiqQwASZSwB3Q+L9P0tr3y5QW+0LKb9TcHEYDGVbJs73uqW1koncXNa12aTNmIIY0WJt1W9gUp/DODyVRqJKJj5DRHDjmJINOf3CL2Pr3QVM3GboauGhkwWtGJzSRsZTdJFctkZK9r82bLa0MgIvcEc7gpxli2LYfWwNoi+Gi6Fz5KiOidVlsl+qHsYcwZa5uAdtxbWyouFsLo6mGpZHPLUxSNkZNPUSSvBax7Gi7iTYNkfYbdYnfVbcX4eocVqmVM5qoqhsZiMtNUyQOcy98riwi4v27XNrXQdbd4QKWks2ofDUSyujEXRSNjiIMDJXObI9wu3ri1wDqBbcq9q+JYYuF4Mdgp5JaSWJsxa5zY3NaRcXBOpvYWFySdLrF3B+DBrRBTyUzmFpY+mnfE5mWMRgNLSCBkaBbbQHfVSMR4bw6vw+hop2Ttp6J7XwCKokjLXNFmnM0gm1+d9dd0EODiyJ0DnVNBVU0zJ6WnfDJlzMfPkyg2NtM4v6itWN4rXux2pw+hqY6KGjo2Vk8xpjO9+dz2taxgPLo3E6E6gCyku4Rwp9XFUyNq3yxvik69XKQ98Zux7hms5w7TfYdgUvF8AocVqIqifxiKqiaWNnpqh8EmUm5aXMIJFxexQdepOOmDDemlgdWilpxPX1NK3JHE3pHsLgyQh97xvJbYkZTqdL7p+O6WCMTzUFW2lmdLHSSgsPjL2Oy5QM1wXHyb2BA1spp4LwPo44200rIms6N7G1EgEzc5faXrftOs5x6175nX3K14hwZhs1NVimjLZpWyiMTSSSRQukOZxazMA251u2x7CEFXiHHniNZJ49RS0cNGZ21cby17nFsUcjchDrWPSAa29ytcL4upsRwbFa6Gmle7Dg4yRRPZJnszP1HNNjcab7ghRcH4Go4YK36YPj09XLJI8mSQhofGyMtBc4uOkY1JuDtbRdhwrCabDIpmQGeQzOzyPnmfK5xsBu4k2sALIOtVHhGweEVrslQ+Olc/M5gBD42xl5kbrq3M0x+13aqBiXhEb9GVVRh0F6qmZO4xFzJWPLIHSt67XWtprbW4I7Cr+k4I4epYujhw5oZ4m6gIL3G8Lnl5bqf9xJvv3raeEcJfA+KojqKkPDw509TJI4h8ZjcMxde2Ukfjvqgqm+EGgbiZoZaeQTMd0MmWRhLZej6QjLfNl/dzWtfu1RvHgdR+M/QleI2wQ1UozxXjjlcRGSM2pNiSBsPgrWLhLCo5+lDaok6uY6qkLHuydHnc3NYuy6XOvPfVVWP8DtxKopmU1QymomQwU72DpM5ZE/MASHhrtNBnBtqdb2QQMS8JNM6kxAYXC59RC2QwkuY/pDHIGuBaHXbe5y5rXA5KdW+ECkoXup6yilgxBsz4XU8s0TQMsbJC7OXZT1ZWWF73PcSrb6oYRmnvFOY5c94TUSdGzO4Pdlbms27hfT/tbK3hfDKyplqXxzxVUspldNBUPifcxtjOrSCAWsYCNuqDvqgrKDjimrqqFsGH1nick0EHjTsjQ18sTZGAtvm2eAdNCfh25VEPDmFwNyxUxa3p4qi3SOPXjY1jDvyaxotztqrdAREQEREBERAXTfDB5ucY9mP5rF3JdN8MHm5xj2Y/msQeZRsiDZEBERAREQEREBERAREQEREBERAREQEREBERAREQEREHdPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEEOXFKGKd0ElVC2Zu7C7rDbl/8AuHxUjp4cmfpY8u98wt/mh+Cq6zhzDaytlq5onGeXR7g8i4yFn9j8QDyWNXwzhtVS01PJE4R08TYo8rrWDSC09hItz7T2lBbeMQ9b9rH1b36w0tusJKymjAL54mguawXeN3aAesqjfwZgzjGRA9pjY5jcshFg4uJ056uvr2N7AsncH4S5jGdE8BoY02dbMGm4B99tuxBduq6dsb5HTxBjG53Oziwb2nu71jFW00sedk8Zb3m1tbag7a6KspOGMMpYZI44nESRyRPJdYlr7ZtvZCVPDVHUvL6iSolkLcpe59ydd9vdbbuVqxX5o4rVlXTvPUmjPLyuev5FZ9NFkD+kZkIuHZhYhUJ4QwnOHCKSwfnyl5IvcnY95ut7uG6F8NJE/pnR0wcGgv8AKzG5v+Sm0U/1k4rCbEaOESGSojHRhhdZ1yMxs3btOg7UbiNG5sbm1UBbJqw5x1tCf7An3FV0HDVBTxTRwdLGJOi1DtW9G7M22n+7XW/wUeXg3CpZHPeJy4uD7mS9nAEX/En1qiXYGyxuzZZGHL5Vjt61wJ4jJ0YlZ0n+3ML/AA9xVZRcPUFFBLDTseyGWEwSMzaObdx//wBu+Kxo+G8PpKplSxj3VDZHy9I91yXPtmP4BBcoiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAum+GDzc4x7MfzWLuS6b4YPNzjHsx/NYg8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO6eBvzj4X7M3ynL0wvM/gb84+F+zN8py9MIOqYpVcQN4rp4aFkhwjPEJ3dADa972JOo2ueVuX73ZK90zaSU0rc0wHVH5d64lraeKuho5JQ2oma5zGdoG/wDncewrdNIyGJ8srg2NjS5zjyA3KCgZX402Oxw/OQHWc4i5sere1tSOVhbfuWNLiuLz1DsuHt6IStjNzawtdx77XtfbRXXj1J0TJDUxBjwC0l4F7i4/AhaIcaw6bo+jq4z0gJbe40ABO+2hBRCvmqsajqHGKl6VmZ12usAwfu2O7hvf3LiWvx3oCWYdGJHMJAzZsrrO03F9QDy0Nt1dmrpg5rTPEHObnAzi5b2ju71jLXUsJcJKiJrm2u0vF9dRogr2VuKGkzOomtm6fIG6kZLXzHs5jny92NRX4qKWCSnw0Olfnzse+2Wx6vxGvutzU6PFKF5kAqogYzZwc7LY2B59xHxW6Srpo2Z5J4mMsDmc8AWOxRKm8bxxrJR4nG9zHPynyc9nWaLX2I1usPpXFjVugZh7Hlj2tebkDKRv7/wVu7EqJrspqY79KIdD+/a+X12WDMXoHxwvZVRubMWBmXU9bybjlfvRCJLW4rHQxvGHtkqXA3Y11gDdtvwLvh3rFlZi3S1HS0YDI435Mov0jgW5SNefW05W3Vg/E6FjA91ZThp1B6QWte1/VfRZCvpHOLRVQFzSGkCQXBPL1oK59bippJHNowJ2FltLh93HNYXv5IB9/ctJr8dLyW4dEADJ1S697C7db8zp778lcitpTGx4qYSx7srXZxZx7AeZWPj9Gbf+VBqMw/aDUXtf46IKT6Qx4SyH6OY5hDMovoP9zu3TTq796tsKnrpmvNfTNgO7Q11+ZFvgAff3LOXEaSKNkjp2OY9/Rgs693WvbS/IFZHEKMC5q6cDXXpBy3RKSiizV9LDSeMuma6C9g9gL7m9tLXvquDiVCC0GrgBcLgGQDs/UPiEEtFpFVTl7mCeIvaC4tzi4ANifUsJMQpIyQ+phDg4MIzi9zsLdpQSUUL6WoemMRqYw8F7SDyLbZr+rMPisjiVEJGsNXBmcC4DONgAf7EFBLRR2VtK9pcyphc0bkPBA/y4WLMQo3xyPbVQlkds7s4s2+10EpFqNTAGZzNGGXDcxcLXOwWr6Rotf/Mp9P8A9Rv59x+CCUihjFKEzmEVUXSBodYutob2177H4KVFLHNGJIntex2zmm4PvQZIiICIiAiIgLpvhg83OMezH81i7kum+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDungb84+F+zN8py9MLzP4G/OPhfszfKcvTCCpqsCgqMS8dfPUNlzMcA0tsMpBAGlwNNr8z2lWNTBHVQOhnbnifo5p2I7D3LW6vpm4iyhMzfG3RmURc8gIBJ7NSPX7imJdP4jL4pm6e3Vy5b78s2l/WghDh7DQ5rmwuGV4kaBI6zSNBYX0FgBbsCw+rOFF5cacl1iLmRx0PvUI1PEjXZY6OJ7GhxD5C0OfocoNnWvq29uYPJTI6jGvE6h8tJCJwxnQsbY9Y+Ve7tufL3ohIlwShljYxzH5GRCFrRI4WaOQ109fPRYy4FRTVMs0zHve8m13kBl2BhtbtAUepmxeWhlaynkhqOkDGPi6MnLc3fZxIta2m9/iotTXcQQNleaNhijc3KWgPc8He7QRseyyCxbw9honZN4veVjg4OL3E3Gx3Wb8EoHmPNE4iONsTRndYNbtpf8VAlrsdZCD4hG57tQWgEC77AEZxrl1voP7Iysx+SRuWhgbGXPBc/QgDyTbNrr6r9gQTnYFh7qd0LoXOjMnSWL3aOsRprpoVrbw7hrXFzYHAkMH+o7Zvk8+SiyT8RCHMylpzIGg5LjV2bUXzaC3rPrWuWq4lMByUNMJHB4ADgLdUZTcu5uO1uSCf9XsN6Rr+gN2tyDrusB8e4JJw9hkmTPTA5XF46x3IA7ewWUPxniJrnkUcLwQ0tBLQAeY8r8e61tbrI1PEXTPZ4lSmNuaz7+Va9tM2l9B3XQSarh+inp4YA18cMbmnK1x6wGXqnu6jfgtH1Uwwyhzo3GIBwEWY5QXWu71mwW+qqMXFVIylpIjCxzbPeR1xzt1tPWR8VGkfjxo4JGRt6fNIZY7NboHXYBqQLgZd/3r8kE6TBKF9IaYxOEJcHFoe4XIaGjn2Af33WiHhvDo3QudHJJJEWua50jt2iwNr22A+CiCo4kY+xpYHhgkaDcWkItkcesLX1Og5203TxriQPYRQwOa5gLgXAZXa3A62vL/DoFm7BqJ1EaQxu8WuCI8xsCDe60xcOYXE4mOmtcWPXdqL37e3VQRVcSF7R4nCGucC53V6oyi9utr1sw17QuDPxK7KBSwtIuPKaAdBa5ue/YIJ0HD1HDNM9plLJY5I3Rl5IOcguN97nKFsGBUAe1wifma/pM3SOuTpvrrsFHpanHX1QFRRQR0+bU5gXFuYD/dobEnntbvW2mqcWdVZZ6NghL3WdcCzQHWv1jqSGfE9iDObAMOmllkkp7vlvnOc63Nzpf/NFqdw1hbg4OgeQ5oY4dK6xAtvr/wAR8Ao8U/ET44pH0tMx4tnivvrrrm00sea1Mq+Jgwl1BTl5PklwAbtsc2t9fV2nZBYP4ew58skjon55C4uPSu1vvzW84RR9FLHkfaUNDz0jruAJOpv2k+tR3PxiTC5x0ccVddvRFtstjlJvcnbrD3aKPSS48DI+eFljFK9jDl0fmBY0kHkLjvtuiUyTA6CSB8UkJex0vTEOeT1rW7ewkWWkcN0HSvL2vdGWhjYy45WAMyae5aKao4hMmWakpxGHN65Iu5tiToHaG9hzt3rGbEMcdiE8NJQxOhY8ASSAtFiTsb9bQA++2u6ISn8NYU8NzUoOUNaOsdhtzVpTQR00XRwtyszOda99XEk/iSqJlXxE/Legp4i4gauDsgvYk2cLkDWw3vvpY8Pq+IwG5aClJcHk9fyTrlHla8jfvtpug7EioY6nHzUubJR0wha9oDwfKbbU2zaa/DvSufjwfMKSOEsDgWF1rkZ9Re9gMottfVEr5F181HERa4tpaUWLsocNSBly/v6Xu7TlbvWHjXERlLjRRNYJLBoLT1LeUetvrtpe26DsaLrr6viQNblw+lJc1xIz+SbnK3yteRvpvZXlIZnU7fGmtE1yDl2Ouh3O41Qbl03wwebnGPZj+axdyXTfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB3TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphBBmwmhnxFlfLTMdWMaGtlN7gA3A+Kk1YmMDhTFrZTaxdsNdfwutqIOvtZj4c1z3QOdkaHZdBe+th29nd3o2PiCOSO0sD2ZgHXA8m2vZrf8B2rsCIKaQY6KOnETqR1TmtKXggW01FuzUWWTGYy3D4gH0xq83Xz3yhtuVtSdB8SrdEHX3N4hdT/AOpAJHB46oAtp1Tz1v8A9LEM4jGd5fS5jlbktpbXMR37Wvy3XYkQVdH9LCGZtWYDM5hMbmDqtdc2BG9rZT8e5RaUcQeNQuqTRiIkdIGXNrE3tftGvrtyV8iClm+nHOkMXi7GgvDRa5cLdUrQ36xlji40jSBcNaL63Gl/Zv2a9y7CiCjq4MYdUxvp3sFgzPd3UIscwA3vexv2BYMHEIja55pS7W7bW5i2vqvdX6IKWkbjjKWcTup3zNYzos2ge4DrXI7deWl1re3iHLLkfRlwc4MDm2BFwGk+oXPrFlfIgoAOIyHnNRBwAyixsTcX77Wv7+5c0EeOiqj8aki8WEjnGwGcsN7A8ri4vbsFuavkQdecOJetY0H7wbYHXTqk/j+HessnEAqH5ZKcxlzrFwGgt1VfogrZXYmKSERMiNQHBshcdCLauCjRMxwSOMr4DlgeG20aZLjLfmrtEFHhrMbZV2q3wmmJcbnV9raXtpvbbv7lpgbj0LXNDI39TeSQOJflGoNtATfS2n4DsSIOsSQcRkSO6SK7owA1rgLP6tzttofipkseMllO1kkdw+QyE21F3ZR6rZduxXaIOu34l6Nv/wApnya6bOvy11Hw071vrIMWeKUxyjpA13SFrg1odmaRccxlDh7/AHq7RBQtbxBlfd9KCM+UBt77ZefZf39y2ULcb8YtVvgEJjJJABLXn4aDT8e5XSIOvSs4ikbIM9LHmaSMguWnIbAE9jtL22t3rP8A+0Of/wDC5c7LC37ttb673/8ASvkQdeYOI3XDnUjBY2NrnyTb35rX7tiruk6boGipt0o0JGzu9bkQF03wwebnGPZj+axdyXTfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB3TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphB1nFGcStxOokw98L6MA9FG/KCTkvrz8puXfZ5PJbKeTiVz4jNDRNYXRl7QNQ23XHlb32/7VrVYpR0s7YaidrJXEANOh1sAfVcgX7SBupU0scETpJXhjG7uOwQdYq3cTw1Nc+jjZOzpB0LZiwNy3N7WNzpbcj1czNxeXG5JKdmGQNZ0RD53vc0NkFgCxu5vqTrbVo1sVYNxbD3BxbW05DQHE9INAdAfxWM2L0cQhcZczJQS17AXNADg03I21cAgqMPl4njhrG1lPTyOZG407g4Xe++gNiAOf4a7rQyo4ubB16OmdO5uYWLS1pyeSeuD5fZfRX30xh3OtgFs1+uNLb/AAWcGJ0VRIY4amNz7E5QdbDnb3H4IOvNqeK5pG2paeMMlYHAgAObku7XMdMx3A9V9SsjUcX+LxOFHQdK64cwnyew+Xse7nbt07AzEqJ8bpGVMRY0Ek5tgLfmPiFqdjeGt3rYLWzF2bQC17k7BBCqzjsGEzy0rYqnEnPIZE6zYw0EgEa31FiQSd1FmquKi9wgoaMDUAyOFtA3XR19Tmt3Wurh+MYewuDquK7XBp617Emw/ujMYw983Rsq4i67Ro7QkkgD16f27UFDE/i2SrDpIaWGK7XFoIcCMhu3e/lEC/dfZbcNn4pbk+kKalMcd8+SxfILttbrAA2zHbcW2V5LilDE/LJVwtd1jYvH7psfgdEbidGWwuM7Gib/AE82mbW2nvQV2KzcQMqyMOpqSSm6RlnPPWyEHNfUbEfA7aKHLPxcyQtjpcOkjblGe5BdfUm2bQC9rX5E9gV9LidFFl6WrhZmF23eBcWBv8CCtMeN4bIXBtZDo4MuXWuSARbt0KCjqJuLwYzFTUbi3K4htgHXb1gbu3BOlt7akc5gl4lGHTuNPQurbjo2ahti5wNzm5DK7v1CsxjGHFod47BlIBBzjX/LFbaSvpaxzm0tRHKWgEhhvYHb+4+KCoj+sD8PmNQImVF2FrYLZrZ7vALja+XQX58+zUZuJGuDI6aIxXYA6UtL7W1JIcBe+5A05B267KiDqUU/F7ImCSlo3vyuzkOB1DBa3WG7r/8ApTqufiEiNtLS0zXGBrnveQ5rZP3m2zAnnqr9EHWJfrFJTSF7Xsk8aNm05iBEXRECxcSCM9jrrblyWh8/GAe4tpKMhpe0C4s4Xbld5V/92mm/bZduRB1983ETKKEimpZKk1DA8A2aIiwFx1duHXHuvZRpJ+KZWxmOmp4HBpcWuDXAuAdZpOfmcu3x5LtKIKfE58ZM1O3DaaLopMvSPmteMdbNcZhc+Ta3f3KXg7q51BGcVbE2r/fEQs33an+6mogIiICIiAiIgIiIC6b4YPNzjHsx/NYu5Lpvhg83OMezH81iDzKNkQbIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIg7p4G/OPhfszfKcvTC8z+Bvzj4X7M3ynL0wgi/R9J40ak08bpy/pOkcLuDsuW4J20uNO09pUiWNkrMsjQ5twbHuN1V1DcX+sMMkJpzhIhLXsLiH5y4dbbWwBttuVPr2zuo5RSECoAvHc2BcNQD3HZBE+gsMylviceU2u3WxtsLdnO3bqthwmiLIWGAFkIIYC42FyCb666gHXmFVwU/EMT2xuqYJIy6xe5t3Zdr+uwv6ye5c07eIWwRRPdT3tGHSGxdp5fdfs/FELJuDYe1rw2mYA4kmxPPe3YkGEUEDs0NO1h6PortJHV7N/X8T2qvjlx2SjqgI4W1TX5Yy4Wad9u0eT+K5kOPkvytgAtlblIuDYXdrvrfTTTmESnswehYx7WwDK9mRwLibjTtPcPgOxDg2HloaaWMtAAsewai/bqVXVDeIHPzwmnbldaxO7e23auIYuIWOeHTUzgc7gSL65iWj1WsPV3ohYfQmHZcvikeXK1uXWxDfJ07raLOHCKCA3ipY2m4PPkbj4KPMMYEMTYjAZD0ge88teobeq11p6LG3R1IdLEJC2MREaC9+sfgiU12EUD3SOdTMcZL5ibm9zc+rXVcyYTRSBgdESGNyt67tBfN273sb73UKBmOtqIhLJTPhEhDurqWaWPrIze+3etJpcebUTOZVQujObomu5a2aTprpqe9ELSbCaGbJ0tNG4sa1rTzAbew/E/FYHBcPLmu8VZdpaW6nQgWFuzQAd9tVBY3H2u6Mvpywyj9rzEdzfTtsW/ApTS45JT1TZo2NqGlgY5oAbe5zEX3GXLvzvr2EpYwHDOr/4jCW+SSSba3PPnc37VMpqOnpjeCJrDYN07AAP7NHwVeBjL6doLoIpelAcQL/s8ovbvzX91lFZ9ZMv7Q0eax0aNAbaHU7badvcg7Cio6YY86VpndTNYCwkAXuNMwv6r+/uV4gIiICIiAiIgIiICIiAiIgIiICIiAum+GDzc4x7MfzWLuS6b4YPNzjHsx/NYg8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO6eBvzj4X7M3ynL0wvM/gb84+F+zN8py9MIK5+NUDMdjwd04GIPhM4jsfIBAvfbmp08zIInSSuysbubXWuoo6apfG+ogikfGQ5jntBLSDcEdmoCzqYI6mF0Uzc0brXF7bG6Cv+n8Ls4isjOUAnKCbA7bD3evRbHYzQNflNQM3W0yn93fktjcLoGtc1tJCA4ZSAwDTs/BPouhyub4pBZ17jIOe6CM3iDDnOIbUAnLnb/wAha9x7u1cHiLCgGEVbXNd+81pIF72ubaXym3byUn6Jw/q/+HBoLDqDbayfRVBkDBSQ5RYgZBpa9vhc29aDTU45QU9+km06JszSASHNdexHw/Edqxk4gw6N0bTOS95sGhhuN76W5EWPYpcmHUcg/aUsLuoI9WA9UG4HqBWBwqgMpkNHB0hJcXZBe53PrKDD6Zw/xWOp8aj6CR2Rr9bErluMUDnBonAJF9WuHb2j/i74FZuwuhdDHE6khMUZu1pYLD/LD4BHYVQuc5zqSElzs56u5119ep+KDT9O4cXZRUtz2JLSCCADY6HvXMeN4dJIGMqmF5c1uUA3u7bksnYPQGIxilia3J0Ys3ZvYFlT4VQ07GtjpoxlDRci50Fgb9qDiuxajophFUS5ZCA7KGkm17X07ytH0/h+aMdMRnc5o6p3aLkfDa26kzYXRTODpqWKRwaGZni5sOV0OGUJkbIaSDO03ByDQ7INH07h3KpBGXPcNO3/AH7uwrfLilHFJ0ck7Q+4BGptcX17NDuosvD2GydPenA6Zoa62lmjkOxTZKCklfnkp4nP6vWLQTpe3wufigjS43QxwRTGVxhlvlcGE7EA6b8wjsdw1r3NNUzM0EkWOwNidlKNDSljWGniyNvYZRYXt+QWBw2iLi40sJJaWnqDY7hBHkxqkjrKinkLmmAgPcSLXLQ7a99iOS4dj+GN3qm2AuXZTYbWvp/yClvoKR8r5H08bnvILiW7m1r/AAAC1uwmgcSTRwXIAJyDYbINEWPYfIJbTgdHIIiLEkuO1rb3sbepHY/hbbZq2IAguBN7EDmO0cvXpupAwugEokFHAHh2fMGDyu31rTFgWGxve4UkRz6EOFwB2AdmuyCfBMyeJskTszHbG1u7ZZrGNjY25Y2hrbk2A5k3P4rJAREQEREBERAREQEREBdN8MHm5xj2Y/msXcl03wwebnGPZj+axB5lGyINkQEREBERAREQEREBERAREQEREBERAREQEREBERAREQd08DfnHwv2ZvlOXpheZ/A35x8L9mb5Tl6YQdYqMPxocSmsiqHPoDIz9j05ADdA45bW7dFf4j4x4nJ4n/r6ZdQOYvvcbXVTXcVYdQ4hNR1JlZJCLyOy9UCwd2/7ST6mlbYuJsJlexsdS5xe5jW2hfYl4u3W3xPLnZBGFNxIWSZq6lDsoyZWDytL3u3a1/f3La6DHjmIqoB5dm6WN/J1y8v/AKkrifirDqWapjrTLTNgeGF8jRZ1yRcAEutcWvZS8VxyhwwUZqpLCrkEcVrakjQ+q9h63BBXNo+IQ5pdWU5zMs8XPlZbXGmgvrohpOJDEwur6cStIuGtAadHZv3e9tvVr3yaHijCqyKodHUFrqdjpJWOaczGg6k2v3HTtC0/XHBhH0rqh7YbBwkdE4Ag2ykaag35e+yIZ1lDjEs1O+KtjYGxsErQSA5+ziO6xJHeAtbaTiHJC59dAZm6OAADTruRl109X91tHFmEBjnSVD4w0vBzxPsMup1ta1tu3kpVBjlFiEwZQuknFg5zxGQ1oIJBJNr3sRpfXdEq6qZxIyJz45YXPc59o2ZeqP3NS34/h2qZUQ4y6vldDUwspMzCxmmawBzA9XmbLAcVYMaY1ArR0QsCejdpckbWvuCo9bxngtLC+Txl0oYbOEbDcG1wNba6Wt2oNjIeIMsTX1EBF7vcHC+7dB1LHZw5bjsUZ8PE8YjAnp5JXNsXtADWuvuQRtY8tdB75TeLcHM74XVD2yteYwwxOzOIANgAL87WOtwVNqsbw6looauoqQynlj6Zjy02LbA327Df1X7CiGvDI8WilBxCaKdjtLMAGXQWO2981/WLKubQ8RSSEy10TA4x6sOwDyXWGXexAvsQNQpTeLMFcWDx0DO4MaXRuAccuawJHYRfsuBuVg7i/BvFnTx1MkrRG6QCOF5Lg3cDTfu9+2qDUKbiKNs7/GoHHruaxpvc6WGrdBv7zzWeHtxzxxgq3ZYHsuTdpLDlIsdN72Omm6lUXEmFVtQIKWq6WUuLLNjda4BNr2tsCR220XFJxJhdZPDFSVPTOmcWMLGOILhe4200BPZb1hEtPQcQOeC6qpmjVxDRoDl0aLt2zbnmLbFZz0eL/SE0tPWtZTvfHZh1ysF81gQbHa3LfuXI4loGwsmqTLTRSM6SN0jb52adfq3sDcDrWNyBZaXcX4Mw1HSVJYKeRschcw9VxAIFrXvra1r3BQZ0tLjnQPFZWQOe6FzBkGUB5vZ219NP/qtbaHG4ogKeqiYRFaz3uku/NuS4E2sT77clMHEOGGAzNqS6MTmmuI3H9oASRttYE3271EfxdhTYmSZqhzHxPlDmwOIIba4va19besEbohploeI5AW+PQBrspPI3sL2IbpqD8T7pEsWPNa54nhs1xsxliXty97dDf3evZbJuJaCCuqKWbpmPhlbCT0ZIc5zczQ0DU3F9huClbxPhdDUzw1Uz4+hDc7zG7LdxIABtqbjleyDTQQ8QuMT6ypga39m50YaL8s4Jt2X259y7Aqml4jwqrrW0lPVtfUuc5gYGuvdoueXr9dlgeJsJbCJX1JYwkgZong6ODdiL7kfFErlF11vGGEubOWvnd0Ojg2Fxuetpp3NJ15albncVYWzKZJZWMJsZDE7I06butbmPVzsgvEVRS8R4bWRyOo5zNkjdKRlLAQ22bV1hcXG50uow4uwlkOarmfSShrXOgmYekYHeTcC+9x8RfVB2BFRScWYPE8iSqLWhpcHmNwDgHZTbTUZiBcaXICuoJWTwRzQuDo5Gh7XDmCLgoM0REBERAXTfDB5ucY9mP5rF3JdN8MHm5xj2Y/msQeZRsiDZEBERAREQEREBERAREQEREBERAREQEREBERAREQEREHdPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEEeahpJ3udNSwSOd5RfGCToW6+4keolYsw6iZlyUlO3La1owLW2+Ciy47QxVs9LJIWSw+XcWAFmm/eOsPgVshxijmmMTHvzi5IMbhYAE327j8EGb8Jw6R0rpKClcZTmkLomnOe06arN2HUbppJX0sLpJGhji5gN26aerQadwUb6ewy+Xxtua2YtsbgXttZZDGsPJYBUt65Ab1TrcX7OzU9nNBubhlA0SBtFTASNyvtE3rDsOmq1jBcLDHMGHUYY4AOAgbYgbcuS0t4gw10zIxUC7/ACTY6m9rdt7rEcR4WWBwqmnUAhoJy3IFzbYAuAvsgmuw2hcCHUdMQ69wYm6335LZT0lNTC1PBFEMob1GBug2GnJRH43QNjhkM46KVr3NeASLNIDvhf8AArU7iHDWxMe6cgvOUMyHNfTS3qIPqQbRgeEhthhlFbLlt0Ddr3tttdZvwfDJL9Jh1G67i85oWm5JuTtvdYMxvDn08k4qmCKM5XuNxlNibH4H4WWIx/DHEhlWx5HJgLj+A7dPXpugkfRlB0vS+JU3S5i/P0Tb5jub2371l9H0ZhZCaWAxMvlYWAtbcFpsOWhI9RIUakxzDqp8bIKlrpH6BtjcHTfs1IHr0UkV1MaeWdsoMUfluAJtoD/Yj4oMBhdAMlqKmGTVv7JvV8nbT/i3+UdixOEYaYOhOH0hhtbJ0Lcu99rLOXEqOKmiqJKhjYJGh7HnYjTX8QtbcXonsndHNn6EEvAaQRbca8xcXHK6DdDh9HBIXw0lPG8uz5mRgHNYi/rsT8SuIMPoqd7XQUlPE5pzAsjAINg2+g7AB6gog4gw0l//AJHVaxshdkdaxvbl3X9Wq4j4hwx7nt8ZDXNc5li06loubduhQSDhGGkknD6QkkuP7FupO525ocIw0sLDh9IWmwI6FtjbbkuanFKWnpYah8hMcxaGZWkk3IAPcNRutMmOUTaOSpjk6aON/RvyW6p7ybAeu6CS3D6JjXNbSU4a55kIEYsXEWLvXbS6wGE4cGuaKCkDXDK4dC3Udh02WtmNYe8VBFSy8AJlHNov/wDT4hYnHaAFg6UkOkMdw0kAgE6nlo0+rS6CTJh1FJUNqJKOnfO05hI6MFwO179ugWM2F4fM+V81DSyPlt0jnRNJfba+mtlrqMaw+nmdFPVMZICAQQdz/wCxb16LVNxBhsV89SAWluYFpBaCQLm40Gu6CVHhlBFN0sVFTMluXZ2xNBuRYm9ua1DBMKDWtGGUQa1uQAQNsG3vbba/JcvxigbHBI6obkmDjGbE5su4230Oi0zcQ4XFG57qtmgvYA3Ol9PcR8QEGwYHhIIIwyiuDcHoG6aW7OxbRheHhznChpQ51sx6Jtzba+nKw+C0fT2GZ8njbM4Ni2xuDubi2lufZzWWIY1Q4fUiGqmEb8gkN9g3MG3P4+4HsQbRheHiF0IoaUROa5jmdE3KWm1wRbY2F/UFj9D4blI+j6Sxbkt0Ldrg222uAfcFqGOUFj+1IIkMYa5pBLgbGwOq1N4kwy5zzmOzc3XaRpp+ofj2IJZwjDTmvQUhzOzH9i3U9u2+pUqGKOGMRwsbGwbNaLAKG7F6IRCTprsMvQ3APlWva2507O1a58doKeZrJpsrXRCYSWJblJsDdBZooEGL0NRK6OGoDpGhxc0NN25d76aWvb16KOziLDXutHPnOcR9Vp0JBOvZsd+YIQW6KsOPYWHlvjkZcLkhtztvt2c+waqzQF03wwebnGPZj+axdyXTfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB3TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphBQV1ZhLcSqIq6kaHsY4mZ8YIcMrXOtzOgbf2R3X1nFMEiLx0JjY2Np6QQkAtdmAsbX2ufUVliOLYVDiMlPU0fSTueyJzuia65IuL87Dv9yiy8QYRlfGcPJJMZex0bLWed9zci503/FEJFLVYGJDGylawsd0OYxXBvl59hLwLlZUlVgMssbIIIy+QkN/YEX1y3uR26X5rVUYtgraanq5aDN4yH2vC3N1dCDfvsFqqMbwcVMbn0U3jFO4BgDAA1zhfkbb/AI7IN5qeHmPbGIIi4FrGhsB3cMzW7c1ga/A4WxCShbHFLTsqL9CCA1zhYED/AJAd11wMdwkdJEcOkD7OkkZ0LdxcOub2PP1qwxHEMOopIYZIGyPlDWRtYxpzDWwF+Qy+7RBEfiuAhnRvjBbEJG5TTuOQXs/l26FcVlTg9NiD46nD2gxWd0vRAjRo1HqDgO73i+Bx2gfS1tVBQB7Y2xvdmDQ5/SOLdRrbyee/qsVxU49hWeR1Th8pec0by6FrrlliWk35XHdr60GwYngIpnxRwNfE57SYxAbOdo6+otpobrZDUYLLIIoKRri9utoMoAsXC9wLeRf4FcPxXC2UbZZKEsY2oEAYY2Xa+wIOhtYDmFEp+JsKZDFmoXRO6xDY42m1jY9h2dva2pG6DfDi3D8AD2RsieG57dAQW6jTbe4Bt70mxbB6eN0bKUlksrWyhsVgCRo49trDbuWt2NYO0NY7DXNDskbQYGWId1hsTpqD79t1sPEGG5mNdRS53FxaOiab5Rve/wAP+kG+TEcDDI6V7IyyN2RkZhOVp1YbaWA3HZrbmuKiuwugooJzR5YaqJ0mkY2IabO7z1R67KPW4lh9EKd7cNgMb4TMBZrXiwLgALdx1uAO1cx8R4U6Mxx0snRMcIvIYG3dqBvaxAvfbTVBjNieBeLteaMPidF0t2waWZYAesE2Ck1FRgVFVdDLBFHKH5ABCdXFoJ2H+0i6jUuOYbUCJsWHHPNkDxkZZoL2s1N+RI030GlrLGTHMIhqJzPQu6YySF7mxh9zFoDf1AWG4/FBIfimBPiDJWgsjyyhj4XdUG2V1raDb3rF2KYEC2kbC09LISYxERZwuCSPw96jVOP4cIpJIsL6WQGIjMxrbl2jbntAvyOg71vmx3B4Zc5pM0pL2ksjaSHN1IvffVBnFiuA9cRRsBmuHBkJu62puAN/ySnq8DdBLJDSRtEDQ6RphDeja4C57NnXPcsxW0f0ZHV0eHwvcJjFHHlFx1y2/VBIva+yjjiDDImVGbD5WOALahoibycGkHXUXdb48kGuDEMCnq5ZpqZ4qpnMa5kkeY5tgNLjyi4esHuW5tZw/PF08lKzPIGFzHQEu65uARbt1/FZSY9hYkLzSPcWOLc+RhsfK7dzb133stFNj2EuFO6OgazpQTERGNGg317O2wvqgmSV2BCnbUSMjEUD+ja90Rs0m+2nPXX81pjrMBqJGCOja973CIfsLaZg3UkbAuGneo8OO4RDTPliw+fxeod0khcwG7ibAWJ7vUPiplfi9FSuv4gZCyPxlhaxo1sO3UEkge9AkrcBZUSNMUZlMnRutASS91xbbc9Ye4rmtxDBYxB4zE2Rjo2Ste6IusNm7i99f7qPUcQ4ayqa3xFzpmyMY4ljbsLjqb3Ox3/7W2bGcIdh8NZNSXjkieGNfE3MWscAW29ZBt3INgqcFZC2ZlKwsbMY7iDVrsucmxF9bDbuUTx7hyONxNLGwXa1oMFs2Y3FtOZ/HdSm43Rv8ZDaQhtM0yy5w0ZbWDtBfYE687aKLHj2HyvjiqcLe2fPlazomu6w0tc2G9x7u9BvZjOBuGV0Qa5khfkMBOVzR5Wg3AF79i24xVYPQvjiraaNwLGRk9FdrGXJaD3XadO5RKbH8JkiZIKG08jWfs2sYSc99Ab2I1N/XrrdbxjGGSwsmbSZ2RSNhBLGksBvYjew6vO1t9kGU+IYVBFHOykzxVQkDpBGALZgHB1+0n3+si6KowFsAnjgiDG1HRhwhP8AqEb3t+Peo8WO4ZJFE04c53Rloja2NhDS89UC5FiRqezY66LfRYxhdZM2CGjfZ0pN3QtDQ4EDN67kC+6DmjqMFqJ4IoaRn7VrmMPQWbYAgjbsuO+y7AutQ8Q4Qx7xDAWSCbo9GNGZ2Um4N7WsN+8XVthGJsxJkjmRPjyOI6xBzDMQCCDzylBPXTfDB5ucY9mP5rF3JdN8MHm5xj2Y/msRLzKNkQbIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIg7p4G/OPhfszfKcvTC8z+Bvzj4X7M3ynL0wgoqvEmUmJyxx4bI6V7g0zNaOvZoN+02vZazxI0U3THDasXZntk77Wv/u7lzUYrikOL1ULMPM9Kz/TcGObezGu8rUG5LgLcxrZYyY9iDA/LglQ7KMwIJs4Xtp1b352I27EQzPEBbK1rsNqA0ua0G2uov8A2sPWbI7HZH0dTLHQSsli6I5ZLa5yO/kDf/tScOxOpqql0dRh8lMwPcxrnk9a1rW05i/PlzUBuPYmbvOB1GU5QGXOa9ze+lrAD427UG2biIQdE2Wjlc+TRpbbrdUm41OmhvrosI+IXdE4jDKgFrc1g29gXWAPfqCR2armoxOukpDUxYa6OeKcxAPidI5zMt7tAA3NhrYabrOXGcQc4sp8LkDhI1l5Q8Ai7cxFm7C51200ug4fxGxnSDxCpJbpoNzmA+Avcnlst+I4u6nlpOigMkUrHvcdLgtIGXca6kc9lEfjeJvin6DBpWvY1+UyZrEi2XTLrcnt2Cxq+I6yjNqjCpALeXmcGk2uG+TudrdvxQbajiB7A6NuHy+MWkLGOO5Zz9V/wUf6d/auqWYNNmPRsz5Oubk3HuDfjp3qZRYtXVLyZMJlp7NNnPJJBs42tbbqgb7kJh+MV9TUwwy4XLC1zbulIdl3tzAI9+vdzQa5+JoomPkNFUdE0vDXkAA5OfvG3at9DjfjcoaKCpjH+54G9nG3/wDUg9hsFEdi1eS5s+FSVFi05RC5oa6/kgm+YjfNoNN9QFg/iStNSIYsKkc9oc57AXF2UDQ2yiwJI310OmyDfUcRWp3yxUE7wGOc0kWBINre9SKvGDTVM0JopntY9rOkA6vWbe57hrc8lzVYpVR01HNBQSSmUftYQHZmHTS9raXO9hpuob8dxI0b5G4NM2Usd0bTmd1xa1xl0GpPuIQZQ8QvdT075MOqGvksX9WzWXvYk9l2nXkBfmFh9Zj4tG4YbUmd0Wcty6Ndr1b9ul/UbrcMaxHxh0RwaazHZS/McpABJI6uu1h6+S3YliNbT10IpqZ01M6PMQIn5r2O52A0GliddkGEWNyPpKmQUEzX07WOc0jygd8o3uBf1rTBjs5k6GfDJhNcN6vk3zZHankHB2vZY81xFjWKGfI/B5C1+RzHAuAaCQCHHLuNTt/2pE2LV8dDHMMKe+Ugl8TXkltnNAt1dfKvsNig1RcRZ6djvEKgzGMSFjRp32K2jHo3U75WUkz8tR0Ba0AkHLmuezs9dgtVNjWIvlcyXB52gPtnuQLF1gdvVf3lYUuL1pja8YO+mjc5pkJDri77ONg3/brdBk3H5XTAHDJxFlY5xI6wzd1tbaX9/YtbOJXOcx30bUdG9zmtIGtwbfA8u247VOxHFKumqBHDhs1QwuaOkYdLOB125EEHsuO1Q347iLGm+BVDnBjXdVxIubEjyb6Zhy3v2IJzMWa/D5JzSyMezJeF24DrWJ7Brr2WPYo2H4+aiGZ01DUROiidK7M3Q25DnryPcexaqjG8Tje3Lg0pGY5rZnXbkJFjl0N7A391+UmPFa51FNMcJlEjWscyLObvLiQRqNLWv6ig4pcadVzQsgo5G31k6QWyjIXD8QB71GZj1QYoL4c8TPyfs7dri1xvyAsfiO1SY8Tr5YKiQYe+ENbG5mcEus469W2paNSAb30Ws4zXMeGDDZphcDpAx7Mwte+Ug2vta+nOyDE8SDI97cNq8rSQbtA2IH45r+pb6jGZGUxlZQTlzZshaW3OQC5dp3DQdtlEix3ExFCZcFnL3xuc8AEBrgNtjv8A5dTJsWq2sgEWGTPkkjjfZ2YBhcSHAnKbZdPigjx8QSXcX4bUBrWgkNbdxJLhoOzQH1HktDMb8XqnRxYW5rpJG58rbXva7jp3n8O1STiuISQSSCkdT2mDBmgfKQ2x1yixOoG2mu6jux/FGl18DnORvWAzdZ1wLA22HW/BBMpscNRA+RtBUMDYXSjMBqR+7pzXMmNObSNmbQzB7pWx5XabtDr/AANvWCk2LVkVI6U4XK6TpujEbCSS2183k+7/ALUR+PYiJszcIqDF0bTk6N2bOd9SLAD1XPLdBmOJG5buw6qHlDVo3A7Nxff1aqbh+Luq6lkfiU8TXtDg99ragm34H8O1QJscxNjGvGCykEZiwFxdbMR/tsLWv6ip2H4lVT1fR1WHvp4jmyPLi65BAAIyi1wSd+SC2XTfDB5ucY9mP5rF3JdN8MHm5xj2Y/msRLzKNkQbIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIg7p4G/OPhfszfKcvTC8z+Bvzj4X7M3ynL0wgqayqxQVToqSjYYw8ASvOhaRqbXGxUetqsbDSaWkjJdTNdYkdWUmxaNeV7+7vVu+spmPLH1ELXjdpeARt+Y+KyZUQvtkmjdc2FnDU2v/AG1QUU1Zj5qGRx0MYjbJZ8mhDmi+oGbnp3iy3muxgYfFIcOaap17xtfo3UW19Wb4d6t6iohp4jJUSxxRg2LnuAA96yY9r23Y4OHaDdBStqMZdJOH0rGCOOTo8trSOBbkO+lxm05dq0wVPELHMZNSQPJLgX30GlwbX7Tb3K8iq6aZ+WKeJ7t7NeCdgf7EH3hbI5Y5G5o3tcO0G6CigrccyRxyUDC8uY0yGwAFus4i/I205rGHFMWlpKsjDgKqINyRnYuJNxe+ugBv/wAleT1UFOGmomjiDzlbncBc9gWRljDwwvbnPK+v+aH4IKGOrx8VBjdRQmMvsJCfJbYa2B1sb9l/drrfi2NB4ibhrDPkzW1y+Vbe/ZyXZbjtCxbLG9zg17SWmzgDse9BSGtxoTFrqCLorEhzXXI100vrp6u3uXFNU422mnNTSxmZsMfRhrfKefKv1thcfAkX2V9cdqXHaEFHV4niMGHyzeInpWyFjW2vmFiQQAeZAHvWnx/HiBfDY26gnK7MbZhcakcri/vXYS9ocGlwueV1wyRkjGvY9rmOFw4G4KDrsVdxBma5+HxFrnlpbe1mjZ178+zlfuVxhctXLTg18IinsCQ3bUXtudtvcpT5GR2zva25sLm1z2LAVEJMYEsZMgzMGYdYdo7dwg2osWSMkF2Pa4AluhvqNwsDUQgNJljs52RvWGrtdPXofgg2ouLjtCx6WPpMmdue18t9bdqDNEuO0JcdoQES47QsTIwSBhe3OQSG31IFr/3HxQZIgIOxXAe0uLQ4XGtroOUWEk0Uf+pIxuhdqbaDcrCSqgjbG6SaNrZHBrCXAZidgO0oNyLUyohe2NzJo3NkNmEOBDjqdO3Y/BcMqqeSd8DJ4nTM8uMPBc31jluEG5FrdUQta1zpWBriGtJcLEnYBbLjtGqAiAg7EIgLpvhg83OMezH81i7kum+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDungb84+F+zN8py9MLzP4G/OPhfszfKcvTCDr9fhuFVOITPmqHR1Mt2OAeB+4G217ntPrsozuHsFdSFvjhDOqTIJWgnLoLm3db4q4rcFoa2cy1EOeQkG9zuARt6jb4dgUd/DOFuD/ANg4Z4xE60jtWgAAb/8AEfj2lEI0dDhHidRTw1rWNMhc92dmYOBuTqN+sNfUsqWhw7Dq+cwV746upZmvJIHWBO4uO5SRw7hoqRP0B6QPDwS8nUbLZNgOHzMaySAlrYmwDrnyGm4G/aEFXPgmDTh8hq3XOZxcyYXtcuNrcgCB6g3sWuHCMCMjZ/G3jyGdHI4N1DmkXaQDcm3xHcrmHBKCGWeSOHK+Zr2vNzqHm7vxWp/D2HySiWSOR8gIdmdI43I2O/u9w7EEWLC8KjoIqSOuPRsY9mbpWkuY8gOadNiQBcWPeosGBYRfoPHs87Qx7srma2JaDa1rXBFu3e5Vm3hvDGwiNsBDRe1nkHUg/wDQWbsAw9zMpjfoGtB6R1wG+SBryQVQwLA5i0MrCcudhDZm9YuJBv2m+nuspldTYTU4U2mfWNhpoyX3ZI1pFgTbbSwPusFvPDuHOILonOAfnAc8kA9bbu6ztO9cfVvDA1jWwOAYx0Ys93km5I3/AORQRaDD8Oo8QbJT4g91Q2MR2c9pGQG1jYf8bfHmuJsHwiaV756sPcXSEZpGdQkdYDTle/aFKZw1hjGPayBzM1rlryDptzXE/DdBNJGbPawFxcwONn3BGvxQa5cGw6srKqqFU5z35XSBrmOa3QWNiCNQOd1phwzCamjhp4ah7YekbI1hAbmOTKNHN/4301vqraiwqkogRTRlgLQw2cdQL2/uVGi4dw2KeOZsB6RhDg4uJ1BuPx1QVcmC4Q+ZrpMQnLy9zyS9ou5pJN+rpq7+yziwDCGZbVxcWt6MdePQZQANG66N2Pf2lWYwDDxN0jYSHdKZiM5sX3Jva/aT8Stb+GcKe1jXU1wxuQdc7XJ7e0oIsOBYTFUUlRHUkPac8eWRobIQ4uJsBY78uQssZcGwaStLXVA8Zle+UNztJJcANrcgdB3ndWdRglFUCMSRutGXubZ5Fi8kuP4lcQ4HQwva5kb7ttlvI42sWu7e1rfggrTg2CxAPfO0PicOs5zQ4OALRy/ywtstMfD+CxtDBXuu5mQXlYSbuPdrqSP7aqybw5h4kfK+NzpnvMjn5iCSd9uVtFlHw5hscIiZC5sdgC0PNiACAD2+UUFezA8FfUiRtSSYx0rm9IMpFgCTptoLnnfVbanBcJkdA+eq6jKZkTWukbldG0ggnTXW2qmx4FRQwSx0zXRGQEFwcd7g3+ICNwGjEEUb+lfkiZFmMhBIbe23PU/FBVyYPhJZMH4hIP2jnSDOwEuIcNere4ubernYIeHsFaJQ+reS9jiXOmbdocW3IPLYa99lZDh3D+lke+N7817AvNm5mBjresBcnh7Ds7XiJ7S0WbaR3V62bTXt/CwQaMMocNw6oLKWsAlcG52ue0l4Is2/8tx6iodPw9gxDYo6p8jujMbbyNcbXuSNN+XqVizh2gGYvY9znuLnHORm6xNj3DNb1ALdT4JRU9RFPHG/pYy4hxeSdd7oKiPBcElpmu8cD43RtLXl7L2GUA3tfkBr2kaLKfBcIp3vlkr5Ii+RjrmVuhboLXHePV3Kb9WMLy2MDicjWXLyTZu2vctzcBoWyZwx9y8SG8jrEi1uewsNEFdFw/g46KJtTnLczWNL2F1yDsbXuA69vUbKXiHDtLXyyPnmqes4uDWuADb5b2055Rvfuss6Xh3DaRwdTwFjhoCHm46wd/cAq3RLr/1Toc73dJUdYtOXM2wy7C1lufw9TuZSN6eoHizcsZ6hI6wde5bvcD/CVdIgqsKwGjwycTU2fpAwsLnWuQTfXRWqIgLpvhg83OMezH81i7kum+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDungb84+F+zN8py9MLzP4G/OPhfszfKcvTCAiIgIiICIiDCeaOnhfLO9scTBmc9xsAO0ldSl8I/DUcjm+OPfY2u2F5B/BQvDO+oZwmwQZhE6oaJrf7bG1+69l8MXe6L6Kx6vFOTJM/Hbg5Ou198GTqUjm++/aVw36VL9y78k+0rhv0qX7l35L4EpeHMpXzOFbIWR5bAgX1Og+F7+5dG3QOmrG+9v6/Dxx0rnmdto9+r7l9pXDfpUv3LvyT7SuG/SpfuXfkvi9TT4bZhgqXXMoa4EGwb27LcaXB7tHjjwMpubEm9zptppYLPubS/d79F+8c/wBvv1fYvtK4b9Kl+5d+SfaVw36VL9y78l8YNPhTn2FVK0dUXy/E7KJXxUkZaKOZ8vWIJcLaaWP4n4Ka9CaW07fu9+iJ6TzxG/D36vuX2lcN+lS/cu/JcjwlcNEgeNyjvMD/AMl8BRa9wabxtzj8Kd7ZvCPfq9T4bX0uJ0jKqhnZPA/Z7D/mq0Y1jOH4JTCfE6lkEZNm3uS49gA1K+b+At85OKs63iw6M9wfrt7v+lSeGd9Q7ixrJc3Qtgb0Q5WN7n4/2XGp0ZW2tnSzbhHPx5ulbXTGmjPEcZfQPtK4b9Kl+5d+SfaVw36VL9y78l8CRdnuDTeNucfhze9s/hHv1ffftK4b9Kl+5d+SfaVw36VL9y78l8WwyPDHRx+PTOa/OS6wNstiANOd7H1LllNhnjbmurHmAMuHFtiXa6fgPj3LGehdLEzH7vfo0jpLPMb/ALffq+0faVw36VL9y78k+0rhv0qX7l35L402kwtxt468XvlNvhcW0O/b61y6lwkNePHHhzRoQM1z2bD/AN2TubS/d79DvHUfb79X2T7SuG/SpfuXfkn2lcN+lS/cu/JfFpqfC2xExVcrn2dYFvMXty56fFVavXoLS2+dv6/CtulM9fD36vvv2lcN+lS/cu/JXOAcUYRjznsw2rbJKwXMbmlrrdtjuF5pV3wU+oj4swo0mbpTUNHV/wBpPW91rrPUdBYKYrWpad4jfjt+F8XSuW14i0RtL0qiIvlXeEREBERAXTfDB5ucY9mP5rF3JdN8MHm5xj2Y/msQeZRsiDZEBERAREQEREBERAREQEREC6XWlanzxskDHuAcdkEu6XUUzRgAmRtjoDfdDPECAZGXO2qCVdLqKJY3AEPab7arKN7ZG5mODm7XCCRdLrSiDddLrSiDddLrSiDvXgb84+F+zN8py9MLzF4GPOThXszfKcvTqAiIgIiICIiDRXUkFdSS01XE2WCQZXsdsQujTeCrA3yOcyeujaToxsjSB8Wkr6Ai3xanLh3jHaY/hlkwY8v+dd3zz7J8E9LxD+dn6U+yfBPS8Q/nZ+lfQ0WveOq+pPNl2LB5IfPPsnwT0vEP52fpT7J8E9LxD+dn6V9DRO8dV9SeZ2LB5IfPPsnwT0vEP52fpT7J8E9LxD+dn6V9DRO8dV9SeZ2LB5IfPPsnwT0vEP52fpXI8FGCAgmqxAjszs/Su84lViho5KhzC9rLFwHZcAn3bqldxVEyOXpKWUSxszloNxobOF+0ODh7lpTWay/Gt55qW02lpO1qwtMEwiiwWhbSYdCIoRqeZce0nmVG4k4cw7iKmbFiMRLmaskYbPZ22K0x8UUb3ta2GpsXiPNk0BN7c78isqjiKKmqHxzQnKC9oyvBcMu+YG1r7jU3C88Rnrfrxv1vjv8ANtNsM06vDZ1j7J8E9LxD+dn6U+yfBPS8Q/nZ+ldlj4mp3RBxp5s5ZnyNLSf7/wDr36LfQ49TVtUIIY5wS8szOaAAbE9t9gV6Z1etjjN55sI0+ln4Vh1P7J8E9LxD+dn6U+yfBPS8Q/nZ+lfQ0WXeOq+pPNp2LB5IfPPsnwT0vEP52fpT7J8E9LxD+dn6V9DRO8dV9SeZ2LB5IfPPsnwT0vEP52fpT7J8E9LxD+dn6V9DRO8dV9SeZ2LB5IfPPsnwT0vEP52fpV9wxwXhPDsxnpGSS1JFhNM7M5o7BawHwXZUVb63UZK9W95mP5WppcNJ61axuIiLyvQIiICIiAum+GDzc4x7MfzWLuS6Z4Y/NvjPsx/NYg8zDZFoGy5QbkWlEG5FpRBuRaUQbkutKIN10utKIN10WlEBRqqjjqSelLspAaWg2Bsbj8Vvyj/Clh/hQQvouC1rvtY9nPc7LJuGwDcvd6zz7fwUuw/wplH+FBB+iqezgc5zC2p2Fwf+lMgiEMYY0ki5Nz3m6yyj/CmUf4UGSLHKP8KZR/hQZIsbD/CmUf4UGSLHKP8ACuco/wAKDu3gY85OFezN8py9OrzD4FwPtKwr2ZvlOXp5AREQEREBERAREQEREBERARR562ngmEU0mR1r6g2A13Ow2PwWAxKhIJ8bgsDY3eBb/LIJaWHYooxCjL8vjMN7X8sLbBUw1AJhlY+wBNjtfZBtsOxYujY4tLmglpuCRsVrqKuCmDDNIGB+jT26XWAxCkLnNFTFdpsesOwH/sIJNh2JYdiiOxOha3MauCxFxZ4Nx3dqOxOiaNaqE7aB4JQS0UUYhRFpcKuDKBcnpBon0jRA28bgva9ukGyCUi4Y5r2BzCHNcLgg3BC5QEREBERAREQEREBERAXTPDH5t8Z9mP5rF3NdM8Mnm2xn2Y/msQeXxsuViALf+1zYIOUXFglgg5RcWCWCDlFxYJYIOUXFguMo/wAKDJFjYf4Uyj/CgyRY5R/hRBko9ZTipjDC4tsbnvGxHvBKkIgrBhstnA1byDrbUC9tdj26rg4fVXt46+xG+uh7tVaIgrX0VR0jctS7oyTfrOuBy5rkUE93E1kh61xvp3bqxRBAiopWTRv8akLGkktJJv8AEqeiIIM1E+SV7hOWNcbgNBBBsBvf/itbMPlDjerkLSbhoJFu7dWSIKz6OmuSa2Qm1mnXTbv7ll4hL0gIrJcgJJbc6jsvdWKIO5+BNpZ4RMHa5xc4MlBcef7J2q9Prx5gGLVOBY1SYnRWM9M/MGu2cNiD3EEhfb6Xw2YA6nYaqhxKKYjrMYxjwD3HML/AIPqiL5j9tXDXo2K/cs/Wn21cNejYr9yz9aD6ci+Y/bVw16Niv3LP1p9tXDXo2K/cs/Wg+nIvmP21cNejYr9yz9afbVw16Niv3LP1oPpyL5j9tXDXo2K/cs/Wn21cNejYr9yz9aD6ci+Y/bVw16Niv3LP1p9tXDXo2K/cs/Wg+nIvmP21cNejYr9yz9afbVw16Niv3LP1oPo1RR09Q7NPE17rWuffb+5+K1twyiaHBtNGA7fTdfPftq4a9GxX7ln60+2rhr0bFfuWfrQfQvoyi6Po/F48gtYW2/y5+K309NFT5uhYGBxuQPgvm321cNejYr9yz9afbVw16Niv3LP1oPpU9PDUNDZ42SNHJwuowwuiDS0U7bHca6/5ZfPvtq4a9GxX7ln60+2rhr0bFfuWfrQfQHYTRPkDnQNNm5Q390DTl7h8FkMMogSfFo7nfTf1r579tXDXo2K/cs/Wn21cNejYr9yz9aD6AcJoi97jA05zctO1/UuW4XRtqHTdA0yHmeXq/uvn321cNejYr9yz9afbVw16Niv3LP1oPpsbGxsaxgDWtFgByC5XzH7auGvRsV+5Z+tPtq4a9GxX7ln60H05F8x+2rhr0bFfuWfrT7auGvRsV+5Z+tB9ORfMftq4a9GxX7ln60+2rhr0bFfuWfrQfTkXzH7auGvRsV+5Z+tPtq4a9GxX7ln60H05F8x+2rhr0bFfuWfrT7auGvRsV+5Z+tB9ORfMftq4a9GxX7ln60+2rhr0bFfuWfrQfTl0zwyebbGfZj+axUn218NejYr9yz9a6P4TPCazifDfovCKaaCie4OmknsHvsbhoAJsL2O/JB8fjwx7GWbVPByhuYCx9d7/AODRZuoagvJbWyBtwQLE2HZurFEFe2hlaSW1TgXOu4akEWtzK2UtNLBGWmfO61gXAkDblfuUxEFX9GT9GGCtksALabW5jVbX0D3GMme72sLMxbr6wb6KeiCu8QmD3FtW+x5G/d39yxOHTaBtbI1oAsLXta3erNEFaygnaLCreGhznWF9z7+RXLaOofTtZJPZwzXILje4sOfvViiCtiw17Cwmoc7KWnnY2t39yskRAREQFHrGSvYwQk3DtbOtpY/92UhEFbbEsw60dgSD6tLLIfSAIBMZGUXt2qwRBW5cQbG1uZjiMpLha5/3BcluIuBGaMbWJHd+asUQVjW4iH3vHaztzfvH5LNzq5rmkhpDnAWaNhzVgiAoVSyr8Za+BzTFpmYfft+CmogrWfSIbrkLrHstc3/touHuxEODRkJsDe2nf+Oys0QVzRiIIBMZbf32/wA2/FYf/EooG3LHv1Btqb8vx3VoiCukdiDWF1mGwAytFye0rZT+PF7TOYw25uAOSmogKA+Os8YeWOGQvFr8m2157+5T0QVtsSu03i537OX+fFIm4k2NrXOjLgHEuPPsCskQVkRxF5N+jY3QajXv/wDSsm3yjNbNbWy5RAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERB/9k=",
                                        "timing": 1500
                                    },
                                    {
                                        "timestamp": 763799224720,
                                        "timing": 1875,
                                        "data": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAFcAfQDASIAAhEBAxEB/8QAHAABAAICAwEAAAAAAAAAAAAAAAQFAgMBBggH/8QATRAAAQMCBAIECgcHBAIAAwkAAQACAwQRBRIhMQZBEyJRYQcUMjdUcXKBkbMVFheTodHSI0JVkpSx8DNSYsEk4SU08SY1RFNjgoOiwv/EABoBAQADAQEBAAAAAAAAAAAAAAABAgMFBAb/xAAvEQEAAgECAggFBAMAAAAAAAAAAQIDBBEhkQUSFBVRUoHwMUFTYtETInGhMkJh/9oADAMBAAIRAxEAPwDriIq+op6t073wSNaLkjrdw0It3H4oLBFBjhrSyYTTMJI6gbp+Nrha2w4i1tmyxga2FyfVqQT/AJ70FkirKePEjOHyyMbHcAtNiSOdrbc/wU+oa58EjYyQ8tIBBtY+tBsRVkVPiDTYzsyk9tyBbvCmUbZ2w2qntfJfdosEG9ERAREQERW9NwzjtVAyamwbEZYni7Xtp3kOHaDZBUIrz6o8R/wLE/6Z/wCSfVHiP+BYn/TP/JBRorz6o8R/wLE/6Z/5J9UeI/4Fif8ATP8AyQUaK8+qPEf8CxP+mf8Akn1R4j/gWJ/0z/yQUaK8+qPEf8CxP+mf+SfVHiP+BYn/AEz/AMkFGivPqjxH/AsT/pn/AJJ9UeI/4Fif9M/8kFGivPqjxH/AsT/pn/kn1R4j/gWJ/wBM/wDJBRorz6o8R/wLE/6Z/wCSfVHiP+BYn/TP/JBRorz6o8R/wLE/6Z/5J9UeI/4Fif8ATP8AyQUaK8+qPEf8CxP+mf8Akn1R4j/gWJ/0z/yQUaK8+qPEf8CxP+mf+SfVHiP+BYn/AEz/AMkFGivPqjxH/AsT/pn/AJJ9UeI/4Fif9M/8kFGivPqjxH/AsT/pn/kn1R4j/gWJ/wBM/wDJBRorz6o8R/wLE/6Z/wCSfVHiP+BYn/TP/JBRorz6o8R/wLE/6Z/5J9UeI/4Fif8ATP8AyQUaK8+qPEf8CxP+mf8Akn1R4j/gWJ/0z/yQUaK8+qPEf8CxP+mf+SfVHiP+BYn/AEz/AMkFGivPqjxH/AsT/pn/AJJ9UeI/4Fif9M/8kFGivPqjxH/AsT/pn/kqHGMJxOhr2x1cM9HJlHUmY5hA11AIsd/wQZIq8U9cZIs9S0xtsXaWLjfuC34hDNPGxsEhjcHXJzEaWPZ32+CCSirG0uINyWqmm173F7g+5WMYc2Noc7M4DU9pQZIoeJwvmjaGMzkZuQO7SOZHatlDG6ON4e3KS9xtYf8ARQQ8ZxmPDJI2PidIXgnQ2sq762Q+iyfzBReN/wD5um9g/wB11+ndG0u6VpdcWFuXeulh0+O2OLTHF4Mue9bzWJdq+tkPosn8wT62Q+iyfzBda6Sl1/Yu1J57dnNZdJSXP7J+XT++vNadmxeWVO0ZPF2P62Q+iyfzBTcJx2PEaowNhex2UuuTddJndE63QsLdTudxyVtwd/8Ae/8A/G7/AKVMumx1pNohbHnvN4iZd4REXMdAREQEREBERAREQEREBERB2rwXUFPiXHuFU1ZGJIcz5Cx2oJaxzhf3gL1ENBovM/gb84+F+zN8py9MICLqPFmK4ycUpsI4djY2olGaSpkALYx+f+erXw5U4vRYpLDjuOYbVU4FgAWtkD77WFrfisaZ4yWmtImduEzHwiXptpupijJe8RvxiN+M/wBbc5dyREWzzCIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAi4ccrSVpqZIqenkqKqTJFG0ve8kgNA3KHwb0VJgeP4XjcssVBO90kWpa7MCR2jtGo+KmitojIYxUAvDsuUOJN7kf9H4FXtjvWeraNpUrkraN4ngnIsCOjFwTYbgm65cSXZQbcyVRdki0SPgjlZHJKGveCWtLyCbb2TPB/+aNr/wCodvip2Ru3oozZqZzw1szS4306Q8jbt7dFtYGubmjeSORDrhNtjfdsXQ/DXh9PVcB1lTNG0z0jmSRPtq0l7Wn3EFd7Ybt132K6d4YPNzjHsx/NYoS8yjZEGyICIiAiIgi1uH0taWmqhEhboCSRb4KN9A4b6K3+Z35qzRXjJeI2iZVmlZ4zCs+gcN9Fb/M780+gcN9Fb/M781Zop/VyeaeaP06eEKz6Bw30Vv8AM781vo8Mo6OUyU0AY8i17k6e9TEUTkvMbTMpilY4xAiIqLCIiAiIgIiICIiAiIgIiIO6eBvzj4X7M3ynL0wvM/gb84+F+zN8py9MIOkcYOxnB8cpsZwmiNdSZTHUwM/1OwEfhsOS6lHhY4s4mp56Dh+pwyAT9PV1VS515De5AB07du3kvsiJpZtpLTbBO2++/wD3f4vNm0857b3tvHDhw+Xh4CIiPSIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIOHjM0jnuo1dDFW0U1LM5zGysLHWNnC/MHtUpEiduMImN+DrfDXDcWC1MlQ+vlqpC3IzOTZjdNALn/AGjXuU12DUTphK57i9rzI0kg5SSTYAjtce9W9kstLZr2t1pnipXFSsdWI4NbnB4LWm99CuT1X5uRFis0WbRX1+HUdfIJKjrODcrSH2sNb/EGxUWXAMNkaQWkElpuHa9W9v7q6SyvGS8cIlScdZ+MKP6u4bna4ZhlfnAzaX2P4KyooKeip2wU9gxuzQbqVZEtktaNrSVpWvGIYsBA13Oq6f4YPNzjHsx/NYu5Lpvhg83OMezH81iou8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO6eBvzj4X7M3ynL0wvM/gb84+F+zN8py9MICIiAiIgIiIC63x5i1Xg+F0ktA4tlmrIqcuFO6dwa4m9mAguK7IoGNYRSYzSsgrRLkjkbMx0UzonNe3YhzSCPig6TReENtJSmLFmiWu8YmjY0sFG4xxtY4ueyR3UcekbZt9QQdATa2k4+wyOkdUPiqQwASZSwB3Q+L9P0tr3y5QW+0LKb9TcHEYDGVbJs73uqW1koncXNa12aTNmIIY0WJt1W9gUp/DODyVRqJKJj5DRHDjmJINOf3CL2Pr3QVM3GboauGhkwWtGJzSRsZTdJFctkZK9r82bLa0MgIvcEc7gpxli2LYfWwNoi+Gi6Fz5KiOidVlsl+qHsYcwZa5uAdtxbWyouFsLo6mGpZHPLUxSNkZNPUSSvBax7Gi7iTYNkfYbdYnfVbcX4eocVqmVM5qoqhsZiMtNUyQOcy98riwi4v27XNrXQdbd4QKWks2ofDUSyujEXRSNjiIMDJXObI9wu3ri1wDqBbcq9q+JYYuF4Mdgp5JaSWJsxa5zY3NaRcXBOpvYWFySdLrF3B+DBrRBTyUzmFpY+mnfE5mWMRgNLSCBkaBbbQHfVSMR4bw6vw+hop2Ttp6J7XwCKokjLXNFmnM0gm1+d9dd0EODiyJ0DnVNBVU0zJ6WnfDJlzMfPkyg2NtM4v6itWN4rXux2pw+hqY6KGjo2Vk8xpjO9+dz2taxgPLo3E6E6gCyku4Rwp9XFUyNq3yxvik69XKQ98Zux7hms5w7TfYdgUvF8AocVqIqifxiKqiaWNnpqh8EmUm5aXMIJFxexQdepOOmDDemlgdWilpxPX1NK3JHE3pHsLgyQh97xvJbYkZTqdL7p+O6WCMTzUFW2lmdLHSSgsPjL2Oy5QM1wXHyb2BA1spp4LwPo44200rIms6N7G1EgEzc5faXrftOs5x6175nX3K14hwZhs1NVimjLZpWyiMTSSSRQukOZxazMA251u2x7CEFXiHHniNZJ49RS0cNGZ21cby17nFsUcjchDrWPSAa29ytcL4upsRwbFa6Gmle7Dg4yRRPZJnszP1HNNjcab7ghRcH4Go4YK36YPj09XLJI8mSQhofGyMtBc4uOkY1JuDtbRdhwrCabDIpmQGeQzOzyPnmfK5xsBu4k2sALIOtVHhGweEVrslQ+Olc/M5gBD42xl5kbrq3M0x+13aqBiXhEb9GVVRh0F6qmZO4xFzJWPLIHSt67XWtprbW4I7Cr+k4I4epYujhw5oZ4m6gIL3G8Lnl5bqf9xJvv3raeEcJfA+KojqKkPDw509TJI4h8ZjcMxde2Ukfjvqgqm+EGgbiZoZaeQTMd0MmWRhLZej6QjLfNl/dzWtfu1RvHgdR+M/QleI2wQ1UozxXjjlcRGSM2pNiSBsPgrWLhLCo5+lDaok6uY6qkLHuydHnc3NYuy6XOvPfVVWP8DtxKopmU1QymomQwU72DpM5ZE/MASHhrtNBnBtqdb2QQMS8JNM6kxAYXC59RC2QwkuY/pDHIGuBaHXbe5y5rXA5KdW+ECkoXup6yilgxBsz4XU8s0TQMsbJC7OXZT1ZWWF73PcSrb6oYRmnvFOY5c94TUSdGzO4Pdlbms27hfT/tbK3hfDKyplqXxzxVUspldNBUPifcxtjOrSCAWsYCNuqDvqgrKDjimrqqFsGH1nick0EHjTsjQ18sTZGAtvm2eAdNCfh25VEPDmFwNyxUxa3p4qi3SOPXjY1jDvyaxotztqrdAREQEREBERAXTfDB5ucY9mP5rF3JdN8MHm5xj2Y/msQeZRsiDZEBERAREQEREBERAREQEREBERAREQEREBERAREQEREHdPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEEOXFKGKd0ElVC2Zu7C7rDbl/8AuHxUjp4cmfpY8u98wt/mh+Cq6zhzDaytlq5onGeXR7g8i4yFn9j8QDyWNXwzhtVS01PJE4R08TYo8rrWDSC09hItz7T2lBbeMQ9b9rH1b36w0tusJKymjAL54mguawXeN3aAesqjfwZgzjGRA9pjY5jcshFg4uJ056uvr2N7AsncH4S5jGdE8BoY02dbMGm4B99tuxBduq6dsb5HTxBjG53Oziwb2nu71jFW00sedk8Zb3m1tbag7a6KspOGMMpYZI44nESRyRPJdYlr7ZtvZCVPDVHUvL6iSolkLcpe59ydd9vdbbuVqxX5o4rVlXTvPUmjPLyuev5FZ9NFkD+kZkIuHZhYhUJ4QwnOHCKSwfnyl5IvcnY95ut7uG6F8NJE/pnR0wcGgv8AKzG5v+Sm0U/1k4rCbEaOESGSojHRhhdZ1yMxs3btOg7UbiNG5sbm1UBbJqw5x1tCf7An3FV0HDVBTxTRwdLGJOi1DtW9G7M22n+7XW/wUeXg3CpZHPeJy4uD7mS9nAEX/En1qiXYGyxuzZZGHL5Vjt61wJ4jJ0YlZ0n+3ML/AA9xVZRcPUFFBLDTseyGWEwSMzaObdx//wBu+Kxo+G8PpKplSxj3VDZHy9I91yXPtmP4BBcoiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAum+GDzc4x7MfzWLuS6b4YPNzjHsx/NYg8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO6eBvzj4X7M3ynL0wvM/gb84+F+zN8py9MIOqYpVcQN4rp4aFkhwjPEJ3dADa972JOo2ueVuX73ZK90zaSU0rc0wHVH5d64lraeKuho5JQ2oma5zGdoG/wDncewrdNIyGJ8srg2NjS5zjyA3KCgZX402Oxw/OQHWc4i5sere1tSOVhbfuWNLiuLz1DsuHt6IStjNzawtdx77XtfbRXXj1J0TJDUxBjwC0l4F7i4/AhaIcaw6bo+jq4z0gJbe40ABO+2hBRCvmqsajqHGKl6VmZ12usAwfu2O7hvf3LiWvx3oCWYdGJHMJAzZsrrO03F9QDy0Nt1dmrpg5rTPEHObnAzi5b2ju71jLXUsJcJKiJrm2u0vF9dRogr2VuKGkzOomtm6fIG6kZLXzHs5jny92NRX4qKWCSnw0Olfnzse+2Wx6vxGvutzU6PFKF5kAqogYzZwc7LY2B59xHxW6Srpo2Z5J4mMsDmc8AWOxRKm8bxxrJR4nG9zHPynyc9nWaLX2I1usPpXFjVugZh7Hlj2tebkDKRv7/wVu7EqJrspqY79KIdD+/a+X12WDMXoHxwvZVRubMWBmXU9bybjlfvRCJLW4rHQxvGHtkqXA3Y11gDdtvwLvh3rFlZi3S1HS0YDI435Mov0jgW5SNefW05W3Vg/E6FjA91ZThp1B6QWte1/VfRZCvpHOLRVQFzSGkCQXBPL1oK59bippJHNowJ2FltLh93HNYXv5IB9/ctJr8dLyW4dEADJ1S697C7db8zp778lcitpTGx4qYSx7srXZxZx7AeZWPj9Gbf+VBqMw/aDUXtf46IKT6Qx4SyH6OY5hDMovoP9zu3TTq796tsKnrpmvNfTNgO7Q11+ZFvgAff3LOXEaSKNkjp2OY9/Rgs693WvbS/IFZHEKMC5q6cDXXpBy3RKSiizV9LDSeMuma6C9g9gL7m9tLXvquDiVCC0GrgBcLgGQDs/UPiEEtFpFVTl7mCeIvaC4tzi4ANifUsJMQpIyQ+phDg4MIzi9zsLdpQSUUL6WoemMRqYw8F7SDyLbZr+rMPisjiVEJGsNXBmcC4DONgAf7EFBLRR2VtK9pcyphc0bkPBA/y4WLMQo3xyPbVQlkds7s4s2+10EpFqNTAGZzNGGXDcxcLXOwWr6Rotf/Mp9P8A9Rv59x+CCUihjFKEzmEVUXSBodYutob2177H4KVFLHNGJIntex2zmm4PvQZIiICIiAiIgLpvhg83OMezH81i7kum+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDungb84+F+zN8py9MLzP4G/OPhfszfKcvTCCpqsCgqMS8dfPUNlzMcA0tsMpBAGlwNNr8z2lWNTBHVQOhnbnifo5p2I7D3LW6vpm4iyhMzfG3RmURc8gIBJ7NSPX7imJdP4jL4pm6e3Vy5b78s2l/WghDh7DQ5rmwuGV4kaBI6zSNBYX0FgBbsCw+rOFF5cacl1iLmRx0PvUI1PEjXZY6OJ7GhxD5C0OfocoNnWvq29uYPJTI6jGvE6h8tJCJwxnQsbY9Y+Ve7tufL3ohIlwShljYxzH5GRCFrRI4WaOQ109fPRYy4FRTVMs0zHve8m13kBl2BhtbtAUepmxeWhlaynkhqOkDGPi6MnLc3fZxIta2m9/iotTXcQQNleaNhijc3KWgPc8He7QRseyyCxbw9honZN4veVjg4OL3E3Gx3Wb8EoHmPNE4iONsTRndYNbtpf8VAlrsdZCD4hG57tQWgEC77AEZxrl1voP7Iysx+SRuWhgbGXPBc/QgDyTbNrr6r9gQTnYFh7qd0LoXOjMnSWL3aOsRprpoVrbw7hrXFzYHAkMH+o7Zvk8+SiyT8RCHMylpzIGg5LjV2bUXzaC3rPrWuWq4lMByUNMJHB4ADgLdUZTcu5uO1uSCf9XsN6Rr+gN2tyDrusB8e4JJw9hkmTPTA5XF46x3IA7ewWUPxniJrnkUcLwQ0tBLQAeY8r8e61tbrI1PEXTPZ4lSmNuaz7+Va9tM2l9B3XQSarh+inp4YA18cMbmnK1x6wGXqnu6jfgtH1Uwwyhzo3GIBwEWY5QXWu71mwW+qqMXFVIylpIjCxzbPeR1xzt1tPWR8VGkfjxo4JGRt6fNIZY7NboHXYBqQLgZd/3r8kE6TBKF9IaYxOEJcHFoe4XIaGjn2Af33WiHhvDo3QudHJJJEWua50jt2iwNr22A+CiCo4kY+xpYHhgkaDcWkItkcesLX1Og5203TxriQPYRQwOa5gLgXAZXa3A62vL/DoFm7BqJ1EaQxu8WuCI8xsCDe60xcOYXE4mOmtcWPXdqL37e3VQRVcSF7R4nCGucC53V6oyi9utr1sw17QuDPxK7KBSwtIuPKaAdBa5ue/YIJ0HD1HDNM9plLJY5I3Rl5IOcguN97nKFsGBUAe1wifma/pM3SOuTpvrrsFHpanHX1QFRRQR0+bU5gXFuYD/dobEnntbvW2mqcWdVZZ6NghL3WdcCzQHWv1jqSGfE9iDObAMOmllkkp7vlvnOc63Nzpf/NFqdw1hbg4OgeQ5oY4dK6xAtvr/wAR8Ao8U/ET44pH0tMx4tnivvrrrm00sea1Mq+Jgwl1BTl5PklwAbtsc2t9fV2nZBYP4ew58skjon55C4uPSu1vvzW84RR9FLHkfaUNDz0jruAJOpv2k+tR3PxiTC5x0ccVddvRFtstjlJvcnbrD3aKPSS48DI+eFljFK9jDl0fmBY0kHkLjvtuiUyTA6CSB8UkJex0vTEOeT1rW7ewkWWkcN0HSvL2vdGWhjYy45WAMyae5aKao4hMmWakpxGHN65Iu5tiToHaG9hzt3rGbEMcdiE8NJQxOhY8ASSAtFiTsb9bQA++2u6ISn8NYU8NzUoOUNaOsdhtzVpTQR00XRwtyszOda99XEk/iSqJlXxE/Legp4i4gauDsgvYk2cLkDWw3vvpY8Pq+IwG5aClJcHk9fyTrlHla8jfvtpug7EioY6nHzUubJR0wha9oDwfKbbU2zaa/DvSufjwfMKSOEsDgWF1rkZ9Re9gMottfVEr5F181HERa4tpaUWLsocNSBly/v6Xu7TlbvWHjXERlLjRRNYJLBoLT1LeUetvrtpe26DsaLrr6viQNblw+lJc1xIz+SbnK3yteRvpvZXlIZnU7fGmtE1yDl2Ouh3O41Qbl03wwebnGPZj+axdyXTfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB3TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphBBmwmhnxFlfLTMdWMaGtlN7gA3A+Kk1YmMDhTFrZTaxdsNdfwutqIOvtZj4c1z3QOdkaHZdBe+th29nd3o2PiCOSO0sD2ZgHXA8m2vZrf8B2rsCIKaQY6KOnETqR1TmtKXggW01FuzUWWTGYy3D4gH0xq83Xz3yhtuVtSdB8SrdEHX3N4hdT/AOpAJHB46oAtp1Tz1v8A9LEM4jGd5fS5jlbktpbXMR37Wvy3XYkQVdH9LCGZtWYDM5hMbmDqtdc2BG9rZT8e5RaUcQeNQuqTRiIkdIGXNrE3tftGvrtyV8iClm+nHOkMXi7GgvDRa5cLdUrQ36xlji40jSBcNaL63Gl/Zv2a9y7CiCjq4MYdUxvp3sFgzPd3UIscwA3vexv2BYMHEIja55pS7W7bW5i2vqvdX6IKWkbjjKWcTup3zNYzos2ge4DrXI7deWl1re3iHLLkfRlwc4MDm2BFwGk+oXPrFlfIgoAOIyHnNRBwAyixsTcX77Wv7+5c0EeOiqj8aki8WEjnGwGcsN7A8ri4vbsFuavkQdecOJetY0H7wbYHXTqk/j+HessnEAqH5ZKcxlzrFwGgt1VfogrZXYmKSERMiNQHBshcdCLauCjRMxwSOMr4DlgeG20aZLjLfmrtEFHhrMbZV2q3wmmJcbnV9raXtpvbbv7lpgbj0LXNDI39TeSQOJflGoNtATfS2n4DsSIOsSQcRkSO6SK7owA1rgLP6tzttofipkseMllO1kkdw+QyE21F3ZR6rZduxXaIOu34l6Nv/wApnya6bOvy11Hw071vrIMWeKUxyjpA13SFrg1odmaRccxlDh7/AHq7RBQtbxBlfd9KCM+UBt77ZefZf39y2ULcb8YtVvgEJjJJABLXn4aDT8e5XSIOvSs4ikbIM9LHmaSMguWnIbAE9jtL22t3rP8A+0Of/wDC5c7LC37ttb673/8ASvkQdeYOI3XDnUjBY2NrnyTb35rX7tiruk6boGipt0o0JGzu9bkQF03wwebnGPZj+axdyXTfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB3TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphB1nFGcStxOokw98L6MA9FG/KCTkvrz8puXfZ5PJbKeTiVz4jNDRNYXRl7QNQ23XHlb32/7VrVYpR0s7YaidrJXEANOh1sAfVcgX7SBupU0scETpJXhjG7uOwQdYq3cTw1Nc+jjZOzpB0LZiwNy3N7WNzpbcj1czNxeXG5JKdmGQNZ0RD53vc0NkFgCxu5vqTrbVo1sVYNxbD3BxbW05DQHE9INAdAfxWM2L0cQhcZczJQS17AXNADg03I21cAgqMPl4njhrG1lPTyOZG407g4Xe++gNiAOf4a7rQyo4ubB16OmdO5uYWLS1pyeSeuD5fZfRX30xh3OtgFs1+uNLb/AAWcGJ0VRIY4amNz7E5QdbDnb3H4IOvNqeK5pG2paeMMlYHAgAObku7XMdMx3A9V9SsjUcX+LxOFHQdK64cwnyew+Xse7nbt07AzEqJ8bpGVMRY0Ek5tgLfmPiFqdjeGt3rYLWzF2bQC17k7BBCqzjsGEzy0rYqnEnPIZE6zYw0EgEa31FiQSd1FmquKi9wgoaMDUAyOFtA3XR19Tmt3Wurh+MYewuDquK7XBp617Emw/ujMYw983Rsq4i67Ro7QkkgD16f27UFDE/i2SrDpIaWGK7XFoIcCMhu3e/lEC/dfZbcNn4pbk+kKalMcd8+SxfILttbrAA2zHbcW2V5LilDE/LJVwtd1jYvH7psfgdEbidGWwuM7Gib/AE82mbW2nvQV2KzcQMqyMOpqSSm6RlnPPWyEHNfUbEfA7aKHLPxcyQtjpcOkjblGe5BdfUm2bQC9rX5E9gV9LidFFl6WrhZmF23eBcWBv8CCtMeN4bIXBtZDo4MuXWuSARbt0KCjqJuLwYzFTUbi3K4htgHXb1gbu3BOlt7akc5gl4lGHTuNPQurbjo2ahti5wNzm5DK7v1CsxjGHFod47BlIBBzjX/LFbaSvpaxzm0tRHKWgEhhvYHb+4+KCoj+sD8PmNQImVF2FrYLZrZ7vALja+XQX58+zUZuJGuDI6aIxXYA6UtL7W1JIcBe+5A05B267KiDqUU/F7ImCSlo3vyuzkOB1DBa3WG7r/8ApTqufiEiNtLS0zXGBrnveQ5rZP3m2zAnnqr9EHWJfrFJTSF7Xsk8aNm05iBEXRECxcSCM9jrrblyWh8/GAe4tpKMhpe0C4s4Xbld5V/92mm/bZduRB1983ETKKEimpZKk1DA8A2aIiwFx1duHXHuvZRpJ+KZWxmOmp4HBpcWuDXAuAdZpOfmcu3x5LtKIKfE58ZM1O3DaaLopMvSPmteMdbNcZhc+Ta3f3KXg7q51BGcVbE2r/fEQs33an+6mogIiICIiAiIgIiIC6b4YPNzjHsx/NYu5Lpvhg83OMezH81iDzKNkQbIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIg7p4G/OPhfszfKcvTC8z+Bvzj4X7M3ynL0wgi/R9J40ak08bpy/pOkcLuDsuW4J20uNO09pUiWNkrMsjQ5twbHuN1V1DcX+sMMkJpzhIhLXsLiH5y4dbbWwBttuVPr2zuo5RSECoAvHc2BcNQD3HZBE+gsMylviceU2u3WxtsLdnO3bqthwmiLIWGAFkIIYC42FyCb666gHXmFVwU/EMT2xuqYJIy6xe5t3Zdr+uwv6ye5c07eIWwRRPdT3tGHSGxdp5fdfs/FELJuDYe1rw2mYA4kmxPPe3YkGEUEDs0NO1h6PortJHV7N/X8T2qvjlx2SjqgI4W1TX5Yy4Wad9u0eT+K5kOPkvytgAtlblIuDYXdrvrfTTTmESnswehYx7WwDK9mRwLibjTtPcPgOxDg2HloaaWMtAAsewai/bqVXVDeIHPzwmnbldaxO7e23auIYuIWOeHTUzgc7gSL65iWj1WsPV3ohYfQmHZcvikeXK1uXWxDfJ07raLOHCKCA3ipY2m4PPkbj4KPMMYEMTYjAZD0ge88teobeq11p6LG3R1IdLEJC2MREaC9+sfgiU12EUD3SOdTMcZL5ibm9zc+rXVcyYTRSBgdESGNyt67tBfN273sb73UKBmOtqIhLJTPhEhDurqWaWPrIze+3etJpcebUTOZVQujObomu5a2aTprpqe9ELSbCaGbJ0tNG4sa1rTzAbew/E/FYHBcPLmu8VZdpaW6nQgWFuzQAd9tVBY3H2u6Mvpywyj9rzEdzfTtsW/ApTS45JT1TZo2NqGlgY5oAbe5zEX3GXLvzvr2EpYwHDOr/4jCW+SSSba3PPnc37VMpqOnpjeCJrDYN07AAP7NHwVeBjL6doLoIpelAcQL/s8ovbvzX91lFZ9ZMv7Q0eax0aNAbaHU7badvcg7Cio6YY86VpndTNYCwkAXuNMwv6r+/uV4gIiICIiAiIgIiICIiAiIgIiICIiAum+GDzc4x7MfzWLuS6b4YPNzjHsx/NYg8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO6eBvzj4X7M3ynL0wvM/gb84+F+zN8py9MIK5+NUDMdjwd04GIPhM4jsfIBAvfbmp08zIInSSuysbubXWuoo6apfG+ogikfGQ5jntBLSDcEdmoCzqYI6mF0Uzc0brXF7bG6Cv+n8Ls4isjOUAnKCbA7bD3evRbHYzQNflNQM3W0yn93fktjcLoGtc1tJCA4ZSAwDTs/BPouhyub4pBZ17jIOe6CM3iDDnOIbUAnLnb/wAha9x7u1cHiLCgGEVbXNd+81pIF72ubaXym3byUn6Jw/q/+HBoLDqDbayfRVBkDBSQ5RYgZBpa9vhc29aDTU45QU9+km06JszSASHNdexHw/Edqxk4gw6N0bTOS95sGhhuN76W5EWPYpcmHUcg/aUsLuoI9WA9UG4HqBWBwqgMpkNHB0hJcXZBe53PrKDD6Zw/xWOp8aj6CR2Rr9bErluMUDnBonAJF9WuHb2j/i74FZuwuhdDHE6khMUZu1pYLD/LD4BHYVQuc5zqSElzs56u5119ep+KDT9O4cXZRUtz2JLSCCADY6HvXMeN4dJIGMqmF5c1uUA3u7bksnYPQGIxilia3J0Ys3ZvYFlT4VQ07GtjpoxlDRci50Fgb9qDiuxajophFUS5ZCA7KGkm17X07ytH0/h+aMdMRnc5o6p3aLkfDa26kzYXRTODpqWKRwaGZni5sOV0OGUJkbIaSDO03ByDQ7INH07h3KpBGXPcNO3/AH7uwrfLilHFJ0ck7Q+4BGptcX17NDuosvD2GydPenA6Zoa62lmjkOxTZKCklfnkp4nP6vWLQTpe3wufigjS43QxwRTGVxhlvlcGE7EA6b8wjsdw1r3NNUzM0EkWOwNidlKNDSljWGniyNvYZRYXt+QWBw2iLi40sJJaWnqDY7hBHkxqkjrKinkLmmAgPcSLXLQ7a99iOS4dj+GN3qm2AuXZTYbWvp/yClvoKR8r5H08bnvILiW7m1r/AAAC1uwmgcSTRwXIAJyDYbINEWPYfIJbTgdHIIiLEkuO1rb3sbepHY/hbbZq2IAguBN7EDmO0cvXpupAwugEokFHAHh2fMGDyu31rTFgWGxve4UkRz6EOFwB2AdmuyCfBMyeJskTszHbG1u7ZZrGNjY25Y2hrbk2A5k3P4rJAREQEREBERAREQEREBdN8MHm5xj2Y/msXcl03wwebnGPZj+axB5lGyINkQEREBERAREQEREBERAREQEREBERAREQEREBERAREQd08DfnHwv2ZvlOXpheZ/A35x8L9mb5Tl6YQdYqMPxocSmsiqHPoDIz9j05ADdA45bW7dFf4j4x4nJ4n/r6ZdQOYvvcbXVTXcVYdQ4hNR1JlZJCLyOy9UCwd2/7ST6mlbYuJsJlexsdS5xe5jW2hfYl4u3W3xPLnZBGFNxIWSZq6lDsoyZWDytL3u3a1/f3La6DHjmIqoB5dm6WN/J1y8v/AKkrifirDqWapjrTLTNgeGF8jRZ1yRcAEutcWvZS8VxyhwwUZqpLCrkEcVrakjQ+q9h63BBXNo+IQ5pdWU5zMs8XPlZbXGmgvrohpOJDEwur6cStIuGtAadHZv3e9tvVr3yaHijCqyKodHUFrqdjpJWOaczGg6k2v3HTtC0/XHBhH0rqh7YbBwkdE4Ag2ykaag35e+yIZ1lDjEs1O+KtjYGxsErQSA5+ziO6xJHeAtbaTiHJC59dAZm6OAADTruRl109X91tHFmEBjnSVD4w0vBzxPsMup1ta1tu3kpVBjlFiEwZQuknFg5zxGQ1oIJBJNr3sRpfXdEq6qZxIyJz45YXPc59o2ZeqP3NS34/h2qZUQ4y6vldDUwspMzCxmmawBzA9XmbLAcVYMaY1ArR0QsCejdpckbWvuCo9bxngtLC+Txl0oYbOEbDcG1wNba6Wt2oNjIeIMsTX1EBF7vcHC+7dB1LHZw5bjsUZ8PE8YjAnp5JXNsXtADWuvuQRtY8tdB75TeLcHM74XVD2yteYwwxOzOIANgAL87WOtwVNqsbw6looauoqQynlj6Zjy02LbA327Df1X7CiGvDI8WilBxCaKdjtLMAGXQWO2981/WLKubQ8RSSEy10TA4x6sOwDyXWGXexAvsQNQpTeLMFcWDx0DO4MaXRuAccuawJHYRfsuBuVg7i/BvFnTx1MkrRG6QCOF5Lg3cDTfu9+2qDUKbiKNs7/GoHHruaxpvc6WGrdBv7zzWeHtxzxxgq3ZYHsuTdpLDlIsdN72Omm6lUXEmFVtQIKWq6WUuLLNjda4BNr2tsCR220XFJxJhdZPDFSVPTOmcWMLGOILhe4200BPZb1hEtPQcQOeC6qpmjVxDRoDl0aLt2zbnmLbFZz0eL/SE0tPWtZTvfHZh1ysF81gQbHa3LfuXI4loGwsmqTLTRSM6SN0jb52adfq3sDcDrWNyBZaXcX4Mw1HSVJYKeRschcw9VxAIFrXvra1r3BQZ0tLjnQPFZWQOe6FzBkGUB5vZ219NP/qtbaHG4ogKeqiYRFaz3uku/NuS4E2sT77clMHEOGGAzNqS6MTmmuI3H9oASRttYE3271EfxdhTYmSZqhzHxPlDmwOIIba4va19besEbohploeI5AW+PQBrspPI3sL2IbpqD8T7pEsWPNa54nhs1xsxliXty97dDf3evZbJuJaCCuqKWbpmPhlbCT0ZIc5zczQ0DU3F9huClbxPhdDUzw1Uz4+hDc7zG7LdxIABtqbjleyDTQQ8QuMT6ypga39m50YaL8s4Jt2X259y7Aqml4jwqrrW0lPVtfUuc5gYGuvdoueXr9dlgeJsJbCJX1JYwkgZong6ODdiL7kfFErlF11vGGEubOWvnd0Ojg2Fxuetpp3NJ15albncVYWzKZJZWMJsZDE7I06butbmPVzsgvEVRS8R4bWRyOo5zNkjdKRlLAQ22bV1hcXG50uow4uwlkOarmfSShrXOgmYekYHeTcC+9x8RfVB2BFRScWYPE8iSqLWhpcHmNwDgHZTbTUZiBcaXICuoJWTwRzQuDo5Gh7XDmCLgoM0REBERAXTfDB5ucY9mP5rF3JdN8MHm5xj2Y/msQeZRsiDZEBERAREQEREBERAREQEREBERAREQEREBERAREQEREHdPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEEeahpJ3udNSwSOd5RfGCToW6+4keolYsw6iZlyUlO3La1owLW2+Ciy47QxVs9LJIWSw+XcWAFmm/eOsPgVshxijmmMTHvzi5IMbhYAE327j8EGb8Jw6R0rpKClcZTmkLomnOe06arN2HUbppJX0sLpJGhji5gN26aerQadwUb6ewy+Xxtua2YtsbgXttZZDGsPJYBUt65Ab1TrcX7OzU9nNBubhlA0SBtFTASNyvtE3rDsOmq1jBcLDHMGHUYY4AOAgbYgbcuS0t4gw10zIxUC7/ACTY6m9rdt7rEcR4WWBwqmnUAhoJy3IFzbYAuAvsgmuw2hcCHUdMQ69wYm6335LZT0lNTC1PBFEMob1GBug2GnJRH43QNjhkM46KVr3NeASLNIDvhf8AArU7iHDWxMe6cgvOUMyHNfTS3qIPqQbRgeEhthhlFbLlt0Ddr3tttdZvwfDJL9Jh1G67i85oWm5JuTtvdYMxvDn08k4qmCKM5XuNxlNibH4H4WWIx/DHEhlWx5HJgLj+A7dPXpugkfRlB0vS+JU3S5i/P0Tb5jub2371l9H0ZhZCaWAxMvlYWAtbcFpsOWhI9RIUakxzDqp8bIKlrpH6BtjcHTfs1IHr0UkV1MaeWdsoMUfluAJtoD/Yj4oMBhdAMlqKmGTVv7JvV8nbT/i3+UdixOEYaYOhOH0hhtbJ0Lcu99rLOXEqOKmiqJKhjYJGh7HnYjTX8QtbcXonsndHNn6EEvAaQRbca8xcXHK6DdDh9HBIXw0lPG8uz5mRgHNYi/rsT8SuIMPoqd7XQUlPE5pzAsjAINg2+g7AB6gog4gw0l//AJHVaxshdkdaxvbl3X9Wq4j4hwx7nt8ZDXNc5li06loubduhQSDhGGkknD6QkkuP7FupO525ocIw0sLDh9IWmwI6FtjbbkuanFKWnpYah8hMcxaGZWkk3IAPcNRutMmOUTaOSpjk6aON/RvyW6p7ybAeu6CS3D6JjXNbSU4a55kIEYsXEWLvXbS6wGE4cGuaKCkDXDK4dC3Udh02WtmNYe8VBFSy8AJlHNov/wDT4hYnHaAFg6UkOkMdw0kAgE6nlo0+rS6CTJh1FJUNqJKOnfO05hI6MFwO179ugWM2F4fM+V81DSyPlt0jnRNJfba+mtlrqMaw+nmdFPVMZICAQQdz/wCxb16LVNxBhsV89SAWluYFpBaCQLm40Gu6CVHhlBFN0sVFTMluXZ2xNBuRYm9ua1DBMKDWtGGUQa1uQAQNsG3vbba/JcvxigbHBI6obkmDjGbE5su4230Oi0zcQ4XFG57qtmgvYA3Ol9PcR8QEGwYHhIIIwyiuDcHoG6aW7OxbRheHhznChpQ51sx6Jtzba+nKw+C0fT2GZ8njbM4Ni2xuDubi2lufZzWWIY1Q4fUiGqmEb8gkN9g3MG3P4+4HsQbRheHiF0IoaUROa5jmdE3KWm1wRbY2F/UFj9D4blI+j6Sxbkt0Ldrg222uAfcFqGOUFj+1IIkMYa5pBLgbGwOq1N4kwy5zzmOzc3XaRpp+ofj2IJZwjDTmvQUhzOzH9i3U9u2+pUqGKOGMRwsbGwbNaLAKG7F6IRCTprsMvQ3APlWva2507O1a58doKeZrJpsrXRCYSWJblJsDdBZooEGL0NRK6OGoDpGhxc0NN25d76aWvb16KOziLDXutHPnOcR9Vp0JBOvZsd+YIQW6KsOPYWHlvjkZcLkhtztvt2c+waqzQF03wwebnGPZj+axdyXTfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB3TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphBQV1ZhLcSqIq6kaHsY4mZ8YIcMrXOtzOgbf2R3X1nFMEiLx0JjY2Np6QQkAtdmAsbX2ufUVliOLYVDiMlPU0fSTueyJzuia65IuL87Dv9yiy8QYRlfGcPJJMZex0bLWed9zci503/FEJFLVYGJDGylawsd0OYxXBvl59hLwLlZUlVgMssbIIIy+QkN/YEX1y3uR26X5rVUYtgraanq5aDN4yH2vC3N1dCDfvsFqqMbwcVMbn0U3jFO4BgDAA1zhfkbb/AI7IN5qeHmPbGIIi4FrGhsB3cMzW7c1ga/A4WxCShbHFLTsqL9CCA1zhYED/AJAd11wMdwkdJEcOkD7OkkZ0LdxcOub2PP1qwxHEMOopIYZIGyPlDWRtYxpzDWwF+Qy+7RBEfiuAhnRvjBbEJG5TTuOQXs/l26FcVlTg9NiD46nD2gxWd0vRAjRo1HqDgO73i+Bx2gfS1tVBQB7Y2xvdmDQ5/SOLdRrbyee/qsVxU49hWeR1Th8pec0by6FrrlliWk35XHdr60GwYngIpnxRwNfE57SYxAbOdo6+otpobrZDUYLLIIoKRri9utoMoAsXC9wLeRf4FcPxXC2UbZZKEsY2oEAYY2Xa+wIOhtYDmFEp+JsKZDFmoXRO6xDY42m1jY9h2dva2pG6DfDi3D8AD2RsieG57dAQW6jTbe4Bt70mxbB6eN0bKUlksrWyhsVgCRo49trDbuWt2NYO0NY7DXNDskbQYGWId1hsTpqD79t1sPEGG5mNdRS53FxaOiab5Rve/wAP+kG+TEcDDI6V7IyyN2RkZhOVp1YbaWA3HZrbmuKiuwugooJzR5YaqJ0mkY2IabO7z1R67KPW4lh9EKd7cNgMb4TMBZrXiwLgALdx1uAO1cx8R4U6Mxx0snRMcIvIYG3dqBvaxAvfbTVBjNieBeLteaMPidF0t2waWZYAesE2Ck1FRgVFVdDLBFHKH5ABCdXFoJ2H+0i6jUuOYbUCJsWHHPNkDxkZZoL2s1N+RI030GlrLGTHMIhqJzPQu6YySF7mxh9zFoDf1AWG4/FBIfimBPiDJWgsjyyhj4XdUG2V1raDb3rF2KYEC2kbC09LISYxERZwuCSPw96jVOP4cIpJIsL6WQGIjMxrbl2jbntAvyOg71vmx3B4Zc5pM0pL2ksjaSHN1IvffVBnFiuA9cRRsBmuHBkJu62puAN/ySnq8DdBLJDSRtEDQ6RphDeja4C57NnXPcsxW0f0ZHV0eHwvcJjFHHlFx1y2/VBIva+yjjiDDImVGbD5WOALahoibycGkHXUXdb48kGuDEMCnq5ZpqZ4qpnMa5kkeY5tgNLjyi4esHuW5tZw/PF08lKzPIGFzHQEu65uARbt1/FZSY9hYkLzSPcWOLc+RhsfK7dzb133stFNj2EuFO6OgazpQTERGNGg317O2wvqgmSV2BCnbUSMjEUD+ja90Rs0m+2nPXX81pjrMBqJGCOja973CIfsLaZg3UkbAuGneo8OO4RDTPliw+fxeod0khcwG7ibAWJ7vUPiplfi9FSuv4gZCyPxlhaxo1sO3UEkge9AkrcBZUSNMUZlMnRutASS91xbbc9Ye4rmtxDBYxB4zE2Rjo2Ste6IusNm7i99f7qPUcQ4ayqa3xFzpmyMY4ljbsLjqb3Ox3/7W2bGcIdh8NZNSXjkieGNfE3MWscAW29ZBt3INgqcFZC2ZlKwsbMY7iDVrsucmxF9bDbuUTx7hyONxNLGwXa1oMFs2Y3FtOZ/HdSm43Rv8ZDaQhtM0yy5w0ZbWDtBfYE687aKLHj2HyvjiqcLe2fPlazomu6w0tc2G9x7u9BvZjOBuGV0Qa5khfkMBOVzR5Wg3AF79i24xVYPQvjiraaNwLGRk9FdrGXJaD3XadO5RKbH8JkiZIKG08jWfs2sYSc99Ab2I1N/XrrdbxjGGSwsmbSZ2RSNhBLGksBvYjew6vO1t9kGU+IYVBFHOykzxVQkDpBGALZgHB1+0n3+si6KowFsAnjgiDG1HRhwhP8AqEb3t+Peo8WO4ZJFE04c53Rloja2NhDS89UC5FiRqezY66LfRYxhdZM2CGjfZ0pN3QtDQ4EDN67kC+6DmjqMFqJ4IoaRn7VrmMPQWbYAgjbsuO+y7AutQ8Q4Qx7xDAWSCbo9GNGZ2Um4N7WsN+8XVthGJsxJkjmRPjyOI6xBzDMQCCDzylBPXTfDB5ucY9mP5rF3JdN8MHm5xj2Y/msRLzKNkQbIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIg7p4G/OPhfszfKcvTC8z+Bvzj4X7M3ynL0wgoqvEmUmJyxx4bI6V7g0zNaOvZoN+02vZazxI0U3THDasXZntk77Wv/u7lzUYrikOL1ULMPM9Kz/TcGObezGu8rUG5LgLcxrZYyY9iDA/LglQ7KMwIJs4Xtp1b352I27EQzPEBbK1rsNqA0ua0G2uov8A2sPWbI7HZH0dTLHQSsli6I5ZLa5yO/kDf/tScOxOpqql0dRh8lMwPcxrnk9a1rW05i/PlzUBuPYmbvOB1GU5QGXOa9ze+lrAD427UG2biIQdE2Wjlc+TRpbbrdUm41OmhvrosI+IXdE4jDKgFrc1g29gXWAPfqCR2armoxOukpDUxYa6OeKcxAPidI5zMt7tAA3NhrYabrOXGcQc4sp8LkDhI1l5Q8Ai7cxFm7C51200ug4fxGxnSDxCpJbpoNzmA+Avcnlst+I4u6nlpOigMkUrHvcdLgtIGXca6kc9lEfjeJvin6DBpWvY1+UyZrEi2XTLrcnt2Cxq+I6yjNqjCpALeXmcGk2uG+TudrdvxQbajiB7A6NuHy+MWkLGOO5Zz9V/wUf6d/auqWYNNmPRsz5Oubk3HuDfjp3qZRYtXVLyZMJlp7NNnPJJBs42tbbqgb7kJh+MV9TUwwy4XLC1zbulIdl3tzAI9+vdzQa5+JoomPkNFUdE0vDXkAA5OfvG3at9DjfjcoaKCpjH+54G9nG3/wDUg9hsFEdi1eS5s+FSVFi05RC5oa6/kgm+YjfNoNN9QFg/iStNSIYsKkc9oc57AXF2UDQ2yiwJI310OmyDfUcRWp3yxUE7wGOc0kWBINre9SKvGDTVM0JopntY9rOkA6vWbe57hrc8lzVYpVR01HNBQSSmUftYQHZmHTS9raXO9hpuob8dxI0b5G4NM2Usd0bTmd1xa1xl0GpPuIQZQ8QvdT075MOqGvksX9WzWXvYk9l2nXkBfmFh9Zj4tG4YbUmd0Wcty6Ndr1b9ul/UbrcMaxHxh0RwaazHZS/McpABJI6uu1h6+S3YliNbT10IpqZ01M6PMQIn5r2O52A0GliddkGEWNyPpKmQUEzX07WOc0jygd8o3uBf1rTBjs5k6GfDJhNcN6vk3zZHankHB2vZY81xFjWKGfI/B5C1+RzHAuAaCQCHHLuNTt/2pE2LV8dDHMMKe+Ugl8TXkltnNAt1dfKvsNig1RcRZ6djvEKgzGMSFjRp32K2jHo3U75WUkz8tR0Ba0AkHLmuezs9dgtVNjWIvlcyXB52gPtnuQLF1gdvVf3lYUuL1pja8YO+mjc5pkJDri77ONg3/brdBk3H5XTAHDJxFlY5xI6wzd1tbaX9/YtbOJXOcx30bUdG9zmtIGtwbfA8u247VOxHFKumqBHDhs1QwuaOkYdLOB125EEHsuO1Q347iLGm+BVDnBjXdVxIubEjyb6Zhy3v2IJzMWa/D5JzSyMezJeF24DrWJ7Brr2WPYo2H4+aiGZ01DUROiidK7M3Q25DnryPcexaqjG8Tje3Lg0pGY5rZnXbkJFjl0N7A391+UmPFa51FNMcJlEjWscyLObvLiQRqNLWv6ig4pcadVzQsgo5G31k6QWyjIXD8QB71GZj1QYoL4c8TPyfs7dri1xvyAsfiO1SY8Tr5YKiQYe+ENbG5mcEus469W2paNSAb30Ws4zXMeGDDZphcDpAx7Mwte+Ug2vta+nOyDE8SDI97cNq8rSQbtA2IH45r+pb6jGZGUxlZQTlzZshaW3OQC5dp3DQdtlEix3ExFCZcFnL3xuc8AEBrgNtjv8A5dTJsWq2sgEWGTPkkjjfZ2YBhcSHAnKbZdPigjx8QSXcX4bUBrWgkNbdxJLhoOzQH1HktDMb8XqnRxYW5rpJG58rbXva7jp3n8O1STiuISQSSCkdT2mDBmgfKQ2x1yixOoG2mu6jux/FGl18DnORvWAzdZ1wLA22HW/BBMpscNRA+RtBUMDYXSjMBqR+7pzXMmNObSNmbQzB7pWx5XabtDr/AANvWCk2LVkVI6U4XK6TpujEbCSS2183k+7/ALUR+PYiJszcIqDF0bTk6N2bOd9SLAD1XPLdBmOJG5buw6qHlDVo3A7Nxff1aqbh+Luq6lkfiU8TXtDg99ragm34H8O1QJscxNjGvGCykEZiwFxdbMR/tsLWv6ip2H4lVT1fR1WHvp4jmyPLi65BAAIyi1wSd+SC2XTfDB5ucY9mP5rF3JdN8MHm5xj2Y/msRLzKNkQbIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIg7p4G/OPhfszfKcvTC8z+Bvzj4X7M3ynL0wgqayqxQVToqSjYYw8ASvOhaRqbXGxUetqsbDSaWkjJdTNdYkdWUmxaNeV7+7vVu+spmPLH1ELXjdpeARt+Y+KyZUQvtkmjdc2FnDU2v/AG1QUU1Zj5qGRx0MYjbJZ8mhDmi+oGbnp3iy3muxgYfFIcOaap17xtfo3UW19Wb4d6t6iohp4jJUSxxRg2LnuAA96yY9r23Y4OHaDdBStqMZdJOH0rGCOOTo8trSOBbkO+lxm05dq0wVPELHMZNSQPJLgX30GlwbX7Tb3K8iq6aZ+WKeJ7t7NeCdgf7EH3hbI5Y5G5o3tcO0G6CigrccyRxyUDC8uY0yGwAFus4i/I205rGHFMWlpKsjDgKqINyRnYuJNxe+ugBv/wAleT1UFOGmomjiDzlbncBc9gWRljDwwvbnPK+v+aH4IKGOrx8VBjdRQmMvsJCfJbYa2B1sb9l/drrfi2NB4ibhrDPkzW1y+Vbe/ZyXZbjtCxbLG9zg17SWmzgDse9BSGtxoTFrqCLorEhzXXI100vrp6u3uXFNU422mnNTSxmZsMfRhrfKefKv1thcfAkX2V9cdqXHaEFHV4niMGHyzeInpWyFjW2vmFiQQAeZAHvWnx/HiBfDY26gnK7MbZhcakcri/vXYS9ocGlwueV1wyRkjGvY9rmOFw4G4KDrsVdxBma5+HxFrnlpbe1mjZ178+zlfuVxhctXLTg18IinsCQ3bUXtudtvcpT5GR2zva25sLm1z2LAVEJMYEsZMgzMGYdYdo7dwg2osWSMkF2Pa4AluhvqNwsDUQgNJljs52RvWGrtdPXofgg2ouLjtCx6WPpMmdue18t9bdqDNEuO0JcdoQES47QsTIwSBhe3OQSG31IFr/3HxQZIgIOxXAe0uLQ4XGtroOUWEk0Uf+pIxuhdqbaDcrCSqgjbG6SaNrZHBrCXAZidgO0oNyLUyohe2NzJo3NkNmEOBDjqdO3Y/BcMqqeSd8DJ4nTM8uMPBc31jluEG5FrdUQta1zpWBriGtJcLEnYBbLjtGqAiAg7EIgLpvhg83OMezH81i7kum+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDungb84+F+zN8py9MLzP4G/OPhfszfKcvTCDr9fhuFVOITPmqHR1Mt2OAeB+4G217ntPrsozuHsFdSFvjhDOqTIJWgnLoLm3db4q4rcFoa2cy1EOeQkG9zuARt6jb4dgUd/DOFuD/ANg4Z4xE60jtWgAAb/8AEfj2lEI0dDhHidRTw1rWNMhc92dmYOBuTqN+sNfUsqWhw7Dq+cwV746upZmvJIHWBO4uO5SRw7hoqRP0B6QPDwS8nUbLZNgOHzMaySAlrYmwDrnyGm4G/aEFXPgmDTh8hq3XOZxcyYXtcuNrcgCB6g3sWuHCMCMjZ/G3jyGdHI4N1DmkXaQDcm3xHcrmHBKCGWeSOHK+Zr2vNzqHm7vxWp/D2HySiWSOR8gIdmdI43I2O/u9w7EEWLC8KjoIqSOuPRsY9mbpWkuY8gOadNiQBcWPeosGBYRfoPHs87Qx7srma2JaDa1rXBFu3e5Vm3hvDGwiNsBDRe1nkHUg/wDQWbsAw9zMpjfoGtB6R1wG+SBryQVQwLA5i0MrCcudhDZm9YuJBv2m+nuspldTYTU4U2mfWNhpoyX3ZI1pFgTbbSwPusFvPDuHOILonOAfnAc8kA9bbu6ztO9cfVvDA1jWwOAYx0Ys93km5I3/AORQRaDD8Oo8QbJT4g91Q2MR2c9pGQG1jYf8bfHmuJsHwiaV756sPcXSEZpGdQkdYDTle/aFKZw1hjGPayBzM1rlryDptzXE/DdBNJGbPawFxcwONn3BGvxQa5cGw6srKqqFU5z35XSBrmOa3QWNiCNQOd1phwzCamjhp4ah7YekbI1hAbmOTKNHN/4301vqraiwqkogRTRlgLQw2cdQL2/uVGi4dw2KeOZsB6RhDg4uJ1BuPx1QVcmC4Q+ZrpMQnLy9zyS9ou5pJN+rpq7+yziwDCGZbVxcWt6MdePQZQANG66N2Pf2lWYwDDxN0jYSHdKZiM5sX3Jva/aT8Stb+GcKe1jXU1wxuQdc7XJ7e0oIsOBYTFUUlRHUkPac8eWRobIQ4uJsBY78uQssZcGwaStLXVA8Zle+UNztJJcANrcgdB3ndWdRglFUCMSRutGXubZ5Fi8kuP4lcQ4HQwva5kb7ttlvI42sWu7e1rfggrTg2CxAPfO0PicOs5zQ4OALRy/ywtstMfD+CxtDBXuu5mQXlYSbuPdrqSP7aqybw5h4kfK+NzpnvMjn5iCSd9uVtFlHw5hscIiZC5sdgC0PNiACAD2+UUFezA8FfUiRtSSYx0rm9IMpFgCTptoLnnfVbanBcJkdA+eq6jKZkTWukbldG0ggnTXW2qmx4FRQwSx0zXRGQEFwcd7g3+ICNwGjEEUb+lfkiZFmMhBIbe23PU/FBVyYPhJZMH4hIP2jnSDOwEuIcNere4ubernYIeHsFaJQ+reS9jiXOmbdocW3IPLYa99lZDh3D+lke+N7817AvNm5mBjresBcnh7Ds7XiJ7S0WbaR3V62bTXt/CwQaMMocNw6oLKWsAlcG52ue0l4Is2/8tx6iodPw9gxDYo6p8jujMbbyNcbXuSNN+XqVizh2gGYvY9znuLnHORm6xNj3DNb1ALdT4JRU9RFPHG/pYy4hxeSdd7oKiPBcElpmu8cD43RtLXl7L2GUA3tfkBr2kaLKfBcIp3vlkr5Ii+RjrmVuhboLXHePV3Kb9WMLy2MDicjWXLyTZu2vctzcBoWyZwx9y8SG8jrEi1uewsNEFdFw/g46KJtTnLczWNL2F1yDsbXuA69vUbKXiHDtLXyyPnmqes4uDWuADb5b2055Rvfuss6Xh3DaRwdTwFjhoCHm46wd/cAq3RLr/1Toc73dJUdYtOXM2wy7C1lufw9TuZSN6eoHizcsZ6hI6wde5bvcD/CVdIgqsKwGjwycTU2fpAwsLnWuQTfXRWqIgLpvhg83OMezH81i7kum+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDungb84+F+zN8py9MLzP4G/OPhfszfKcvTCAiIgIiICIiDCeaOnhfLO9scTBmc9xsAO0ldSl8I/DUcjm+OPfY2u2F5B/BQvDO+oZwmwQZhE6oaJrf7bG1+69l8MXe6L6Kx6vFOTJM/Hbg5Ou198GTqUjm++/aVw36VL9y78k+0rhv0qX7l35L4EpeHMpXzOFbIWR5bAgX1Og+F7+5dG3QOmrG+9v6/Dxx0rnmdto9+r7l9pXDfpUv3LvyT7SuG/SpfuXfkvi9TT4bZhgqXXMoa4EGwb27LcaXB7tHjjwMpubEm9zptppYLPubS/d79F+8c/wBvv1fYvtK4b9Kl+5d+SfaVw36VL9y78l8YNPhTn2FVK0dUXy/E7KJXxUkZaKOZ8vWIJcLaaWP4n4Ka9CaW07fu9+iJ6TzxG/D36vuX2lcN+lS/cu/JcjwlcNEgeNyjvMD/AMl8BRa9wabxtzj8Kd7ZvCPfq9T4bX0uJ0jKqhnZPA/Z7D/mq0Y1jOH4JTCfE6lkEZNm3uS49gA1K+b+At85OKs63iw6M9wfrt7v+lSeGd9Q7ixrJc3Qtgb0Q5WN7n4/2XGp0ZW2tnSzbhHPx5ulbXTGmjPEcZfQPtK4b9Kl+5d+SfaVw36VL9y78l8CRdnuDTeNucfhze9s/hHv1ffftK4b9Kl+5d+SfaVw36VL9y78l8WwyPDHRx+PTOa/OS6wNstiANOd7H1LllNhnjbmurHmAMuHFtiXa6fgPj3LGehdLEzH7vfo0jpLPMb/ALffq+0faVw36VL9y78k+0rhv0qX7l35L402kwtxt468XvlNvhcW0O/b61y6lwkNePHHhzRoQM1z2bD/AN2TubS/d79DvHUfb79X2T7SuG/SpfuXfkn2lcN+lS/cu/JfFpqfC2xExVcrn2dYFvMXty56fFVavXoLS2+dv6/CtulM9fD36vvv2lcN+lS/cu/JXOAcUYRjznsw2rbJKwXMbmlrrdtjuF5pV3wU+oj4swo0mbpTUNHV/wBpPW91rrPUdBYKYrWpad4jfjt+F8XSuW14i0RtL0qiIvlXeEREBERAXTfDB5ucY9mP5rF3JdN8MHm5xj2Y/msQeZRsiDZEBERAREQEREBERAREQEREC6XWlanzxskDHuAcdkEu6XUUzRgAmRtjoDfdDPECAZGXO2qCVdLqKJY3AEPab7arKN7ZG5mODm7XCCRdLrSiDddLrSiDddLrSiDvXgb84+F+zN8py9MLzF4GPOThXszfKcvTqAiIgIiICIiDRXUkFdSS01XE2WCQZXsdsQujTeCrA3yOcyeujaToxsjSB8Wkr6Ai3xanLh3jHaY/hlkwY8v+dd3zz7J8E9LxD+dn6U+yfBPS8Q/nZ+lfQ0WveOq+pPNl2LB5IfPPsnwT0vEP52fpT7J8E9LxD+dn6V9DRO8dV9SeZ2LB5IfPPsnwT0vEP52fpT7J8E9LxD+dn6V9DRO8dV9SeZ2LB5IfPPsnwT0vEP52fpXI8FGCAgmqxAjszs/Su84lViho5KhzC9rLFwHZcAn3bqldxVEyOXpKWUSxszloNxobOF+0ODh7lpTWay/Gt55qW02lpO1qwtMEwiiwWhbSYdCIoRqeZce0nmVG4k4cw7iKmbFiMRLmaskYbPZ22K0x8UUb3ta2GpsXiPNk0BN7c78isqjiKKmqHxzQnKC9oyvBcMu+YG1r7jU3C88Rnrfrxv1vjv8ANtNsM06vDZ1j7J8E9LxD+dn6U+yfBPS8Q/nZ+ldlj4mp3RBxp5s5ZnyNLSf7/wDr36LfQ49TVtUIIY5wS8szOaAAbE9t9gV6Z1etjjN55sI0+ln4Vh1P7J8E9LxD+dn6U+yfBPS8Q/nZ+lfQ0WXeOq+pPNp2LB5IfPPsnwT0vEP52fpT7J8E9LxD+dn6V9DRO8dV9SeZ2LB5IfPPsnwT0vEP52fpT7J8E9LxD+dn6V9DRO8dV9SeZ2LB5IfPPsnwT0vEP52fpV9wxwXhPDsxnpGSS1JFhNM7M5o7BawHwXZUVb63UZK9W95mP5WppcNJ61axuIiLyvQIiICIiAum+GDzc4x7MfzWLuS6Z4Y/NvjPsx/NYg8zDZFoGy5QbkWlEG5FpRBuRaUQbkutKIN10utKIN10WlEBRqqjjqSelLspAaWg2Bsbj8Vvyj/Clh/hQQvouC1rvtY9nPc7LJuGwDcvd6zz7fwUuw/wplH+FBB+iqezgc5zC2p2Fwf+lMgiEMYY0ki5Nz3m6yyj/CmUf4UGSLHKP8KZR/hQZIsbD/CmUf4UGSLHKP8ACuco/wAKDu3gY85OFezN8py9OrzD4FwPtKwr2ZvlOXp5AREQEREBERAREQEREBERARR562ngmEU0mR1r6g2A13Ow2PwWAxKhIJ8bgsDY3eBb/LIJaWHYooxCjL8vjMN7X8sLbBUw1AJhlY+wBNjtfZBtsOxYujY4tLmglpuCRsVrqKuCmDDNIGB+jT26XWAxCkLnNFTFdpsesOwH/sIJNh2JYdiiOxOha3MauCxFxZ4Nx3dqOxOiaNaqE7aB4JQS0UUYhRFpcKuDKBcnpBon0jRA28bgva9ukGyCUi4Y5r2BzCHNcLgg3BC5QEREBERAREQEREBERAXTPDH5t8Z9mP5rF3NdM8Mnm2xn2Y/msQeXxsuViALf+1zYIOUXFglgg5RcWCWCDlFxYJYIOUXFguMo/wAKDJFjYf4Uyj/CgyRY5R/hRBko9ZTipjDC4tsbnvGxHvBKkIgrBhstnA1byDrbUC9tdj26rg4fVXt46+xG+uh7tVaIgrX0VR0jctS7oyTfrOuBy5rkUE93E1kh61xvp3bqxRBAiopWTRv8akLGkktJJv8AEqeiIIM1E+SV7hOWNcbgNBBBsBvf/itbMPlDjerkLSbhoJFu7dWSIKz6OmuSa2Qm1mnXTbv7ll4hL0gIrJcgJJbc6jsvdWKIO5+BNpZ4RMHa5xc4MlBcef7J2q9Prx5gGLVOBY1SYnRWM9M/MGu2cNiD3EEhfb6Xw2YA6nYaqhxKKYjrMYxjwD3HML/AIPqiL5j9tXDXo2K/cs/Wn21cNejYr9yz9aD6ci+Y/bVw16Niv3LP1p9tXDXo2K/cs/Wg+nIvmP21cNejYr9yz9afbVw16Niv3LP1oPpyL5j9tXDXo2K/cs/Wn21cNejYr9yz9aD6ci+Y/bVw16Niv3LP1p9tXDXo2K/cs/Wg+nIvmP21cNejYr9yz9afbVw16Niv3LP1oPo1RR09Q7NPE17rWuffb+5+K1twyiaHBtNGA7fTdfPftq4a9GxX7ln60+2rhr0bFfuWfrQfQvoyi6Po/F48gtYW2/y5+K309NFT5uhYGBxuQPgvm321cNejYr9yz9afbVw16Niv3LP1oPpU9PDUNDZ42SNHJwuowwuiDS0U7bHca6/5ZfPvtq4a9GxX7ln60+2rhr0bFfuWfrQfQHYTRPkDnQNNm5Q390DTl7h8FkMMogSfFo7nfTf1r579tXDXo2K/cs/Wn21cNejYr9yz9aD6AcJoi97jA05zctO1/UuW4XRtqHTdA0yHmeXq/uvn321cNejYr9yz9afbVw16Niv3LP1oPpsbGxsaxgDWtFgByC5XzH7auGvRsV+5Z+tPtq4a9GxX7ln60H05F8x+2rhr0bFfuWfrT7auGvRsV+5Z+tB9ORfMftq4a9GxX7ln60+2rhr0bFfuWfrQfTkXzH7auGvRsV+5Z+tPtq4a9GxX7ln60H05F8x+2rhr0bFfuWfrT7auGvRsV+5Z+tB9ORfMftq4a9GxX7ln60+2rhr0bFfuWfrQfTl0zwyebbGfZj+axUn218NejYr9yz9a6P4TPCazifDfovCKaaCie4OmknsHvsbhoAJsL2O/JB8fjwx7GWbVPByhuYCx9d7/AODRZuoagvJbWyBtwQLE2HZurFEFe2hlaSW1TgXOu4akEWtzK2UtNLBGWmfO61gXAkDblfuUxEFX9GT9GGCtksALabW5jVbX0D3GMme72sLMxbr6wb6KeiCu8QmD3FtW+x5G/d39yxOHTaBtbI1oAsLXta3erNEFaygnaLCreGhznWF9z7+RXLaOofTtZJPZwzXILje4sOfvViiCtiw17Cwmoc7KWnnY2t39yskRAREQFHrGSvYwQk3DtbOtpY/92UhEFbbEsw60dgSD6tLLIfSAIBMZGUXt2qwRBW5cQbG1uZjiMpLha5/3BcluIuBGaMbWJHd+asUQVjW4iH3vHaztzfvH5LNzq5rmkhpDnAWaNhzVgiAoVSyr8Za+BzTFpmYfft+CmogrWfSIbrkLrHstc3/touHuxEODRkJsDe2nf+Oys0QVzRiIIBMZbf32/wA2/FYf/EooG3LHv1Btqb8vx3VoiCukdiDWF1mGwAytFye0rZT+PF7TOYw25uAOSmogKA+Os8YeWOGQvFr8m2157+5T0QVtsSu03i537OX+fFIm4k2NrXOjLgHEuPPsCskQVkRxF5N+jY3QajXv/wDSsm3yjNbNbWy5RAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERB/9k="
                                    },
                                    {
                                        "data": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAFcAfQDASIAAhEBAxEB/8QAHAABAAIDAQEBAAAAAAAAAAAAAAQFAgMGCAEH/8QATBAAAQMCBAIECgcHBAIBAQkAAQACAwQRBRIhMQZBEyJRYQcUMjdUcXKBkbMVFheTodHSI0JVkpSx8DNSYsEk4fE0JjVEU2OCg6LC/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAECAwUEBv/EAC8RAQACAQICCQMEAwEAAAAAAAABAgMEESGRBRIUFTFRUoHwQVPREyJioTJCcWH/2gAMAwEAAhEDEQA/AOcRFX1FPVune+CRrRckdbuGhFu4/FBYIoMcNaWTCaZhJHUDdPxtcLW2HEWts2WMDWwuT6tSCf8APegskVZTx4kZw+WRjY7gFpsSRztbbn+Cn1DXPgkbGSHlpAINrH1oNiKsip8QabGdmUntuQLd4UyjbO2G1U9r5L7tFgg3oiICIiAiK3puGcdqoGTU2DYjLE8Xa9tO8hw7QbIKhFefVHiP+BYn/TP/ACT6o8R/wLE/6Z/5IKNFefVHiP8AgWJ/0z/yT6o8R/wLE/6Z/wCSCjRXn1R4j/gWJ/0z/wAk+qPEf8CxP+mf+SCjRXn1R4j/AIFif9M/8k+qPEf8CxP+mf8Akgo0V59UeI/4Fif9M/8AJPqjxH/AsT/pn/kgo0V59UeI/wCBYn/TP/JPqjxH/AsT/pn/AJIKNFefVHiP+BYn/TP/ACT6o8R/wLE/6Z/5IKNFefVHiP8AgWJ/0z/yT6o8R/wLE/6Z/wCSCjRXn1R4j/gWJ/0z/wAk+qPEf8CxP+mf+SCjRXn1R4j/AIFif9M/8k+qPEf8CxP+mf8Akgo0V59UeI/4Fif9M/8AJPqjxH/AsT/pn/kgo0V59UeI/wCBYn/TP/JPqjxH/AsT/pn/AJIKNFefVHiP+BYn/TP/ACT6o8R/wLE/6Z/5IKNFefVHiP8AgWJ/0z/yT6o8R/wLE/6Z/wCSCjRXn1R4j/gWJ/0z/wAk+qPEf8CxP+mf+SCjRXn1R4j/AIFif9M/8k+qPEf8CxP+mf8Akgo0V59UeI/4Fif9M/8AJPqjxH/AsT/pn/kgo0V59UeI/wCBYn/TP/JUOMYTidDXtjq4Z6OTKOpMxzCBrqARY7/ggyRV4p64yRZ6lpjbYu0sXG/cFvxCGaeNjYJDG4OuTmI0sezvt8EElFWNpcQbktVNNr3uL3B9ysYw5sbQ52ZwGp7SgyRQ8ThfNG0MZnIzcgd2kcyO1bKGN0cbw9uUl7jaw/6KCHjOMx4ZJGx8TpC8E6G1lXfWyH0WT+YKLxv/APV03sH+65+ndG0u6VpdcWFuXeulh0+O2OLTHF4Mue9bzWJdV9bIfRZP5gn1sh9Fk/mC5rpKXX9i7Unnt2c1l0lJc/sn5dP7681p2bF6ZU7Rk83R/WyH0WT+YKbhOOx4jVGBsL2Oyl1ybriZ3ROt0LC3U7ncclbcHf8A3v8A/wAbv+lTLpsdaTaIWx57zeImXcIiLmOgIiICIiAiIgIiICIiAiIg6rwXUFPiXHuFU1ZGJIcz5Cx2oJaxzhf3gL1ENBovM/gb84+F+zN8py9MICLkeLMVxk4pTYRw7GxtRKM0lTIAWxj8/wDPVr4cqcXosUlhx3HMNqqcCwALWyB99rC1vxWNM8ZLTWkTO3CZjwiXptpupijJe8RvxiN+M/1tzl2SIi2eYREQEREBERAREQEREBERAREQEREBERAREQEuO1a6iTo2E81WVVS2CGSeokDIo2lz3E6ADcq1azbwVtaK+K3uO1LjtXK4NxDQYxLLHRTudJHqWuBBI7R3KYMRpi8sFQ0vzZcouTfUf9H4LW2nvWdpjipGalo3iV9dFWxyuYb3JCnB2ewabXFyVjauzSJ3bEWiR8EcrI5JQ17wS1peQTbeyZ4P/wA0bX/1Dt8U2N29FGbNTOeGtmaXG+nSHkbdvbotrA1zc0byRyIdcJtsb7ti4Pw14fT1XAdZUzRtM9I5kkT7atJe1p9xBXdsN2677Fcd4YPNzjHsx/NYoS8yjZEGyICIiAiIgi1uH0taWmqhEhboCSRb4KN9A4b6K3+Z35qzRXjJeI2iZVmlZ4zCs+gcN9Fb/M780+gcN9Fb/M781Zop/VyeqeaP06eUKz6Bw30Vv8zvzW+jwyjo5TJTQBjyLXuTp71MRROS8xtMymKVjjECIiosIiICIiAiIgIiICIiAiIg7TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphBxHGDsZwfHKbGcJojXUmUx1MDP9TsBH4bDkuSjwscWcTU89Bw/U4ZAJ+nq6qpc68hvcgA6du3byX7IiaWbaS02wTtvvv8A+7+LzZtPOe297bxw4cPp5eQiIj0iIiAiIgIiICIiAiIgIiICIiAiIgIiICIiCPWMLourqRqqqsgjraSankLgyRpY4tNiL9nYVenVaH0sTzdzRdXpea+CtqxZyXD3DjMIqJJ3Vc1TIW5GZybMbpoBc9g+CmOwaldKJCXl7Xl7SbHLck6Ajtce9X/iUP8AsCeJQ/7Atbam9rdafFlXT1rG0IV8xyt1cVYsb0YB5WsUigZH5LQFtWNrdZtEbK+vw6jr5BJUdZwblaQ+1hrf4g2Kiy4BhsjSC0gktNw7Xq3t/dXSWUxkvHCJVnHWfGFH9XcNztcMwyvzgZtL7H8FZUUFPRU7YKewY3ZoN1KsiWyWtG1pK0rXjEMWAga7nVcf4YPNzjHsx/NYuyXG+GDzc4x7MfzWKi7zKNkQbIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIg7TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphAREQEREBERAXN8eYtV4PhdJLQOLZZqyKnLhTuncGuJvZgILiukUDGsIpMZpWQVolyRyNmY6KZ0TmvbsQ5pBHxQcTReENtJSmLFmiWu8YmjY0sFG4xxtY4ueyR3UcekbZt9QQdATa2k4+wyOkdUPiqQwASZSwB3Q+L9P0tr3y5QW+0LKb9TcHEYDGVbJs73uqW1koncXNa12aTNmIIY0WJt1W9gUp/DODyVRqJKJj5DRHDjmJINOf3CL2Pr3QVM3GboauGhkwWtGJzSRsZTdJFctkZK9r82bLa0MgIvcEc7gpxli2LYfWwNoi+Gi6Fz5KiOidVlsl+qHsYcwZa5uAdtxbWyouFsLo6mGpZHPLUxSNkZNPUSSvBax7Gi7iTYNkfYbdYnfVbcX4eocVqmVM5qoqhsZiMtNUyQOcy98riwi4v27XNrXQc27wgUtJZtQ+GolldGIuikbHEQYGSuc2R7hdvXFrgHUC25V7V8SwxcLwY7BTyS0ksTZi1zmxua0i4uCdTewsLkk6XWLuD8GDWiCnkpnMLSx9NO+JzMsYjAaWkEDI0C22gO+qkYjw3h1fh9DRTsnbT0T2vgEVRJGWuaLNOZpBNr87667oIcHFkToHOqaCqppmT0tO+GTLmY+fJlBsbaZxf1FasbxWvdjtTh9DUx0UNHRsrJ5jTGd787nta1jAeXRuJ0J1AFlJdwjhT6uKpkbVvljfFJ16uUh74zdj3DNZzh2m+w7ApeL4BQ4rURVE/jEVVE0sbPTVD4JMpNy0uYQSLi9ig56k46YMN6aWB1aKWnE9fU0rckcTekewuDJCH3vG8ltiRlOp0vun47pYIxPNQVbaWZ0sdJKCw+MvY7LlAzXBcfJvYEDWymngvA+jjjbTSsiazo3sbUSATNzl9pet+06znHrXvmdfcrXiHBmGzU1WKaMtmlbKIxNJJJFC6Q5nFrMwDbnW7bHsIQVeIceeI1knj1FLRw0ZnbVxvLXucWxRyNyEOtY9IBrb3K1wvi6mxHBsVroaaV7sODjJFE9kmezM/Uc02NxpvuCFFwfgajhgrfpg+PT1cskjyZJCGh8bIy0Fzi46RjUm4O1tF0OFYTTYZFMyAzyGZ2eR88z5XONgN3Em1gBZBzVR4RsHhFa7JUPjpXPzOYAQ+NsZeZG66tzNMftd2qgYl4RG/RlVUYdBeqpmTuMRcyVjyyB0reu11raa21uCOwq/pOCOHqWLo4cOaGeJuoCC9xvC55eW6n/AHEm+/etp4Rwl8D4qiOoqQ8PDnT1MkjiHxmNwzF17ZSR+O+qCqb4QaBuJmhlp5BMx3QyZZGEtl6PpCMt82X93Na1+7VG8eB1H4z9CV4jbBDVSjPFeOOVxEZIzak2JIGw+CtYuEsKjn6UNqiTq5jqqQse7J0edzc1i7Lpc6899VVY/wADtxKopmU1QymomQwU72DpM5ZE/MASHhrtNBnBtqdb2QQMS8JNM6kxAYXC59RC2QwkuY/pDHIGuBaHXbe5y5rXA5KdW+ECkoXup6yilgxBsz4XU8s0TQMsbJC7OXZT1ZWWF73PcSrb6oYRmnvFOY5c94TUSdGzO4Pdlbms27hfT/tbK3hfDKyplqXxzxVUspldNBUPifcxtjOrSCAWsYCNuqDvqgrKDjimrqqFsGH1nick0EHjTsjQ18sTZGAtvm2eAdNCfh1yqIeHMLgblipi1vTxVFukcevGxrGHfk1jRbnbVW6AiIgIiICIiAuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB2ngb84+F+zN8py9MLzP4G/OPhfszfKcvTCCHLilDFO6CSqhbM3dhd1hty//cPipHTw5M/Sx5d75hb/ADQ/BVdZw5htZWy1c0TjPLo9weRcZCz+x+IB5LGr4Zw2qpaankicI6eJsUeV1rBpBaewkW59p7SgtvGIet+1j6t79YaW3WElZTRgF88TQXNYLvG7tAPWVRv4MwZxjIge0xscxuWQiwcXE6c9XX17G9gWTuD8JcxjOieA0MabOtmDTcA++23Ygu3VdO2N8jp4gxjc7nZxYN7T3d6xiraaWPOyeMt7za2ttQdtdFWUnDGGUsMkccTiJI5InkusS19s23shKnhqjqXl9RJUSyFuUvc+5Ou+3utt3K1Yr9UcVqyrp3nqTRnl5XPX8is+miyB/SMyEXDswsQqE8IYTnDhFJYPz5S8kXuTse83W93DdC+Gkif0zo6YODQX+VmNzf8AJTaKf6ycVhNiNHCJDJURjowwus65GY2bt2nQdqNxGjc2NzaqAtk1Yc462hP9gT7iq6Dhqgp4po4OljEnRah2rejdmbbT/drrf4KPLwbhUsjnvE5cXB9zJezgCL/iT61RLoGyxuzZZGHL5Vjt618E8Rk6MSs6T/bmF/h7iqyi4eoKKCWGnY9kMsJgkZm0c27j/wD7d8VjR8N4fSVTKljHuqGyPl6R7rkufbMfwCC5REQEREBERAREQEREBERAREQEREBERAREQEREBcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEHKYpVcQN4rp4aFkhwjPEJ3dADa972JOo2ueVuX73SV7pm0kppW5pgOqPy718lraeKuho5JQ2oma5zGdoG/wDncewrdNIyGJ8srg2NjS5zjyA3KCgZX402Oxw/OQHWc4i5sere1tSOVhbfuWNLiuLz1DsuHt6IStjNzawtdx77XtfbRXXj1J0TJDUxBjwC0l4F7i4/AhaIcaw6bo+jq4z0gJbe40ABO+2hBRCvmqsajqHGKl6VmZ12usAwfu2O7hvf3L5LX470BLMOjEjmEgZs2V1nabi+oB5aG26uzV0wc1pniDnNzgZxct7R3d6xlrqWEuElRE1zbXaXi+uo0QV7K3FDSZnUTWzdPkDdSMlr5j2cxz5e7Gor8VFLBJT4aHSvz52PfbLY9X4jX3W5qdHilC8yAVUQMZs4OdlsbA8+4j4rdJV00bM8k8TGWBzOeALHYolTeN441ko8Tje5jn5T5OezrNFr7Ea3WH0rixq3QMw9jyx7WvNyBlI39/4K3diVE12U1Md+lEOh/ftfL67LBmL0D44Xsqo3NmLAzLqet5Nxyv3ohElrcVjoY3jD2yVLgbsa6wBu234F3w71iysxbpajpaMBkcb8mUX6RwLcpGvPracrbqwfidCxge6spw06g9ILWva/qvoshX0jnFoqoC5pDSBILgnl60Fc+txU0kjm0YE7Cy2lw+7jmsL38kA+/uWk1+Ol5LcOiABk6pde9hdut+Z099+SuRW0pjY8VMJY92Vrs4s49gPMrHx+jNv/ACoNRmH7Qai9r/HRBSfSGPCWQ/RzHMIZlF9B/ud26adXfvVthU9dM15r6ZsB3aGuvzIt8AD7+5Zy4jSRRskdOxzHv6MFnXu617aX5ArI4hRgXNXTga69IOW6JSUUWavpYaTxl0zXQXsHsBfc3tpa99V8OJUILQauAFwuAZAOz9Q+IQS0WkVVOXuYJ4i9oLi3OLgA2J9SwkxCkjJD6mEODgwjOL3Owt2lBJRQvpah6YxGpjDwXtIPIttmv6sw+KyOJUQkaw1cGZwLgM42AB/sQUEtFHZW0r2lzKmFzRuQ8ED/AC4WLMQo3xyPbVQlkds7s4s2+10EpFqNTAGZzNGGXDcxcLXOwWr6Rotf/Mp9P/1G/n3H4IJSKGMUoTOYRVRdIGh1i62hvbXvsfgpUUsc0Ykie17HbOabg+9BkiIgIiICIiAuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB2ngb84+F+zN8py9MLzP4G/OPhfszfKcvTCCpqsCgqMS8dfPUNlzMcA0tsMpBAGlwNNr8z2lWNTBHVQOhnbnifo5p2I7D3LW6vpm4iyhMzfG3RmURc8gIBJ7NSPX7imJdP4jL4pm6e3Vy5b78s2l/WghDh7DQ5rmwuGV4kaBI6zSNBYX0FgBbsCw+rOFF5cacl1iLmRx0PvUI1PEjXZY6OJ7GhxD5C0OfocoNnWvq29uYPJTI6jGvE6h8tJCJwxnQsbY9Y+Ve7tufL3ohIlwShljYxzH5GRCFrRI4WaOQ109fPRYy4FRTVMs0zHve8m13kBl2BhtbtAUepmxeWhlaynkhqOkDGPi6MnLc3fZxIta2m9/iotTXcQQNleaNhijc3KWgPc8He7QRseyyCxbw9honZN4veVjg4OL3E3Gx3Wb8EoHmPNE4iONsTRndYNbtpf8VAlrsdZCD4hG57tQWgEC77AEZxrl1voP7Iysx+SRuWhgbGXPBc/QgDyTbNrr6r9gQTnYFh7qd0LoXOjMnSWL3aOsRprpoVrbw7hrXFzYHAkMH+o7Zvk8+SiyT8RCHMylpzIGg5LjV2bUXzaC3rPrWuWq4lMByUNMJHB4ADgLdUZTcu5uO1uSCf9XsN6Rr+gN2tyDrusB8e4JJw9hkmTPTA5XF46x3IA7ewWUPxniJrnkUcLwQ0tBLQAeY8r8e61tbrI1PEXTPZ4lSmNuaz7+Va9tM2l9B3XQSarh+inp4YA18cMbmnK1x6wGXqnu6jfgtH1Uwwyhzo3GIBwEWY5QXWu71mwW+qqMXFVIylpIjCxzbPeR1xzt1tPWR8VGkfjxo4JGRt6fNIZY7NboHXYBqQLgZd/wB6/JBOkwShfSGmMThCXBxaHuFyGho59gH991oh4bw6N0LnRySSRFrmudI7dosDa9tgPgogqOJGPsaWB4YJGg3FpCLZHHrC19ToOdtN08a4kD2EUMDmuYC4FwGV2twOtry/w6BZuwaidRGkMbvFrgiPMbAg3utMXDmFxOJjprXFj13ai9+3t1UEVXEhe0eJwhrnAud1eqMovbra9bMNe0L4Z+JXZQKWFpFx5TQDoLXNz37BBOg4eo4ZpntMpZLHJG6MvJBzkFxvvc5QtgwKgD2uET8zX9Jm6R1ydN9ddgo9LU46+qAqKKCOnzanMC4tzAf7tDYk89rd6201TizqrLPRsEJe6zrgWaA61+sdSQz4nsQZzYBh00ssklPd8t85znW5udL/AOaLU7hrC3BwdA8hzQxw6V1iBbfX/iPgFHin4ifHFI+lpmPFs8V99ddc2mljzWplXxMGEuoKcvJ8kuADdtjm1vr6u07ILB/D2HPlkkdE/PIXFx6V2t9+a3nCKPopY8j7ShoeekddwBJ1N+0n1qO5+MSYXOOjjirrt6IttlscpN7k7dYe7RR6SXHgZHzwssYpXsYcuj8wLGkg8hcd9t0SmSYHQSQPikhL2Ol6Yhzyeta3b2Eiy0jhug6V5e17oy0MbGXHKwBmTT3LRTVHEJkyzUlOIw5vXJF3NsSdA7Q3sOdu9YzYhjjsQnhpKGJ0LHgCSQFosSdjfraAH3213RCU/hrCnhualByhrR1jsNuatKaCOmi6OFuVmZzrXvq4kn8SVRMq+In5b0FPEXEDVwdkF7Emzhcga2G999LH4+r4jAbloKUlweT1/JOuUeVryN++2m6DokVDHU4+alzZKOmELXtAeD5Tbam2bTX4d6Vz8eD5hSRwlgcCwutcjPqL3sBlFtr6olfIufNRxEWuLaWlFi7KHDUgZcv7+l7u05W71h41xEZS40UTWCSwaC09S3lHrb67aXtug6NFzr6viQNblw+lJc1xIz+SbnK3yteRvpvZXlIZnU7fGmtE1yDl2Ouh3O41Qblxvhg83OMezH81i7Jcb4YPNzjHsx/NYg8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO08DfnHwv2ZvlOXpheZ/A35x8L9mb5Tl6YQQZsJoZ8RZXy0zHVjGhrZTe4ANwPipNWJjA4Uxa2U2sXbDXX8LraiDn2sx8Oa57oHOyNDsugvfWw7ezu70bHxBHJHaWB7MwDrgeTbXs1v+A7V0CIKaQY6KOnETqR1TmtKXggW01FuzUWWTGYy3D4gH0xq83Xz3yhtuVtSdB8SrdEHPubxC6n/wBSASODx1QBbTqnnrf/AKWIZxGM7y+lzHK3JbS2uYjv2tfluuiRBV0f0sIZm1ZgMzmExuYOq11zYEb2tlPx7lFpRxB41C6pNGIiR0gZc2sTe1+0a+u3JXyIKWb6cc6QxeLsaC8NFrlwt1StDfrGWOLjSNIFw1ovrcaX9m/Zr3LoUQUdXBjDqmN9O9gsGZ7u6hFjmAG972N+wLBg4hEbXPNKXa3ba3MW19V7q/RBS0jccZSzid1O+ZrGdFm0D3Ada5Hbry0utb28Q5Zcj6MuDnBgc2wIuA0n1C59Ysr5EFABxGQ85qIOAGUWNibi/fa1/f3L7QR46KqPxqSLxYSOcbAZyw3sDyuLi9uwW5q+RBzzhxL1rGg/eDbA66dUn8fw71lk4gFQ/LJTmMudYuA0Fuqr9EFbK7ExSQiJkRqA4NkLjoRbVwUaJmOCRxlfAcsDw22jTJcZb81dogo8NZjbKu1W+E0xLjc6vtbS9tN7bd/ctMDceha5oZG/qbySBxL8o1BtoCb6W0/AdEiDmJIOIyJHdJFd0YAa1wFn9W5220PxUyWPGSynaySO4fIZCbai7so9Vsu3YrtEHO34l6Nv/wBJnya6bOvy11Hw071vrIMWeKUxyjpA13SFrg1odmaRccxlDh7/AHq7RBQtbxBlfd9KCM+UBt77ZefZf39y2ULcb8YtVvgEJjJJABLXn4aDT8e5XSIOelZxFI2QZ6WPM0kZBctOQ2AJ7HaXttbvWf8A9oc//wCFy52WFv3ba313v/6V8iDnmDiN1w51IwWNja58k29+a1+7Yq7pOm6BoqbdKNCRs7vW5EBcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEHM4oziVuJ1EmHvhfRgHoo35QScl9eflNy77PJ5LZTycSufEZoaJrC6MvaBqG2648re+3/atarFKOlnbDUTtZK4gBp0OtgD6rkC/aQN1KmljgidJK8MY3dx2CDmKt3E8NTXPo42Ts6QdC2YsDctze1jc6W3I9XMzcXlxuSSnZhkDWdEQ+d73NDZBYAsbub6k621aNbFWDcWw9wcW1tOQ0BxPSDQHQH8VjNi9HEIXGXMyUEtewFzQA4NNyNtXAIKjD5eJ44axtZT08jmRuNO4OF3vvoDYgDn+Gu60MqOLmwdejpnTubmFi0tacnknrg+X2X0V99MYdzrYBbNfrjS2/wAFnBidFUSGOGpjc+xOUHWw529x+CDnm1PFc0jbUtPGGSsDgQAHNyXdrmOmY7geq+pWRqOL/F4nCjoOldcOYT5PYfL2Pdzt26dAzEqJ8bpGVMRY0Ek5tgLfmPiFqdjeGt3rYLWzF2bQC17k7BBCqzjsGEzy0rYqnEnPIZE6zYw0EgEa31FiQSd1FmquKi9wgoaMDUAyOFtA3XR19Tmt3Wurh+MYewuDquK7XBp617Emw/ujMYw983Rsq4i67Ro7QkkgD16f27UFDE/i2SrDpIaWGK7XFoIcCMhu3e/lEC/dfZbcNn4pbk+kKalMcd8+SxfILttbrAA2zHbcW2V5LilDE/LJVwtd1jYvH7psfgdEbidGWwuM7Gib/TzaZtbae9BXYrNxAyrIw6mpJKbpGWc89bIQc19RsR8Dtoocs/FzJC2Olw6SNuUZ7kF19SbZtAL2tfkT2BX0uJ0UWXpauFmYXbd4FxYG/wACCtMeN4bIXBtZDo4MuXWuSARbt0KCjqJuLwYzFTUbi3K4htgHXb1gbu3BOlt7akc5gl4lGHTuNPQurbjo2ahti5wNzm5DK7v1CsxjGHFod47BlIBBzjX/ACxW2kr6Wsc5tLURyloBIYb2B2/uPigqI/rA/D5jUCJlRdha2C2a2e7wC42vl0F+fPs1GbiRrgyOmiMV2AOlLS+1tSSHAXvuQNOQduulRByUU/F7ImCSlo3vyuzkOB1DBa3WG7r/APpTqufiEiNtLS0zXGBrnveQ5rZP3m2zAnnqr9EHMS/WKSmkL2vZJ40bNpzECIuiIFi4kEZ7HXW3LktD5+MA9xbSUZDS9oFxZwu3K7yr/wC7TTftsuuRBz75uImUUJFNSyVJqGB4Bs0RFgLjq7cOuPdeyjST8UytjMdNTwODS4tcGuBcA6zSc/M5dvjyXUogp8TnxkzU7cNpouiky9I+a14x1s1xmFz5Nrd/cpeDurnUEZxVsTav98RCzfdqf7qaiAiIgIiICIiAiIgLjfDB5ucY9mP5rF2S43wwebnGPZj+axB5lGyINkQEREBERAREQEREBERAREQEREBERAREQEREBERAREQdp4G/OPhfszfKcvTC8z+Bvzj4X7M3ynL0wgi/R9J40ak08bpy/pOkcLuDsuW4J20uNO09pUiWNkrMsjQ5twbHuN1V1DcX+sMMkJpzhIhLXsLiH5y4dbbWwBttuVPr2zuo5RSECoAvHc2BcNQD3HZBE+gsMylviceU2u3WxtsLdnO3bqthwmiLIWGAFkIIYC42FyCb666gHXmFVwU/EMT2xuqYJIy6xe5t3Zdr+uwv6ye5fadvELYIonup72jDpDYu08vuv2fiiFk3BsPa14bTMAcSTYnnvbsSDCKCB2aGnaw9H0V2kjq9m/r+J7VXxy47JR1QEcLapr8sZcLNO+3aPJ/FfZDj5L8rYALZW5SLg2F3a7630005hEp7MHoWMe1sAyvZkcC4m407T3D4DsQ4Nh5aGmljLQALHsGov26lV1Q3iBz88Jp25XWsTu3tt2r5DFxCxzw6amcDncCRfXMS0eq1h6u9ELD6Ew7Ll8Ujy5Wty62Ib5OndbRZw4RQQG8VLG03B58jcfBR5hjAhibEYDIekD3nlr1Db1WutPRY26OpDpYhIWxiIjQXv1j8ESmuwige6RzqZjjJfMTc3ubn1a6r7JhNFIGB0RIY3K3ru0F83bvexvvdQoGY62oiEslM+ESEO6upZpY+sjN77d60mlx5tRM5lVC6M5uia7lrZpOmump70QtJsJoZsnS00bixrWtPMBt7D8T8VgcFw8ua7xVl2lpbqdCBYW7NAB321UFjcfa7oy+nLDKP2vMR3N9O2xb8ClNLjklPVNmjY2oaWBjmgBt7nMRfcZcu/O+vYSljAcM6v/iMJb5JJJtrc8+dzftUymo6emN4ImsNg3TsAA/s0fBV4GMvp2gugil6UBxAv+zyi9u/Nf3WUVn1ky/tDR5rHRo0BtodTttp29yDoUVHTDHnStM7qZrAWEgC9xpmF/Vf39yvEBERAREQEREBERAREQEREBERAREQFxvhg83OMezH81i7Jcb4YPNzjHsx/NYg8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO08DfnHwv2ZvlOXpheZ/A35x8L9mb5Tl6YQVz8aoGY7Hg7pwMQfCZxHY+QCBe+3NTp5mQROkldlY3c2utdRR01S+N9RBFI+MhzHPaCWkG4I7NQFnUwR1MLopm5o3WuL22N0Ff9P4XZxFZGcoBOUE2B22Hu9ei2Oxmga/KagZutplP7u/JbG4XQNa5raSEBwykBgGnZ+CfRdDlc3xSCzr3GQc90EZvEGHOcQ2oBOXO3/kLXuPd2r4eIsKAYRVtc137zWkgXva5tpfKbdvJSfonD+r/wCHBoLDqDbayfRVBkDBSQ5RYgZBpa9vhc29aDTU45QU9+km06JszSASHNdexHw/Edqxk4gw6N0bTOS95sGhhuN76W5EWPYpcmHUcg/aUsLuoI9WA9UG4HqBWBwqgMpkNHB0hJcXZBe53PrKDD6Zw/xWOp8aj6CR2Rr9bEr63GKBzg0TgEi+rXDt7R/xd8Cs3YXQuhjidSQmKM3a0sFh/lh8AjsKoXOc51JCS52c9Xc66+vU/FBp+ncOLsoqW57ElpBBABsdD3r7HjeHSSBjKpheXNblAN7u25LJ2D0BiMYpYmtydGLN2b2BZU+FUNOxrY6aMZQ0XIudBYG/ag+V2LUdFMIqiXLIQHZQ0k2va+neVo+n8PzRjpiM7nNHVO7Rcj4bW3UmbC6KZwdNSxSODQzM8XNhyuhwyhMjZDSQZ2m4OQaHZBo+ncO5VIIy57hp2/793YVvlxSjik6OSdofcAjU2uL69mh3UWXh7DZOnvTgdM0NdbSzRyHYpslBSSvzyU8Tn9XrFoJ0vb4XPxQRpcboY4IpjK4wy3yuDCdiAdN+YR2O4a17mmqZmaCSLHYGxOylGhpSxrDTxZG3sMosL2/ILA4bRFxcaWEktLT1BsdwgjyY1SR1lRTyFzTAQHuJFrlodte+xHJfHY/hjd6ptgLl2U2G1r6f8gpb6CkfK+R9PG57yC4lu5ta/wAAAtbsJoHEk0cFyACcg2GyDRFj2HyCW04HRyCIixJLjta297G3qR2P4W22atiAILgTexA5jtHL16bqQMLoBKJBRwB4dnzBg8rt9a0xYFhsb3uFJEc+hDhcAdgHZrsgnwTMnibJE7Mx2xtbu2WaxjY2NuWNoa25NgOZNz+KyQEREBERAREQEREBERAXG+GDzc4x7MfzWLslxvhg83OMezH81iDzKNkQbIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIg7TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphBzFRh+NDiU1kVQ59AZGfsenIAboHHLa3bor/EfGPE5PE/8AX0y6gcxfe42uqmu4qw6hxCajqTKySEXkdl6oFg7t/wBpJ9TStsXE2EyvY2Opc4vcxrbQvsS8Xbrb4nlzsgjCm4kLJM1dSh2UZMrB5Wl73bta/v7ltdBjxzEVUA8uzdLG/k65eX/ySvk/FWHUs1THWmWmbA8ML5Gizrki4AJda4teyl4rjlDhgozVSWFXII4rW1JGh9V7D1uCCubR8QhzS6spzmZZ4ufKy2uNNBfXRDScSGJhdX04laRcNaA06Ozfu97berXvk0PFGFVkVQ6OoLXU7HSSsc05mNB1JtfuOnaFp+uODCPpXVD2w2DhI6JwBBtlI01Bvy99kQzrKHGJZqd8VbGwNjYJWgkBz9nEd1iSO8Ba20nEOSFz66AzN0cAAGnXcjLrp6v7raOLMIDHOkqHxhpeDnifYZdTra1rbdvJSqDHKLEJgyhdJOLBzniMhrQQSCSbXvYjS+u6JV1UziRkTnxywue5z7Rsy9Ufualvx/DtUyohxl1fK6GphZSZmFjNM1gDmB6vM2WA4qwY0xqBWjohYE9G7S5I2tfcFR63jPBaWF8njLpQw2cI2G4Nrga210tbtQbGQ8QZYmvqICL3e4OF926DqWOzhy3HYoz4eJ4xGBPTySubYvaAGtdfcgjax5a6D3ym8W4OZ3wuqHtla8xhhidmcQAbAAX52sdbgqbVY3h1LRQ1dRUhlPLH0zHlpsW2Bvt2G/qv2FENeGR4tFKDiE0U7HaWYAMugsdt75r+sWVc2h4ikkJlromBxj1YdgHkusMu9iBfYgahSm8WYK4sHjoGdwY0ujcA45c1gSOwi/ZcDcrB3F+DeLOnjqZJWiN0gEcLyXBu4Gm/d79tUGoU3EUbZ3+NQOPXc1jTe50sNW6Df3nms8PbjnjjBVuywPZcm7SWHKRY6b3sdNN1KouJMKragQUtV0spcWWbG61wCbXtbYEjttovlJxJhdZPDFSVPTOmcWMLGOILhe4200BPZb1hEtPQcQOeC6qpmjVxDRoDl0aLt2zbnmLbFZz0eL/SE0tPWtZTvfHZh1ysF81gQbHa3LfuX0cS0DYWTVJlpopGdJG6Rt87NOv1b2BuB1rG5AstLuL8GYajpKksFPI2OQuYeq4gEC1r31ta17goM6WlxzoHisrIHPdC5gyDKA83s7a+mn/ytbaHG4ogKeqiYRFaz3uku/NuS4E2sT77clMHEOGGAzNqS6MTmmuI3H9oASRttYE3271EfxdhTYmSZqhzHxPlDmwOIIba4va19besEbohploeI5AW+PQBrspPI3sL2IbpqD8T7pEsWPNa54nhs1xsxliXty97dDf3evZbJuJaCCuqKWbpmPhlbCT0ZIc5zczQ0DU3F9huClbxPhdDUzw1Uz4+hDc7zG7LdxIABtqbjleyDTQQ8QuMT6ypga39m50YaL8s4Jt2X259y6BVNLxHhVXWtpKera+pc5zAwNde7Rc8vX67LA8TYS2ESvqSxhJAzRPB0cG7EX3I+KJXKLnW8YYS5s5a+d3Q6ODYXG562mnc0nXlqVudxVhbMpkllYwmxkMTsjTpu61uY9XOyC8RVFLxHhtZHI6jnM2SN0pGUsBDbZtXWFxcbnS6jDi7CWQ5quZ9JKGtc6CZh6Rgd5NwL73HxF9UHQIqKTizB4nkSVRa0NLg8xuAcA7KbaajMQLjS5AV1BKyeCOaFwdHI0Pa4cwRcFBmiIgIiIC43wwebnGPZj+axdkuN8MHm5xj2Y/msQeZRsiDZEBERAREQEREBERAREQEREBERAREQEREBERAREQEREHaeBvzj4X7M3ynL0wvM/gb84+F+zN8py9MII81DSTvc6algkc7yi+MEnQt19xI9RKxZh1EzLkpKduW1rRgWtt8FFlx2hirZ6WSQslh8u4sALNN+8dYfArZDjFHNMYmPfnFyQY3CwAJvt3H4IM34Th0jpXSUFK4ynNIXRNOc9p01WbsOo3TSSvpYXSSNDHFzAbt009Wg07go309hl8vjbc1sxbY3AvbayyGNYeSwCpb1yA3qnW4v2dmp7OaDc3DKBokDaKmAkblfaJvWHYdNVrGC4WGOYMOowxwAcBA2xA25clpbxBhrpmRioF3+SbHU3tbtvdYjiPCywOFU06gENBOW5AubbAFwF9kE12G0LgQ6jpiHXuDE3W+/JbKekpqYWp4IohlDeowN0Gw05KI/G6BscMhnHRSte5rwCRZpAd8L/gVqdxDhrYmPdOQXnKGZDmvppb1EH1INowPCQ2wwyitly26Bu17222us34Phkl+kw6jddxec0LTck3J23usGY3hz6eScVTBFGcr3G4ymxNj8D8LLEY/hjiQyrY8jkwFx/Adunr03QSPoyg6XpfEqbpcxfn6Jt8x3N7b96y+j6MwshNLAYmXysLAWtuC02HLQkeokKNSY5h1U+NkFS10j9A2xuDpv2akD16KSK6mNPLO2UGKPy3AE20B/sR8UGAwugGS1FTDJq39k3q+Ttp/xb/KOxYnCMNMHQnD6Qw2tk6FuXe+1lnLiVHFTRVElQxsEjQ9jzsRpr+IWtuL0T2Tujmz9CCXgNIItuNeYuLjldBuhw+jgkL4aSnjeXZ8zIwDmsRf12J+JXyDD6Kne10FJTxOacwLIwCDYNvoOwAeoKIOIMNJf/5HVaxshdkdaxvbl3X9Wq+R8Q4Y9z2+MhrmucyxadS0XNu3QoJBwjDSSTh9ISSXH9i3Unc7c0OEYaWFhw+kLTYEdC2xttyX2pxSlp6WGofITHMWhmVpJNyAD3DUbrTJjlE2jkqY5Omjjf0b8luqe8mwHrugktw+iY1zW0lOGueZCBGLFxFi7120usBhOHBrmigpA1wyuHQt1HYdNlrZjWHvFQRUsvACZRzaL/8Ax8QsTjtACwdKSHSGO4aSAQCdTy0afVpdBJkw6ikqG1ElHTvnacwkdGC4Ha9+3QLGbC8PmfK+ahpZHy26RzomkvttfTWy11GNYfTzOinqmMkBAIIO5/8AYt69Fqm4gw2K+epALS3MC0gtBIFzcaDXdBKjwygim6WKipmS3Ls7Ymg3IsTe3NahgmFBrWjDKINa3IAIG2Db3tttfkvr8YoGxwSOqG5Jg4xmxObLuNt9DotM3EOFxRue6rZoL2ANzpfT3EfEBBsGB4SCCMMorg3B6BumluzsW0YXh4c5woaUOdbMeibc22vpysPgtH09hmfJ42zODYtsbg7m4tpbn2c1liGNUOH1IhqphG/IJDfYNzBtz+PuB7EG0YXh4hdCKGlETmuY5nRNylptcEW2Nhf1BY/Q+G5SPo+ksW5LdC3a4NttrgH3BahjlBY/tSCJDGGuaQS4GxsDqtTeJMMuc85js3N12kaafqH49iCWcIw05r0FIczsx/Yt1PbtvqVKhijhjEcLGxsGzWiwChuxeiEQk6a7DL0NwD5Vr2tudOztWufHaCnmayabK10QmEliW5SbA3QWaKBBi9DUSujhqA6RocXNDTduXe+mlr29eijs4iw17rRz5znEfVadCQTr2bHfmCEFuirDj2Fh5b45GXC5Ibc7b7dnPsGqs0Bcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEFBXVmEtxKoirqRoexjiZnxghwytc63M6Bt/ZHdfWcUwSIvHQmNjY2npBCQC12YCxtfa59RWWI4thUOIyU9TR9JO57InO6Jrrki4vzsO/wByiy8QYRlfGcPJJMZex0bLWed9zci503/FEJFLVYGJDGylawsd0OYxXBvl59hLwLlZUlVgMssbIIIy+QkN/YEX1y3uR26X5rVUYtgraanq5aDN4yH2vC3N1dCDfvsFqqMbwcVMbn0U3jFO4BgDAA1zhfkbb/jsg3mp4eY9sYgiLgWsaGwHdwzNbtzWBr8DhbEJKFscUtOyov0IIDXOFgQP+QHddfBjuEjpIjh0gfZ0kjOhbuLh1zex5+tWGI4hh1FJDDJA2R8oayNrGNOYa2AvyGX3aIIj8VwEM6N8YLYhI3KadxyC9n8u3Qr5WVOD02IPjqcPaDFZ3S9ECNGjUeoOA7veL4HHaB9LW1UFAHtjbG92YNDn9I4t1GtvJ57+qxXypx7Cs8jqnD5S85o3l0LXXLLEtJvyuO7X1oNgxPARTPijga+Jz2kxiA2c7R19RbTQ3WyGowWWQRQUjXF7dbQZQBYuF7gW8i/wK+PxXC2UbZZKEsY2oEAYY2Xa+wIOhtYDmFEp+JsKZDFmoXRO6xDY42m1jY9h2dva2pG6DfDi3D8AD2RsieG57dAQW6jTbe4Bt70mxbB6eN0bKUlksrWyhsVgCRo49trDbuWt2NYO0NY7DXNDskbQYGWId1hsTpqD79t1sPEGG5mNdRS53FxaOiab5Rve/wAP+kG+TEcDDI6V7IyyN2RkZhOVp1YbaWA3HZrbmvlRXYXQUUE5o8sNVE6TSMbENNnd56o9dlHrcSw+iFO9uGwGN8JmAs1rxYFwAFu463AHavsfEeFOjMcdLJ0THCLyGBt3agb2sQL3201QYzYngXi7XmjD4nRdLdsGlmWAHrBNgpNRUYFRVXQywRRyh+QAQnVxaCdh/tIuo1LjmG1AibFhxzzZA8ZGWaC9rNTfkSNN9BpayxkxzCIaicz0LumMkhe5sYfcxaA39QFhuPxQSH4pgT4gyVoLI8soY+F3VBtlda2g296xdimBAtpGwtPSyEmMREWcLgkj8Peo1Tj+HCKSSLC+lkBiIzMa25do257QL8joO9b5sdweGXOaTNKS9pLI2khzdSL331QZxYrgPXEUbAZrhwZCbutqbgDf8kp6vA3QSyQ0kbRA0OkaYQ3o2uAuezZ1z3LMVtH9GR1dHh8L3CYxRx5Rcdctv1QSL2vso44gwyJlRmw+VjgC2oaIm8nBpB11F3W+PJBrgxDAp6uWaameKqZzGuZJHmObYDS48ouHrB7lubWcPzxdPJSszyBhcx0BLuubgEW7dfxWUmPYWJC80j3Fji3PkYbHyu3c29d97LRTY9hLhTujoGs6UExERjRoN9eztsL6oJkldgQp21EjIxFA/o2vdEbNJvtpz11/NaY6zAaiRgjo2ve9wiH7C2mYN1JGwLhp3qPDjuEQ0z5YsPn8XqHdJIXMBu4mwFie71D4qZX4vRUrr+IGQsj8ZYWsaNbDt1BJIHvQJK3AWVEjTFGZTJ0brQEkvdcW23PWHuK+1uIYLGIPGYmyMdGyVr3RF1hs3cXvr/dR6jiHDWVTW+IudM2RjHEsbdhcdTe52O//AGts2M4Q7D4ayakvHJE8Ma+JuYtY4Att6yDbuQbBU4KyFszKVhY2Yx3EGrXZc5NiL62G3conj3DkcbiaWNgu1rQYLZsxuLacz+O6lNxujf4yG0hDaZpllzhoy2sHaC+wJ1520UWPHsPlfHFU4W9s+fK1nRNd1hpa5sN7j3d6DezGcDcMrog1zJC/IYCcrmjytBuAL37FtxiqwehfHFW00bgWMjJ6K7WMuS0Huu06dyiU2P4TJEyQUNp5Gs/ZtYwk576A3sRqb+vXW63jGMMlhZM2kzsikbCCWNJYDexG9h1edrb7IMp8QwqCKOdlJniqhIHSCMAWzAODr9pPv9ZF0VRgLYBPHBEGNqOjDhCf9Qje9vx71Hix3DJIomnDnO6MtEbWxsIaXnqgXIsSNT2bHXRb6LGMLrJmwQ0b7OlJu6FoaHAgZvXcgX3QfaOowWongihpGftWuYw9BZtgCCNuy477LoFzUPEOEMe8QwFkgm6PRjRmdlJuDe1rDfvF1bYRibMSZI5kT48jiOsQcwzEAgg88pQT1xvhg83OMezH81i7Jcb4YPNzjHsx/NYiXmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB2ngb84+F+zN8py9MLzP4G/OPhfszfKcvTCCiq8SZSYnLHHhsjpXuDTM1o69mg37Ta9lrPEjRTdMcNqxdme2Tvta/wDu7l9qMVxSHF6qFmHmelZ/puDHNvZjXeVqDclwFuY1ssZMexBgflwSodlGYEE2cL206t787EbdiIZniAtla12G1AaXNaDbXUX/ALWHrNkdjsj6OpljoJWSxdEcsltc5HfyBv8A9qTh2J1NVUujqMPkpmB7mNc8nrWta2nMX58uagNx7Ezd5wOoynKAy5zXub30tYAfG3ag2zcRCDomy0crnyaNLbdbqk3Gp00N9dFhHxC7onEYZUAtbmsG3sC6wB79QSOzVfajE66SkNTFhro54pzEA+J0jnMy3u0ADc2Gthpus5cZxBziynwuQOEjWXlDwCLtzEWbsLnXbTS6D4/iNjOkHiFSS3TQbnMB8Be5PLZb8Rxd1PLSdFAZIpWPe46XBaQMu411I57KI/G8TfFP0GDStexr8pkzWJFsumXW5PbsFjV8R1lGbVGFSAW8vM4NJtcN8nc7W7fig21HED2B0bcPl8YtIWMcdyzn6r/go/07+1dUswabMejZnydc3JuPcG/HTvUyixauqXkyYTLT2abOeSSDZxta23VA33ITD8Yr6mphhlwuWFrm3dKQ7LvbmAR79e7mg1z8TRRMfIaKo6JpeGvIAByc/eNu1b6HG/G5Q0UFTGP9zwN7ONv/AOpB7DYKI7Fq8lzZ8KkqLFpyiFzQ11/JBN8xG+bQab6gLB/ElaakQxYVI57Q5z2AuLsoGhtlFgSRvrodNkG+o4itTvlioJ3gMc5pIsCQbW96kVeMGmqZoTRTPax7WdIB1es29z3DW55L7VYpVR01HNBQSSmUftYQHZmHTS9raXO9hpuob8dxI0b5G4NM2Usd0bTmd1xa1xl0GpPuIQZQ8QvdT075MOqGvksX9WzWXvYk9l2nXkBfmFh9Zj4tG4YbUmd0Wcty6Ndr1b9ul/UbrcMaxHxh0RwaazHZS/McpABJI6uu1h6+S3YliNbT10IpqZ01M6PMQIn5r2O52A0GliddkGEWNyPpKmQUEzX07WOc0jygd8o3uBf1rTBjs5k6GfDJhNcN6vk3zZHankHB2vZY818ixrFDPkfg8ha/I5jgXANBIBDjl3Gp2/7UibFq+OhjmGFPfKQS+JryS2zmgW6uvlX2GxQaouIs9Ox3iFQZjGJCxo077FbRj0bqd8rKSZ+Wo6AtaASDlzXPZ2euwWqmxrEXyuZLg87QH2z3IFi6wO3qv7ysKXF60xteMHfTRuc0yEh1xd9nGwb/ALdboMm4/K6YA4ZOIsrHOJHWGbutrbS/v7FrZxK5zmO+jajo3uc1pA1uDb4Hl23Hap2I4pV01QI4cNmqGFzR0jDpZwOu3Igg9lx2qG/HcRY03wKoc4Ma7quJFzYkeTfTMOW9+xBOZizX4fJOaWRj2ZLwu3AdaxPYNdeyx7FGw/HzUQzOmoaiJ0UTpXZm6G3Ic9eR7j2LVUY3icb25cGlIzHNbM67chIscuhvYG/uvykx4rXOoppjhMoka1jmRZzd5cSCNRpa1/UUHylxp1XNCyCjkbfWTpBbKMhcPxAHvUZmPVBigvhzxM/J+zt2uLXG/ICx+I7VJjxOvlgqJBh74Q1sbmZwS6zjr1balo1IBvfRazjNcx4YMNmmFwOkDHszC175SDa+1r6c7IMTxIMj3tw2rytJBu0DYgfjmv6lvqMZkZTGVlBOXNmyFpbc5ALl2ncNB22USLHcTEUJlwWcvfG5zwAQGuA22O/+XUybFqtrIBFhkz5JI432dmAYXEhwJym2XT4oI8fEEl3F+G1Aa1oJDW3cSS4aDs0B9R5LQzG/F6p0cWFua6SRufK2172u46d5/DtUk4riEkEkgpHU9pgwZoHykNsdcosTqBtpruo7sfxRpdfA5zkb1gM3WdcCwNth1vwQTKbHDUQPkbQVDA2F0ozAakfu6c19kxpzaRszaGYPdK2PK7Tdodf4G3rBSbFqyKkdKcLldJ03RiNhJJba+byfd/2oj8exETZm4RUGLo2nJ0bs2c76kWAHqueW6DMcSNy3dh1UPKGrRuB2bi+/q1U3D8XdV1LI/Ep4mvaHB77W1BNvwP4dqgTY5ibGNeMFlIIzFgLi62Yj/bYWtf1FTsPxKqnq+jqsPfTxHNkeXF1yCAARlFrgk78kFsuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rES8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO08DfnHwv2ZvlOXpheZ/A35x8L9mb5Tl6YQVNZVYoKp0VJRsMYeAJXnQtI1NrjYqPW1WNhpNLSRkupmusSOrKTYtGvK9/d3q3fWUzHlj6iFrxu0vAI2/MfFZMqIX2yTRuubCzhqbX/ALaoKKasx81DI46GMRtks+TQhzRfUDNz07xZbzXYwMPikOHNNU6942v0bqLa+rN8O9W9RUQ08RkqJY4owbFz3AAe9ZMe17bscHDtBugpW1GMuknD6VjBHHJ0eW1pHAtyHfS4zacu1aYKniFjmMmpIHklwL76DS4Nr9pt7leRVdNM/LFPE929mvBOwP8AYg+8LZHLHI3NG9rh2g3QUUFbjmSOOSgYXlzGmQ2AAt1nEX5G2nNYw4pi0tJVkYcBVRBuSM7FxJuL310AN/8Akryeqgpw01E0cQecrc7gLnsCyMsYeGF7c55X1/zQ/BBQx1ePioMbqKExl9hIT5LbDWwOtjfsv7tdb8WxoPETcNYZ8ma2uXyrb37OS6W47QsWyxvc4Ne0lps4A7HvQUhrcaExa6gi6KxIc11yNdNL66ert7l8pqnG2005qaWMzNhj6MNb5Tz5V+tsLj4Ei+yvrjtS47Qgo6vE8Rgw+WbxE9K2Qsa218wsSCADzIA960+P48QL4bG3UE5XZjbMLjUjlcX966EvaHBpcLnldfGSMkY17HtcxwuHA3BQc7FXcQZmufh8Ra55aW3tZo2de/Ps5X7lcYXLVy04NfCIp7AkN21F7bnbb3KU+Rkds72tubC5tc9iwFRCTGBLGTIMzBmHWHaO3cINqLFkjJBdj2uAJbob6jcLA1EIDSZY7Odkb1hq7XT16H4INqL5cdoWPSx9Jkztz2vlvrbtQZolx2hLjtCAiXHaFiZGCQML25yCQ2+pAtf+4+KDJEBB2K+B7S4tDhca2ug+osJJoo/9SRjdC7U20G5WElVBG2N0k0bWyODWEuAzE7AdpQbkWplRC9sbmTRubIbMIcCHHU6dux+C+MqqeSd8DJ4nTM8uMPBc31jluEG5FrdUQta1zpWBriGtJcLEnYBbLjtGqAiAg7EIgLjfDB5ucY9mP5rF2S43wwebnGPZj+axB5lGyINkQEREBERAREQEREBERAREQEREBERAREQEREBERAREQdp4G/OPhfszfKcvTC8z+Bvzj4X7M3ynL0wg5+vw3CqnEJnzVDo6mW7HAPA/cDba9z2n12UZ3D2CupC3xwhnVJkErQTl0Fzbut8VcVuC0NbOZaiHPISDe53AI29Rt8OwKO/hnC3B/wCwcM8YidaR2rQAAN/+I/HtKIRo6HCPE6inhrWsaZC57s7MwcDcnUb9Ya+pZUtDh2HV85gr3x1dSzNeSQOsCdxcdykjh3DRUifoD0geHgl5Oo2WybAcPmY1kkBLWxNgHXPkNNwN+0IKufBMGnD5DVuuczi5kwva5cbW5AED1BvYtcOEYEZGz+NvHkM6ORwbqHNIu0gG5NviO5XMOCUEMs8kcOV8zXtebnUPN3fitT+HsPklEskcj5AQ7M6RxuRsd/d7h2IIsWF4VHQRUkdcejYx7M3StJcx5Ac06bEgC4se9RYMCwi/QePZ52hj3ZXM1sS0G1rWuCLdu9yrNvDeGNhEbYCGi9rPIOpB/wCgs3YBh7mZTG/QNaD0jrgN8kDXkgqhgWBzFoZWE5c7CGzN6xcSDftN9PdZTK6mwmpwptM+sbDTRkvuyRrSLAm22lgfdYLeeHcOcQXROcA/OA55IB623d1nad6+fVvDA1jWwOAYx0Ys93km5I3/AORQRaDD8Oo8QbJT4g91Q2MR2c9pGQG1jYf8bfHmvk2D4RNK989WHuLpCM0jOoSOsBpyvftClM4awxjHtZA5ma1y15B025r5Pw3QTSRmz2sBcXMDjZ9wRr8UGuXBsOrKyqqhVOc9+V0ga5jmt0FjYgjUDndaYcMwmpo4aeGoe2HpGyNYQG5jkyjRzf8AjfTW+qtqLCqSiBFNGWAtDDZx1Avb+5UaLh3DYp45mwHpGEODi4nUG4/HVBVyYLhD5mukxCcvL3PJL2i7mkk36umrv7LOLAMIZltXFxa3ox149BlAA0bro3Y9/aVZjAMPE3SNhId0pmIzmxfcm9r9pPxK1v4Zwp7WNdTXDG5B1ztcnt7Sgiw4FhMVRSVEdSQ9pzx5ZGhshDi4mwFjvy5CyxlwbBpK0tdUDxmV75Q3O0klwA2tyB0Hed1Z1GCUVQIxJG60Ze5tnkWLyS4/iV8hwOhhe1zI33bbLeRxtYtd29rW/BBWnBsFiAe+dofE4dZzmhwcAWjl/lhbZaY+H8FjaGCvddzMgvKwk3ce7XUkf21Vk3hzDxI+V8bnTPeZHPzEEk77craLKPhzDY4REyFzY7AFoebEAEAHt8ooK9mB4K+pEjakkxjpXN6QZSLAEnTbQXPO+q21OC4TI6B89V1GUzImtdI3K6NpBBOmuttVNjwKihgljpmuiMgILg473Bv8QEbgNGIIo39K/JEyLMZCCQ29tuep+KCrkwfCSyYPxCQftHOkGdgJcQ4a9W9xc29XOwQ8PYK0Sh9W8l7HEudM27Q4tuQeWw177KyHDuH9LI98b35r2BebNzMDHW9YC+nh7Ds7XiJ7S0WbaR3V62bTXt/CwQaMMocNw6oLKWsAlcG52ue0l4Is2/8ALceoqHT8PYMQ2KOqfI7ozG28jXG17kjTfl6lYs4doBmL2Pc57i5xzkZusTY9wzW9QC3U+CUVPURTxxv6WMuIcXknXe6CojwXBJaZrvHA+N0bS15ey9hlAN7X5Aa9pGiynwXCKd75ZK+SIvkY65lboW6C1x3j1dym/VjC8tjA4nI1ly8k2btr3Lc3AaFsmcMfcvEhvI6xItbnsLDRBXRcP4OOiibU5y3M1jS9hdcg7G17gOvb1Gyl4hw7S18sj55qnrOLg1rgA2+W9tOeUb37rLOl4dw2kcHU8BY4aAh5uOsHf3AKt0S5/wCqdDne7pKjrFpy5m2GXYWstz+HqdzKRvT1A8WbljPUJHWDr3Ld7gf4SrpEFVhWA0eGTiamz9IGFhc61yCb66K1REBcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEBERAREQEREGE80dPC+Wd7Y4mDM57jYAdpK5KXwj8NRyOb4499ja7YXkH8FC8M76hnCbBBmETqhomt/tsbX7r2X4Yu90X0Vj1eKcmSZ8duDk67X3wZOpSOb99+0rhv0qX7l35J9pXDfpUv3LvyX4EpeHMpXzOFbIWR5bAgX1Og+F7+5dG3QOmrG+9v6/Dxx0rnmdto+e79y+0rhv0qX7l35J9pXDfpUv3LvyX4vU0+G2YYKl1zKGuBBsG9uy3Glwe7R448DKbmxJvc6baaWCz7m0v8vnsv3jn/j8937F9pXDfpUv3LvyT7SuG/SpfuXfkvxg0+FOfYVUrR1RfL8TsolfFSRloo5ny9YglwtppY/ifgpr0JpbTt+757InpPPEb8Pnu/cvtK4b9Kl+5d+S+jwlcNEgeNyjvMD/AMl+Aote4NN525x+FO9s3lHz3ep8Nr6XE6RlVQzsngfs9h/zVaMaxnD8EphPidSyCMmzb3JcewAalfm/gLfOTirOt4sOjPcH67e7/pUnhnfUO4sayXN0LYG9EOVje5+P9lxqdGVtrZ0s24Rz8+bpW10xpozxHGX6B9pXDfpUv3LvyT7SuG/SpfuXfkvwJF2e4NN525x+HN72z+UfPd++/aVw36VL9y78k+0rhv0qX7l35L8WwyPDHRx+PTOa/OS6wNstiANOd7H1L6ymwzxtzXVjzAGXDi2xLtdPwHx7ljPQuliZj93z2aR0lnmN/wBvz3ftH2lcN+lS/cu/JPtK4b9Kl+5d+S/Gm0mFuNvHXi98pt8Li2h37fWvrqXCQ148ceHNGhAzXPZsP/dk7m0v8vnsd46j+Pz3fsn2lcN+lS/cu/JPtK4b9Kl+5d+S/FpqfC2xExVcrn2dYFvMXty56fFVavXoLS2+tv6/CtulM9fL57v337SuG/SpfuXfkrnAOKMIx5z2YbVtklYLmNzS11u2x3C80q74KfUR8WYUaTN0pqGjq/7Set7rXWeo6CwUxWtS07xG/Hb8L4ulctrxFojaXpVERfKu8IiICIiAuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAul1pWp88bJAx7gHHZBLul1FM0YAJkbY6A33QzxAgGRlztqglXS6iiWNwBD2m+2qyje2RuZjg5u1wgkXS60og3XS60og3XS60og7rwN+cfC/Zm+U5emF5i8DHnJwr2ZvlOXp1AREQEREBERBorqSCupJaaribLBIMr2O2IXDTeCrA3yOcyeujaToxsjSB8Wkr9ARb4tTlw7xjtMf8ZZMGPL/nXd+efZPgnpeIfzs/Sn2T4J6XiH87P0r9DRa946r7k82XYsHoh+efZPgnpeIfzs/Sn2T4J6XiH87P0r9DRO8dV9yeZ2LB6Ifnn2T4J6XiH87P0p9k+Cel4h/Oz9K/Q0TvHVfcnmdiweiH559k+Cel4h/Oz9K+jwUYICCarECOzOz9K7nEqsUNHJUOYXtZYuA7LgE+7dUruKomRy9JSyiWNmctBuNDZwv2hwcPctKazWX41vPNS2m0tJ2tWFpgmEUWC0LaTDoRFCNTzLj2k8yo3EnDmHcRUzYsRiJczVkjDZ7O2xWmPiije9rWw1Ni8R5smgJvbnfkVlUcRRU1Q+OaE5QXtGV4Lhl3zA2tfcam4XniM9b9eN+t47/VtNsM06vDZzH2T4J6XiH87P0p9k+Cel4h/Oz9K6WPiandEHGnmzlmfI0tJ/v/AOvfot9Dj1NW1QghjnBLyzM5oABsT232BXpnV62OM3nmwjT6WfCsOT+yfBPS8Q/nZ+lPsnwT0vEP52fpX6Giy7x1X3J5tOxYPRD88+yfBPS8Q/nZ+lPsnwT0vEP52fpX6Gid46r7k8zsWD0Q/PPsnwT0vEP52fpT7J8E9LxD+dn6V+honeOq+5PM7Fg9EPzz7J8E9LxD+dn6VfcMcF4Tw7MZ6RkktSRYTTOzOaOwWsB8F0qKt9bqMlere8zH/VqaXDSetWsbiIi8r0CIiAiIgLjfDB5ucY9mP5rF2S4zwx+bfGfZj+axB5mGyLQNl9QbkWlEG5FpRBuRaUQbkutKIN10utKIN10WlEBRqqjjqSelLspAaWg2Bsbj8Vvyj/CmUf4UEL6Lgta77WPZz3OyybhsA3L3es8+38FLyj/CmUf4UEH6Kp7OBznMLanYXB/6UyCIQxhjSSLk3PebrLKP8KZR/hQZIsco/wAKZR/hQZIsco/wplH+FBkixyj/AAr7lH+FB23gY85OFezN8py9OrzD4FwPtKwr2ZvlOXp5AREQEREBERAREQEREBERARR562ngmEU0mR1r6g2A13Ow2PwWAxKhIJ8bgsDY3eBb/LIJaWHYooxCjL8vjMN7X8sLbBUw1AJhlY+wBNjtfZBtsOxYujY4tLmglpuCRsVrqKuCmDDNIGB+jT26XWAxCkLnNFTFdpsesOwH/sIJNh2JYdiiOxOha3MauCxFxZ4Nx3dqOxOiaNaqE7aB4JQS0UUYhRFpcKuDKBcnpBon0jRA28bgva9ukGyCUi+Mc17A5hDmuFwQbghfUBERAREQEREBERAREQFxnhj82+M+zH81i7NcZ4ZPNtjPsx/NYg8vjZfViALf+19sEH1F8sEsEH1F8sEsEH1F8sEsEH1F8sF8yj/CgyRY5R/hTKP8KDJFjlH+FEGSIiAiIgIiICIiAiIgIiIO18DHnJwr2ZvlOXp1ePMAxapwLGqTE6Kxnpn5g12zhsQe4gkL9vpfDZgDqdhqqHEopiOsxjGPAPccwv8AAIP1RF+Y/bVw16Niv3LP1p9tXDXo2K/cs/Wg/TkX5j9tXDXo2K/cs/Wn21cNejYr9yz9aD9ORfmP21cNejYr9yz9afbVw16Niv3LP1oP05F+Y/bVw16Niv3LP1p9tXDXo2K/cs/Wg/TkX5j9tXDXo2K/cs/Wn21cNejYr9yz9aD9ORfmP21cNejYr9yz9afbVw16Niv3LP1oP0aoo6eodmnia91rXPvt/c/Fa24ZRNDg2mjAdvpuvz37auGvRsV+5Z+tPtq4a9GxX7ln60H6F9GUXR9H4vHkFrC23+XPxW+npoqfN0LAwONyB8F+bfbVw16Niv3LP1p9tXDXo2K/cs/Wg/Sp6eGoaGzxskaOThdRhhdEGlop22O411/yy/Pvtq4a9GxX7ln60+2rhr0bFfuWfrQfoDsJonyBzoGmzcob+6Bpy9w+CyGGUQJPi0dzvpv61+e/bVw16Niv3LP1p9tXDXo2K/cs/Wg/QDhNEXvcYGnOblp2v6l9bhdG2odN0DTIeZ5er+6/Pvtq4a9GxX7ln60+2rhr0bFfuWfrQfpsbGxsaxgDWtFgByC+r8x+2rhr0bFfuWfrT7auGvRsV+5Z+tB+nIvzH7auGvRsV+5Z+tPtq4a9GxX7ln60H6ci/Mftq4a9GxX7ln60+2rhr0bFfuWfrQfpyL8x+2rhr0bFfuWfrT7auGvRsV+5Z+tB+nIvzH7auGvRsV+5Z+tPtq4a9GxX7ln60H6ci/Mftq4a9GxX7ln60+2rhr0bFfuWfrQfpy4zwx+bfGfZj+axUn218NejYr9yz9a4fwmeE1nE+G/ReEU00FE9wdNJPYPfY3DQATYXsd+SD8yGy+oiAiIgIiICIiAiIgIiICIiAo9ZHNJG0QPyOvqe7Y/n7lIRBWhmI5SC9g56b7bX9a+E4new6K5GhtoD3/5urNEFc91eJA0ZSCSM1tuwlfQMRJcSYgM2g7v/AJVgiCDGK4TM6R0Zjuc1hrvp+CnIiCFK2r6Z/ROaG3u0n1DT8D8VrY3EMxBfGG33trb/AOVYogrcuJEk5ogQNBbQnRZ2xDOBmjyXNzbWynogwiz9EzpbdJYZrbX5rTWsne1vizw119b/AB/uAPeVJRBXxx13RyMfIy/RkNcN83IrF7cSc05XRNILbX59v+d6skQV7W4gHEZmZS4ancN5+/sWIbiRa4F8Td7FvqNt+9WSIIEza/ppDE5mSwDQV9mZWCYujcC2456WsNh23upyIK1xxDMxpDOsTct2Czc2tdHCS5okB69tBuP/AH/m09EFeRXuLTeNtiTbt0NgffZbaVlTma+peL5SHNbtf/LqWiAiIgIiICIiAiIgIiICIiAiIgIiICiVjagvaac7Dm6w35+5S0QVzG4jm6zo7Fx5DQaL6BiBsHOjHaW+7/2rBEFeRiGl8mjbdW2pvvr3LEtxJ1jniFnbDmLG/wD1ZWSIK5jcQaH3MZ1OUE92n4rOB1YKlrZw0x5bktHdr+KnIgKvDK9sj7PY5hcbXOoBJ/sLKwRBXx+PhoDsl+ZNtNO5a3HEndI1uQENsHbC+u34K0RBXOGIm4vGBcWtvbvQur2yMFmOBJvYbD/LKxRBWSOxJoblEZc4DYaA3591lKpRVZj4wWFvIAer/wBqSiAq6GOvZG0FzS4WzF2t/wAVYogrQ3ETu5gBOu2yyJr2sucnV5DUkKwRBX05xBxaZeja3QkW15X/AAv71YIiAiIg/9k=",
                                        "timestamp": 763799599720,
                                        "timing": 2250
                                    },
                                    {
                                        "timing": 2625,
                                        "timestamp": 763799974720,
                                        "data": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAFcAfQDASIAAhEBAxEB/8QAHAABAAIDAQEBAAAAAAAAAAAAAAQFAgMGCAEH/8QATBAAAQMCBAIECgcHBAIBAQkAAQACAwQRBRIhMQZBEyJRYQcUMjdUcXKBkbMVFheTodHSI0JVkpSx8DNSYsEk4fE0JjVEU2OCg6LC/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAECAwUEBv/EAC8RAQACAQICCQMEAwEAAAAAAAABAgMEESGRBRIUFTFRUoHwQVPREyJioTJCcWH/2gAMAwEAAhEDEQA/AOcRFX1FPVune+CRrRckdbuGhFu4/FBYIoMcNaWTCaZhJHUDdPxtcLW2HEWts2WMDWwuT6tSCf8APegskVZTx4kZw+WRjY7gFpsSRztbbn+Cn1DXPgkbGSHlpAINrH1oNiKsip8QabGdmUntuQLd4UyjbO2G1U9r5L7tFgg3oiICIiAiK3puGcdqoGTU2DYjLE8Xa9tO8hw7QbIKhFefVHiP+BYn/TP/ACT6o8R/wLE/6Z/5IKNFefVHiP8AgWJ/0z/yT6o8R/wLE/6Z/wCSCjRXn1R4j/gWJ/0z/wAk+qPEf8CxP+mf+SCjRXn1R4j/AIFif9M/8k+qPEf8CxP+mf8Akgo0V59UeI/4Fif9M/8AJPqjxH/AsT/pn/kgo0V59UeI/wCBYn/TP/JPqjxH/AsT/pn/AJIKNFefVHiP+BYn/TP/ACT6o8R/wLE/6Z/5IKNFefVHiP8AgWJ/0z/yT6o8R/wLE/6Z/wCSCjRXn1R4j/gWJ/0z/wAk+qPEf8CxP+mf+SCjRXn1R4j/AIFif9M/8k+qPEf8CxP+mf8Akgo0V59UeI/4Fif9M/8AJPqjxH/AsT/pn/kgo0V59UeI/wCBYn/TP/JPqjxH/AsT/pn/AJIKNFefVHiP+BYn/TP/ACT6o8R/wLE/6Z/5IKNFefVHiP8AgWJ/0z/yT6o8R/wLE/6Z/wCSCjRXn1R4j/gWJ/0z/wAk+qPEf8CxP+mf+SCjRXn1R4j/AIFif9M/8k+qPEf8CxP+mf8Akgo0V59UeI/4Fif9M/8AJPqjxH/AsT/pn/kgo0V59UeI/wCBYn/TP/JUOMYTidDXtjq4Z6OTKOpMxzCBrqARY7/ggyRV4p64yRZ6lpjbYu0sXG/cFvxCGaeNjYJDG4OuTmI0sezvt8EElFWNpcQbktVNNr3uL3B9ysYw5sbQ52ZwGp7SgyRQ8ThfNG0MZnIzcgd2kcyO1bKGN0cbw9uUl7jaw/6KCHjOMx4ZJGx8TpC8E6G1lXfWyH0WT+YKLxv/APV03sH+65+ndG0u6VpdcWFuXeulh0+O2OLTHF4Mue9bzWJdV9bIfRZP5gn1sh9Fk/mC5rpKXX9i7Unnt2c1l0lJc/sn5dP7681p2bF6ZU7Rk83R/WyH0WT+YKbhOOx4jVGBsL2Oyl1ybriZ3ROt0LC3U7ncclbcHf8A3v8A/wAbv+lTLpsdaTaIWx57zeImXcIiLmOgIiICIiAiIgIiICIiAiIg6rwXUFPiXHuFU1ZGJIcz5Cx2oJaxzhf3gL1ENBovM/gb84+F+zN8py9MICLkeLMVxk4pTYRw7GxtRKM0lTIAWxj8/wDPVr4cqcXosUlhx3HMNqqcCwALWyB99rC1vxWNM8ZLTWkTO3CZjwiXptpupijJe8RvxiN+M/1tzl2SIi2eYREQEREBERAREQEREBERAREQEREBERAREQEuO1a6iTo2E81WVVS2CGSeokDIo2lz3E6ADcq1azbwVtaK+K3uO1LjtXK4NxDQYxLLHRTudJHqWuBBI7R3KYMRpi8sFQ0vzZcouTfUf9H4LW2nvWdpjipGalo3iV9dFWxyuYb3JCnB2ewabXFyVjauzSJ3bEWiR8EcrI5JQ17wS1peQTbeyZ4P/wA0bX/1Dt8U2N29FGbNTOeGtmaXG+nSHkbdvbotrA1zc0byRyIdcJtsb7ti4Pw14fT1XAdZUzRtM9I5kkT7atJe1p9xBXdsN2677Fcd4YPNzjHsx/NYoS8yjZEGyICIiAiIgi1uH0taWmqhEhboCSRb4KN9A4b6K3+Z35qzRXjJeI2iZVmlZ4zCs+gcN9Fb/M780+gcN9Fb/M781Zop/VyeqeaP06eUKz6Bw30Vv8zvzW+jwyjo5TJTQBjyLXuTp71MRROS8xtMymKVjjECIiosIiICIiAiIgIiICIiAiIg7TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphBxHGDsZwfHKbGcJojXUmUx1MDP9TsBH4bDkuSjwscWcTU89Bw/U4ZAJ+nq6qpc68hvcgA6du3byX7IiaWbaS02wTtvvv8A+7+LzZtPOe297bxw4cPp5eQiIj0iIiAiIgIiICIiAiIgIiICIiAiIgIiICIiCPWMLourqRqqqsgjraSankLgyRpY4tNiL9nYVenVaH0sTzdzRdXpea+CtqxZyXD3DjMIqJJ3Vc1TIW5GZybMbpoBc9g+CmOwaldKJCXl7Xl7SbHLck6Ajtce9X/iUP8AsCeJQ/7Atbam9rdafFlXT1rG0IV8xyt1cVYsb0YB5WsUigZH5LQFtWNrdZtEbK+vw6jr5BJUdZwblaQ+1hrf4g2Kiy4BhsjSC0gktNw7Xq3t/dXSWUxkvHCJVnHWfGFH9XcNztcMwyvzgZtL7H8FZUUFPRU7YKewY3ZoN1KsiWyWtG1pK0rXjEMWAga7nVcf4YPNzjHsx/NYuyXG+GDzc4x7MfzWKi7zKNkQbIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIg7TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphAREQEREBERAXN8eYtV4PhdJLQOLZZqyKnLhTuncGuJvZgILiukUDGsIpMZpWQVolyRyNmY6KZ0TmvbsQ5pBHxQcTReENtJSmLFmiWu8YmjY0sFG4xxtY4ueyR3UcekbZt9QQdATa2k4+wyOkdUPiqQwASZSwB3Q+L9P0tr3y5QW+0LKb9TcHEYDGVbJs73uqW1koncXNa12aTNmIIY0WJt1W9gUp/DODyVRqJKJj5DRHDjmJINOf3CL2Pr3QVM3GboauGhkwWtGJzSRsZTdJFctkZK9r82bLa0MgIvcEc7gpxli2LYfWwNoi+Gi6Fz5KiOidVlsl+qHsYcwZa5uAdtxbWyouFsLo6mGpZHPLUxSNkZNPUSSvBax7Gi7iTYNkfYbdYnfVbcX4eocVqmVM5qoqhsZiMtNUyQOcy98riwi4v27XNrXQc27wgUtJZtQ+GolldGIuikbHEQYGSuc2R7hdvXFrgHUC25V7V8SwxcLwY7BTyS0ksTZi1zmxua0i4uCdTewsLkk6XWLuD8GDWiCnkpnMLSx9NO+JzMsYjAaWkEDI0C22gO+qkYjw3h1fh9DRTsnbT0T2vgEVRJGWuaLNOZpBNr87667oIcHFkToHOqaCqppmT0tO+GTLmY+fJlBsbaZxf1FasbxWvdjtTh9DUx0UNHRsrJ5jTGd787nta1jAeXRuJ0J1AFlJdwjhT6uKpkbVvljfFJ16uUh74zdj3DNZzh2m+w7ApeL4BQ4rURVE/jEVVE0sbPTVD4JMpNy0uYQSLi9ig56k46YMN6aWB1aKWnE9fU0rckcTekewuDJCH3vG8ltiRlOp0vun47pYIxPNQVbaWZ0sdJKCw+MvY7LlAzXBcfJvYEDWymngvA+jjjbTSsiazo3sbUSATNzl9pet+06znHrXvmdfcrXiHBmGzU1WKaMtmlbKIxNJJJFC6Q5nFrMwDbnW7bHsIQVeIceeI1knj1FLRw0ZnbVxvLXucWxRyNyEOtY9IBrb3K1wvi6mxHBsVroaaV7sODjJFE9kmezM/Uc02NxpvuCFFwfgajhgrfpg+PT1cskjyZJCGh8bIy0Fzi46RjUm4O1tF0OFYTTYZFMyAzyGZ2eR88z5XONgN3Em1gBZBzVR4RsHhFa7JUPjpXPzOYAQ+NsZeZG66tzNMftd2qgYl4RG/RlVUYdBeqpmTuMRcyVjyyB0reu11raa21uCOwq/pOCOHqWLo4cOaGeJuoCC9xvC55eW6n/AHEm+/etp4Rwl8D4qiOoqQ8PDnT1MkjiHxmNwzF17ZSR+O+qCqb4QaBuJmhlp5BMx3QyZZGEtl6PpCMt82X93Na1+7VG8eB1H4z9CV4jbBDVSjPFeOOVxEZIzak2JIGw+CtYuEsKjn6UNqiTq5jqqQse7J0edzc1i7Lpc6899VVY/wADtxKopmU1QymomQwU72DpM5ZE/MASHhrtNBnBtqdb2QQMS8JNM6kxAYXC59RC2QwkuY/pDHIGuBaHXbe5y5rXA5KdW+ECkoXup6yilgxBsz4XU8s0TQMsbJC7OXZT1ZWWF73PcSrb6oYRmnvFOY5c94TUSdGzO4Pdlbms27hfT/tbK3hfDKyplqXxzxVUspldNBUPifcxtjOrSCAWsYCNuqDvqgrKDjimrqqFsGH1nick0EHjTsjQ18sTZGAtvm2eAdNCfh1yqIeHMLgblipi1vTxVFukcevGxrGHfk1jRbnbVW6AiIgIiICIiAuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB2ngb84+F+zN8py9MLzP4G/OPhfszfKcvTCCHLilDFO6CSqhbM3dhd1hty//cPipHTw5M/Sx5d75hb/ADQ/BVdZw5htZWy1c0TjPLo9weRcZCz+x+IB5LGr4Zw2qpaankicI6eJsUeV1rBpBaewkW59p7SgtvGIet+1j6t79YaW3WElZTRgF88TQXNYLvG7tAPWVRv4MwZxjIge0xscxuWQiwcXE6c9XX17G9gWTuD8JcxjOieA0MabOtmDTcA++23Ygu3VdO2N8jp4gxjc7nZxYN7T3d6xiraaWPOyeMt7za2ttQdtdFWUnDGGUsMkccTiJI5InkusS19s23shKnhqjqXl9RJUSyFuUvc+5Ou+3utt3K1Yr9UcVqyrp3nqTRnl5XPX8is+miyB/SMyEXDswsQqE8IYTnDhFJYPz5S8kXuTse83W93DdC+Gkif0zo6YODQX+VmNzf8AJTaKf6ycVhNiNHCJDJURjowwus65GY2bt2nQdqNxGjc2NzaqAtk1Yc462hP9gT7iq6Dhqgp4po4OljEnRah2rejdmbbT/drrf4KPLwbhUsjnvE5cXB9zJezgCL/iT61RLoGyxuzZZGHL5Vjt618E8Rk6MSs6T/bmF/h7iqyi4eoKKCWGnY9kMsJgkZm0c27j/wD7d8VjR8N4fSVTKljHuqGyPl6R7rkufbMfwCC5REQEREBERAREQEREBERAREQEREBERAREQEREBcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEHKYpVcQN4rp4aFkhwjPEJ3dADa972JOo2ueVuX73SV7pm0kppW5pgOqPy718lraeKuho5JQ2oma5zGdoG/wDncewrdNIyGJ8srg2NjS5zjyA3KCgZX402Oxw/OQHWc4i5sere1tSOVhbfuWNLiuLz1DsuHt6IStjNzawtdx77XtfbRXXj1J0TJDUxBjwC0l4F7i4/AhaIcaw6bo+jq4z0gJbe40ABO+2hBRCvmqsajqHGKl6VmZ12usAwfu2O7hvf3L5LX470BLMOjEjmEgZs2V1nabi+oB5aG26uzV0wc1pniDnNzgZxct7R3d6xlrqWEuElRE1zbXaXi+uo0QV7K3FDSZnUTWzdPkDdSMlr5j2cxz5e7Gor8VFLBJT4aHSvz52PfbLY9X4jX3W5qdHilC8yAVUQMZs4OdlsbA8+4j4rdJV00bM8k8TGWBzOeALHYolTeN441ko8Tje5jn5T5OezrNFr7Ea3WH0rixq3QMw9jyx7WvNyBlI39/4K3diVE12U1Md+lEOh/ftfL67LBmL0D44Xsqo3NmLAzLqet5Nxyv3ohElrcVjoY3jD2yVLgbsa6wBu234F3w71iysxbpajpaMBkcb8mUX6RwLcpGvPracrbqwfidCxge6spw06g9ILWva/qvoshX0jnFoqoC5pDSBILgnl60Fc+txU0kjm0YE7Cy2lw+7jmsL38kA+/uWk1+Ol5LcOiABk6pde9hdut+Z099+SuRW0pjY8VMJY92Vrs4s49gPMrHx+jNv/ACoNRmH7Qai9r/HRBSfSGPCWQ/RzHMIZlF9B/ud26adXfvVthU9dM15r6ZsB3aGuvzIt8AD7+5Zy4jSRRskdOxzHv6MFnXu617aX5ArI4hRgXNXTga69IOW6JSUUWavpYaTxl0zXQXsHsBfc3tpa99V8OJUILQauAFwuAZAOz9Q+IQS0WkVVOXuYJ4i9oLi3OLgA2J9SwkxCkjJD6mEODgwjOL3Owt2lBJRQvpah6YxGpjDwXtIPIttmv6sw+KyOJUQkaw1cGZwLgM42AB/sQUEtFHZW0r2lzKmFzRuQ8ED/AC4WLMQo3xyPbVQlkds7s4s2+10EpFqNTAGZzNGGXDcxcLXOwWr6Rotf/Mp9P/1G/n3H4IJSKGMUoTOYRVRdIGh1i62hvbXvsfgpUUsc0Ykie17HbOabg+9BkiIgIiICIiAuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB2ngb84+F+zN8py9MLzP4G/OPhfszfKcvTCCpqsCgqMS8dfPUNlzMcA0tsMpBAGlwNNr8z2lWNTBHVQOhnbnifo5p2I7D3LW6vpm4iyhMzfG3RmURc8gIBJ7NSPX7imJdP4jL4pm6e3Vy5b78s2l/WghDh7DQ5rmwuGV4kaBI6zSNBYX0FgBbsCw+rOFF5cacl1iLmRx0PvUI1PEjXZY6OJ7GhxD5C0OfocoNnWvq29uYPJTI6jGvE6h8tJCJwxnQsbY9Y+Ve7tufL3ohIlwShljYxzH5GRCFrRI4WaOQ109fPRYy4FRTVMs0zHve8m13kBl2BhtbtAUepmxeWhlaynkhqOkDGPi6MnLc3fZxIta2m9/iotTXcQQNleaNhijc3KWgPc8He7QRseyyCxbw9honZN4veVjg4OL3E3Gx3Wb8EoHmPNE4iONsTRndYNbtpf8VAlrsdZCD4hG57tQWgEC77AEZxrl1voP7Iysx+SRuWhgbGXPBc/QgDyTbNrr6r9gQTnYFh7qd0LoXOjMnSWL3aOsRprpoVrbw7hrXFzYHAkMH+o7Zvk8+SiyT8RCHMylpzIGg5LjV2bUXzaC3rPrWuWq4lMByUNMJHB4ADgLdUZTcu5uO1uSCf9XsN6Rr+gN2tyDrusB8e4JJw9hkmTPTA5XF46x3IA7ewWUPxniJrnkUcLwQ0tBLQAeY8r8e61tbrI1PEXTPZ4lSmNuaz7+Va9tM2l9B3XQSarh+inp4YA18cMbmnK1x6wGXqnu6jfgtH1Uwwyhzo3GIBwEWY5QXWu71mwW+qqMXFVIylpIjCxzbPeR1xzt1tPWR8VGkfjxo4JGRt6fNIZY7NboHXYBqQLgZd/wB6/JBOkwShfSGmMThCXBxaHuFyGho59gH991oh4bw6N0LnRySSRFrmudI7dosDa9tgPgogqOJGPsaWB4YJGg3FpCLZHHrC19ToOdtN08a4kD2EUMDmuYC4FwGV2twOtry/w6BZuwaidRGkMbvFrgiPMbAg3utMXDmFxOJjprXFj13ai9+3t1UEVXEhe0eJwhrnAud1eqMovbra9bMNe0L4Z+JXZQKWFpFx5TQDoLXNz37BBOg4eo4ZpntMpZLHJG6MvJBzkFxvvc5QtgwKgD2uET8zX9Jm6R1ydN9ddgo9LU46+qAqKKCOnzanMC4tzAf7tDYk89rd6201TizqrLPRsEJe6zrgWaA61+sdSQz4nsQZzYBh00ssklPd8t85znW5udL/AOaLU7hrC3BwdA8hzQxw6V1iBbfX/iPgFHin4ifHFI+lpmPFs8V99ddc2mljzWplXxMGEuoKcvJ8kuADdtjm1vr6u07ILB/D2HPlkkdE/PIXFx6V2t9+a3nCKPopY8j7ShoeekddwBJ1N+0n1qO5+MSYXOOjjirrt6IttlscpN7k7dYe7RR6SXHgZHzwssYpXsYcuj8wLGkg8hcd9t0SmSYHQSQPikhL2Ol6Yhzyeta3b2Eiy0jhug6V5e17oy0MbGXHKwBmTT3LRTVHEJkyzUlOIw5vXJF3NsSdA7Q3sOdu9YzYhjjsQnhpKGJ0LHgCSQFosSdjfraAH3213RCU/hrCnhualByhrR1jsNuatKaCOmi6OFuVmZzrXvq4kn8SVRMq+In5b0FPEXEDVwdkF7Emzhcga2G999LH4+r4jAbloKUlweT1/JOuUeVryN++2m6DokVDHU4+alzZKOmELXtAeD5Tbam2bTX4d6Vz8eD5hSRwlgcCwutcjPqL3sBlFtr6olfIufNRxEWuLaWlFi7KHDUgZcv7+l7u05W71h41xEZS40UTWCSwaC09S3lHrb67aXtug6NFzr6viQNblw+lJc1xIz+SbnK3yteRvpvZXlIZnU7fGmtE1yDl2Ouh3O41Qblxvhg83OMezH81i7Jcb4YPNzjHsx/NYg8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO08DfnHwv2ZvlOXpheZ/A35x8L9mb5Tl6YQQZsJoZ8RZXy0zHVjGhrZTe4ANwPipNWJjA4Uxa2U2sXbDXX8LraiDn2sx8Oa57oHOyNDsugvfWw7ezu70bHxBHJHaWB7MwDrgeTbXs1v+A7V0CIKaQY6KOnETqR1TmtKXggW01FuzUWWTGYy3D4gH0xq83Xz3yhtuVtSdB8SrdEHPubxC6n/wBSASODx1QBbTqnnrf/AKWIZxGM7y+lzHK3JbS2uYjv2tfluuiRBV0f0sIZm1ZgMzmExuYOq11zYEb2tlPx7lFpRxB41C6pNGIiR0gZc2sTe1+0a+u3JXyIKWb6cc6QxeLsaC8NFrlwt1StDfrGWOLjSNIFw1ovrcaX9m/Zr3LoUQUdXBjDqmN9O9gsGZ7u6hFjmAG972N+wLBg4hEbXPNKXa3ba3MW19V7q/RBS0jccZSzid1O+ZrGdFm0D3Ada5Hbry0utb28Q5Zcj6MuDnBgc2wIuA0n1C59Ysr5EFABxGQ85qIOAGUWNibi/fa1/f3L7QR46KqPxqSLxYSOcbAZyw3sDyuLi9uwW5q+RBzzhxL1rGg/eDbA66dUn8fw71lk4gFQ/LJTmMudYuA0Fuqr9EFbK7ExSQiJkRqA4NkLjoRbVwUaJmOCRxlfAcsDw22jTJcZb81dogo8NZjbKu1W+E0xLjc6vtbS9tN7bd/ctMDceha5oZG/qbySBxL8o1BtoCb6W0/AdEiDmJIOIyJHdJFd0YAa1wFn9W5220PxUyWPGSynaySO4fIZCbai7so9Vsu3YrtEHO34l6Nv/wBJnya6bOvy11Hw071vrIMWeKUxyjpA13SFrg1odmaRccxlDh7/AHq7RBQtbxBlfd9KCM+UBt77ZefZf39y2ULcb8YtVvgEJjJJABLXn4aDT8e5XSIOelZxFI2QZ6WPM0kZBctOQ2AJ7HaXttbvWf8A9oc//wCFy52WFv3ba313v/6V8iDnmDiN1w51IwWNja58k29+a1+7Yq7pOm6BoqbdKNCRs7vW5EBcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEHM4oziVuJ1EmHvhfRgHoo35QScl9eflNy77PJ5LZTycSufEZoaJrC6MvaBqG2648re+3/atarFKOlnbDUTtZK4gBp0OtgD6rkC/aQN1KmljgidJK8MY3dx2CDmKt3E8NTXPo42Ts6QdC2YsDctze1jc6W3I9XMzcXlxuSSnZhkDWdEQ+d73NDZBYAsbub6k621aNbFWDcWw9wcW1tOQ0BxPSDQHQH8VjNi9HEIXGXMyUEtewFzQA4NNyNtXAIKjD5eJ44axtZT08jmRuNO4OF3vvoDYgDn+Gu60MqOLmwdejpnTubmFi0tacnknrg+X2X0V99MYdzrYBbNfrjS2/wAFnBidFUSGOGpjc+xOUHWw529x+CDnm1PFc0jbUtPGGSsDgQAHNyXdrmOmY7geq+pWRqOL/F4nCjoOldcOYT5PYfL2Pdzt26dAzEqJ8bpGVMRY0Ek5tgLfmPiFqdjeGt3rYLWzF2bQC17k7BBCqzjsGEzy0rYqnEnPIZE6zYw0EgEa31FiQSd1FmquKi9wgoaMDUAyOFtA3XR19Tmt3Wurh+MYewuDquK7XBp617Emw/ujMYw983Rsq4i67Ro7QkkgD16f27UFDE/i2SrDpIaWGK7XFoIcCMhu3e/lEC/dfZbcNn4pbk+kKalMcd8+SxfILttbrAA2zHbcW2V5LilDE/LJVwtd1jYvH7psfgdEbidGWwuM7Gib/TzaZtbae9BXYrNxAyrIw6mpJKbpGWc89bIQc19RsR8Dtoocs/FzJC2Olw6SNuUZ7kF19SbZtAL2tfkT2BX0uJ0UWXpauFmYXbd4FxYG/wACCtMeN4bIXBtZDo4MuXWuSARbt0KCjqJuLwYzFTUbi3K4htgHXb1gbu3BOlt7akc5gl4lGHTuNPQurbjo2ahti5wNzm5DK7v1CsxjGHFod47BlIBBzjX/ACxW2kr6Wsc5tLURyloBIYb2B2/uPigqI/rA/D5jUCJlRdha2C2a2e7wC42vl0F+fPs1GbiRrgyOmiMV2AOlLS+1tSSHAXvuQNOQduulRByUU/F7ImCSlo3vyuzkOB1DBa3WG7r/APpTqufiEiNtLS0zXGBrnveQ5rZP3m2zAnnqr9EHMS/WKSmkL2vZJ40bNpzECIuiIFi4kEZ7HXW3LktD5+MA9xbSUZDS9oFxZwu3K7yr/wC7TTftsuuRBz75uImUUJFNSyVJqGB4Bs0RFgLjq7cOuPdeyjST8UytjMdNTwODS4tcGuBcA6zSc/M5dvjyXUogp8TnxkzU7cNpouiky9I+a14x1s1xmFz5Nrd/cpeDurnUEZxVsTav98RCzfdqf7qaiAiIgIiICIiAiIgLjfDB5ucY9mP5rF2S43wwebnGPZj+axB5lGyINkQEREBERAREQEREBERAREQEREBERAREQEREBERAREQdp4G/OPhfszfKcvTC8z+Bvzj4X7M3ynL0wgi/R9J40ak08bpy/pOkcLuDsuW4J20uNO09pUiWNkrMsjQ5twbHuN1V1DcX+sMMkJpzhIhLXsLiH5y4dbbWwBttuVPr2zuo5RSECoAvHc2BcNQD3HZBE+gsMylviceU2u3WxtsLdnO3bqthwmiLIWGAFkIIYC42FyCb666gHXmFVwU/EMT2xuqYJIy6xe5t3Zdr+uwv6ye5fadvELYIonup72jDpDYu08vuv2fiiFk3BsPa14bTMAcSTYnnvbsSDCKCB2aGnaw9H0V2kjq9m/r+J7VXxy47JR1QEcLapr8sZcLNO+3aPJ/FfZDj5L8rYALZW5SLg2F3a7630005hEp7MHoWMe1sAyvZkcC4m407T3D4DsQ4Nh5aGmljLQALHsGov26lV1Q3iBz88Jp25XWsTu3tt2r5DFxCxzw6amcDncCRfXMS0eq1h6u9ELD6Ew7Ll8Ujy5Wty62Ib5OndbRZw4RQQG8VLG03B58jcfBR5hjAhibEYDIekD3nlr1Db1WutPRY26OpDpYhIWxiIjQXv1j8ESmuwige6RzqZjjJfMTc3ubn1a6r7JhNFIGB0RIY3K3ru0F83bvexvvdQoGY62oiEslM+ESEO6upZpY+sjN77d60mlx5tRM5lVC6M5uia7lrZpOmump70QtJsJoZsnS00bixrWtPMBt7D8T8VgcFw8ua7xVl2lpbqdCBYW7NAB321UFjcfa7oy+nLDKP2vMR3N9O2xb8ClNLjklPVNmjY2oaWBjmgBt7nMRfcZcu/O+vYSljAcM6v/iMJb5JJJtrc8+dzftUymo6emN4ImsNg3TsAA/s0fBV4GMvp2gugil6UBxAv+zyi9u/Nf3WUVn1ky/tDR5rHRo0BtodTttp29yDoUVHTDHnStM7qZrAWEgC9xpmF/Vf39yvEBERAREQEREBERAREQEREBERAREQFxvhg83OMezH81i7Jcb4YPNzjHsx/NYg8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO08DfnHwv2ZvlOXpheZ/A35x8L9mb5Tl6YQVz8aoGY7Hg7pwMQfCZxHY+QCBe+3NTp5mQROkldlY3c2utdRR01S+N9RBFI+MhzHPaCWkG4I7NQFnUwR1MLopm5o3WuL22N0Ff9P4XZxFZGcoBOUE2B22Hu9ei2Oxmga/KagZutplP7u/JbG4XQNa5raSEBwykBgGnZ+CfRdDlc3xSCzr3GQc90EZvEGHOcQ2oBOXO3/kLXuPd2r4eIsKAYRVtc137zWkgXva5tpfKbdvJSfonD+r/wCHBoLDqDbayfRVBkDBSQ5RYgZBpa9vhc29aDTU45QU9+km06JszSASHNdexHw/Edqxk4gw6N0bTOS95sGhhuN76W5EWPYpcmHUcg/aUsLuoI9WA9UG4HqBWBwqgMpkNHB0hJcXZBe53PrKDD6Zw/xWOp8aj6CR2Rr9bEr63GKBzg0TgEi+rXDt7R/xd8Cs3YXQuhjidSQmKM3a0sFh/lh8AjsKoXOc51JCS52c9Xc66+vU/FBp+ncOLsoqW57ElpBBABsdD3r7HjeHSSBjKpheXNblAN7u25LJ2D0BiMYpYmtydGLN2b2BZU+FUNOxrY6aMZQ0XIudBYG/ag+V2LUdFMIqiXLIQHZQ0k2va+neVo+n8PzRjpiM7nNHVO7Rcj4bW3UmbC6KZwdNSxSODQzM8XNhyuhwyhMjZDSQZ2m4OQaHZBo+ncO5VIIy57hp2/793YVvlxSjik6OSdofcAjU2uL69mh3UWXh7DZOnvTgdM0NdbSzRyHYpslBSSvzyU8Tn9XrFoJ0vb4XPxQRpcboY4IpjK4wy3yuDCdiAdN+YR2O4a17mmqZmaCSLHYGxOylGhpSxrDTxZG3sMosL2/ILA4bRFxcaWEktLT1BsdwgjyY1SR1lRTyFzTAQHuJFrlodte+xHJfHY/hjd6ptgLl2U2G1r6f8gpb6CkfK+R9PG57yC4lu5ta/wAAAtbsJoHEk0cFyACcg2GyDRFj2HyCW04HRyCIixJLjta297G3qR2P4W22atiAILgTexA5jtHL16bqQMLoBKJBRwB4dnzBg8rt9a0xYFhsb3uFJEc+hDhcAdgHZrsgnwTMnibJE7Mx2xtbu2WaxjY2NuWNoa25NgOZNz+KyQEREBERAREQEREBERAXG+GDzc4x7MfzWLslxvhg83OMezH81iDzKNkQbIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIg7TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphBzFRh+NDiU1kVQ59AZGfsenIAboHHLa3bor/EfGPE5PE/8AX0y6gcxfe42uqmu4qw6hxCajqTKySEXkdl6oFg7t/wBpJ9TStsXE2EyvY2Opc4vcxrbQvsS8Xbrb4nlzsgjCm4kLJM1dSh2UZMrB5Wl73bta/v7ltdBjxzEVUA8uzdLG/k65eX/ySvk/FWHUs1THWmWmbA8ML5Gizrki4AJda4teyl4rjlDhgozVSWFXII4rW1JGh9V7D1uCCubR8QhzS6spzmZZ4ufKy2uNNBfXRDScSGJhdX04laRcNaA06Ozfu97berXvk0PFGFVkVQ6OoLXU7HSSsc05mNB1JtfuOnaFp+uODCPpXVD2w2DhI6JwBBtlI01Bvy99kQzrKHGJZqd8VbGwNjYJWgkBz9nEd1iSO8Ba20nEOSFz66AzN0cAAGnXcjLrp6v7raOLMIDHOkqHxhpeDnifYZdTra1rbdvJSqDHKLEJgyhdJOLBzniMhrQQSCSbXvYjS+u6JV1UziRkTnxywue5z7Rsy9Ufualvx/DtUyohxl1fK6GphZSZmFjNM1gDmB6vM2WA4qwY0xqBWjohYE9G7S5I2tfcFR63jPBaWF8njLpQw2cI2G4Nrga210tbtQbGQ8QZYmvqICL3e4OF926DqWOzhy3HYoz4eJ4xGBPTySubYvaAGtdfcgjax5a6D3ym8W4OZ3wuqHtla8xhhidmcQAbAAX52sdbgqbVY3h1LRQ1dRUhlPLH0zHlpsW2Bvt2G/qv2FENeGR4tFKDiE0U7HaWYAMugsdt75r+sWVc2h4ikkJlromBxj1YdgHkusMu9iBfYgahSm8WYK4sHjoGdwY0ujcA45c1gSOwi/ZcDcrB3F+DeLOnjqZJWiN0gEcLyXBu4Gm/d79tUGoU3EUbZ3+NQOPXc1jTe50sNW6Df3nms8PbjnjjBVuywPZcm7SWHKRY6b3sdNN1KouJMKragQUtV0spcWWbG61wCbXtbYEjttovlJxJhdZPDFSVPTOmcWMLGOILhe4200BPZb1hEtPQcQOeC6qpmjVxDRoDl0aLt2zbnmLbFZz0eL/SE0tPWtZTvfHZh1ysF81gQbHa3LfuX0cS0DYWTVJlpopGdJG6Rt87NOv1b2BuB1rG5AstLuL8GYajpKksFPI2OQuYeq4gEC1r31ta17goM6WlxzoHisrIHPdC5gyDKA83s7a+mn/ytbaHG4ogKeqiYRFaz3uku/NuS4E2sT77clMHEOGGAzNqS6MTmmuI3H9oASRttYE3271EfxdhTYmSZqhzHxPlDmwOIIba4va19besEbohploeI5AW+PQBrspPI3sL2IbpqD8T7pEsWPNa54nhs1xsxliXty97dDf3evZbJuJaCCuqKWbpmPhlbCT0ZIc5zczQ0DU3F9huClbxPhdDUzw1Uz4+hDc7zG7LdxIABtqbjleyDTQQ8QuMT6ypga39m50YaL8s4Jt2X259y6BVNLxHhVXWtpKera+pc5zAwNde7Rc8vX67LA8TYS2ESvqSxhJAzRPB0cG7EX3I+KJXKLnW8YYS5s5a+d3Q6ODYXG562mnc0nXlqVudxVhbMpkllYwmxkMTsjTpu61uY9XOyC8RVFLxHhtZHI6jnM2SN0pGUsBDbZtXWFxcbnS6jDi7CWQ5quZ9JKGtc6CZh6Rgd5NwL73HxF9UHQIqKTizB4nkSVRa0NLg8xuAcA7KbaajMQLjS5AV1BKyeCOaFwdHI0Pa4cwRcFBmiIgIiIC43wwebnGPZj+axdkuN8MHm5xj2Y/msQeZRsiDZEBERAREQEREBERAREQEREBERAREQEREBERAREQEREHaeBvzj4X7M3ynL0wvM/gb84+F+zN8py9MII81DSTvc6algkc7yi+MEnQt19xI9RKxZh1EzLkpKduW1rRgWtt8FFlx2hirZ6WSQslh8u4sALNN+8dYfArZDjFHNMYmPfnFyQY3CwAJvt3H4IM34Th0jpXSUFK4ynNIXRNOc9p01WbsOo3TSSvpYXSSNDHFzAbt009Wg07go309hl8vjbc1sxbY3AvbayyGNYeSwCpb1yA3qnW4v2dmp7OaDc3DKBokDaKmAkblfaJvWHYdNVrGC4WGOYMOowxwAcBA2xA25clpbxBhrpmRioF3+SbHU3tbtvdYjiPCywOFU06gENBOW5AubbAFwF9kE12G0LgQ6jpiHXuDE3W+/JbKekpqYWp4IohlDeowN0Gw05KI/G6BscMhnHRSte5rwCRZpAd8L/gVqdxDhrYmPdOQXnKGZDmvppb1EH1INowPCQ2wwyitly26Bu17222us34Phkl+kw6jddxec0LTck3J23usGY3hz6eScVTBFGcr3G4ymxNj8D8LLEY/hjiQyrY8jkwFx/Adunr03QSPoyg6XpfEqbpcxfn6Jt8x3N7b96y+j6MwshNLAYmXysLAWtuC02HLQkeokKNSY5h1U+NkFS10j9A2xuDpv2akD16KSK6mNPLO2UGKPy3AE20B/sR8UGAwugGS1FTDJq39k3q+Ttp/xb/KOxYnCMNMHQnD6Qw2tk6FuXe+1lnLiVHFTRVElQxsEjQ9jzsRpr+IWtuL0T2Tujmz9CCXgNIItuNeYuLjldBuhw+jgkL4aSnjeXZ8zIwDmsRf12J+JXyDD6Kne10FJTxOacwLIwCDYNvoOwAeoKIOIMNJf/5HVaxshdkdaxvbl3X9Wq+R8Q4Y9z2+MhrmucyxadS0XNu3QoJBwjDSSTh9ISSXH9i3Unc7c0OEYaWFhw+kLTYEdC2xttyX2pxSlp6WGofITHMWhmVpJNyAD3DUbrTJjlE2jkqY5Omjjf0b8luqe8mwHrugktw+iY1zW0lOGueZCBGLFxFi7120usBhOHBrmigpA1wyuHQt1HYdNlrZjWHvFQRUsvACZRzaL/8Ax8QsTjtACwdKSHSGO4aSAQCdTy0afVpdBJkw6ikqG1ElHTvnacwkdGC4Ha9+3QLGbC8PmfK+ahpZHy26RzomkvttfTWy11GNYfTzOinqmMkBAIIO5/8AYt69Fqm4gw2K+epALS3MC0gtBIFzcaDXdBKjwygim6WKipmS3Ls7Ymg3IsTe3NahgmFBrWjDKINa3IAIG2Db3tttfkvr8YoGxwSOqG5Jg4xmxObLuNt9DotM3EOFxRue6rZoL2ANzpfT3EfEBBsGB4SCCMMorg3B6BumluzsW0YXh4c5woaUOdbMeibc22vpysPgtH09hmfJ42zODYtsbg7m4tpbn2c1liGNUOH1IhqphG/IJDfYNzBtz+PuB7EG0YXh4hdCKGlETmuY5nRNylptcEW2Nhf1BY/Q+G5SPo+ksW5LdC3a4NttrgH3BahjlBY/tSCJDGGuaQS4GxsDqtTeJMMuc85js3N12kaafqH49iCWcIw05r0FIczsx/Yt1PbtvqVKhijhjEcLGxsGzWiwChuxeiEQk6a7DL0NwD5Vr2tudOztWufHaCnmayabK10QmEliW5SbA3QWaKBBi9DUSujhqA6RocXNDTduXe+mlr29eijs4iw17rRz5znEfVadCQTr2bHfmCEFuirDj2Fh5b45GXC5Ibc7b7dnPsGqs0Bcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEFBXVmEtxKoirqRoexjiZnxghwytc63M6Bt/ZHdfWcUwSIvHQmNjY2npBCQC12YCxtfa59RWWI4thUOIyU9TR9JO57InO6Jrrki4vzsO/wByiy8QYRlfGcPJJMZex0bLWed9zci503/FEJFLVYGJDGylawsd0OYxXBvl59hLwLlZUlVgMssbIIIy+QkN/YEX1y3uR26X5rVUYtgraanq5aDN4yH2vC3N1dCDfvsFqqMbwcVMbn0U3jFO4BgDAA1zhfkbb/jsg3mp4eY9sYgiLgWsaGwHdwzNbtzWBr8DhbEJKFscUtOyov0IIDXOFgQP+QHddfBjuEjpIjh0gfZ0kjOhbuLh1zex5+tWGI4hh1FJDDJA2R8oayNrGNOYa2AvyGX3aIIj8VwEM6N8YLYhI3KadxyC9n8u3Qr5WVOD02IPjqcPaDFZ3S9ECNGjUeoOA7veL4HHaB9LW1UFAHtjbG92YNDn9I4t1GtvJ57+qxXypx7Cs8jqnD5S85o3l0LXXLLEtJvyuO7X1oNgxPARTPijga+Jz2kxiA2c7R19RbTQ3WyGowWWQRQUjXF7dbQZQBYuF7gW8i/wK+PxXC2UbZZKEsY2oEAYY2Xa+wIOhtYDmFEp+JsKZDFmoXRO6xDY42m1jY9h2dva2pG6DfDi3D8AD2RsieG57dAQW6jTbe4Bt70mxbB6eN0bKUlksrWyhsVgCRo49trDbuWt2NYO0NY7DXNDskbQYGWId1hsTpqD79t1sPEGG5mNdRS53FxaOiab5Rve/wAP+kG+TEcDDI6V7IyyN2RkZhOVp1YbaWA3HZrbmvlRXYXQUUE5o8sNVE6TSMbENNnd56o9dlHrcSw+iFO9uGwGN8JmAs1rxYFwAFu463AHavsfEeFOjMcdLJ0THCLyGBt3agb2sQL3201QYzYngXi7XmjD4nRdLdsGlmWAHrBNgpNRUYFRVXQywRRyh+QAQnVxaCdh/tIuo1LjmG1AibFhxzzZA8ZGWaC9rNTfkSNN9BpayxkxzCIaicz0LumMkhe5sYfcxaA39QFhuPxQSH4pgT4gyVoLI8soY+F3VBtlda2g296xdimBAtpGwtPSyEmMREWcLgkj8Peo1Tj+HCKSSLC+lkBiIzMa25do257QL8joO9b5sdweGXOaTNKS9pLI2khzdSL331QZxYrgPXEUbAZrhwZCbutqbgDf8kp6vA3QSyQ0kbRA0OkaYQ3o2uAuezZ1z3LMVtH9GR1dHh8L3CYxRx5Rcdctv1QSL2vso44gwyJlRmw+VjgC2oaIm8nBpB11F3W+PJBrgxDAp6uWaameKqZzGuZJHmObYDS48ouHrB7lubWcPzxdPJSszyBhcx0BLuubgEW7dfxWUmPYWJC80j3Fji3PkYbHyu3c29d97LRTY9hLhTujoGs6UExERjRoN9eztsL6oJkldgQp21EjIxFA/o2vdEbNJvtpz11/NaY6zAaiRgjo2ve9wiH7C2mYN1JGwLhp3qPDjuEQ0z5YsPn8XqHdJIXMBu4mwFie71D4qZX4vRUrr+IGQsj8ZYWsaNbDt1BJIHvQJK3AWVEjTFGZTJ0brQEkvdcW23PWHuK+1uIYLGIPGYmyMdGyVr3RF1hs3cXvr/dR6jiHDWVTW+IudM2RjHEsbdhcdTe52O//AGts2M4Q7D4ayakvHJE8Ma+JuYtY4Att6yDbuQbBU4KyFszKVhY2Yx3EGrXZc5NiL62G3conj3DkcbiaWNgu1rQYLZsxuLacz+O6lNxujf4yG0hDaZpllzhoy2sHaC+wJ1520UWPHsPlfHFU4W9s+fK1nRNd1hpa5sN7j3d6DezGcDcMrog1zJC/IYCcrmjytBuAL37FtxiqwehfHFW00bgWMjJ6K7WMuS0Huu06dyiU2P4TJEyQUNp5Gs/ZtYwk576A3sRqb+vXW63jGMMlhZM2kzsikbCCWNJYDexG9h1edrb7IMp8QwqCKOdlJniqhIHSCMAWzAODr9pPv9ZF0VRgLYBPHBEGNqOjDhCf9Qje9vx71Hix3DJIomnDnO6MtEbWxsIaXnqgXIsSNT2bHXRb6LGMLrJmwQ0b7OlJu6FoaHAgZvXcgX3QfaOowWongihpGftWuYw9BZtgCCNuy477LoFzUPEOEMe8QwFkgm6PRjRmdlJuDe1rDfvF1bYRibMSZI5kT48jiOsQcwzEAgg88pQT1xvhg83OMezH81i7Jcb4YPNzjHsx/NYiXmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB2ngb84+F+zN8py9MLzP4G/OPhfszfKcvTCCiq8SZSYnLHHhsjpXuDTM1o69mg37Ta9lrPEjRTdMcNqxdme2Tvta/wDu7l9qMVxSHF6qFmHmelZ/puDHNvZjXeVqDclwFuY1ssZMexBgflwSodlGYEE2cL206t787EbdiIZniAtla12G1AaXNaDbXUX/ALWHrNkdjsj6OpljoJWSxdEcsltc5HfyBv8A9qTh2J1NVUujqMPkpmB7mNc8nrWta2nMX58uagNx7Ezd5wOoynKAy5zXub30tYAfG3ag2zcRCDomy0crnyaNLbdbqk3Gp00N9dFhHxC7onEYZUAtbmsG3sC6wB79QSOzVfajE66SkNTFhro54pzEA+J0jnMy3u0ADc2Gthpus5cZxBziynwuQOEjWXlDwCLtzEWbsLnXbTS6D4/iNjOkHiFSS3TQbnMB8Be5PLZb8Rxd1PLSdFAZIpWPe46XBaQMu411I57KI/G8TfFP0GDStexr8pkzWJFsumXW5PbsFjV8R1lGbVGFSAW8vM4NJtcN8nc7W7fig21HED2B0bcPl8YtIWMcdyzn6r/go/07+1dUswabMejZnydc3JuPcG/HTvUyixauqXkyYTLT2abOeSSDZxta23VA33ITD8Yr6mphhlwuWFrm3dKQ7LvbmAR79e7mg1z8TRRMfIaKo6JpeGvIAByc/eNu1b6HG/G5Q0UFTGP9zwN7ONv/AOpB7DYKI7Fq8lzZ8KkqLFpyiFzQ11/JBN8xG+bQab6gLB/ElaakQxYVI57Q5z2AuLsoGhtlFgSRvrodNkG+o4itTvlioJ3gMc5pIsCQbW96kVeMGmqZoTRTPax7WdIB1es29z3DW55L7VYpVR01HNBQSSmUftYQHZmHTS9raXO9hpuob8dxI0b5G4NM2Usd0bTmd1xa1xl0GpPuIQZQ8QvdT075MOqGvksX9WzWXvYk9l2nXkBfmFh9Zj4tG4YbUmd0Wcty6Ndr1b9ul/UbrcMaxHxh0RwaazHZS/McpABJI6uu1h6+S3YliNbT10IpqZ01M6PMQIn5r2O52A0GliddkGEWNyPpKmQUEzX07WOc0jygd8o3uBf1rTBjs5k6GfDJhNcN6vk3zZHankHB2vZY818ixrFDPkfg8ha/I5jgXANBIBDjl3Gp2/7UibFq+OhjmGFPfKQS+JryS2zmgW6uvlX2GxQaouIs9Ox3iFQZjGJCxo077FbRj0bqd8rKSZ+Wo6AtaASDlzXPZ2euwWqmxrEXyuZLg87QH2z3IFi6wO3qv7ysKXF60xteMHfTRuc0yEh1xd9nGwb/ALdboMm4/K6YA4ZOIsrHOJHWGbutrbS/v7FrZxK5zmO+jajo3uc1pA1uDb4Hl23Hap2I4pV01QI4cNmqGFzR0jDpZwOu3Igg9lx2qG/HcRY03wKoc4Ma7quJFzYkeTfTMOW9+xBOZizX4fJOaWRj2ZLwu3AdaxPYNdeyx7FGw/HzUQzOmoaiJ0UTpXZm6G3Ic9eR7j2LVUY3icb25cGlIzHNbM67chIscuhvYG/uvykx4rXOoppjhMoka1jmRZzd5cSCNRpa1/UUHylxp1XNCyCjkbfWTpBbKMhcPxAHvUZmPVBigvhzxM/J+zt2uLXG/ICx+I7VJjxOvlgqJBh74Q1sbmZwS6zjr1balo1IBvfRazjNcx4YMNmmFwOkDHszC175SDa+1r6c7IMTxIMj3tw2rytJBu0DYgfjmv6lvqMZkZTGVlBOXNmyFpbc5ALl2ncNB22USLHcTEUJlwWcvfG5zwAQGuA22O/+XUybFqtrIBFhkz5JI432dmAYXEhwJym2XT4oI8fEEl3F+G1Aa1oJDW3cSS4aDs0B9R5LQzG/F6p0cWFua6SRufK2172u46d5/DtUk4riEkEkgpHU9pgwZoHykNsdcosTqBtpruo7sfxRpdfA5zkb1gM3WdcCwNth1vwQTKbHDUQPkbQVDA2F0ozAakfu6c19kxpzaRszaGYPdK2PK7Tdodf4G3rBSbFqyKkdKcLldJ03RiNhJJba+byfd/2oj8exETZm4RUGLo2nJ0bs2c76kWAHqueW6DMcSNy3dh1UPKGrRuB2bi+/q1U3D8XdV1LI/Ep4mvaHB77W1BNvwP4dqgTY5ibGNeMFlIIzFgLi62Yj/bYWtf1FTsPxKqnq+jqsPfTxHNkeXF1yCAARlFrgk78kFsuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rES8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO08DfnHwv2ZvlOXpheZ/A35x8L9mb5Tl6YQVNZVYoKp0VJRsMYeAJXnQtI1NrjYqPW1WNhpNLSRkupmusSOrKTYtGvK9/d3q3fWUzHlj6iFrxu0vAI2/MfFZMqIX2yTRuubCzhqbX/ALaoKKasx81DI46GMRtks+TQhzRfUDNz07xZbzXYwMPikOHNNU6942v0bqLa+rN8O9W9RUQ08RkqJY4owbFz3AAe9ZMe17bscHDtBugpW1GMuknD6VjBHHJ0eW1pHAtyHfS4zacu1aYKniFjmMmpIHklwL76DS4Nr9pt7leRVdNM/LFPE929mvBOwP8AYg+8LZHLHI3NG9rh2g3QUUFbjmSOOSgYXlzGmQ2AAt1nEX5G2nNYw4pi0tJVkYcBVRBuSM7FxJuL310AN/8Akryeqgpw01E0cQecrc7gLnsCyMsYeGF7c55X1/zQ/BBQx1ePioMbqKExl9hIT5LbDWwOtjfsv7tdb8WxoPETcNYZ8ma2uXyrb37OS6W47QsWyxvc4Ne0lps4A7HvQUhrcaExa6gi6KxIc11yNdNL66ert7l8pqnG2005qaWMzNhj6MNb5Tz5V+tsLj4Ei+yvrjtS47Qgo6vE8Rgw+WbxE9K2Qsa218wsSCADzIA960+P48QL4bG3UE5XZjbMLjUjlcX966EvaHBpcLnldfGSMkY17HtcxwuHA3BQc7FXcQZmufh8Ra55aW3tZo2de/Ps5X7lcYXLVy04NfCIp7AkN21F7bnbb3KU+Rkds72tubC5tc9iwFRCTGBLGTIMzBmHWHaO3cINqLFkjJBdj2uAJbob6jcLA1EIDSZY7Odkb1hq7XT16H4INqL5cdoWPSx9Jkztz2vlvrbtQZolx2hLjtCAiXHaFiZGCQML25yCQ2+pAtf+4+KDJEBB2K+B7S4tDhca2ug+osJJoo/9SRjdC7U20G5WElVBG2N0k0bWyODWEuAzE7AdpQbkWplRC9sbmTRubIbMIcCHHU6dux+C+MqqeSd8DJ4nTM8uMPBc31jluEG5FrdUQta1zpWBriGtJcLEnYBbLjtGqAiAg7EIgLjfDB5ucY9mP5rF2S43wwebnGPZj+axB5lGyINkQEREBERAREQEREBERAREQEREBERAREQEREBERAREQdp4G/OPhfszfKcvTC8z+Bvzj4X7M3ynL0wg5+vw3CqnEJnzVDo6mW7HAPA/cDba9z2n12UZ3D2CupC3xwhnVJkErQTl0Fzbut8VcVuC0NbOZaiHPISDe53AI29Rt8OwKO/hnC3B/wCwcM8YidaR2rQAAN/+I/HtKIRo6HCPE6inhrWsaZC57s7MwcDcnUb9Ya+pZUtDh2HV85gr3x1dSzNeSQOsCdxcdykjh3DRUifoD0geHgl5Oo2WybAcPmY1kkBLWxNgHXPkNNwN+0IKufBMGnD5DVuuczi5kwva5cbW5AED1BvYtcOEYEZGz+NvHkM6ORwbqHNIu0gG5NviO5XMOCUEMs8kcOV8zXtebnUPN3fitT+HsPklEskcj5AQ7M6RxuRsd/d7h2IIsWF4VHQRUkdcejYx7M3StJcx5Ac06bEgC4se9RYMCwi/QePZ52hj3ZXM1sS0G1rWuCLdu9yrNvDeGNhEbYCGi9rPIOpB/wCgs3YBh7mZTG/QNaD0jrgN8kDXkgqhgWBzFoZWE5c7CGzN6xcSDftN9PdZTK6mwmpwptM+sbDTRkvuyRrSLAm22lgfdYLeeHcOcQXROcA/OA55IB623d1nad6+fVvDA1jWwOAYx0Ys93km5I3/AORQRaDD8Oo8QbJT4g91Q2MR2c9pGQG1jYf8bfHmvk2D4RNK989WHuLpCM0jOoSOsBpyvftClM4awxjHtZA5ma1y15B025r5Pw3QTSRmz2sBcXMDjZ9wRr8UGuXBsOrKyqqhVOc9+V0ga5jmt0FjYgjUDndaYcMwmpo4aeGoe2HpGyNYQG5jkyjRzf8AjfTW+qtqLCqSiBFNGWAtDDZx1Avb+5UaLh3DYp45mwHpGEODi4nUG4/HVBVyYLhD5mukxCcvL3PJL2i7mkk36umrv7LOLAMIZltXFxa3ox149BlAA0bro3Y9/aVZjAMPE3SNhId0pmIzmxfcm9r9pPxK1v4Zwp7WNdTXDG5B1ztcnt7Sgiw4FhMVRSVEdSQ9pzx5ZGhshDi4mwFjvy5CyxlwbBpK0tdUDxmV75Q3O0klwA2tyB0Hed1Z1GCUVQIxJG60Ze5tnkWLyS4/iV8hwOhhe1zI33bbLeRxtYtd29rW/BBWnBsFiAe+dofE4dZzmhwcAWjl/lhbZaY+H8FjaGCvddzMgvKwk3ce7XUkf21Vk3hzDxI+V8bnTPeZHPzEEk77craLKPhzDY4REyFzY7AFoebEAEAHt8ooK9mB4K+pEjakkxjpXN6QZSLAEnTbQXPO+q21OC4TI6B89V1GUzImtdI3K6NpBBOmuttVNjwKihgljpmuiMgILg473Bv8QEbgNGIIo39K/JEyLMZCCQ29tuep+KCrkwfCSyYPxCQftHOkGdgJcQ4a9W9xc29XOwQ8PYK0Sh9W8l7HEudM27Q4tuQeWw177KyHDuH9LI98b35r2BebNzMDHW9YC+nh7Ds7XiJ7S0WbaR3V62bTXt/CwQaMMocNw6oLKWsAlcG52ue0l4Is2/8ALceoqHT8PYMQ2KOqfI7ozG28jXG17kjTfl6lYs4doBmL2Pc57i5xzkZusTY9wzW9QC3U+CUVPURTxxv6WMuIcXknXe6CojwXBJaZrvHA+N0bS15ey9hlAN7X5Aa9pGiynwXCKd75ZK+SIvkY65lboW6C1x3j1dym/VjC8tjA4nI1ly8k2btr3Lc3AaFsmcMfcvEhvI6xItbnsLDRBXRcP4OOiibU5y3M1jS9hdcg7G17gOvb1Gyl4hw7S18sj55qnrOLg1rgA2+W9tOeUb37rLOl4dw2kcHU8BY4aAh5uOsHf3AKt0S5/wCqdDne7pKjrFpy5m2GXYWstz+HqdzKRvT1A8WbljPUJHWDr3Ld7gf4SrpEFVhWA0eGTiamz9IGFhc61yCb66K1REBcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEBERAREQEREGE80dPC+Wd7Y4mDM57jYAdpK5KXwj8NRyOb4499ja7YXkH8FC8M76hnCbBBmETqhomt/tsbX7r2X4Yu90X0Vj1eKcmSZ8duDk67X3wZOpSOb99+0rhv0qX7l35J9pXDfpUv3LvyX4EpeHMpXzOFbIWR5bAgX1Og+F7+5dG3QOmrG+9v6/Dxx0rnmdto+e79y+0rhv0qX7l35J9pXDfpUv3LvyX4vU0+G2YYKl1zKGuBBsG9uy3Glwe7R448DKbmxJvc6baaWCz7m0v8vnsv3jn/j8937F9pXDfpUv3LvyT7SuG/SpfuXfkvxg0+FOfYVUrR1RfL8TsolfFSRloo5ny9YglwtppY/ifgpr0JpbTt+757InpPPEb8Pnu/cvtK4b9Kl+5d+S+jwlcNEgeNyjvMD/AMl+Aote4NN525x+FO9s3lHz3ep8Nr6XE6RlVQzsngfs9h/zVaMaxnD8EphPidSyCMmzb3JcewAalfm/gLfOTirOt4sOjPcH67e7/pUnhnfUO4sayXN0LYG9EOVje5+P9lxqdGVtrZ0s24Rz8+bpW10xpozxHGX6B9pXDfpUv3LvyT7SuG/SpfuXfkvwJF2e4NN525x+HN72z+UfPd++/aVw36VL9y78k+0rhv0qX7l35L8WwyPDHRx+PTOa/OS6wNstiANOd7H1L6ymwzxtzXVjzAGXDi2xLtdPwHx7ljPQuliZj93z2aR0lnmN/wBvz3ftH2lcN+lS/cu/JPtK4b9Kl+5d+S/Gm0mFuNvHXi98pt8Li2h37fWvrqXCQ148ceHNGhAzXPZsP/dk7m0v8vnsd46j+Pz3fsn2lcN+lS/cu/JPtK4b9Kl+5d+S/FpqfC2xExVcrn2dYFvMXty56fFVavXoLS2+tv6/CtulM9fL57v337SuG/SpfuXfkrnAOKMIx5z2YbVtklYLmNzS11u2x3C80q74KfUR8WYUaTN0pqGjq/7Set7rXWeo6CwUxWtS07xG/Hb8L4ulctrxFojaXpVERfKu8IiICIiAuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAul1pWp88bJAx7gHHZBLul1FM0YAJkbY6A33QzxAgGRlztqglXS6iiWNwBD2m+2qyje2RuZjg5u1wgkXS60og3XS60og3XS60og7rwN+cfC/Zm+U5emF5i8DHnJwr2ZvlOXp1AREQEREBERBorqSCupJaaribLBIMr2O2IXDTeCrA3yOcyeujaToxsjSB8Wkr9ARb4tTlw7xjtMf8ZZMGPL/nXd+efZPgnpeIfzs/Sn2T4J6XiH87P0r9DRa946r7k82XYsHoh+efZPgnpeIfzs/Sn2T4J6XiH87P0r9DRO8dV9yeZ2LB6Ifnn2T4J6XiH87P0p9k+Cel4h/Oz9K/Q0TvHVfcnmdiweiH559k+Cel4h/Oz9K+jwUYICCarECOzOz9K7nEqsUNHJUOYXtZYuA7LgE+7dUruKomRy9JSyiWNmctBuNDZwv2hwcPctKazWX41vPNS2m0tJ2tWFpgmEUWC0LaTDoRFCNTzLj2k8yo3EnDmHcRUzYsRiJczVkjDZ7O2xWmPiije9rWw1Ni8R5smgJvbnfkVlUcRRU1Q+OaE5QXtGV4Lhl3zA2tfcam4XniM9b9eN+t47/VtNsM06vDZzH2T4J6XiH87P0p9k+Cel4h/Oz9K6WPiandEHGnmzlmfI0tJ/v/AOvfot9Dj1NW1QghjnBLyzM5oABsT232BXpnV62OM3nmwjT6WfCsOT+yfBPS8Q/nZ+lPsnwT0vEP52fpX6Giy7x1X3J5tOxYPRD88+yfBPS8Q/nZ+lPsnwT0vEP52fpX6Gid46r7k8zsWD0Q/PPsnwT0vEP52fpT7J8E9LxD+dn6V+honeOq+5PM7Fg9EPzz7J8E9LxD+dn6VfcMcF4Tw7MZ6RkktSRYTTOzOaOwWsB8F0qKt9bqMlere8zH/VqaXDSetWsbiIi8r0CIiAiIgLjfDB5ucY9mP5rF2S4zwx+bfGfZj+axB5mGyLQNl9QbkWlEG5FpRBuRaUQbkutKIN10utKIN10WlEBRqqjjqSelLspAaWg2Bsbj8Vvyj/CmUf4UEL6Lgta77WPZz3OyybhsA3L3es8+38FLyj/CmUf4UEH6Kp7OBznMLanYXB/6UyCIQxhjSSLk3PebrLKP8KZR/hQZIsco/wAKZR/hQZIsco/wplH+FBkixyj/AAr7lH+FB23gY85OFezN8py9OrzD4FwPtKwr2ZvlOXp5AREQEREBERAREQEREBERARR562ngmEU0mR1r6g2A13Ow2PwWAxKhIJ8bgsDY3eBb/LIJaWHYooxCjL8vjMN7X8sLbBUw1AJhlY+wBNjtfZBtsOxYujY4tLmglpuCRsVrqKuCmDDNIGB+jT26XWAxCkLnNFTFdpsesOwH/sIJNh2JYdiiOxOha3MauCxFxZ4Nx3dqOxOiaNaqE7aB4JQS0UUYhRFpcKuDKBcnpBon0jRA28bgva9ukGyCUi+Mc17A5hDmuFwQbghfUBERAREQEREBERAREQFxnhj82+M+zH81i7NcZ4ZPNtjPsx/NYg8vjZfViALf+19sEH1F8sEsEH1F8sEsEH1F8sEsEH1F8sF8yj/CgyRY5R/hTKP8KDJFjlH+FEGSIiAiIgIiICIiAiIgIiIO18DHnJwr2ZvlOXp1ePMAxapwLGqTE6Kxnpn5g12zhsQe4gkL9vpfDZgDqdhqqHEopiOsxjGPAPccwv8AAIP1RF+Y/bVw16Niv3LP1p9tXDXo2K/cs/Wg/TkX5j9tXDXo2K/cs/Wn21cNejYr9yz9aD9ORfmP21cNejYr9yz9afbVw16Niv3LP1oP05F+Y/bVw16Niv3LP1p9tXDXo2K/cs/Wg/TkX5j9tXDXo2K/cs/Wn21cNejYr9yz9aD9ORfmP21cNejYr9yz9afbVw16Niv3LP1oP0aoo6eodmnia91rXPvt/c/Fa24ZRNDg2mjAdvpuvz37auGvRsV+5Z+tPtq4a9GxX7ln60H6F9GUXR9H4vHkFrC23+XPxW+npoqfN0LAwONyB8F+bfbVw16Niv3LP1p9tXDXo2K/cs/Wg/Sp6eGoaGzxskaOThdRhhdEGlop22O411/yy/Pvtq4a9GxX7ln60+2rhr0bFfuWfrQfoDsJonyBzoGmzcob+6Bpy9w+CyGGUQJPi0dzvpv61+e/bVw16Niv3LP1p9tXDXo2K/cs/Wg/QDhNEXvcYGnOblp2v6l9bhdG2odN0DTIeZ5er+6/Pvtq4a9GxX7ln60+2rhr0bFfuWfrQfpsbGxsaxgDWtFgByC+r8x+2rhr0bFfuWfrT7auGvRsV+5Z+tB+nIvzH7auGvRsV+5Z+tPtq4a9GxX7ln60H6ci/Mftq4a9GxX7ln60+2rhr0bFfuWfrQfpyL8x+2rhr0bFfuWfrT7auGvRsV+5Z+tB+nIvzH7auGvRsV+5Z+tPtq4a9GxX7ln60H6ci/Mftq4a9GxX7ln60+2rhr0bFfuWfrQfpy4zwx+bfGfZj+axUn218NejYr9yz9a4fwmeE1nE+G/ReEU00FE9wdNJPYPfY3DQATYXsd+SD8yGy+oiAiIgIiICIiAiIgIiICIiAo9ZHNJG0QPyOvqe7Y/n7lIRBWhmI5SC9g56b7bX9a+E4new6K5GhtoD3/5urNEFc91eJA0ZSCSM1tuwlfQMRJcSYgM2g7v/AJVgiCDGK4TM6R0Zjuc1hrvp+CnIiCFK2r6Z/ROaG3u0n1DT8D8VrY3EMxBfGG33trb/AOVYogrcuJEk5ogQNBbQnRZ2xDOBmjyXNzbWynogwiz9EzpbdJYZrbX5rTWsne1vizw119b/AB/uAPeVJRBXxx13RyMfIy/RkNcN83IrF7cSc05XRNILbX59v+d6skQV7W4gHEZmZS4ancN5+/sWIbiRa4F8Td7FvqNt+9WSIIEza/ppDE5mSwDQV9mZWCYujcC2456WsNh23upyIK1xxDMxpDOsTct2Czc2tdHCS5okB69tBuP/AH/m09EFeRXuLTeNtiTbt0NgffZbaVlTma+peL5SHNbtf/LqWiAiIgIiICIiAiIgIiICIiAiIgIiICiVjagvaac7Dm6w35+5S0QVzG4jm6zo7Fx5DQaL6BiBsHOjHaW+7/2rBEFeRiGl8mjbdW2pvvr3LEtxJ1jniFnbDmLG/wD1ZWSIK5jcQaH3MZ1OUE92n4rOB1YKlrZw0x5bktHdr+KnIgKvDK9sj7PY5hcbXOoBJ/sLKwRBXx+PhoDsl+ZNtNO5a3HEndI1uQENsHbC+u34K0RBXOGIm4vGBcWtvbvQur2yMFmOBJvYbD/LKxRBWSOxJoblEZc4DYaA3591lKpRVZj4wWFvIAer/wBqSiAq6GOvZG0FzS4WzF2t/wAVYogrQ3ETu5gBOu2yyJr2sucnV5DUkKwRBX05xBxaZeja3QkW15X/AAv71YIiAiIg/9k="
                                    },
                                    {
                                        "timestamp": 763800349720,
                                        "data": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAFcAfQDASIAAhEBAxEB/8QAHAABAAIDAQEBAAAAAAAAAAAAAAQFAgMGCAEH/8QATBAAAQMCBAIECgcHBAIBAQkAAQACAwQRBRIhMQZBEyJRYQcUMjdUcXKBkbMVFheTodHSI0JVkpSx8DNSYsEk4fE0JjVEU2OCg6LC/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAECAwUEBv/EAC8RAQACAQICCQMEAwEAAAAAAAABAgMEESGRBRIUFTFRUoHwQVPREyJioTJCcWH/2gAMAwEAAhEDEQA/AOcRFX1FPVune+CRrRckdbuGhFu4/FBYIoMcNaWTCaZhJHUDdPxtcLW2HEWts2WMDWwuT6tSCf8APegskVZTx4kZw+WRjY7gFpsSRztbbn+Cn1DXPgkbGSHlpAINrH1oNiKsip8QabGdmUntuQLd4UyjbO2G1U9r5L7tFgg3oiICIiAiK3puGcdqoGTU2DYjLE8Xa9tO8hw7QbIKhFefVHiP+BYn/TP/ACT6o8R/wLE/6Z/5IKNFefVHiP8AgWJ/0z/yT6o8R/wLE/6Z/wCSCjRXn1R4j/gWJ/0z/wAk+qPEf8CxP+mf+SCjRXn1R4j/AIFif9M/8k+qPEf8CxP+mf8Akgo0V59UeI/4Fif9M/8AJPqjxH/AsT/pn/kgo0V59UeI/wCBYn/TP/JPqjxH/AsT/pn/AJIKNFefVHiP+BYn/TP/ACT6o8R/wLE/6Z/5IKNFefVHiP8AgWJ/0z/yT6o8R/wLE/6Z/wCSCjRXn1R4j/gWJ/0z/wAk+qPEf8CxP+mf+SCjRXn1R4j/AIFif9M/8k+qPEf8CxP+mf8Akgo0V59UeI/4Fif9M/8AJPqjxH/AsT/pn/kgo0V59UeI/wCBYn/TP/JPqjxH/AsT/pn/AJIKNFefVHiP+BYn/TP/ACT6o8R/wLE/6Z/5IKNFefVHiP8AgWJ/0z/yT6o8R/wLE/6Z/wCSCjRXn1R4j/gWJ/0z/wAk+qPEf8CxP+mf+SCjRXn1R4j/AIFif9M/8k+qPEf8CxP+mf8Akgo0V59UeI/4Fif9M/8AJPqjxH/AsT/pn/kgo0V59UeI/wCBYn/TP/JUOMYTidDXtjq4Z6OTKOpMxzCBrqARY7/ggyRV4p64yRZ6lpjbYu0sXG/cFvxCGaeNjYJDG4OuTmI0sezvt8EElFWNpcQbktVNNr3uL3B9ysYw5sbQ52ZwGp7SgyRQ8ThfNG0MZnIzcgd2kcyO1bKGN0cbw9uUl7jaw/6KCHjOMx4ZJGx8TpC8E6G1lXfWyH0WT+YKLxv/APV03sH+65+ndG0u6VpdcWFuXeulh0+O2OLTHF4Mue9bzWJdV9bIfRZP5gn1sh9Fk/mC5rpKXX9i7Unnt2c1l0lJc/sn5dP7681p2bF6ZU7Rk83R/WyH0WT+YKbhOOx4jVGBsL2Oyl1ybriZ3ROt0LC3U7ncclbcHf8A3v8A/wAbv+lTLpsdaTaIWx57zeImXcIiLmOgIiICIiAiIgIiICIiAiIg6rwXUFPiXHuFU1ZGJIcz5Cx2oJaxzhf3gL1ENBovM/gb84+F+zN8py9MICLkeLMVxk4pTYRw7GxtRKM0lTIAWxj8/wDPVr4cqcXosUlhx3HMNqqcCwALWyB99rC1vxWNM8ZLTWkTO3CZjwiXptpupijJe8RvxiN+M/1tzl2SIi2eYREQEREBERAREQEREBERAREQEREBERAREQEuO1a6iTo2E81WVVS2CGSeokDIo2lz3E6ADcq1azbwVtaK+K3uO1LjtXK4NxDQYxLLHRTudJHqWuBBI7R3KYMRpi8sFQ0vzZcouTfUf9H4LW2nvWdpjipGalo3iV9dFWxyuYb3JCnB2ewabXFyVjauzSJ3bEWiR8EcrI5JQ17wS1peQTbeyZ4P/wA0bX/1Dt8U2N29FGbNTOeGtmaXG+nSHkbdvbotrA1zc0byRyIdcJtsb7ti4Pw14fT1XAdZUzRtM9I5kkT7atJe1p9xBXdsN2677Fcd4YPNzjHsx/NYoS8yjZEGyICIiAiIgi1uH0taWmqhEhboCSRb4KN9A4b6K3+Z35qzRXjJeI2iZVmlZ4zCs+gcN9Fb/M780+gcN9Fb/M781Zop/VyeqeaP06eUKz6Bw30Vv8zvzW+jwyjo5TJTQBjyLXuTp71MRROS8xtMymKVjjECIiosIiICIiAiIgIiICIiAiIg7TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphBxHGDsZwfHKbGcJojXUmUx1MDP9TsBH4bDkuSjwscWcTU89Bw/U4ZAJ+nq6qpc68hvcgA6du3byX7IiaWbaS02wTtvvv8A+7+LzZtPOe297bxw4cPp5eQiIj0iIiAiIgIiICIiAiIgIiICIiAiIgIiICIiCPWMLourqRqqqsgjraSankLgyRpY4tNiL9nYVenVaH0sTzdzRdXpea+CtqxZyXD3DjMIqJJ3Vc1TIW5GZybMbpoBc9g+CmOwaldKJCXl7Xl7SbHLck6Ajtce9X/iUP8AsCeJQ/7Atbam9rdafFlXT1rG0IV8xyt1cVYsb0YB5WsUigZH5LQFtWNrdZtEbK+vw6jr5BJUdZwblaQ+1hrf4g2Kiy4BhsjSC0gktNw7Xq3t/dXSWUxkvHCJVnHWfGFH9XcNztcMwyvzgZtL7H8FZUUFPRU7YKewY3ZoN1KsiWyWtG1pK0rXjEMWAga7nVcf4YPNzjHsx/NYuyXG+GDzc4x7MfzWKi7zKNkQbIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIg7TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphAREQEREBERAXN8eYtV4PhdJLQOLZZqyKnLhTuncGuJvZgILiukUDGsIpMZpWQVolyRyNmY6KZ0TmvbsQ5pBHxQcTReENtJSmLFmiWu8YmjY0sFG4xxtY4ueyR3UcekbZt9QQdATa2k4+wyOkdUPiqQwASZSwB3Q+L9P0tr3y5QW+0LKb9TcHEYDGVbJs73uqW1koncXNa12aTNmIIY0WJt1W9gUp/DODyVRqJKJj5DRHDjmJINOf3CL2Pr3QVM3GboauGhkwWtGJzSRsZTdJFctkZK9r82bLa0MgIvcEc7gpxli2LYfWwNoi+Gi6Fz5KiOidVlsl+qHsYcwZa5uAdtxbWyouFsLo6mGpZHPLUxSNkZNPUSSvBax7Gi7iTYNkfYbdYnfVbcX4eocVqmVM5qoqhsZiMtNUyQOcy98riwi4v27XNrXQc27wgUtJZtQ+GolldGIuikbHEQYGSuc2R7hdvXFrgHUC25V7V8SwxcLwY7BTyS0ksTZi1zmxua0i4uCdTewsLkk6XWLuD8GDWiCnkpnMLSx9NO+JzMsYjAaWkEDI0C22gO+qkYjw3h1fh9DRTsnbT0T2vgEVRJGWuaLNOZpBNr87667oIcHFkToHOqaCqppmT0tO+GTLmY+fJlBsbaZxf1FasbxWvdjtTh9DUx0UNHRsrJ5jTGd787nta1jAeXRuJ0J1AFlJdwjhT6uKpkbVvljfFJ16uUh74zdj3DNZzh2m+w7ApeL4BQ4rURVE/jEVVE0sbPTVD4JMpNy0uYQSLi9ig56k46YMN6aWB1aKWnE9fU0rckcTekewuDJCH3vG8ltiRlOp0vun47pYIxPNQVbaWZ0sdJKCw+MvY7LlAzXBcfJvYEDWymngvA+jjjbTSsiazo3sbUSATNzl9pet+06znHrXvmdfcrXiHBmGzU1WKaMtmlbKIxNJJJFC6Q5nFrMwDbnW7bHsIQVeIceeI1knj1FLRw0ZnbVxvLXucWxRyNyEOtY9IBrb3K1wvi6mxHBsVroaaV7sODjJFE9kmezM/Uc02NxpvuCFFwfgajhgrfpg+PT1cskjyZJCGh8bIy0Fzi46RjUm4O1tF0OFYTTYZFMyAzyGZ2eR88z5XONgN3Em1gBZBzVR4RsHhFa7JUPjpXPzOYAQ+NsZeZG66tzNMftd2qgYl4RG/RlVUYdBeqpmTuMRcyVjyyB0reu11raa21uCOwq/pOCOHqWLo4cOaGeJuoCC9xvC55eW6n/AHEm+/etp4Rwl8D4qiOoqQ8PDnT1MkjiHxmNwzF17ZSR+O+qCqb4QaBuJmhlp5BMx3QyZZGEtl6PpCMt82X93Na1+7VG8eB1H4z9CV4jbBDVSjPFeOOVxEZIzak2JIGw+CtYuEsKjn6UNqiTq5jqqQse7J0edzc1i7Lpc6899VVY/wADtxKopmU1QymomQwU72DpM5ZE/MASHhrtNBnBtqdb2QQMS8JNM6kxAYXC59RC2QwkuY/pDHIGuBaHXbe5y5rXA5KdW+ECkoXup6yilgxBsz4XU8s0TQMsbJC7OXZT1ZWWF73PcSrb6oYRmnvFOY5c94TUSdGzO4Pdlbms27hfT/tbK3hfDKyplqXxzxVUspldNBUPifcxtjOrSCAWsYCNuqDvqgrKDjimrqqFsGH1nick0EHjTsjQ18sTZGAtvm2eAdNCfh1yqIeHMLgblipi1vTxVFukcevGxrGHfk1jRbnbVW6AiIgIiICIiAuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB2ngb84+F+zN8py9MLzP4G/OPhfszfKcvTCCHLilDFO6CSqhbM3dhd1hty//cPipHTw5M/Sx5d75hb/ADQ/BVdZw5htZWy1c0TjPLo9weRcZCz+x+IB5LGr4Zw2qpaankicI6eJsUeV1rBpBaewkW59p7SgtvGIet+1j6t79YaW3WElZTRgF88TQXNYLvG7tAPWVRv4MwZxjIge0xscxuWQiwcXE6c9XX17G9gWTuD8JcxjOieA0MabOtmDTcA++23Ygu3VdO2N8jp4gxjc7nZxYN7T3d6xiraaWPOyeMt7za2ttQdtdFWUnDGGUsMkccTiJI5InkusS19s23shKnhqjqXl9RJUSyFuUvc+5Ou+3utt3K1Yr9UcVqyrp3nqTRnl5XPX8is+miyB/SMyEXDswsQqE8IYTnDhFJYPz5S8kXuTse83W93DdC+Gkif0zo6YODQX+VmNzf8AJTaKf6ycVhNiNHCJDJURjowwus65GY2bt2nQdqNxGjc2NzaqAtk1Yc462hP9gT7iq6Dhqgp4po4OljEnRah2rejdmbbT/drrf4KPLwbhUsjnvE5cXB9zJezgCL/iT61RLoGyxuzZZGHL5Vjt618E8Rk6MSs6T/bmF/h7iqyi4eoKKCWGnY9kMsJgkZm0c27j/wD7d8VjR8N4fSVTKljHuqGyPl6R7rkufbMfwCC5REQEREBERAREQEREBERAREQEREBERAREQEREBcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEHKYpVcQN4rp4aFkhwjPEJ3dADa972JOo2ueVuX73SV7pm0kppW5pgOqPy718lraeKuho5JQ2oma5zGdoG/wDncewrdNIyGJ8srg2NjS5zjyA3KCgZX402Oxw/OQHWc4i5sere1tSOVhbfuWNLiuLz1DsuHt6IStjNzawtdx77XtfbRXXj1J0TJDUxBjwC0l4F7i4/AhaIcaw6bo+jq4z0gJbe40ABO+2hBRCvmqsajqHGKl6VmZ12usAwfu2O7hvf3L5LX470BLMOjEjmEgZs2V1nabi+oB5aG26uzV0wc1pniDnNzgZxct7R3d6xlrqWEuElRE1zbXaXi+uo0QV7K3FDSZnUTWzdPkDdSMlr5j2cxz5e7Gor8VFLBJT4aHSvz52PfbLY9X4jX3W5qdHilC8yAVUQMZs4OdlsbA8+4j4rdJV00bM8k8TGWBzOeALHYolTeN441ko8Tje5jn5T5OezrNFr7Ea3WH0rixq3QMw9jyx7WvNyBlI39/4K3diVE12U1Md+lEOh/ftfL67LBmL0D44Xsqo3NmLAzLqet5Nxyv3ohElrcVjoY3jD2yVLgbsa6wBu234F3w71iysxbpajpaMBkcb8mUX6RwLcpGvPracrbqwfidCxge6spw06g9ILWva/qvoshX0jnFoqoC5pDSBILgnl60Fc+txU0kjm0YE7Cy2lw+7jmsL38kA+/uWk1+Ol5LcOiABk6pde9hdut+Z099+SuRW0pjY8VMJY92Vrs4s49gPMrHx+jNv/ACoNRmH7Qai9r/HRBSfSGPCWQ/RzHMIZlF9B/ud26adXfvVthU9dM15r6ZsB3aGuvzIt8AD7+5Zy4jSRRskdOxzHv6MFnXu617aX5ArI4hRgXNXTga69IOW6JSUUWavpYaTxl0zXQXsHsBfc3tpa99V8OJUILQauAFwuAZAOz9Q+IQS0WkVVOXuYJ4i9oLi3OLgA2J9SwkxCkjJD6mEODgwjOL3Owt2lBJRQvpah6YxGpjDwXtIPIttmv6sw+KyOJUQkaw1cGZwLgM42AB/sQUEtFHZW0r2lzKmFzRuQ8ED/AC4WLMQo3xyPbVQlkds7s4s2+10EpFqNTAGZzNGGXDcxcLXOwWr6Rotf/Mp9P/1G/n3H4IJSKGMUoTOYRVRdIGh1i62hvbXvsfgpUUsc0Ykie17HbOabg+9BkiIgIiICIiAuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB2ngb84+F+zN8py9MLzP4G/OPhfszfKcvTCCpqsCgqMS8dfPUNlzMcA0tsMpBAGlwNNr8z2lWNTBHVQOhnbnifo5p2I7D3LW6vpm4iyhMzfG3RmURc8gIBJ7NSPX7imJdP4jL4pm6e3Vy5b78s2l/WghDh7DQ5rmwuGV4kaBI6zSNBYX0FgBbsCw+rOFF5cacl1iLmRx0PvUI1PEjXZY6OJ7GhxD5C0OfocoNnWvq29uYPJTI6jGvE6h8tJCJwxnQsbY9Y+Ve7tufL3ohIlwShljYxzH5GRCFrRI4WaOQ109fPRYy4FRTVMs0zHve8m13kBl2BhtbtAUepmxeWhlaynkhqOkDGPi6MnLc3fZxIta2m9/iotTXcQQNleaNhijc3KWgPc8He7QRseyyCxbw9honZN4veVjg4OL3E3Gx3Wb8EoHmPNE4iONsTRndYNbtpf8VAlrsdZCD4hG57tQWgEC77AEZxrl1voP7Iysx+SRuWhgbGXPBc/QgDyTbNrr6r9gQTnYFh7qd0LoXOjMnSWL3aOsRprpoVrbw7hrXFzYHAkMH+o7Zvk8+SiyT8RCHMylpzIGg5LjV2bUXzaC3rPrWuWq4lMByUNMJHB4ADgLdUZTcu5uO1uSCf9XsN6Rr+gN2tyDrusB8e4JJw9hkmTPTA5XF46x3IA7ewWUPxniJrnkUcLwQ0tBLQAeY8r8e61tbrI1PEXTPZ4lSmNuaz7+Va9tM2l9B3XQSarh+inp4YA18cMbmnK1x6wGXqnu6jfgtH1Uwwyhzo3GIBwEWY5QXWu71mwW+qqMXFVIylpIjCxzbPeR1xzt1tPWR8VGkfjxo4JGRt6fNIZY7NboHXYBqQLgZd/wB6/JBOkwShfSGmMThCXBxaHuFyGho59gH991oh4bw6N0LnRySSRFrmudI7dosDa9tgPgogqOJGPsaWB4YJGg3FpCLZHHrC19ToOdtN08a4kD2EUMDmuYC4FwGV2twOtry/w6BZuwaidRGkMbvFrgiPMbAg3utMXDmFxOJjprXFj13ai9+3t1UEVXEhe0eJwhrnAud1eqMovbra9bMNe0L4Z+JXZQKWFpFx5TQDoLXNz37BBOg4eo4ZpntMpZLHJG6MvJBzkFxvvc5QtgwKgD2uET8zX9Jm6R1ydN9ddgo9LU46+qAqKKCOnzanMC4tzAf7tDYk89rd6201TizqrLPRsEJe6zrgWaA61+sdSQz4nsQZzYBh00ssklPd8t85znW5udL/AOaLU7hrC3BwdA8hzQxw6V1iBbfX/iPgFHin4ifHFI+lpmPFs8V99ddc2mljzWplXxMGEuoKcvJ8kuADdtjm1vr6u07ILB/D2HPlkkdE/PIXFx6V2t9+a3nCKPopY8j7ShoeekddwBJ1N+0n1qO5+MSYXOOjjirrt6IttlscpN7k7dYe7RR6SXHgZHzwssYpXsYcuj8wLGkg8hcd9t0SmSYHQSQPikhL2Ol6Yhzyeta3b2Eiy0jhug6V5e17oy0MbGXHKwBmTT3LRTVHEJkyzUlOIw5vXJF3NsSdA7Q3sOdu9YzYhjjsQnhpKGJ0LHgCSQFosSdjfraAH3213RCU/hrCnhualByhrR1jsNuatKaCOmi6OFuVmZzrXvq4kn8SVRMq+In5b0FPEXEDVwdkF7Emzhcga2G999LH4+r4jAbloKUlweT1/JOuUeVryN++2m6DokVDHU4+alzZKOmELXtAeD5Tbam2bTX4d6Vz8eD5hSRwlgcCwutcjPqL3sBlFtr6olfIufNRxEWuLaWlFi7KHDUgZcv7+l7u05W71h41xEZS40UTWCSwaC09S3lHrb67aXtug6NFzr6viQNblw+lJc1xIz+SbnK3yteRvpvZXlIZnU7fGmtE1yDl2Ouh3O41Qblxvhg83OMezH81i7Jcb4YPNzjHsx/NYg8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO08DfnHwv2ZvlOXpheZ/A35x8L9mb5Tl6YQQZsJoZ8RZXy0zHVjGhrZTe4ANwPipNWJjA4Uxa2U2sXbDXX8LraiDn2sx8Oa57oHOyNDsugvfWw7ezu70bHxBHJHaWB7MwDrgeTbXs1v+A7V0CIKaQY6KOnETqR1TmtKXggW01FuzUWWTGYy3D4gH0xq83Xz3yhtuVtSdB8SrdEHPubxC6n/wBSASODx1QBbTqnnrf/AKWIZxGM7y+lzHK3JbS2uYjv2tfluuiRBV0f0sIZm1ZgMzmExuYOq11zYEb2tlPx7lFpRxB41C6pNGIiR0gZc2sTe1+0a+u3JXyIKWb6cc6QxeLsaC8NFrlwt1StDfrGWOLjSNIFw1ovrcaX9m/Zr3LoUQUdXBjDqmN9O9gsGZ7u6hFjmAG972N+wLBg4hEbXPNKXa3ba3MW19V7q/RBS0jccZSzid1O+ZrGdFm0D3Ada5Hbry0utb28Q5Zcj6MuDnBgc2wIuA0n1C59Ysr5EFABxGQ85qIOAGUWNibi/fa1/f3L7QR46KqPxqSLxYSOcbAZyw3sDyuLi9uwW5q+RBzzhxL1rGg/eDbA66dUn8fw71lk4gFQ/LJTmMudYuA0Fuqr9EFbK7ExSQiJkRqA4NkLjoRbVwUaJmOCRxlfAcsDw22jTJcZb81dogo8NZjbKu1W+E0xLjc6vtbS9tN7bd/ctMDceha5oZG/qbySBxL8o1BtoCb6W0/AdEiDmJIOIyJHdJFd0YAa1wFn9W5220PxUyWPGSynaySO4fIZCbai7so9Vsu3YrtEHO34l6Nv/wBJnya6bOvy11Hw071vrIMWeKUxyjpA13SFrg1odmaRccxlDh7/AHq7RBQtbxBlfd9KCM+UBt77ZefZf39y2ULcb8YtVvgEJjJJABLXn4aDT8e5XSIOelZxFI2QZ6WPM0kZBctOQ2AJ7HaXttbvWf8A9oc//wCFy52WFv3ba313v/6V8iDnmDiN1w51IwWNja58k29+a1+7Yq7pOm6BoqbdKNCRs7vW5EBcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEHM4oziVuJ1EmHvhfRgHoo35QScl9eflNy77PJ5LZTycSufEZoaJrC6MvaBqG2648re+3/atarFKOlnbDUTtZK4gBp0OtgD6rkC/aQN1KmljgidJK8MY3dx2CDmKt3E8NTXPo42Ts6QdC2YsDctze1jc6W3I9XMzcXlxuSSnZhkDWdEQ+d73NDZBYAsbub6k621aNbFWDcWw9wcW1tOQ0BxPSDQHQH8VjNi9HEIXGXMyUEtewFzQA4NNyNtXAIKjD5eJ44axtZT08jmRuNO4OF3vvoDYgDn+Gu60MqOLmwdejpnTubmFi0tacnknrg+X2X0V99MYdzrYBbNfrjS2/wAFnBidFUSGOGpjc+xOUHWw529x+CDnm1PFc0jbUtPGGSsDgQAHNyXdrmOmY7geq+pWRqOL/F4nCjoOldcOYT5PYfL2Pdzt26dAzEqJ8bpGVMRY0Ek5tgLfmPiFqdjeGt3rYLWzF2bQC17k7BBCqzjsGEzy0rYqnEnPIZE6zYw0EgEa31FiQSd1FmquKi9wgoaMDUAyOFtA3XR19Tmt3Wurh+MYewuDquK7XBp617Emw/ujMYw983Rsq4i67Ro7QkkgD16f27UFDE/i2SrDpIaWGK7XFoIcCMhu3e/lEC/dfZbcNn4pbk+kKalMcd8+SxfILttbrAA2zHbcW2V5LilDE/LJVwtd1jYvH7psfgdEbidGWwuM7Gib/TzaZtbae9BXYrNxAyrIw6mpJKbpGWc89bIQc19RsR8Dtoocs/FzJC2Olw6SNuUZ7kF19SbZtAL2tfkT2BX0uJ0UWXpauFmYXbd4FxYG/wACCtMeN4bIXBtZDo4MuXWuSARbt0KCjqJuLwYzFTUbi3K4htgHXb1gbu3BOlt7akc5gl4lGHTuNPQurbjo2ahti5wNzm5DK7v1CsxjGHFod47BlIBBzjX/ACxW2kr6Wsc5tLURyloBIYb2B2/uPigqI/rA/D5jUCJlRdha2C2a2e7wC42vl0F+fPs1GbiRrgyOmiMV2AOlLS+1tSSHAXvuQNOQduulRByUU/F7ImCSlo3vyuzkOB1DBa3WG7r/APpTqufiEiNtLS0zXGBrnveQ5rZP3m2zAnnqr9EHMS/WKSmkL2vZJ40bNpzECIuiIFi4kEZ7HXW3LktD5+MA9xbSUZDS9oFxZwu3K7yr/wC7TTftsuuRBz75uImUUJFNSyVJqGB4Bs0RFgLjq7cOuPdeyjST8UytjMdNTwODS4tcGuBcA6zSc/M5dvjyXUogp8TnxkzU7cNpouiky9I+a14x1s1xmFz5Nrd/cpeDurnUEZxVsTav98RCzfdqf7qaiAiIgIiICIiAiIgLjfDB5ucY9mP5rF2S43wwebnGPZj+axB5lGyINkQEREBERAREQEREBERAREQEREBERAREQEREBERAREQdp4G/OPhfszfKcvTC8z+Bvzj4X7M3ynL0wgi/R9J40ak08bpy/pOkcLuDsuW4J20uNO09pUiWNkrMsjQ5twbHuN1V1DcX+sMMkJpzhIhLXsLiH5y4dbbWwBttuVPr2zuo5RSECoAvHc2BcNQD3HZBE+gsMylviceU2u3WxtsLdnO3bqthwmiLIWGAFkIIYC42FyCb666gHXmFVwU/EMT2xuqYJIy6xe5t3Zdr+uwv6ye5fadvELYIonup72jDpDYu08vuv2fiiFk3BsPa14bTMAcSTYnnvbsSDCKCB2aGnaw9H0V2kjq9m/r+J7VXxy47JR1QEcLapr8sZcLNO+3aPJ/FfZDj5L8rYALZW5SLg2F3a7630005hEp7MHoWMe1sAyvZkcC4m407T3D4DsQ4Nh5aGmljLQALHsGov26lV1Q3iBz88Jp25XWsTu3tt2r5DFxCxzw6amcDncCRfXMS0eq1h6u9ELD6Ew7Ll8Ujy5Wty62Ib5OndbRZw4RQQG8VLG03B58jcfBR5hjAhibEYDIekD3nlr1Db1WutPRY26OpDpYhIWxiIjQXv1j8ESmuwige6RzqZjjJfMTc3ubn1a6r7JhNFIGB0RIY3K3ru0F83bvexvvdQoGY62oiEslM+ESEO6upZpY+sjN77d60mlx5tRM5lVC6M5uia7lrZpOmump70QtJsJoZsnS00bixrWtPMBt7D8T8VgcFw8ua7xVl2lpbqdCBYW7NAB321UFjcfa7oy+nLDKP2vMR3N9O2xb8ClNLjklPVNmjY2oaWBjmgBt7nMRfcZcu/O+vYSljAcM6v/iMJb5JJJtrc8+dzftUymo6emN4ImsNg3TsAA/s0fBV4GMvp2gugil6UBxAv+zyi9u/Nf3WUVn1ky/tDR5rHRo0BtodTttp29yDoUVHTDHnStM7qZrAWEgC9xpmF/Vf39yvEBERAREQEREBERAREQEREBERAREQFxvhg83OMezH81i7Jcb4YPNzjHsx/NYg8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO08DfnHwv2ZvlOXpheZ/A35x8L9mb5Tl6YQVz8aoGY7Hg7pwMQfCZxHY+QCBe+3NTp5mQROkldlY3c2utdRR01S+N9RBFI+MhzHPaCWkG4I7NQFnUwR1MLopm5o3WuL22N0Ff9P4XZxFZGcoBOUE2B22Hu9ei2Oxmga/KagZutplP7u/JbG4XQNa5raSEBwykBgGnZ+CfRdDlc3xSCzr3GQc90EZvEGHOcQ2oBOXO3/kLXuPd2r4eIsKAYRVtc137zWkgXva5tpfKbdvJSfonD+r/wCHBoLDqDbayfRVBkDBSQ5RYgZBpa9vhc29aDTU45QU9+km06JszSASHNdexHw/Edqxk4gw6N0bTOS95sGhhuN76W5EWPYpcmHUcg/aUsLuoI9WA9UG4HqBWBwqgMpkNHB0hJcXZBe53PrKDD6Zw/xWOp8aj6CR2Rr9bEr63GKBzg0TgEi+rXDt7R/xd8Cs3YXQuhjidSQmKM3a0sFh/lh8AjsKoXOc51JCS52c9Xc66+vU/FBp+ncOLsoqW57ElpBBABsdD3r7HjeHSSBjKpheXNblAN7u25LJ2D0BiMYpYmtydGLN2b2BZU+FUNOxrY6aMZQ0XIudBYG/ag+V2LUdFMIqiXLIQHZQ0k2va+neVo+n8PzRjpiM7nNHVO7Rcj4bW3UmbC6KZwdNSxSODQzM8XNhyuhwyhMjZDSQZ2m4OQaHZBo+ncO5VIIy57hp2/793YVvlxSjik6OSdofcAjU2uL69mh3UWXh7DZOnvTgdM0NdbSzRyHYpslBSSvzyU8Tn9XrFoJ0vb4XPxQRpcboY4IpjK4wy3yuDCdiAdN+YR2O4a17mmqZmaCSLHYGxOylGhpSxrDTxZG3sMosL2/ILA4bRFxcaWEktLT1BsdwgjyY1SR1lRTyFzTAQHuJFrlodte+xHJfHY/hjd6ptgLl2U2G1r6f8gpb6CkfK+R9PG57yC4lu5ta/wAAAtbsJoHEk0cFyACcg2GyDRFj2HyCW04HRyCIixJLjta297G3qR2P4W22atiAILgTexA5jtHL16bqQMLoBKJBRwB4dnzBg8rt9a0xYFhsb3uFJEc+hDhcAdgHZrsgnwTMnibJE7Mx2xtbu2WaxjY2NuWNoa25NgOZNz+KyQEREBERAREQEREBERAXG+GDzc4x7MfzWLslxvhg83OMezH81iDzKNkQbIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIg7TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphBzFRh+NDiU1kVQ59AZGfsenIAboHHLa3bor/EfGPE5PE/8AX0y6gcxfe42uqmu4qw6hxCajqTKySEXkdl6oFg7t/wBpJ9TStsXE2EyvY2Opc4vcxrbQvsS8Xbrb4nlzsgjCm4kLJM1dSh2UZMrB5Wl73bta/v7ltdBjxzEVUA8uzdLG/k65eX/ySvk/FWHUs1THWmWmbA8ML5Gizrki4AJda4teyl4rjlDhgozVSWFXII4rW1JGh9V7D1uCCubR8QhzS6spzmZZ4ufKy2uNNBfXRDScSGJhdX04laRcNaA06Ozfu97berXvk0PFGFVkVQ6OoLXU7HSSsc05mNB1JtfuOnaFp+uODCPpXVD2w2DhI6JwBBtlI01Bvy99kQzrKHGJZqd8VbGwNjYJWgkBz9nEd1iSO8Ba20nEOSFz66AzN0cAAGnXcjLrp6v7raOLMIDHOkqHxhpeDnifYZdTra1rbdvJSqDHKLEJgyhdJOLBzniMhrQQSCSbXvYjS+u6JV1UziRkTnxywue5z7Rsy9Ufualvx/DtUyohxl1fK6GphZSZmFjNM1gDmB6vM2WA4qwY0xqBWjohYE9G7S5I2tfcFR63jPBaWF8njLpQw2cI2G4Nrga210tbtQbGQ8QZYmvqICL3e4OF926DqWOzhy3HYoz4eJ4xGBPTySubYvaAGtdfcgjax5a6D3ym8W4OZ3wuqHtla8xhhidmcQAbAAX52sdbgqbVY3h1LRQ1dRUhlPLH0zHlpsW2Bvt2G/qv2FENeGR4tFKDiE0U7HaWYAMugsdt75r+sWVc2h4ikkJlromBxj1YdgHkusMu9iBfYgahSm8WYK4sHjoGdwY0ujcA45c1gSOwi/ZcDcrB3F+DeLOnjqZJWiN0gEcLyXBu4Gm/d79tUGoU3EUbZ3+NQOPXc1jTe50sNW6Df3nms8PbjnjjBVuywPZcm7SWHKRY6b3sdNN1KouJMKragQUtV0spcWWbG61wCbXtbYEjttovlJxJhdZPDFSVPTOmcWMLGOILhe4200BPZb1hEtPQcQOeC6qpmjVxDRoDl0aLt2zbnmLbFZz0eL/SE0tPWtZTvfHZh1ysF81gQbHa3LfuX0cS0DYWTVJlpopGdJG6Rt87NOv1b2BuB1rG5AstLuL8GYajpKksFPI2OQuYeq4gEC1r31ta17goM6WlxzoHisrIHPdC5gyDKA83s7a+mn/ytbaHG4ogKeqiYRFaz3uku/NuS4E2sT77clMHEOGGAzNqS6MTmmuI3H9oASRttYE3271EfxdhTYmSZqhzHxPlDmwOIIba4va19besEbohploeI5AW+PQBrspPI3sL2IbpqD8T7pEsWPNa54nhs1xsxliXty97dDf3evZbJuJaCCuqKWbpmPhlbCT0ZIc5zczQ0DU3F9huClbxPhdDUzw1Uz4+hDc7zG7LdxIABtqbjleyDTQQ8QuMT6ypga39m50YaL8s4Jt2X259y6BVNLxHhVXWtpKera+pc5zAwNde7Rc8vX67LA8TYS2ESvqSxhJAzRPB0cG7EX3I+KJXKLnW8YYS5s5a+d3Q6ODYXG562mnc0nXlqVudxVhbMpkllYwmxkMTsjTpu61uY9XOyC8RVFLxHhtZHI6jnM2SN0pGUsBDbZtXWFxcbnS6jDi7CWQ5quZ9JKGtc6CZh6Rgd5NwL73HxF9UHQIqKTizB4nkSVRa0NLg8xuAcA7KbaajMQLjS5AV1BKyeCOaFwdHI0Pa4cwRcFBmiIgIiIC43wwebnGPZj+axdkuN8MHm5xj2Y/msQeZRsiDZEBERAREQEREBERAREQEREBERAREQEREBERAREQEREHaeBvzj4X7M3ynL0wvM/gb84+F+zN8py9MII81DSTvc6algkc7yi+MEnQt19xI9RKxZh1EzLkpKduW1rRgWtt8FFlx2hirZ6WSQslh8u4sALNN+8dYfArZDjFHNMYmPfnFyQY3CwAJvt3H4IM34Th0jpXSUFK4ynNIXRNOc9p01WbsOo3TSSvpYXSSNDHFzAbt009Wg07go309hl8vjbc1sxbY3AvbayyGNYeSwCpb1yA3qnW4v2dmp7OaDc3DKBokDaKmAkblfaJvWHYdNVrGC4WGOYMOowxwAcBA2xA25clpbxBhrpmRioF3+SbHU3tbtvdYjiPCywOFU06gENBOW5AubbAFwF9kE12G0LgQ6jpiHXuDE3W+/JbKekpqYWp4IohlDeowN0Gw05KI/G6BscMhnHRSte5rwCRZpAd8L/gVqdxDhrYmPdOQXnKGZDmvppb1EH1INowPCQ2wwyitly26Bu17222us34Phkl+kw6jddxec0LTck3J23usGY3hz6eScVTBFGcr3G4ymxNj8D8LLEY/hjiQyrY8jkwFx/Adunr03QSPoyg6XpfEqbpcxfn6Jt8x3N7b96y+j6MwshNLAYmXysLAWtuC02HLQkeokKNSY5h1U+NkFS10j9A2xuDpv2akD16KSK6mNPLO2UGKPy3AE20B/sR8UGAwugGS1FTDJq39k3q+Ttp/xb/KOxYnCMNMHQnD6Qw2tk6FuXe+1lnLiVHFTRVElQxsEjQ9jzsRpr+IWtuL0T2Tujmz9CCXgNIItuNeYuLjldBuhw+jgkL4aSnjeXZ8zIwDmsRf12J+JXyDD6Kne10FJTxOacwLIwCDYNvoOwAeoKIOIMNJf/5HVaxshdkdaxvbl3X9Wq+R8Q4Y9z2+MhrmucyxadS0XNu3QoJBwjDSSTh9ISSXH9i3Unc7c0OEYaWFhw+kLTYEdC2xttyX2pxSlp6WGofITHMWhmVpJNyAD3DUbrTJjlE2jkqY5Omjjf0b8luqe8mwHrugktw+iY1zW0lOGueZCBGLFxFi7120usBhOHBrmigpA1wyuHQt1HYdNlrZjWHvFQRUsvACZRzaL/8Ax8QsTjtACwdKSHSGO4aSAQCdTy0afVpdBJkw6ikqG1ElHTvnacwkdGC4Ha9+3QLGbC8PmfK+ahpZHy26RzomkvttfTWy11GNYfTzOinqmMkBAIIO5/8AYt69Fqm4gw2K+epALS3MC0gtBIFzcaDXdBKjwygim6WKipmS3Ls7Ymg3IsTe3NahgmFBrWjDKINa3IAIG2Db3tttfkvr8YoGxwSOqG5Jg4xmxObLuNt9DotM3EOFxRue6rZoL2ANzpfT3EfEBBsGB4SCCMMorg3B6BumluzsW0YXh4c5woaUOdbMeibc22vpysPgtH09hmfJ42zODYtsbg7m4tpbn2c1liGNUOH1IhqphG/IJDfYNzBtz+PuB7EG0YXh4hdCKGlETmuY5nRNylptcEW2Nhf1BY/Q+G5SPo+ksW5LdC3a4NttrgH3BahjlBY/tSCJDGGuaQS4GxsDqtTeJMMuc85js3N12kaafqH49iCWcIw05r0FIczsx/Yt1PbtvqVKhijhjEcLGxsGzWiwChuxeiEQk6a7DL0NwD5Vr2tudOztWufHaCnmayabK10QmEliW5SbA3QWaKBBi9DUSujhqA6RocXNDTduXe+mlr29eijs4iw17rRz5znEfVadCQTr2bHfmCEFuirDj2Fh5b45GXC5Ibc7b7dnPsGqs0Bcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEFBXVmEtxKoirqRoexjiZnxghwytc63M6Bt/ZHdfWcUwSIvHQmNjY2npBCQC12YCxtfa59RWWI4thUOIyU9TR9JO57InO6Jrrki4vzsO/wByiy8QYRlfGcPJJMZex0bLWed9zci503/FEJFLVYGJDGylawsd0OYxXBvl59hLwLlZUlVgMssbIIIy+QkN/YEX1y3uR26X5rVUYtgraanq5aDN4yH2vC3N1dCDfvsFqqMbwcVMbn0U3jFO4BgDAA1zhfkbb/jsg3mp4eY9sYgiLgWsaGwHdwzNbtzWBr8DhbEJKFscUtOyov0IIDXOFgQP+QHddfBjuEjpIjh0gfZ0kjOhbuLh1zex5+tWGI4hh1FJDDJA2R8oayNrGNOYa2AvyGX3aIIj8VwEM6N8YLYhI3KadxyC9n8u3Qr5WVOD02IPjqcPaDFZ3S9ECNGjUeoOA7veL4HHaB9LW1UFAHtjbG92YNDn9I4t1GtvJ57+qxXypx7Cs8jqnD5S85o3l0LXXLLEtJvyuO7X1oNgxPARTPijga+Jz2kxiA2c7R19RbTQ3WyGowWWQRQUjXF7dbQZQBYuF7gW8i/wK+PxXC2UbZZKEsY2oEAYY2Xa+wIOhtYDmFEp+JsKZDFmoXRO6xDY42m1jY9h2dva2pG6DfDi3D8AD2RsieG57dAQW6jTbe4Bt70mxbB6eN0bKUlksrWyhsVgCRo49trDbuWt2NYO0NY7DXNDskbQYGWId1hsTpqD79t1sPEGG5mNdRS53FxaOiab5Rve/wAP+kG+TEcDDI6V7IyyN2RkZhOVp1YbaWA3HZrbmvlRXYXQUUE5o8sNVE6TSMbENNnd56o9dlHrcSw+iFO9uGwGN8JmAs1rxYFwAFu463AHavsfEeFOjMcdLJ0THCLyGBt3agb2sQL3201QYzYngXi7XmjD4nRdLdsGlmWAHrBNgpNRUYFRVXQywRRyh+QAQnVxaCdh/tIuo1LjmG1AibFhxzzZA8ZGWaC9rNTfkSNN9BpayxkxzCIaicz0LumMkhe5sYfcxaA39QFhuPxQSH4pgT4gyVoLI8soY+F3VBtlda2g296xdimBAtpGwtPSyEmMREWcLgkj8Peo1Tj+HCKSSLC+lkBiIzMa25do257QL8joO9b5sdweGXOaTNKS9pLI2khzdSL331QZxYrgPXEUbAZrhwZCbutqbgDf8kp6vA3QSyQ0kbRA0OkaYQ3o2uAuezZ1z3LMVtH9GR1dHh8L3CYxRx5Rcdctv1QSL2vso44gwyJlRmw+VjgC2oaIm8nBpB11F3W+PJBrgxDAp6uWaameKqZzGuZJHmObYDS48ouHrB7lubWcPzxdPJSszyBhcx0BLuubgEW7dfxWUmPYWJC80j3Fji3PkYbHyu3c29d97LRTY9hLhTujoGs6UExERjRoN9eztsL6oJkldgQp21EjIxFA/o2vdEbNJvtpz11/NaY6zAaiRgjo2ve9wiH7C2mYN1JGwLhp3qPDjuEQ0z5YsPn8XqHdJIXMBu4mwFie71D4qZX4vRUrr+IGQsj8ZYWsaNbDt1BJIHvQJK3AWVEjTFGZTJ0brQEkvdcW23PWHuK+1uIYLGIPGYmyMdGyVr3RF1hs3cXvr/dR6jiHDWVTW+IudM2RjHEsbdhcdTe52O//AGts2M4Q7D4ayakvHJE8Ma+JuYtY4Att6yDbuQbBU4KyFszKVhY2Yx3EGrXZc5NiL62G3conj3DkcbiaWNgu1rQYLZsxuLacz+O6lNxujf4yG0hDaZpllzhoy2sHaC+wJ1520UWPHsPlfHFU4W9s+fK1nRNd1hpa5sN7j3d6DezGcDcMrog1zJC/IYCcrmjytBuAL37FtxiqwehfHFW00bgWMjJ6K7WMuS0Huu06dyiU2P4TJEyQUNp5Gs/ZtYwk576A3sRqb+vXW63jGMMlhZM2kzsikbCCWNJYDexG9h1edrb7IMp8QwqCKOdlJniqhIHSCMAWzAODr9pPv9ZF0VRgLYBPHBEGNqOjDhCf9Qje9vx71Hix3DJIomnDnO6MtEbWxsIaXnqgXIsSNT2bHXRb6LGMLrJmwQ0b7OlJu6FoaHAgZvXcgX3QfaOowWongihpGftWuYw9BZtgCCNuy477LoFzUPEOEMe8QwFkgm6PRjRmdlJuDe1rDfvF1bYRibMSZI5kT48jiOsQcwzEAgg88pQT1xvhg83OMezH81i7Jcb4YPNzjHsx/NYiXmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB2ngb84+F+zN8py9MLzP4G/OPhfszfKcvTCCiq8SZSYnLHHhsjpXuDTM1o69mg37Ta9lrPEjRTdMcNqxdme2Tvta/wDu7l9qMVxSHF6qFmHmelZ/puDHNvZjXeVqDclwFuY1ssZMexBgflwSodlGYEE2cL206t787EbdiIZniAtla12G1AaXNaDbXUX/ALWHrNkdjsj6OpljoJWSxdEcsltc5HfyBv8A9qTh2J1NVUujqMPkpmB7mNc8nrWta2nMX58uagNx7Ezd5wOoynKAy5zXub30tYAfG3ag2zcRCDomy0crnyaNLbdbqk3Gp00N9dFhHxC7onEYZUAtbmsG3sC6wB79QSOzVfajE66SkNTFhro54pzEA+J0jnMy3u0ADc2Gthpus5cZxBziynwuQOEjWXlDwCLtzEWbsLnXbTS6D4/iNjOkHiFSS3TQbnMB8Be5PLZb8Rxd1PLSdFAZIpWPe46XBaQMu411I57KI/G8TfFP0GDStexr8pkzWJFsumXW5PbsFjV8R1lGbVGFSAW8vM4NJtcN8nc7W7fig21HED2B0bcPl8YtIWMcdyzn6r/go/07+1dUswabMejZnydc3JuPcG/HTvUyixauqXkyYTLT2abOeSSDZxta23VA33ITD8Yr6mphhlwuWFrm3dKQ7LvbmAR79e7mg1z8TRRMfIaKo6JpeGvIAByc/eNu1b6HG/G5Q0UFTGP9zwN7ONv/AOpB7DYKI7Fq8lzZ8KkqLFpyiFzQ11/JBN8xG+bQab6gLB/ElaakQxYVI57Q5z2AuLsoGhtlFgSRvrodNkG+o4itTvlioJ3gMc5pIsCQbW96kVeMGmqZoTRTPax7WdIB1es29z3DW55L7VYpVR01HNBQSSmUftYQHZmHTS9raXO9hpuob8dxI0b5G4NM2Usd0bTmd1xa1xl0GpPuIQZQ8QvdT075MOqGvksX9WzWXvYk9l2nXkBfmFh9Zj4tG4YbUmd0Wcty6Ndr1b9ul/UbrcMaxHxh0RwaazHZS/McpABJI6uu1h6+S3YliNbT10IpqZ01M6PMQIn5r2O52A0GliddkGEWNyPpKmQUEzX07WOc0jygd8o3uBf1rTBjs5k6GfDJhNcN6vk3zZHankHB2vZY818ixrFDPkfg8ha/I5jgXANBIBDjl3Gp2/7UibFq+OhjmGFPfKQS+JryS2zmgW6uvlX2GxQaouIs9Ox3iFQZjGJCxo077FbRj0bqd8rKSZ+Wo6AtaASDlzXPZ2euwWqmxrEXyuZLg87QH2z3IFi6wO3qv7ysKXF60xteMHfTRuc0yEh1xd9nGwb/ALdboMm4/K6YA4ZOIsrHOJHWGbutrbS/v7FrZxK5zmO+jajo3uc1pA1uDb4Hl23Hap2I4pV01QI4cNmqGFzR0jDpZwOu3Igg9lx2qG/HcRY03wKoc4Ma7quJFzYkeTfTMOW9+xBOZizX4fJOaWRj2ZLwu3AdaxPYNdeyx7FGw/HzUQzOmoaiJ0UTpXZm6G3Ic9eR7j2LVUY3icb25cGlIzHNbM67chIscuhvYG/uvykx4rXOoppjhMoka1jmRZzd5cSCNRpa1/UUHylxp1XNCyCjkbfWTpBbKMhcPxAHvUZmPVBigvhzxM/J+zt2uLXG/ICx+I7VJjxOvlgqJBh74Q1sbmZwS6zjr1balo1IBvfRazjNcx4YMNmmFwOkDHszC175SDa+1r6c7IMTxIMj3tw2rytJBu0DYgfjmv6lvqMZkZTGVlBOXNmyFpbc5ALl2ncNB22USLHcTEUJlwWcvfG5zwAQGuA22O/+XUybFqtrIBFhkz5JI432dmAYXEhwJym2XT4oI8fEEl3F+G1Aa1oJDW3cSS4aDs0B9R5LQzG/F6p0cWFua6SRufK2172u46d5/DtUk4riEkEkgpHU9pgwZoHykNsdcosTqBtpruo7sfxRpdfA5zkb1gM3WdcCwNth1vwQTKbHDUQPkbQVDA2F0ozAakfu6c19kxpzaRszaGYPdK2PK7Tdodf4G3rBSbFqyKkdKcLldJ03RiNhJJba+byfd/2oj8exETZm4RUGLo2nJ0bs2c76kWAHqueW6DMcSNy3dh1UPKGrRuB2bi+/q1U3D8XdV1LI/Ep4mvaHB77W1BNvwP4dqgTY5ibGNeMFlIIzFgLi62Yj/bYWtf1FTsPxKqnq+jqsPfTxHNkeXF1yCAARlFrgk78kFsuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rES8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO08DfnHwv2ZvlOXpheZ/A35x8L9mb5Tl6YQVNZVYoKp0VJRsMYeAJXnQtI1NrjYqPW1WNhpNLSRkupmusSOrKTYtGvK9/d3q3fWUzHlj6iFrxu0vAI2/MfFZMqIX2yTRuubCzhqbX/ALaoKKasx81DI46GMRtks+TQhzRfUDNz07xZbzXYwMPikOHNNU6942v0bqLa+rN8O9W9RUQ08RkqJY4owbFz3AAe9ZMe17bscHDtBugpW1GMuknD6VjBHHJ0eW1pHAtyHfS4zacu1aYKniFjmMmpIHklwL76DS4Nr9pt7leRVdNM/LFPE929mvBOwP8AYg+8LZHLHI3NG9rh2g3QUUFbjmSOOSgYXlzGmQ2AAt1nEX5G2nNYw4pi0tJVkYcBVRBuSM7FxJuL310AN/8Akryeqgpw01E0cQecrc7gLnsCyMsYeGF7c55X1/zQ/BBQx1ePioMbqKExl9hIT5LbDWwOtjfsv7tdb8WxoPETcNYZ8ma2uXyrb37OS6W47QsWyxvc4Ne0lps4A7HvQUhrcaExa6gi6KxIc11yNdNL66ert7l8pqnG2005qaWMzNhj6MNb5Tz5V+tsLj4Ei+yvrjtS47Qgo6vE8Rgw+WbxE9K2Qsa218wsSCADzIA960+P48QL4bG3UE5XZjbMLjUjlcX966EvaHBpcLnldfGSMkY17HtcxwuHA3BQc7FXcQZmufh8Ra55aW3tZo2de/Ps5X7lcYXLVy04NfCIp7AkN21F7bnbb3KU+Rkds72tubC5tc9iwFRCTGBLGTIMzBmHWHaO3cINqLFkjJBdj2uAJbob6jcLA1EIDSZY7Odkb1hq7XT16H4INqL5cdoWPSx9Jkztz2vlvrbtQZolx2hLjtCAiXHaFiZGCQML25yCQ2+pAtf+4+KDJEBB2K+B7S4tDhca2ug+osJJoo/9SRjdC7U20G5WElVBG2N0k0bWyODWEuAzE7AdpQbkWplRC9sbmTRubIbMIcCHHU6dux+C+MqqeSd8DJ4nTM8uMPBc31jluEG5FrdUQta1zpWBriGtJcLEnYBbLjtGqAiAg7EIgLjfDB5ucY9mP5rF2S43wwebnGPZj+axB5lGyINkQEREBERAREQEREBERAREQEREBERAREQEREBERAREQdp4G/OPhfszfKcvTC8z+Bvzj4X7M3ynL0wg5+vw3CqnEJnzVDo6mW7HAPA/cDba9z2n12UZ3D2CupC3xwhnVJkErQTl0Fzbut8VcVuC0NbOZaiHPISDe53AI29Rt8OwKO/hnC3B/wCwcM8YidaR2rQAAN/+I/HtKIRo6HCPE6inhrWsaZC57s7MwcDcnUb9Ya+pZUtDh2HV85gr3x1dSzNeSQOsCdxcdykjh3DRUifoD0geHgl5Oo2WybAcPmY1kkBLWxNgHXPkNNwN+0IKufBMGnD5DVuuczi5kwva5cbW5AED1BvYtcOEYEZGz+NvHkM6ORwbqHNIu0gG5NviO5XMOCUEMs8kcOV8zXtebnUPN3fitT+HsPklEskcj5AQ7M6RxuRsd/d7h2IIsWF4VHQRUkdcejYx7M3StJcx5Ac06bEgC4se9RYMCwi/QePZ52hj3ZXM1sS0G1rWuCLdu9yrNvDeGNhEbYCGi9rPIOpB/wCgs3YBh7mZTG/QNaD0jrgN8kDXkgqhgWBzFoZWE5c7CGzN6xcSDftN9PdZTK6mwmpwptM+sbDTRkvuyRrSLAm22lgfdYLeeHcOcQXROcA/OA55IB623d1nad6+fVvDA1jWwOAYx0Ys93km5I3/AORQRaDD8Oo8QbJT4g91Q2MR2c9pGQG1jYf8bfHmvk2D4RNK989WHuLpCM0jOoSOsBpyvftClM4awxjHtZA5ma1y15B025r5Pw3QTSRmz2sBcXMDjZ9wRr8UGuXBsOrKyqqhVOc9+V0ga5jmt0FjYgjUDndaYcMwmpo4aeGoe2HpGyNYQG5jkyjRzf8AjfTW+qtqLCqSiBFNGWAtDDZx1Avb+5UaLh3DYp45mwHpGEODi4nUG4/HVBVyYLhD5mukxCcvL3PJL2i7mkk36umrv7LOLAMIZltXFxa3ox149BlAA0bro3Y9/aVZjAMPE3SNhId0pmIzmxfcm9r9pPxK1v4Zwp7WNdTXDG5B1ztcnt7Sgiw4FhMVRSVEdSQ9pzx5ZGhshDi4mwFjvy5CyxlwbBpK0tdUDxmV75Q3O0klwA2tyB0Hed1Z1GCUVQIxJG60Ze5tnkWLyS4/iV8hwOhhe1zI33bbLeRxtYtd29rW/BBWnBsFiAe+dofE4dZzmhwcAWjl/lhbZaY+H8FjaGCvddzMgvKwk3ce7XUkf21Vk3hzDxI+V8bnTPeZHPzEEk77craLKPhzDY4REyFzY7AFoebEAEAHt8ooK9mB4K+pEjakkxjpXN6QZSLAEnTbQXPO+q21OC4TI6B89V1GUzImtdI3K6NpBBOmuttVNjwKihgljpmuiMgILg473Bv8QEbgNGIIo39K/JEyLMZCCQ29tuep+KCrkwfCSyYPxCQftHOkGdgJcQ4a9W9xc29XOwQ8PYK0Sh9W8l7HEudM27Q4tuQeWw177KyHDuH9LI98b35r2BebNzMDHW9YC+nh7Ds7XiJ7S0WbaR3V62bTXt/CwQaMMocNw6oLKWsAlcG52ue0l4Is2/8ALceoqHT8PYMQ2KOqfI7ozG28jXG17kjTfl6lYs4doBmL2Pc57i5xzkZusTY9wzW9QC3U+CUVPURTxxv6WMuIcXknXe6CojwXBJaZrvHA+N0bS15ey9hlAN7X5Aa9pGiynwXCKd75ZK+SIvkY65lboW6C1x3j1dym/VjC8tjA4nI1ly8k2btr3Lc3AaFsmcMfcvEhvI6xItbnsLDRBXRcP4OOiibU5y3M1jS9hdcg7G17gOvb1Gyl4hw7S18sj55qnrOLg1rgA2+W9tOeUb37rLOl4dw2kcHU8BY4aAh5uOsHf3AKt0S5/wCqdDne7pKjrFpy5m2GXYWstz+HqdzKRvT1A8WbljPUJHWDr3Ld7gf4SrpEFVhWA0eGTiamz9IGFhc61yCb66K1REBcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEBERAREQEREGE80dPC+Wd7Y4mDM57jYAdpK5KXwj8NRyOb4499ja7YXkH8FC8M76hnCbBBmETqhomt/tsbX7r2X4Yu90X0Vj1eKcmSZ8duDk67X3wZOpSOb99+0rhv0qX7l35J9pXDfpUv3LvyX4EpeHMpXzOFbIWR5bAgX1Og+F7+5dG3QOmrG+9v6/Dxx0rnmdto+e79y+0rhv0qX7l35J9pXDfpUv3LvyX4vU0+G2YYKl1zKGuBBsG9uy3Glwe7R448DKbmxJvc6baaWCz7m0v8vnsv3jn/j8937F9pXDfpUv3LvyT7SuG/SpfuXfkvxg0+FOfYVUrR1RfL8TsolfFSRloo5ny9YglwtppY/ifgpr0JpbTt+757InpPPEb8Pnu/cvtK4b9Kl+5d+S+jwlcNEgeNyjvMD/AMl+Aote4NN525x+FO9s3lHz3ep8Nr6XE6RlVQzsngfs9h/zVaMaxnD8EphPidSyCMmzb3JcewAalfm/gLfOTirOt4sOjPcH67e7/pUnhnfUO4sayXN0LYG9EOVje5+P9lxqdGVtrZ0s24Rz8+bpW10xpozxHGX6B9pXDfpUv3LvyT7SuG/SpfuXfkvwJF2e4NN525x+HN72z+UfPd++/aVw36VL9y78k+0rhv0qX7l35L8WwyPDHRx+PTOa/OS6wNstiANOd7H1L6ymwzxtzXVjzAGXDi2xLtdPwHx7ljPQuliZj93z2aR0lnmN/wBvz3ftH2lcN+lS/cu/JPtK4b9Kl+5d+S/Gm0mFuNvHXi98pt8Li2h37fWvrqXCQ148ceHNGhAzXPZsP/dk7m0v8vnsd46j+Pz3fsn2lcN+lS/cu/JPtK4b9Kl+5d+S/FpqfC2xExVcrn2dYFvMXty56fFVavXoLS2+tv6/CtulM9fL57v337SuG/SpfuXfkrnAOKMIx5z2YbVtklYLmNzS11u2x3C80q74KfUR8WYUaTN0pqGjq/7Set7rXWeo6CwUxWtS07xG/Hb8L4ulctrxFojaXpVERfKu8IiICIiAuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAul1pWp88bJAx7gHHZBLul1FM0YAJkbY6A33QzxAgGRlztqglXS6iiWNwBD2m+2qyje2RuZjg5u1wgkXS60og3XS60og3XS60og7rwN+cfC/Zm+U5emF5i8DHnJwr2ZvlOXp1AREQEREBERBorqSCupJaaribLBIMr2O2IXDTeCrA3yOcyeujaToxsjSB8Wkr9ARb4tTlw7xjtMf8ZZMGPL/nXd+efZPgnpeIfzs/Sn2T4J6XiH87P0r9DRa946r7k82XYsHoh+efZPgnpeIfzs/Sn2T4J6XiH87P0r9DRO8dV9yeZ2LB6Ifnn2T4J6XiH87P0p9k+Cel4h/Oz9K/Q0TvHVfcnmdiweiH559k+Cel4h/Oz9K+jwUYICCarECOzOz9K7nEqsUNHJUOYXtZYuA7LgE+7dUruKomRy9JSyiWNmctBuNDZwv2hwcPctKazWX41vPNS2m0tJ2tWFpgmEUWC0LaTDoRFCNTzLj2k8yo3EnDmHcRUzYsRiJczVkjDZ7O2xWmPiije9rWw1Ni8R5smgJvbnfkVlUcRRU1Q+OaE5QXtGV4Lhl3zA2tfcam4XniM9b9eN+t47/VtNsM06vDZzH2T4J6XiH87P0p9k+Cel4h/Oz9K6WPiandEHGnmzlmfI0tJ/v/AOvfot9Dj1NW1QghjnBLyzM5oABsT232BXpnV62OM3nmwjT6WfCsOT+yfBPS8Q/nZ+lPsnwT0vEP52fpX6Giy7x1X3J5tOxYPRD88+yfBPS8Q/nZ+lPsnwT0vEP52fpX6Gid46r7k8zsWD0Q/PPsnwT0vEP52fpT7J8E9LxD+dn6V+honeOq+5PM7Fg9EPzz7J8E9LxD+dn6VfcMcF4Tw7MZ6RkktSRYTTOzOaOwWsB8F0qKt9bqMlere8zH/VqaXDSetWsbiIi8r0CIiAiIgLjfDB5ucY9mP5rF2S4zwx+bfGfZj+axB5mGyLQNl9QbkWlEG5FpRBuRaUQbkutKIN10utKIN10WlEBRqqjjqSelLspAaWg2Bsbj8Vvyj/CmUf4UEL6Lgta77WPZz3OyybhsA3L3es8+38FLyj/CmUf4UEH6Kp7OBznMLanYXB/6UyCIQxhjSSLk3PebrLKP8KZR/hQZIsco/wAKZR/hQZIsco/wplH+FBkixyj/AAr7lH+FB23gY85OFezN8py9OrzD4FwPtKwr2ZvlOXp5AREQEREBERAREQEREBERARR562ngmEU0mR1r6g2A13Ow2PwWAxKhIJ8bgsDY3eBb/LIJaWHYooxCjL8vjMN7X8sLbBUw1AJhlY+wBNjtfZBtsOxYujY4tLmglpuCRsVrqKuCmDDNIGB+jT26XWAxCkLnNFTFdpsesOwH/sIJNh2JYdiiOxOha3MauCxFxZ4Nx3dqOxOiaNaqE7aB4JQS0UUYhRFpcKuDKBcnpBon0jRA28bgva9ukGyCUi+Mc17A5hDmuFwQbghfUBERAREQEREBERAREQFxnhj82+M+zH81i7NcZ4ZPNtjPsx/NYg8vjZfViALf+19sEH1F8sEsEH1F8sEsEH1F8sEsEH1F8sF8yj/CgyRY5R/hTKP8KDJFjlH+FEGSIiAiIgIiICIiAiIgIiIO18DHnJwr2ZvlOXp1ePMAxapwLGqTE6Kxnpn5g12zhsQe4gkL9vpfDZgDqdhqqHEopiOsxjGPAPccwv8AAIP1RF+Y/bVw16Niv3LP1p9tXDXo2K/cs/Wg/TkX5j9tXDXo2K/cs/Wn21cNejYr9yz9aD9ORfmP21cNejYr9yz9afbVw16Niv3LP1oP05F+Y/bVw16Niv3LP1p9tXDXo2K/cs/Wg/TkX5j9tXDXo2K/cs/Wn21cNejYr9yz9aD9ORfmP21cNejYr9yz9afbVw16Niv3LP1oP0aoo6eodmnia91rXPvt/c/Fa24ZRNDg2mjAdvpuvz37auGvRsV+5Z+tPtq4a9GxX7ln60H6F9GUXR9H4vHkFrC23+XPxW+npoqfN0LAwONyB8F+bfbVw16Niv3LP1p9tXDXo2K/cs/Wg/Sp6eGoaGzxskaOThdRhhdEGlop22O411/yy/Pvtq4a9GxX7ln60+2rhr0bFfuWfrQfoDsJonyBzoGmzcob+6Bpy9w+CyGGUQJPi0dzvpv61+e/bVw16Niv3LP1p9tXDXo2K/cs/Wg/QDhNEXvcYGnOblp2v6l9bhdG2odN0DTIeZ5er+6/Pvtq4a9GxX7ln60+2rhr0bFfuWfrQfpsbGxsaxgDWtFgByC+r8x+2rhr0bFfuWfrT7auGvRsV+5Z+tB+nIvzH7auGvRsV+5Z+tPtq4a9GxX7ln60H6ci/Mftq4a9GxX7ln60+2rhr0bFfuWfrQfpyL8x+2rhr0bFfuWfrT7auGvRsV+5Z+tB+nIvzH7auGvRsV+5Z+tPtq4a9GxX7ln60H6ci/Mftq4a9GxX7ln60+2rhr0bFfuWfrQfpy4zwx+bfGfZj+axUn218NejYr9yz9a4fwmeE1nE+G/ReEU00FE9wdNJPYPfY3DQATYXsd+SD8yGy+oiAiIgIiICIiAiIgIiICIiAo9ZHNJG0QPyOvqe7Y/n7lIRBWhmI5SC9g56b7bX9a+E4new6K5GhtoD3/5urNEFc91eJA0ZSCSM1tuwlfQMRJcSYgM2g7v/AJVgiCDGK4TM6R0Zjuc1hrvp+CnIiCFK2r6Z/ROaG3u0n1DT8D8VrY3EMxBfGG33trb/AOVYogrcuJEk5ogQNBbQnRZ2xDOBmjyXNzbWynogwiz9EzpbdJYZrbX5rTWsne1vizw119b/AB/uAPeVJRBXxx13RyMfIy/RkNcN83IrF7cSc05XRNILbX59v+d6skQV7W4gHEZmZS4ancN5+/sWIbiRa4F8Td7FvqNt+9WSIIEza/ppDE5mSwDQV9mZWCYujcC2456WsNh23upyIK1xxDMxpDOsTct2Czc2tdHCS5okB69tBuP/AH/m09EFeRXuLTeNtiTbt0NgffZbaVlTma+peL5SHNbtf/LqWiAiIgIiICIiAiIgIiICIiAiIgIiICiVjagvaac7Dm6w35+5S0QVzG4jm6zo7Fx5DQaL6BiBsHOjHaW+7/2rBEFeRiGl8mjbdW2pvvr3LEtxJ1jniFnbDmLG/wD1ZWSIK5jcQaH3MZ1OUE92n4rOB1YKlrZw0x5bktHdr+KnIgKvDK9sj7PY5hcbXOoBJ/sLKwRBXx+PhoDsl+ZNtNO5a3HEndI1uQENsHbC+u34K0RBXOGIm4vGBcWtvbvQur2yMFmOBJvYbD/LKxRBWSOxJoblEZc4DYaA3591lKpRVZj4wWFvIAer/wBqSiAq6GOvZG0FzS4WzF2t/wAVYogrQ3ETu5gBOu2yyJr2sucnV5DUkKwRBX05xBxaZeja3QkW15X/AAv71YIiAiIg/9k=",
                                        "timing": 3000
                                    }
                                ],
                                "scale": 3000,
                                "type": "filmstrip"
                            }
                        },
                        "link-in-text-block": {
                            "id": "link-in-text-block",
                            "title": "Links rely on color to be distinguishable.",
                            "description": "Low-contrast text is difficult or impossible for many users to read. Link text that is discernible improves the experience for users with low vision. [Learn how to make links distinguishable](https://dequeuniversity.com/rules/axe/4.8/link-in-text-block).",
                            "score": 0,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "debugData": {
                                    "tags": [
                                        "cat.color",
                                        "wcag2a",
                                        "wcag141",
                                        "TTv5",
                                        "TT13.a",
                                        "EN-301-549",
                                        "EN-9.1.4.1"
                                    ],
                                    "type": "debugdata",
                                    "impact": "serious"
                                },
                                "items": [
                                    {
                                        "node": {
                                            "explanation": "Fix any of the following:\n  The link has insufficient color contrast of 1.55:1 with the surrounding text. (Minimum contrast is 3:1, link text: #1a0dab, surrounding text: #4d5156)\n  The link has no styling (such as underline) to distinguish it from the surrounding text",
                                            "boundingRect": {
                                                "left": 719,
                                                "top": 578,
                                                "right": 767,
                                                "height": 15,
                                                "bottom": 593,
                                                "width": 49
                                            },
                                            "selector": "div.o3j99 > div#gws-output-pages-elements-homepage_additional_languages__als > div#SIvCob > a",
                                            "nodeLabel": "English",
                                            "snippet": "<a href=\"https://www.google.com/setprefs?sig=0__3jxyNK6oEKzSql4pTbA4nJOXGw%3D&amp;hl=en…\">",
                                            "type": "node",
                                            "lhId": "1-2-A",
                                            "path": "1,HTML,1,BODY,2,DIV,3,DIV,2,DIV,1,DIV,1,A"
                                        },
                                        "subItems": {
                                            "type": "subitems",
                                            "items": [
                                                {
                                                    "relatedNode": {
                                                        "nodeLabel": "Google angeboten auf: English",
                                                        "boundingRect": {
                                                            "bottom": 600,
                                                            "top": 572,
                                                            "width": 185,
                                                            "left": 583,
                                                            "height": 28,
                                                            "right": 767
                                                        },
                                                        "snippet": "<div id=\"SIvCob\">",
                                                        "path": "1,HTML,1,BODY,2,DIV,3,DIV,2,DIV,1,DIV",
                                                        "type": "node",
                                                        "lhId": "1-3-DIV",
                                                        "selector": "div.L3eUgb > div.o3j99 > div#gws-output-pages-elements-homepage_additional_languages__als > div#SIvCob"
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "type": "table",
                                "headings": [
                                    {
                                        "key": "node",
                                        "valueType": "node",
                                        "subItemsHeading": {
                                            "valueType": "node",
                                            "key": "relatedNode"
                                        },
                                        "label": "Failing Elements"
                                    }
                                ]
                            }
                        },
                        "aria-progressbar-name": {
                            "id": "aria-progressbar-name",
                            "title": "ARIA `progressbar` elements have accessible names",
                            "description": "When a `progressbar` element doesn't have an accessible name, screen readers announce it with a generic name, making it unusable for users who rely on screen readers. [Learn how to label `progressbar` elements](https://dequeuniversity.com/rules/axe/4.8/aria-progressbar-name).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "prioritize-lcp-image": {
                            "id": "prioritize-lcp-image",
                            "title": "Preload Largest Contentful Paint image",
                            "description": "If the LCP element is dynamically added to the page, you should preload the image in order to improve LCP. [Learn more about preloading LCP elements](https://web.dev/articles/optimize-lcp#optimize_when_the_resource_is_discovered).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "csp-xss": {
                            "id": "csp-xss",
                            "title": "Ensure CSP is effective against XSS attacks",
                            "description": "A strong Content Security Policy (CSP) significantly reduces the risk of cross-site scripting (XSS) attacks. [Learn how to use a CSP to prevent XSS](https://developer.chrome.com/docs/lighthouse/best-practices/csp-xss/)",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "details": {
                                "headings": [
                                    {
                                        "valueType": "text",
                                        "subItemsHeading": {
                                            "key": "description"
                                        },
                                        "key": "description",
                                        "label": "Description"
                                    },
                                    {
                                        "label": "Directive",
                                        "key": "directive",
                                        "valueType": "code",
                                        "subItemsHeading": {
                                            "key": "directive"
                                        }
                                    },
                                    {
                                        "key": "severity",
                                        "valueType": "text",
                                        "subItemsHeading": {
                                            "key": "severity"
                                        },
                                        "label": "Severity"
                                    }
                                ],
                                "type": "table",
                                "items": [
                                    {
                                        "severity": "High",
                                        "description": "No CSP found in enforcement mode"
                                    }
                                ]
                            }
                        },
                        "list": {
                            "id": "list",
                            "title": "Lists contain only `<li>` elements and script supporting elements (`<script>` and `<template>`).",
                            "description": "Screen readers have a specific way of announcing lists. Ensuring proper list structure aids screen reader output. [Learn more about proper list structure](https://dequeuniversity.com/rules/axe/4.8/list).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "items": [],
                                "type": "table",
                                "headings": []
                            }
                        },
                        "html-has-lang": {
                            "id": "html-has-lang",
                            "title": "`<html>` element has a `[lang]` attribute",
                            "description": "If a page doesn't specify a `lang` attribute, a screen reader assumes that the page is in the default language that the user chose when setting up the screen reader. If the page isn't actually in the default language, then the screen reader might not announce the page's text correctly. [Learn more about the `lang` attribute](https://dequeuniversity.com/rules/axe/4.8/html-has-lang).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "items": [],
                                "headings": [],
                                "type": "table"
                            }
                        },
                        "image-alt": {
                            "id": "image-alt",
                            "title": "Image elements have `[alt]` attributes",
                            "description": "Informative elements should aim for short, descriptive alternate text. Decorative elements can be ignored with an empty alt attribute. [Learn more about the `alt` attribute](https://dequeuniversity.com/rules/axe/4.8/image-alt).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "items": [],
                                "type": "table",
                                "headings": []
                            }
                        },
                        "render-blocking-resources": {
                            "id": "render-blocking-resources",
                            "title": "Eliminate render-blocking resources",
                            "description": "Resources are blocking the first paint of your page. Consider delivering critical JS/CSS inline and deferring all non-critical JS/styles. [Learn how to eliminate render-blocking resources](https://developer.chrome.com/docs/lighthouse/performance/render-blocking-resources/).",
                            "score": 1,
                            "scoreDisplayMode": "metricSavings",
                            "details": {
                                "headings": [],
                                "items": [],
                                "overallSavingsMs": 0,
                                "type": "opportunity"
                            },
                            "numericValue": 0,
                            "numericUnit": "millisecond"
                        },
                        "http-status-code": {
                            "id": "http-status-code",
                            "title": "Page has successful HTTP status code",
                            "description": "Pages with unsuccessful HTTP status codes may not be indexed properly. [Learn more about HTTP status codes](https://developer.chrome.com/docs/lighthouse/seo/http-status-code/).",
                            "score": 1,
                            "scoreDisplayMode": "binary"
                        },
                        "input-button-name": {
                            "id": "input-button-name",
                            "title": "Input buttons have discernible text.",
                            "description": "Adding discernable and accessible text to input buttons may help screen reader users understand the purpose of the input button. [Learn more about input buttons](https://dequeuniversity.com/rules/axe/4.8/input-button-name).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "unused-javascript": {
                            "id": "unused-javascript",
                            "title": "Reduce unused JavaScript",
                            "description": "Reduce unused JavaScript and defer loading scripts until they are required to decrease bytes consumed by network activity. [Learn how to reduce unused JavaScript](https://developer.chrome.com/docs/lighthouse/performance/unused-javascript/).",
                            "score": 0,
                            "scoreDisplayMode": "metricSavings",
                            "displayValue": "Potential savings of 299 KiB",
                            "details": {
                                "items": [
                                    {
                                        "totalBytes": 278320,
                                        "url": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/ed=1/dg=2/br=1/rs=ACT90oEcAGSwfSNPLyn9LHwQv0bYDA_7PQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf,FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe,KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=cdos,hsm,jsa,mb4ZUb,d,csi,cEt90b,SNUn3,qddgKe,sTsDMc,dtl0hd,eHDfl",
                                        "wastedPercent": 49.4286634129954,
                                        "wastedBytes": 137570
                                    },
                                    {
                                        "wastedBytes": 87069,
                                        "url": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/exm=SNUn3,cEt90b,cdos,csi,d,dtl0hd,eHDfl,hsm,jsa,mb4ZUb,qddgKe,sTsDMc/ed=1/dg=2/br=1/ujg=1/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=B2qlPe,DhPYme,GU4Gab,MpJwZc,NzU6V,UUJqVe,Wo3n8,aa,abd,async,epYOx,ifl,ms4mZb,pHXghd,q0xTif,s39S4,sOXFj,sb_wiz,sf,sonic,spch?xjs=s1",
                                        "totalBytes": 147853,
                                        "wastedPercent": 58.889100764374625
                                    },
                                    {
                                        "wastedPercent": 72.24094375043457,
                                        "wastedBytes": 55925,
                                        "totalBytes": 77414,
                                        "url": "https://www.gstatic.com/og/_/js/k=og.qtm.en_US.u8Ti_iwBwEs.2019.O/rt=j/m=qabr,q_dnp,qcwid,qapid,qald,q_dg/exm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/rs=AA2YrTsL4HiE1bvJV-MS9_mgAxWPHzXqxw"
                                    },
                                    {
                                        "totalBytes": 41036,
                                        "wastedPercent": 62.22560223629039,
                                        "url": "https://apis.google.com/_/scs/abc-static/_/js/k=gapi.gapi.en.GsbA68hXs80.O/m=gapi_iframes,googleapis_client/rt=j/sv=1/d=1/ed=1/rs=AHpOoo899t-H8Lxb3OqzMDuPn6TV_i36ag/cb=gapi.loaded_0",
                                        "wastedBytes": 25535
                                    }
                                ],
                                "headings": [
                                    {
                                        "key": "url",
                                        "subItemsHeading": {
                                            "key": "source",
                                            "valueType": "code"
                                        },
                                        "label": "URL",
                                        "valueType": "url"
                                    },
                                    {
                                        "subItemsHeading": {
                                            "key": "sourceBytes"
                                        },
                                        "label": "Transfer Size",
                                        "key": "totalBytes",
                                        "valueType": "bytes"
                                    },
                                    {
                                        "label": "Potential Savings",
                                        "key": "wastedBytes",
                                        "valueType": "bytes",
                                        "subItemsHeading": {
                                            "key": "sourceWastedBytes"
                                        }
                                    }
                                ],
                                "type": "opportunity",
                                "overallSavingsMs": 130,
                                "sortedBy": [
                                    "wastedBytes"
                                ],
                                "debugData": {
                                    "type": "debugdata",
                                    "metricSavings": {
                                        "FCP": 0,
                                        "LCP": 120
                                    }
                                },
                                "overallSavingsBytes": 306099
                            },
                            "numericValue": 130,
                            "numericUnit": "millisecond"
                        },
                        "uses-long-cache-ttl": {
                            "id": "uses-long-cache-ttl",
                            "title": "Uses efficient cache policy on static assets",
                            "description": "A long cache lifetime can speed up repeat visits to your page. [Learn more about efficient cache policies](https://developer.chrome.com/docs/lighthouse/performance/uses-long-cache-ttl/).",
                            "score": 1,
                            "scoreDisplayMode": "metricSavings",
                            "displayValue": "0 resources found",
                            "details": {
                                "items": [],
                                "type": "table",
                                "headings": []
                            },
                            "numericValue": 0,
                            "numericUnit": "byte"
                        },
                        "unsized-images": {
                            "id": "unsized-images",
                            "title": "Image elements do not have explicit `width` and `height`",
                            "description": "Set an explicit width and height on image elements to reduce layout shifts and improve CLS. [Learn how to set image dimensions](https://web.dev/articles/optimize-cls#images_without_dimensions)",
                            "score": 0.5,
                            "scoreDisplayMode": "metricSavings",
                            "details": {
                                "items": [
                                    {
                                        "url": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAYCAMAAAAiV0Z6AAAAPFBMVEVLoEN0wU6CzFKCzFKCzFKCz…",
                                        "node": {
                                            "lhId": "1-53-IMG",
                                            "boundingRect": {
                                                "top": 862,
                                                "height": 14,
                                                "right": 509,
                                                "width": 12,
                                                "left": 497,
                                                "bottom": 876
                                            },
                                            "path": "1,HTML,1,BODY,2,DIV,5,DIV,2,DIV,1,DIV,0,A,0,IMG",
                                            "selector": "div.KxwPGc > div.KxwPGc > a.pHiOh > img.Pb9hCb",
                                            "type": "node",
                                            "snippet": "<img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAYCAMAAAAiV0Z6AAAAPFBM…\" class=\"Pb9hCb\" alt=\"\" data-iml=\"1707821877274\" data-atf=\"1\" data-frt=\"0\">",
                                            "nodeLabel": "div.KxwPGc > div.KxwPGc > a.pHiOh > img.Pb9hCb"
                                        }
                                    }
                                ],
                                "type": "table",
                                "headings": [
                                    {
                                        "key": "node",
                                        "valueType": "node"
                                    },
                                    {
                                        "valueType": "url",
                                        "label": "URL",
                                        "key": "url"
                                    }
                                ]
                            }
                        },
                        "timing-budget": {
                            "id": "timing-budget",
                            "title": "Timing budget",
                            "description": "Set a timing budget to help you keep an eye on the performance of your site. Performant sites load fast and respond to user input events quickly. [Learn more about performance budgets](https://developers.google.com/web/tools/lighthouse/audits/budgets).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "no-document-write": {
                            "id": "no-document-write",
                            "title": "Avoids `document.write()`",
                            "description": "For users on slow connections, external scripts dynamically injected via `document.write()` can delay page load by tens of seconds. [Learn how to avoid document.write()](https://developer.chrome.com/docs/lighthouse/best-practices/no-document-write/).",
                            "score": 1,
                            "scoreDisplayMode": "metricSavings",
                            "details": {
                                "headings": [],
                                "items": [],
                                "type": "table"
                            }
                        },
                        "use-landmarks": {
                            "id": "use-landmarks",
                            "title": "HTML5 landmark elements are used to improve navigation",
                            "description": "Landmark elements (`<main>`, `<nav>`, etc.) are used to improve the keyboard navigation of the page for assistive technology. [Learn more about landmark elements](https://developer.chrome.com/docs/lighthouse/accessibility/use-landmarks/).",
                            "score": null,
                            "scoreDisplayMode": "manual"
                        },
                        "deprecations": {
                            "id": "deprecations",
                            "title": "Avoids deprecated APIs",
                            "description": "Deprecated APIs will eventually be removed from the browser. [Learn more about deprecated APIs](https://developer.chrome.com/docs/lighthouse/best-practices/deprecations/).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "items": [],
                                "type": "table",
                                "headings": []
                            }
                        },
                        "heading-order": {
                            "id": "heading-order",
                            "title": "Heading elements appear in a sequentially-descending order",
                            "description": "Properly ordered headings that do not skip levels convey the semantic structure of the page, making it easier to navigate and understand when using assistive technologies. [Learn more about heading order](https://dequeuniversity.com/rules/axe/4.8/heading-order).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "type": "table",
                                "headings": [],
                                "items": []
                            }
                        },
                        "definition-list": {
                            "id": "definition-list",
                            "title": "`<dl>`'s contain only properly-ordered `<dt>` and `<dd>` groups, `<script>`, `<template>` or `<div>` elements.",
                            "description": "When definition lists are not properly marked up, screen readers may produce confusing or inaccurate output. [Learn how to structure definition lists correctly](https://dequeuniversity.com/rules/axe/4.8/definition-list).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "bypass": {
                            "id": "bypass",
                            "title": "The page contains a heading, skip link, or landmark region",
                            "description": "Adding ways to bypass repetitive content lets keyboard users navigate the page more efficiently. [Learn more about bypass blocks](https://dequeuniversity.com/rules/axe/4.8/bypass).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "table-duplicate-name": {
                            "id": "table-duplicate-name",
                            "title": "Tables have different content in the summary attribute and `<caption>`.",
                            "description": "The summary attribute should describe the table structure, while `<caption>` should have the onscreen title. Accurate table mark-up helps users of screen readers. [Learn more about summary and caption](https://dequeuniversity.com/rules/axe/4.8/table-duplicate-name).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "button-name": {
                            "id": "button-name",
                            "title": "Buttons have an accessible name",
                            "description": "When a button doesn't have an accessible name, screen readers announce it as \"button\", making it unusable for users who rely on screen readers. [Learn how to make buttons more accessible](https://dequeuniversity.com/rules/axe/4.8/button-name).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "type": "table",
                                "items": [],
                                "headings": []
                            }
                        },
                        "uses-rel-preconnect": {
                            "id": "uses-rel-preconnect",
                            "title": "Preconnect to required origins",
                            "description": "Consider adding `preconnect` or `dns-prefetch` resource hints to establish early connections to important third-party origins. [Learn how to preconnect to required origins](https://developer.chrome.com/docs/lighthouse/performance/uses-rel-preconnect/).",
                            "score": 1,
                            "scoreDisplayMode": "metricSavings",
                            "details": {
                                "items": [],
                                "headings": [],
                                "overallSavingsMs": 0,
                                "sortedBy": [
                                    "wastedMs"
                                ],
                                "type": "opportunity"
                            },
                            "warnings": [],
                            "numericValue": 0,
                            "numericUnit": "millisecond"
                        },
                        "meta-viewport": {
                            "id": "meta-viewport",
                            "title": "`[user-scalable=\"no\"]` is not used in the `<meta name=\"viewport\">` element and the `[maximum-scale]` attribute is not less than 5.",
                            "description": "Disabling zooming is problematic for users with low vision who rely on screen magnification to properly see the contents of a web page. [Learn more about the viewport meta tag](https://dequeuniversity.com/rules/axe/4.8/meta-viewport).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "label": {
                            "id": "label",
                            "title": "Form elements have associated labels",
                            "description": "Labels ensure that form controls are announced properly by assistive technologies, like screen readers. [Learn more about form element labels](https://dequeuniversity.com/rules/axe/4.8/label).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "unminified-javascript": {
                            "id": "unminified-javascript",
                            "title": "Minify JavaScript",
                            "description": "Minifying JavaScript files can reduce payload sizes and script parse time. [Learn how to minify JavaScript](https://developer.chrome.com/docs/lighthouse/performance/unminified-javascript/).",
                            "score": 1,
                            "scoreDisplayMode": "metricSavings",
                            "details": {
                                "overallSavingsMs": 0,
                                "items": [],
                                "overallSavingsBytes": 0,
                                "headings": [],
                                "debugData": {
                                    "metricSavings": {
                                        "FCP": 0,
                                        "LCP": 0
                                    },
                                    "type": "debugdata"
                                },
                                "type": "opportunity",
                                "sortedBy": [
                                    "wastedBytes"
                                ]
                            },
                            "warnings": [],
                            "numericValue": 0,
                            "numericUnit": "millisecond"
                        },
                        "select-name": {
                            "id": "select-name",
                            "title": "Select elements have associated label elements.",
                            "description": "Form elements without effective labels can create frustrating experiences for screen reader users. [Learn more about the `select` element](https://dequeuniversity.com/rules/axe/4.8/select-name).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "robots-txt": {
                            "id": "robots-txt",
                            "title": "robots.txt is valid",
                            "description": "If your robots.txt file is malformed, crawlers may not be able to understand how you want your website to be crawled or indexed. [Learn more about robots.txt](https://developer.chrome.com/docs/lighthouse/seo/invalid-robots-txt/).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "type": "table",
                                "headings": [],
                                "items": []
                            }
                        },
                        "skip-link": {
                            "id": "skip-link",
                            "title": "Skip links are focusable.",
                            "description": "Including a skip link can help users skip to the main content to save time. [Learn more about skip links](https://dequeuniversity.com/rules/axe/4.8/skip-link).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "first-contentful-paint": {
                            "id": "first-contentful-paint",
                            "title": "First Contentful Paint",
                            "description": "First Contentful Paint marks the time at which the first text or image is painted. [Learn more about the First Contentful Paint metric](https://developer.chrome.com/docs/lighthouse/performance/first-contentful-paint/).",
                            "score": 1,
                            "scoreDisplayMode": "numeric",
                            "displayValue": "0.5 s",
                            "numericValue": 524.5,
                            "numericUnit": "millisecond"
                        },
                        "tabindex": {
                            "id": "tabindex",
                            "title": "No element has a `[tabindex]` value greater than 0",
                            "description": "A value greater than 0 implies an explicit navigation ordering. Although technically valid, this often creates frustrating experiences for users who rely on assistive technologies. [Learn more about the `tabindex` attribute](https://dequeuniversity.com/rules/axe/4.8/tabindex).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "type": "table",
                                "headings": [],
                                "items": []
                            }
                        },
                        "charset": {
                            "id": "charset",
                            "title": "Properly defines charset",
                            "description": "A character encoding declaration is required. It can be done with a `<meta>` tag in the first 1024 bytes of the HTML or in the Content-Type HTTP response header. [Learn more about declaring the character encoding](https://developer.chrome.com/docs/lighthouse/best-practices/charset/).",
                            "score": 1,
                            "scoreDisplayMode": "binary"
                        },
                        "legacy-javascript": {
                            "id": "legacy-javascript",
                            "title": "Avoid serving legacy JavaScript to modern browsers",
                            "description": "Polyfills and transforms enable legacy browsers to use new JavaScript features. However, many aren't necessary for modern browsers. For your bundled JavaScript, adopt a modern script deployment strategy using module/nomodule feature detection to reduce the amount of code shipped to modern browsers, while retaining support for legacy browsers. [Learn how to use modern JavaScript](https://web.dev/articles/publish-modern-javascript)",
                            "score": 0.5,
                            "scoreDisplayMode": "metricSavings",
                            "displayValue": "Potential savings of 10 KiB",
                            "details": {
                                "items": [
                                    {
                                        "subItems": {
                                            "type": "subitems",
                                            "items": [
                                                {
                                                    "signal": "Date.prototype.toISOString",
                                                    "location": {
                                                        "urlProvider": "network",
                                                        "type": "source-location",
                                                        "column": 15,
                                                        "url": "https://apis.google.com/_/scs/abc-static/_/js/k=gapi.gapi.en.GsbA68hXs80.O/m=gapi_iframes,googleapis_client/rt=j/sv=1/d=1/ed=1/rs=AHpOoo899t-H8Lxb3OqzMDuPn6TV_i36ag/cb=gapi.loaded_0",
                                                        "line": 121
                                                    }
                                                }
                                            ]
                                        },
                                        "url": "https://apis.google.com/_/scs/abc-static/_/js/k=gapi.gapi.en.GsbA68hXs80.O/m=gapi_iframes,googleapis_client/rt=j/sv=1/d=1/ed=1/rs=AHpOoo899t-H8Lxb3OqzMDuPn6TV_i36ag/cb=gapi.loaded_0",
                                        "wastedBytes": 9923,
                                        "totalBytes": 0
                                    }
                                ],
                                "sortedBy": [
                                    "wastedBytes"
                                ],
                                "overallSavingsBytes": 9923,
                                "type": "opportunity",
                                "overallSavingsMs": 0,
                                "debugData": {
                                    "metricSavings": {
                                        "FCP": 0,
                                        "LCP": 0
                                    },
                                    "type": "debugdata"
                                },
                                "headings": [
                                    {
                                        "subItemsHeading": {
                                            "key": "location",
                                            "valueType": "source-location"
                                        },
                                        "label": "URL",
                                        "valueType": "url",
                                        "key": "url"
                                    },
                                    {
                                        "valueType": "code",
                                        "subItemsHeading": {
                                            "key": "signal"
                                        },
                                        "key": null
                                    },
                                    {
                                        "key": "wastedBytes",
                                        "label": "Potential Savings",
                                        "valueType": "bytes"
                                    }
                                ]
                            },
                            "numericValue": 0,
                            "numericUnit": "millisecond"
                        },
                        "duplicate-id-active": {
                            "id": "duplicate-id-active",
                            "title": "`[id]` attributes on active, focusable elements are unique",
                            "description": "All focusable elements must have a unique `id` to ensure that they're visible to assistive technologies. [Learn how to fix duplicate `id`s](https://dequeuniversity.com/rules/axe/4.8/duplicate-id-active).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "headings": [],
                                "items": [],
                                "type": "table"
                            }
                        },
                        "aria-allowed-attr": {
                            "id": "aria-allowed-attr",
                            "title": "`[aria-*]` attributes match their roles",
                            "description": "Each ARIA `role` supports a specific subset of `aria-*` attributes. Mismatching these invalidates the `aria-*` attributes. [Learn how to match ARIA attributes to their roles](https://dequeuniversity.com/rules/axe/4.8/aria-allowed-attr).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "items": [],
                                "headings": [],
                                "type": "table"
                            }
                        },
                        "network-rtt": {
                            "id": "network-rtt",
                            "title": "Network Round Trip Times",
                            "description": "Network round trip times (RTT) have a large impact on performance. If the RTT to an origin is high, it's an indication that servers closer to the user could improve performance. [Learn more about the Round Trip Time](https://hpbn.co/primer-on-latency-and-bandwidth/).",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "displayValue": "0 ms",
                            "details": {
                                "type": "table",
                                "headings": [
                                    {
                                        "key": "origin",
                                        "valueType": "text",
                                        "label": "URL"
                                    },
                                    {
                                        "key": "rtt",
                                        "valueType": "ms",
                                        "label": "Time Spent",
                                        "granularity": 1
                                    }
                                ],
                                "items": [
                                    {
                                        "origin": "https://www.google.com",
                                        "rtt": 0
                                    },
                                    {
                                        "origin": "https://fonts.gstatic.com",
                                        "rtt": 0
                                    },
                                    {
                                        "origin": "https://www.gstatic.com",
                                        "rtt": 0
                                    },
                                    {
                                        "origin": "https://apis.google.com",
                                        "rtt": 0
                                    }
                                ],
                                "sortedBy": [
                                    "rtt"
                                ]
                            },
                            "numericValue": 0,
                            "numericUnit": "millisecond"
                        },
                        "font-size": {
                            "id": "font-size",
                            "title": "Document uses legible font sizes",
                            "description": "Font sizes less than 12px are too small to be legible and require mobile visitors to “pinch to zoom” in order to read. Strive to have >60% of page text ≥12px. [Learn more about legible font sizes](https://developer.chrome.com/docs/lighthouse/seo/font-size/).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "td-headers-attr": {
                            "id": "td-headers-attr",
                            "title": "Cells in a `<table>` element that use the `[headers]` attribute refer to table cells within the same table.",
                            "description": "Screen readers have features to make navigating tables easier. Ensuring `<td>` cells using the `[headers]` attribute only refer to other cells in the same table may improve the experience for screen reader users. [Learn more about the `headers` attribute](https://dequeuniversity.com/rules/axe/4.8/td-headers-attr).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "tap-targets": {
                            "id": "tap-targets",
                            "title": "Tap targets are sized appropriately",
                            "description": "Interactive elements like buttons and links should be large enough (48x48px), or have enough space around them, to be easy enough to tap without overlapping onto other elements. [Learn more about tap targets](https://developer.chrome.com/docs/lighthouse/seo/tap-targets/).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "td-has-header": {
                            "id": "td-has-header",
                            "title": "`<td>` elements in a large `<table>` have one or more table headers.",
                            "description": "Screen readers have features to make navigating tables easier. Ensuring that `<td>` elements in a large table (3 or more cells in width and height) have an associated table header may improve the experience for screen reader users. [Learn more about table headers](https://dequeuniversity.com/rules/axe/4.8/td-has-header).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "third-party-cookies": {
                            "id": "third-party-cookies",
                            "title": "Avoids third-party cookies",
                            "description": "Support for third-party cookies will be removed in a future version of Chrome. [Learn more about phasing out third-party cookies](https://developer.chrome.com/en/docs/privacy-sandbox/third-party-cookie-phase-out/).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "headings": [],
                                "type": "table",
                                "items": []
                            }
                        },
                        "target-size": {
                            "id": "target-size",
                            "title": "Touch targets have sufficient size and spacing.",
                            "description": "Touch targets with sufficient size and spacing help users who may have difficulty targeting small controls to activate the targets. [Learn more about touch targets](https://dequeuniversity.com/rules/axe/4.8/target-size).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "meta-refresh": {
                            "id": "meta-refresh",
                            "title": "The document does not use `<meta http-equiv=\"refresh\">`",
                            "description": "Users do not expect a page to refresh automatically, and doing so will move focus back to the top of the page. This may create a frustrating or confusing experience. [Learn more about the refresh meta tag](https://dequeuniversity.com/rules/axe/4.8/meta-refresh).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "custom-controls-labels": {
                            "id": "custom-controls-labels",
                            "title": "Custom controls have associated labels",
                            "description": "Custom interactive controls have associated labels, provided by aria-label or aria-labelledby. [Learn more about custom controls and labels](https://developer.chrome.com/docs/lighthouse/accessibility/custom-controls-labels/).",
                            "score": null,
                            "scoreDisplayMode": "manual"
                        },
                        "third-party-summary": {
                            "id": "third-party-summary",
                            "title": "Minimize third-party usage",
                            "description": "Third-party code can significantly impact load performance. Limit the number of redundant third-party providers and try to load third-party code after your page has primarily finished loading. [Learn how to minimize third-party impact](https://developers.google.com/web/fundamentals/performance/optimizing-content-efficiency/loading-third-party-javascript/).",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "displayValue": "Third-party code blocked the main thread for 0 ms",
                            "details": {
                                "isEntityGrouped": true,
                                "headings": [
                                    {
                                        "label": "Third-Party",
                                        "key": "entity",
                                        "subItemsHeading": {
                                            "key": "url",
                                            "valueType": "url"
                                        },
                                        "valueType": "text"
                                    },
                                    {
                                        "key": "transferSize",
                                        "subItemsHeading": {
                                            "key": "transferSize"
                                        },
                                        "valueType": "bytes",
                                        "label": "Transfer Size",
                                        "granularity": 1
                                    },
                                    {
                                        "subItemsHeading": {
                                            "key": "blockingTime"
                                        },
                                        "valueType": "ms",
                                        "key": "blockingTime",
                                        "granularity": 1,
                                        "label": "Main-Thread Blocking Time"
                                    }
                                ],
                                "type": "table",
                                "items": [
                                    {
                                        "entity": "Google CDN",
                                        "transferSize": 79824,
                                        "mainThreadTime": 38.582,
                                        "tbtImpact": 0,
                                        "subItems": {
                                            "type": "subitems",
                                            "items": [
                                                {
                                                    "url": "https://www.gstatic.com/og/_/js/k=og.qtm.en_US.u8Ti_iwBwEs.2019.O/rt=j/m=qabr,q_dnp,qcwid,qapid,qald,q_dg/exm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/rs=AA2YrTsL4HiE1bvJV-MS9_mgAxWPHzXqxw",
                                                    "tbtImpact": 0,
                                                    "mainThreadTime": 37.716,
                                                    "transferSize": 78352,
                                                    "blockingTime": 0
                                                },
                                                {
                                                    "tbtImpact": 0,
                                                    "blockingTime": 0,
                                                    "mainThreadTime": 0.866,
                                                    "transferSize": 1472,
                                                    "url": "https://www.gstatic.com/og/_/ss/k=og.qtm.zz20CdIDKVg.L.W.O/m=qcwid/excm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/ct=zgms/rs=AA2YrTvwL5uXLldqnwtu49O3C0adR0c4Jg"
                                                }
                                            ]
                                        },
                                        "blockingTime": 0
                                    },
                                    {
                                        "entity": "google.com",
                                        "tbtImpact": 0,
                                        "mainThreadTime": 0,
                                        "subItems": {
                                            "type": "subitems",
                                            "items": [
                                                {
                                                    "url": "https://google.com/",
                                                    "transferSize": 1410,
                                                    "tbtImpact": 0,
                                                    "blockingTime": 0,
                                                    "mainThreadTime": 0
                                                }
                                            ]
                                        },
                                        "transferSize": 1410,
                                        "blockingTime": 0
                                    },
                                    {
                                        "blockingTime": 0,
                                        "tbtImpact": 0,
                                        "entity": "Google Fonts",
                                        "transferSize": 1273,
                                        "subItems": {
                                            "items": [
                                                {
                                                    "tbtImpact": 0,
                                                    "url": "https://fonts.gstatic.com/s/i/productlogos/googleg/v6/24px.svg",
                                                    "blockingTime": 0,
                                                    "transferSize": 1273,
                                                    "mainThreadTime": 0
                                                }
                                            ],
                                            "type": "subitems"
                                        },
                                        "mainThreadTime": 0
                                    }
                                ],
                                "summary": {
                                    "wastedMs": 0,
                                    "wastedBytes": 82507
                                }
                            }
                        },
                        "first-meaningful-paint": {
                            "id": "first-meaningful-paint",
                            "title": "First Meaningful Paint",
                            "description": "First Meaningful Paint measures when the primary content of a page is visible. [Learn more about the First Meaningful Paint metric](https://developer.chrome.com/docs/lighthouse/performance/first-meaningful-paint/).",
                            "score": 0.99,
                            "scoreDisplayMode": "numeric",
                            "displayValue": "0.5 s",
                            "numericValue": 541,
                            "numericUnit": "millisecond"
                        },
                        "font-display": {
                            "id": "font-display",
                            "title": "All text remains visible during webfont loads",
                            "description": "Leverage the `font-display` CSS feature to ensure text is user-visible while webfonts are loading. [Learn more about `font-display`](https://developer.chrome.com/docs/lighthouse/performance/font-display/).",
                            "score": 1,
                            "scoreDisplayMode": "metricSavings",
                            "details": {
                                "items": [],
                                "headings": [],
                                "type": "table"
                            },
                            "warnings": []
                        },
                        "image-aspect-ratio": {
                            "id": "image-aspect-ratio",
                            "title": "Displays images with correct aspect ratio",
                            "description": "Image display dimensions should match natural aspect ratio. [Learn more about image aspect ratio](https://developer.chrome.com/docs/lighthouse/best-practices/image-aspect-ratio/).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "type": "table",
                                "items": [],
                                "headings": []
                            }
                        },
                        "resource-summary": {
                            "id": "resource-summary",
                            "title": "Resources Summary",
                            "description": "Aggregates all network requests and groups them by type",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "details": {
                                "type": "table",
                                "headings": [
                                    {
                                        "label": "Resource Type",
                                        "valueType": "text",
                                        "key": "label"
                                    },
                                    {
                                        "key": "requestCount",
                                        "label": "Requests",
                                        "valueType": "numeric"
                                    },
                                    {
                                        "valueType": "bytes",
                                        "label": "Transfer Size",
                                        "key": "transferSize"
                                    }
                                ],
                                "items": [
                                    {
                                        "resourceType": "total",
                                        "label": "Total",
                                        "transferSize": 758567,
                                        "requestCount": 28
                                    },
                                    {
                                        "transferSize": 560125,
                                        "requestCount": 7,
                                        "resourceType": "script",
                                        "label": "Script"
                                    },
                                    {
                                        "requestCount": 12,
                                        "resourceType": "other",
                                        "transferSize": 102513,
                                        "label": "Other"
                                    },
                                    {
                                        "requestCount": 1,
                                        "transferSize": 78453,
                                        "label": "Document",
                                        "resourceType": "document"
                                    },
                                    {
                                        "requestCount": 7,
                                        "transferSize": 16004,
                                        "label": "Image",
                                        "resourceType": "image"
                                    },
                                    {
                                        "resourceType": "stylesheet",
                                        "label": "Stylesheet",
                                        "requestCount": 1,
                                        "transferSize": 1472
                                    },
                                    {
                                        "resourceType": "media",
                                        "transferSize": 0,
                                        "requestCount": 0,
                                        "label": "Media"
                                    },
                                    {
                                        "resourceType": "font",
                                        "requestCount": 0,
                                        "transferSize": 0,
                                        "label": "Font"
                                    },
                                    {
                                        "requestCount": 4,
                                        "transferSize": 82507,
                                        "resourceType": "third-party",
                                        "label": "Third-party"
                                    }
                                ]
                            }
                        },
                        "offscreen-images": {
                            "id": "offscreen-images",
                            "title": "Defer offscreen images",
                            "description": "Consider lazy-loading offscreen and hidden images after all critical resources have finished loading to lower time to interactive. [Learn how to defer offscreen images](https://developer.chrome.com/docs/lighthouse/performance/offscreen-images/).",
                            "score": 1,
                            "scoreDisplayMode": "metricSavings",
                            "details": {
                                "debugData": {
                                    "type": "debugdata",
                                    "metricSavings": {
                                        "FCP": 0,
                                        "LCP": 0
                                    }
                                },
                                "items": [],
                                "type": "opportunity",
                                "overallSavingsBytes": 0,
                                "sortedBy": [
                                    "wastedBytes"
                                ],
                                "overallSavingsMs": 0,
                                "headings": []
                            },
                            "warnings": [],
                            "numericValue": 0,
                            "numericUnit": "millisecond"
                        },
                        "layout-shift-elements": {
                            "id": "layout-shift-elements",
                            "title": "Avoid large layout shifts",
                            "description": "These DOM elements were most affected by layout shifts. Some layout shifts may not be included in the CLS metric value due to [windowing](https://web.dev/articles/cls#what_is_cls). [Learn how to improve CLS](https://web.dev/articles/optimize-cls)",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "displayValue": "3 elements found",
                            "details": {
                                "headings": [
                                    {
                                        "valueType": "node",
                                        "key": "node",
                                        "label": "Element"
                                    },
                                    {
                                        "label": "Layout shift impact",
                                        "granularity": 0.001,
                                        "key": "score",
                                        "valueType": "numeric"
                                    }
                                ],
                                "items": [
                                    {
                                        "node": {
                                            "lhId": "page-1-DIV",
                                            "type": "node",
                                            "nodeLabel": "Drei Jahrzehnte Klimaschutz: Jede Entscheidung zählt",
                                            "snippet": "<div class=\"KxwPGc ssOUyb\">",
                                            "path": "1,HTML,1,BODY,2,DIV,5,DIV,2,DIV,1,DIV",
                                            "selector": "div.L3eUgb > div.o3j99 > div.KxwPGc > div.KxwPGc",
                                            "boundingRect": {
                                                "right": 1330,
                                                "width": 1310,
                                                "bottom": 894,
                                                "top": 847,
                                                "height": 47,
                                                "left": 20
                                            }
                                        },
                                        "score": 0.02333862664067355
                                    },
                                    {
                                        "node": {
                                            "path": "1,HTML,1,BODY,2,DIV,5,DIV,2,DIV,0,DIV",
                                            "type": "node",
                                            "boundingRect": {
                                                "right": 527,
                                                "width": 507,
                                                "height": 46,
                                                "bottom": 940,
                                                "top": 894,
                                                "left": 20
                                            },
                                            "selector": "div.L3eUgb > div.o3j99 > div.KxwPGc > div.KxwPGc",
                                            "lhId": "page-2-DIV",
                                            "snippet": "<div class=\"KxwPGc AghGtd\">",
                                            "nodeLabel": "Werbeprogramme\nUnternehmen\nWie funktioniert die Google Suche?"
                                        },
                                        "score": 0.017872983347968142
                                    },
                                    {
                                        "score": 0.015693018400582834,
                                        "node": {
                                            "nodeLabel": "Datenschutzerklärung\nNutzungsbedingungen\nEinstellungen",
                                            "lhId": "page-3-DIV",
                                            "boundingRect": {
                                                "height": 46,
                                                "bottom": 940,
                                                "top": 894,
                                                "right": 1330,
                                                "left": 880,
                                                "width": 450
                                            },
                                            "path": "1,HTML,1,BODY,2,DIV,5,DIV,2,DIV,2,DIV",
                                            "type": "node",
                                            "selector": "div.L3eUgb > div.o3j99 > div.KxwPGc > div.KxwPGc",
                                            "snippet": "<div class=\"KxwPGc iTjxkf\">"
                                        }
                                    }
                                ],
                                "type": "table"
                            }
                        },
                        "network-requests": {
                            "id": "network-requests",
                            "title": "Network Requests",
                            "description": "Lists the network requests that were made during page load.",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "details": {
                                "headings": [
                                    {
                                        "key": "url",
                                        "valueType": "url",
                                        "label": "URL"
                                    },
                                    {
                                        "key": "protocol",
                                        "label": "Protocol",
                                        "valueType": "text"
                                    },
                                    {
                                        "valueType": "ms",
                                        "label": "Network Request Time",
                                        "granularity": 1,
                                        "key": "networkRequestTime"
                                    },
                                    {
                                        "key": "networkEndTime",
                                        "label": "Network End Time",
                                        "valueType": "ms",
                                        "granularity": 1
                                    },
                                    {
                                        "key": "transferSize",
                                        "granularity": 1,
                                        "label": "Transfer Size",
                                        "displayUnit": "kb",
                                        "valueType": "bytes"
                                    },
                                    {
                                        "label": "Resource Size",
                                        "key": "resourceSize",
                                        "valueType": "bytes",
                                        "displayUnit": "kb",
                                        "granularity": 1
                                    },
                                    {
                                        "valueType": "text",
                                        "label": "Status Code",
                                        "key": "statusCode"
                                    },
                                    {
                                        "label": "MIME Type",
                                        "valueType": "text",
                                        "key": "mimeType"
                                    },
                                    {
                                        "valueType": "text",
                                        "key": "resourceType",
                                        "label": "Resource Type"
                                    }
                                ],
                                "type": "table",
                                "items": [
                                    {
                                        "sessionTargetType": "page",
                                        "statusCode": 301,
                                        "protocol": "http/1.1",
                                        "finished": true,
                                        "mimeType": "text/html",
                                        "resourceSize": 0,
                                        "priority": "VeryHigh",
                                        "transferSize": 1410,
                                        "networkRequestTime": 1.3860000371932983,
                                        "entity": "google.com",
                                        "url": "https://google.com/",
                                        "experimentalFromMainFrame": true,
                                        "networkEndTime": 20.68499994277954,
                                        "rendererStartTime": 0
                                    },
                                    {
                                        "statusCode": 200,
                                        "priority": "VeryHigh",
                                        "networkEndTime": 1113.1340000629425,
                                        "rendererStartTime": 20.68499994277954,
                                        "resourceType": "Document",
                                        "entity": "Other Google APIs/SDKs",
                                        "protocol": "h2",
                                        "resourceSize": 274487,
                                        "finished": true,
                                        "mimeType": "text/html",
                                        "sessionTargetType": "page",
                                        "transferSize": 78453,
                                        "networkRequestTime": 21.479000091552734,
                                        "experimentalFromMainFrame": true,
                                        "url": "https://www.google.com/"
                                    },
                                    {
                                        "protocol": "h2",
                                        "finished": true,
                                        "transferSize": 279247,
                                        "networkRequestTime": 1165.1870000362396,
                                        "priority": "Low",
                                        "experimentalFromMainFrame": true,
                                        "resourceSize": 857288,
                                        "entity": "Other Google APIs/SDKs",
                                        "resourceType": "Script",
                                        "url": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/ed=1/dg=2/br=1/rs=ACT90oEcAGSwfSNPLyn9LHwQv0bYDA_7PQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf,FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe,KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=cdos,hsm,jsa,mb4ZUb,d,csi,cEt90b,SNUn3,qddgKe,sTsDMc,dtl0hd,eHDfl",
                                        "sessionTargetType": "page",
                                        "statusCode": 200,
                                        "networkEndTime": 1187.8950001001358,
                                        "rendererStartTime": 1162.6080000400543,
                                        "mimeType": "text/javascript"
                                    },
                                    {
                                        "finished": true,
                                        "protocol": "h2",
                                        "mimeType": "image/png",
                                        "networkEndTime": 1171.667000055313,
                                        "experimentalFromMainFrame": true,
                                        "resourceType": "Image",
                                        "rendererStartTime": 1163.5540000200272,
                                        "sessionTargetType": "page",
                                        "networkRequestTime": 1165.805999994278,
                                        "priority": "Medium",
                                        "entity": "Other Google APIs/SDKs",
                                        "resourceSize": 5969,
                                        "statusCode": 200,
                                        "transferSize": 6616,
                                        "url": "https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png"
                                    },
                                    {
                                        "sessionTargetType": "page",
                                        "experimentalFromMainFrame": true,
                                        "protocol": "h2",
                                        "resourceSize": 2590,
                                        "transferSize": 3237,
                                        "priority": "Low",
                                        "networkRequestTime": 1185.3780000209808,
                                        "entity": "Other Google APIs/SDKs",
                                        "finished": true,
                                        "statusCode": 200,
                                        "rendererStartTime": 1163.9150000810623,
                                        "networkEndTime": 1190.8410000801086,
                                        "url": "https://www.google.com/images/hpp/spark-42x42px.png",
                                        "mimeType": "image/png",
                                        "resourceType": "Image"
                                    },
                                    {
                                        "networkRequestTime": 1165.904000043869,
                                        "transferSize": 1273,
                                        "priority": "Medium",
                                        "protocol": "h2",
                                        "mimeType": "image/svg+xml",
                                        "url": "https://fonts.gstatic.com/s/i/productlogos/googleg/v6/24px.svg",
                                        "finished": true,
                                        "networkEndTime": 1171.2560000419617,
                                        "sessionTargetType": "page",
                                        "rendererStartTime": 1164.083999991417,
                                        "experimentalFromMainFrame": true,
                                        "entity": "Google Fonts",
                                        "resourceType": "Image",
                                        "resourceSize": 742,
                                        "statusCode": 200
                                    },
                                    {
                                        "url": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAYCAMAAAAiV0Z6AAAAPFBMVEVLoEN0wU6CzFKCzFKCzFKCz…",
                                        "networkRequestTime": 1236.3120000362396,
                                        "priority": "Low",
                                        "mimeType": "image/png",
                                        "transferSize": 0,
                                        "resourceType": "Image",
                                        "sessionTargetType": "page",
                                        "statusCode": 200,
                                        "protocol": "data",
                                        "rendererStartTime": 1236.3120000362396,
                                        "networkEndTime": 1236.5100001096725,
                                        "experimentalFromMainFrame": true,
                                        "finished": true,
                                        "resourceSize": 315
                                    },
                                    {
                                        "transferSize": 1307,
                                        "priority": "High",
                                        "resourceSize": 660,
                                        "resourceType": "Image",
                                        "rendererStartTime": 1244.9370000362396,
                                        "experimentalFromMainFrame": true,
                                        "statusCode": 200,
                                        "sessionTargetType": "page",
                                        "entity": "Other Google APIs/SDKs",
                                        "finished": true,
                                        "protocol": "h2",
                                        "mimeType": "image/webp",
                                        "url": "https://www.google.com/images/searchbox/desktop_searchbox_sprites318_hr.webp",
                                        "networkEndTime": 1252.736999988556,
                                        "networkRequestTime": 1245.7870000600815
                                    },
                                    {
                                        "finished": true,
                                        "statusCode": -1,
                                        "experimentalFromMainFrame": true,
                                        "networkEndTime": 1321.5880000591278,
                                        "url": "https://www.google.com/gen_204?ei=NEvLZYTrK5KxqtsP4d-0oA0&vet=10ahUKEwiE1bSilKiEAxWSmGoFHeEvDdQQhJAHCCI..s&bl=2Rh4&s=webhp&gl=de&pc=SEARCH_HOMEPAGE&isMobile=false",
                                        "sessionTargetType": "page",
                                        "resourceType": "Ping",
                                        "priority": "VeryLow",
                                        "networkRequestTime": 1287.388000011444,
                                        "rendererStartTime": 1287.388000011444,
                                        "resourceSize": 0,
                                        "transferSize": 0,
                                        "entity": "Other Google APIs/SDKs"
                                    },
                                    {
                                        "transferSize": 0,
                                        "networkRequestTime": 1290.5030000209808,
                                        "mimeType": "image/svg+xml",
                                        "resourceSize": 775,
                                        "resourceType": "Image",
                                        "statusCode": 200,
                                        "finished": true,
                                        "url": "data:image/svg+xml,<svg width='16' height='16' xmlns='http://www.w3.org/2000/svg'><path  fill='%233…",
                                        "sessionTargetType": "page",
                                        "networkEndTime": 1290.7070000171661,
                                        "rendererStartTime": 1290.5030000209808,
                                        "protocol": "data",
                                        "priority": "Low",
                                        "experimentalFromMainFrame": true
                                    },
                                    {
                                        "protocol": "data",
                                        "networkEndTime": 1293.067999958992,
                                        "experimentalFromMainFrame": true,
                                        "networkRequestTime": 1292.8600000143051,
                                        "statusCode": 200,
                                        "sessionTargetType": "page",
                                        "resourceType": "Image",
                                        "priority": "Low",
                                        "transferSize": 0,
                                        "url": "data:image/svg+xml,<svg width='16' height='16' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/sv…",
                                        "finished": true,
                                        "mimeType": "image/svg+xml",
                                        "resourceSize": 236,
                                        "rendererStartTime": 1292.8600000143051
                                    },
                                    {
                                        "url": "data:image/svg+xml,<svg width='16' height='16' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/sv…",
                                        "priority": "Low",
                                        "sessionTargetType": "page",
                                        "networkEndTime": 1294.9220000505447,
                                        "networkRequestTime": 1294.7170001268387,
                                        "statusCode": 200,
                                        "resourceSize": 197,
                                        "transferSize": 0,
                                        "experimentalFromMainFrame": true,
                                        "resourceType": "Image",
                                        "rendererStartTime": 1294.7170001268387,
                                        "finished": true,
                                        "mimeType": "image/svg+xml",
                                        "protocol": "data"
                                    },
                                    {
                                        "resourceType": "Image",
                                        "networkRequestTime": 1296.819000005722,
                                        "sessionTargetType": "page",
                                        "mimeType": "image/svg+xml",
                                        "experimentalFromMainFrame": true,
                                        "statusCode": 200,
                                        "transferSize": 0,
                                        "protocol": "data",
                                        "networkEndTime": 1297.0599999427795,
                                        "rendererStartTime": 1296.819000005722,
                                        "priority": "Low",
                                        "finished": true,
                                        "url": "data:image/svg+xml,<svg width='16' height='16' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/sv…",
                                        "resourceSize": 686
                                    },
                                    {
                                        "networkRequestTime": 1298.7070001363754,
                                        "url": "data:image/svg+xml,<svg width='16' height='16' xmlns='http://www.w3.org/2000/svg'><path  fill='%233…",
                                        "mimeType": "image/svg+xml",
                                        "resourceSize": 338,
                                        "sessionTargetType": "page",
                                        "priority": "Low",
                                        "resourceType": "Image",
                                        "finished": true,
                                        "protocol": "data",
                                        "statusCode": 200,
                                        "networkEndTime": 1298.8840000629425,
                                        "rendererStartTime": 1298.7070001363754,
                                        "experimentalFromMainFrame": true,
                                        "transferSize": 0
                                    },
                                    {
                                        "resourceSize": 1137,
                                        "transferSize": 0,
                                        "mimeType": "image/svg+xml",
                                        "resourceType": "Image",
                                        "networkRequestTime": 1300.4819999933243,
                                        "experimentalFromMainFrame": true,
                                        "statusCode": 200,
                                        "rendererStartTime": 1300.4819999933243,
                                        "networkEndTime": 1300.680999994278,
                                        "protocol": "data",
                                        "url": "data:image/svg+xml,<svg width='16' height='16' viewBox='0 0 16 16' fill='%233c4043' xmlns='http://w…",
                                        "sessionTargetType": "page",
                                        "priority": "Low",
                                        "finished": true
                                    },
                                    {
                                        "priority": "Low",
                                        "resourceType": "Image",
                                        "finished": true,
                                        "networkEndTime": 1322.958999991417,
                                        "transferSize": 1176,
                                        "rendererStartTime": 1308.3429999351501,
                                        "networkRequestTime": 1311.4850000143051,
                                        "statusCode": 204,
                                        "resourceSize": 0,
                                        "entity": "Other Google APIs/SDKs",
                                        "experimentalFromMainFrame": true,
                                        "protocol": "h2",
                                        "mimeType": "text/html",
                                        "url": "https://www.google.com/gen_204?atyp=i&ct=bxjs&cad=&b=0&ei=NEvLZYTrK5KxqtsP4d-0oA0&zx=1707821877247&opi=89978449",
                                        "sessionTargetType": "page"
                                    },
                                    {
                                        "url": "https://www.gstatic.com/og/_/js/k=og.qtm.en_US.u8Ti_iwBwEs.2019.O/rt=j/m=qabr,q_dnp,qcwid,qapid,qald,q_dg/exm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/rs=AA2YrTsL4HiE1bvJV-MS9_mgAxWPHzXqxw",
                                        "mimeType": "text/javascript",
                                        "protocol": "h2",
                                        "sessionTargetType": "page",
                                        "entity": "Google CDN",
                                        "finished": true,
                                        "rendererStartTime": 1326.6749999523163,
                                        "networkEndTime": 1333.3310000896454,
                                        "resourceSize": 215735,
                                        "experimentalFromMainFrame": true,
                                        "transferSize": 78352,
                                        "statusCode": 200,
                                        "priority": "Low",
                                        "networkRequestTime": 1327.3159999847412,
                                        "resourceType": "Script"
                                    },
                                    {
                                        "protocol": "h2",
                                        "networkRequestTime": 1327.8519999980927,
                                        "resourceSize": 1684,
                                        "entity": "Google CDN",
                                        "transferSize": 1472,
                                        "url": "https://www.gstatic.com/og/_/ss/k=og.qtm.zz20CdIDKVg.L.W.O/m=qcwid/excm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/ct=zgms/rs=AA2YrTvwL5uXLldqnwtu49O3C0adR0c4Jg",
                                        "experimentalFromMainFrame": true,
                                        "rendererStartTime": 1327.345999956131,
                                        "statusCode": 200,
                                        "finished": true,
                                        "mimeType": "text/css",
                                        "resourceType": "Stylesheet",
                                        "sessionTargetType": "page",
                                        "priority": "VeryHigh",
                                        "networkEndTime": 1334.027999997139
                                    },
                                    {
                                        "url": "https://www.google.com/gen_204?s=webhp&t=aft&atyp=csi&ei=NEvLZYTrK5KxqtsP4d-0oA0&rt=wsrt.1113,aft.217,afti.208,hst.77,prt.217&wh=940&imn=13&ima=4&imad=0&imac=0&imf=0&aft=1&aftp=-1&opi=89978449",
                                        "transferSize": 0,
                                        "sessionTargetType": "page",
                                        "networkRequestTime": 1333.7740000486374,
                                        "resourceType": "Ping",
                                        "entity": "Other Google APIs/SDKs",
                                        "resourceSize": 0,
                                        "networkEndTime": 1344.1430000066757,
                                        "priority": "VeryLow",
                                        "statusCode": -1,
                                        "rendererStartTime": 1333.7740000486374,
                                        "finished": true,
                                        "experimentalFromMainFrame": true
                                    },
                                    {
                                        "statusCode": 200,
                                        "resourceSize": 8488,
                                        "networkEndTime": 1654.2639999389648,
                                        "rendererStartTime": 1574.7880001068115,
                                        "transferSize": 7142,
                                        "protocol": "h2",
                                        "sessionTargetType": "page",
                                        "entity": "Other Google APIs/SDKs",
                                        "priority": "High",
                                        "experimentalFromMainFrame": true,
                                        "mimeType": "application/json",
                                        "resourceType": "XHR",
                                        "networkRequestTime": 1576.0340000391006,
                                        "url": "https://www.google.com/complete/search?q&cp=0&client=gws-wiz&xssi=t&gs_pcrt=2&hl=de&authuser=0&psi=NEvLZYTrK5KxqtsP4d-0oA0.1707821877526&dpr=1&nolsbt=1",
                                        "finished": true
                                    },
                                    {
                                        "sessionTargetType": "page",
                                        "finished": true,
                                        "priority": "VeryLow",
                                        "resourceType": "Ping",
                                        "rendererStartTime": 1581.1699999570847,
                                        "statusCode": -1,
                                        "entity": "Other Google APIs/SDKs",
                                        "url": "https://www.google.com/gen_204?atyp=csi&ei=NEvLZYTrK5KxqtsP4d-0oA0&s=webhp&t=all&wh=940&imn=13&ima=4&imad=0&imac=0&imf=0&aft=1&aftp=-1&adh=&ime=3&imex=3&imeh=9&imeha=0&imehb=0&imea=0&imeb=0&imel=0&imed=0&scp=0&mem=ujhs.10,tjhs.10,jhsl.3760,dm.8&nv=ne.1,feid.8e1a5994-7e0b-40bf-b972-e04af151b3c8&net=dl.9000,ect.4g,rtt.0&hp=&sys=hc.41&p=bs.true&rt=hst.77,aft.217,afti.208,prt.217,aftqf.222,xjses.256,xjsee.371,xjs.371,lcp.179,fcp.179,wsrt.1113,cst.0,dnst.0,rqst.1093,rspt.0,rqstt.20,unt.20,cstt.20,dit.1345&zx=1707821877542&opi=89978449",
                                        "resourceSize": 0,
                                        "networkEndTime": 1618.9049999713898,
                                        "networkRequestTime": 1581.1699999570847,
                                        "transferSize": 0,
                                        "experimentalFromMainFrame": true
                                    },
                                    {
                                        "transferSize": 148771,
                                        "statusCode": 200,
                                        "sessionTargetType": "page",
                                        "mimeType": "text/javascript",
                                        "entity": "Other Google APIs/SDKs",
                                        "priority": "Low",
                                        "resourceSize": 492952,
                                        "url": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/exm=SNUn3,cEt90b,cdos,csi,d,dtl0hd,eHDfl,hsm,jsa,mb4ZUb,qddgKe,sTsDMc/ed=1/dg=2/br=1/ujg=1/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=B2qlPe,DhPYme,GU4Gab,MpJwZc,NzU6V,UUJqVe,Wo3n8,aa,abd,async,epYOx,ifl,ms4mZb,pHXghd,q0xTif,s39S4,sOXFj,sb_wiz,sf,sonic,spch?xjs=s1",
                                        "resourceType": "Script",
                                        "networkRequestTime": 1605.085000038147,
                                        "rendererStartTime": 1602.8050000667572,
                                        "networkEndTime": 1673.6979999542236,
                                        "finished": true,
                                        "protocol": "h2",
                                        "experimentalFromMainFrame": true
                                    },
                                    {
                                        "sessionTargetType": "page",
                                        "resourceSize": 173856,
                                        "experimentalFromMainFrame": true,
                                        "entity": "Other Google APIs/SDKs",
                                        "finished": true,
                                        "url": "https://www.google.com/xjs/_/js/md=1/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ",
                                        "priority": "High",
                                        "mimeType": "text/javascript",
                                        "protocol": "h2",
                                        "resourceType": "Fetch",
                                        "networkEndTime": 1622.0760000944138,
                                        "statusCode": 200,
                                        "networkRequestTime": 1609.630000114441,
                                        "rendererStartTime": 1605.5379999876022,
                                        "transferSize": 90879
                                    },
                                    {
                                        "networkEndTime": 1631.7599999904633,
                                        "protocol": "h2",
                                        "sessionTargetType": "page",
                                        "mimeType": "text/html",
                                        "entity": "Other Google APIs/SDKs",
                                        "resourceSize": 0,
                                        "experimentalFromMainFrame": true,
                                        "networkRequestTime": 1614.3120000362396,
                                        "rendererStartTime": 1612.9620000123978,
                                        "finished": true,
                                        "transferSize": 1219,
                                        "url": "https://www.google.com/client_204?atyp=i&biw=1350&bih=940&ei=NEvLZYTrK5KxqtsP4d-0oA0&opi=89978449",
                                        "statusCode": 204,
                                        "priority": "Low",
                                        "resourceType": "Image"
                                    },
                                    {
                                        "networkEndTime": 1662.75100004673,
                                        "finished": true,
                                        "entity": "Other Google APIs/SDKs",
                                        "experimentalFromMainFrame": true,
                                        "sessionTargetType": "page",
                                        "resourceType": "Script",
                                        "resourceSize": 121630,
                                        "priority": "Low",
                                        "rendererStartTime": 1654.7440000772476,
                                        "networkRequestTime": 1656.0600000619888,
                                        "url": "https://apis.google.com/_/scs/abc-static/_/js/k=gapi.gapi.en.GsbA68hXs80.O/m=gapi_iframes,googleapis_client/rt=j/sv=1/d=1/ed=1/rs=AHpOoo899t-H8Lxb3OqzMDuPn6TV_i36ag/cb=gapi.loaded_0",
                                        "transferSize": 42045,
                                        "statusCode": 200,
                                        "mimeType": "text/javascript",
                                        "protocol": "h2"
                                    },
                                    {
                                        "entity": "Other Google APIs/SDKs",
                                        "networkEndTime": 1868.8090000152588,
                                        "resourceSize": 24360,
                                        "transferSize": 8614,
                                        "finished": true,
                                        "rendererStartTime": 1854.348000049591,
                                        "priority": "Low",
                                        "url": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=0/dg=2/br=1/ujg=1/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ/m=sy1bb,P10Owf,synp,sy1a1,sy1a2,gSZvdb,sys8,sysa,sysb,WlNQGd,synn,syyj,syyl,nabPbb,syno,synq,synr,syns,synu,DPreE,sylj,sys7,sys9,CnSW2d,kQvlef,syyk,fXO0xe?xjs=s3",
                                        "resourceType": "Script",
                                        "statusCode": 200,
                                        "sessionTargetType": "page",
                                        "networkRequestTime": 1857.8320000171661,
                                        "experimentalFromMainFrame": true,
                                        "mimeType": "text/javascript",
                                        "protocol": "h2"
                                    },
                                    {
                                        "sessionTargetType": "page",
                                        "statusCode": -1,
                                        "rendererStartTime": 1899.557000041008,
                                        "transferSize": 0,
                                        "priority": "VeryLow",
                                        "resourceSize": 0,
                                        "experimentalFromMainFrame": true,
                                        "entity": "Other Google APIs/SDKs",
                                        "resourceType": "Ping",
                                        "url": "https://www.google.com/gen_204?atyp=i&ei=NEvLZYTrK5KxqtsP4d-0oA0&dt19=2&zx=1707821877860&opi=89978449",
                                        "networkRequestTime": 1899.557000041008,
                                        "finished": true,
                                        "networkEndTime": 2002.9079999923706
                                    },
                                    {
                                        "experimentalFromMainFrame": true,
                                        "sessionTargetType": "page",
                                        "statusCode": 204,
                                        "resourceSize": 0,
                                        "resourceType": "XHR",
                                        "priority": "High",
                                        "mimeType": "text/html",
                                        "url": "https://www.google.com/client_204?cs=1&opi=89978449",
                                        "networkRequestTime": 1916.6219999790192,
                                        "networkEndTime": 1951.1790000200272,
                                        "rendererStartTime": 1908.3720000982285,
                                        "entity": "Other Google APIs/SDKs",
                                        "transferSize": 1613,
                                        "finished": true,
                                        "protocol": "h2"
                                    },
                                    {
                                        "resourceSize": 0,
                                        "priority": "VeryLow",
                                        "finished": true,
                                        "networkRequestTime": 1920.182000041008,
                                        "sessionTargetType": "page",
                                        "experimentalFromMainFrame": true,
                                        "entity": "Other Google APIs/SDKs",
                                        "rendererStartTime": 1920.182000041008,
                                        "statusCode": -1,
                                        "resourceType": "Ping",
                                        "url": "https://www.google.com/gen_204?atyp=csi&ei=NEvLZYTrK5KxqtsP4d-0oA0&s=promo&rt=hpbas.805&zx=1707821877881&opi=89978449",
                                        "networkEndTime": 2003.1480001211166,
                                        "transferSize": 0
                                    },
                                    {
                                        "mimeType": "text/plain",
                                        "resourceType": "XHR",
                                        "priority": "High",
                                        "entity": "Other Google APIs/SDKs",
                                        "finished": true,
                                        "resourceSize": 84,
                                        "transferSize": 1469,
                                        "networkRequestTime": 1966.2159999608994,
                                        "sessionTargetType": "page",
                                        "statusCode": 200,
                                        "networkEndTime": 2085.044000029564,
                                        "protocol": "h2",
                                        "rendererStartTime": 1959.7330000400543,
                                        "url": "https://www.google.com/async/hpba?vet=10ahUKEwiE1bSilKiEAxWSmGoFHeEvDdQQj-0KCCE..i&ei=NEvLZYTrK5KxqtsP4d-0oA0&opi=89978449&yv=3&cs=0&async=_ck:xjs.hd.kc4QrUgb_z0.L.W.O,_k:xjs.hd.en.MlTHDnVjdsg.O,_am:AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY,_csss:ACT90oFLAp31ohpVKmZUfeodMjV6BinQ9Q,_fmt:prog,_id:a3JU5b",
                                        "experimentalFromMainFrame": true
                                    },
                                    {
                                        "protocol": "h2",
                                        "transferSize": 1456,
                                        "resourceType": "Script",
                                        "url": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=0/dg=2/br=1/ujg=1/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ/m=syef,aLUfP?xjs=s3",
                                        "statusCode": 200,
                                        "resourceSize": 1573,
                                        "sessionTargetType": "page",
                                        "experimentalFromMainFrame": true,
                                        "finished": true,
                                        "networkEndTime": 2101.0670000314713,
                                        "mimeType": "text/javascript",
                                        "priority": "Low",
                                        "networkRequestTime": 2086.4840000867844,
                                        "rendererStartTime": 2020.849000096321,
                                        "entity": "Other Google APIs/SDKs"
                                    },
                                    {
                                        "resourceSize": 0,
                                        "networkRequestTime": 2095.1350001096725,
                                        "priority": "VeryLow",
                                        "sessionTargetType": "page",
                                        "rendererStartTime": 2095.1350001096725,
                                        "entity": "Other Google APIs/SDKs",
                                        "transferSize": 0,
                                        "finished": true,
                                        "statusCode": -1,
                                        "experimentalFromMainFrame": true,
                                        "networkEndTime": 2135.2829999923706,
                                        "resourceType": "Ping",
                                        "url": "https://www.google.com/gen_204?atyp=csi&ei=NUvLZbX2OK6owPAP3r6asA8&s=async&astyp=hpba&ima=0&imn=0&mem=ujhs.10,tjhs.10,jhsl.3760,dm.8&nv=ne.1,feid.8e1a5994-7e0b-40bf-b972-e04af151b3c8&hp=&rt=ttfb.159,st.161,bs.27,aaft.165,acrt.165,art.166&zx=1707821878056&opi=89978449"
                                    },
                                    {
                                        "rendererStartTime": 2105.8540000915527,
                                        "resourceSize": 0,
                                        "finished": true,
                                        "networkEndTime": 2135.4490000009537,
                                        "resourceType": "Ping",
                                        "experimentalFromMainFrame": true,
                                        "entity": "Other Google APIs/SDKs",
                                        "networkRequestTime": 2105.8540000915527,
                                        "url": "https://www.google.com/gen_204?atyp=csi&ei=NEvLZYTrK5KxqtsP4d-0oA0&s=promo&rt=hpbas.805,hpbarr.186&zx=1707821878066&opi=89978449",
                                        "sessionTargetType": "page",
                                        "statusCode": -1,
                                        "transferSize": 0,
                                        "priority": "VeryLow"
                                    },
                                    {
                                        "resourceType": "Script",
                                        "resourceSize": 1672,
                                        "priority": "Low",
                                        "rendererStartTime": 2137.362000107765,
                                        "networkEndTime": 2194.6380001306534,
                                        "entity": "Other Google APIs/SDKs",
                                        "protocol": "h2",
                                        "statusCode": 200,
                                        "url": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=0/dg=2/br=1/ujg=1/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ/m=kMFpHd,sy8b,bm51tf?xjs=s3",
                                        "finished": true,
                                        "mimeType": "text/javascript",
                                        "experimentalFromMainFrame": true,
                                        "sessionTargetType": "page",
                                        "transferSize": 1640,
                                        "networkRequestTime": 2186.070000052452
                                    },
                                    {
                                        "transferSize": 1176,
                                        "finished": true,
                                        "entity": "Other Google APIs/SDKs",
                                        "resourceSize": 0,
                                        "protocol": "h2",
                                        "rendererStartTime": 2207.6310000419617,
                                        "statusCode": 204,
                                        "mimeType": "text/html",
                                        "resourceType": "Image",
                                        "url": "https://www.google.com/gen_204?atyp=i&ct=psnt&cad=&nt=navigate&ei=NEvLZYTrK5KxqtsP4d-0oA0&zx=1707821878168&opi=89978449",
                                        "sessionTargetType": "page",
                                        "networkRequestTime": 2208.87399995327,
                                        "experimentalFromMainFrame": true,
                                        "networkEndTime": 2217.988000035286,
                                        "priority": "Low"
                                    }
                                ],
                                "debugData": {
                                    "type": "debugdata",
                                    "networkStartTimeTs": 763797349859
                                }
                            }
                        },
                        "crawlable-anchors": {
                            "id": "crawlable-anchors",
                            "title": "Links are not crawlable",
                            "description": "Search engines may use `href` attributes on links to crawl websites. Ensure that the `href` attribute of anchor elements links to an appropriate destination, so more pages of the site can be discovered. [Learn how to make links crawlable](https://support.google.com/webmasters/answer/9112205)",
                            "score": 0,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "headings": [
                                    {
                                        "key": "node",
                                        "valueType": "node",
                                        "label": "Uncrawlable Link"
                                    }
                                ],
                                "items": [
                                    {
                                        "node": {
                                            "boundingRect": {
                                                "width": 125,
                                                "bottom": 840,
                                                "top": 792,
                                                "right": 737,
                                                "height": 48,
                                                "left": 613
                                            },
                                            "path": "1,HTML,1,BODY,3,DIV,4,DIV,2,DIV,1,SPAN,0,DIV,0,DIV,0,DIV,2,DIV,1,DIV,0,BUTTON,0,A",
                                            "selector": "div.spoKVd > div.GzLjMd > button#VnjCcb > a.eOjPIe",
                                            "nodeLabel": "Weitere Optionen",
                                            "type": "node",
                                            "lhId": "1-27-A",
                                            "snippet": "<a class=\"eOjPIe\" tabindex=\"0\">"
                                        }
                                    }
                                ],
                                "type": "table"
                            }
                        },
                        "aria-dialog-name": {
                            "id": "aria-dialog-name",
                            "title": "Elements with `role=\"dialog\"` or `role=\"alertdialog\"` have accessible names.",
                            "description": "ARIA dialog elements without accessible names may prevent screen readers users from discerning the purpose of these elements. [Learn how to make ARIA dialog elements more accessible](https://dequeuniversity.com/rules/axe/4.8/aria-dialog-name).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "items": [],
                                "headings": [],
                                "type": "table"
                            }
                        },
                        "landmark-one-main": {
                            "id": "landmark-one-main",
                            "title": "Document has a main landmark.",
                            "description": "One main landmark helps screen reader users navigate a web page. [Learn more about landmarks](https://dequeuniversity.com/rules/axe/4.8/landmark-one-main).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "aria-meter-name": {
                            "id": "aria-meter-name",
                            "title": "ARIA `meter` elements have accessible names",
                            "description": "When a meter element doesn't have an accessible name, screen readers announce it with a generic name, making it unusable for users who rely on screen readers. [Learn how to name `meter` elements](https://dequeuniversity.com/rules/axe/4.8/aria-meter-name).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "paste-preventing-inputs": {
                            "id": "paste-preventing-inputs",
                            "title": "Allows users to paste into input fields",
                            "description": "Preventing input pasting is a bad practice for the UX, and weakens security by blocking password managers.[Learn more about user-friendly input fields](https://developer.chrome.com/docs/lighthouse/best-practices/paste-preventing-inputs/).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "items": [],
                                "headings": [],
                                "type": "table"
                            }
                        },
                        "uses-passive-event-listeners": {
                            "id": "uses-passive-event-listeners",
                            "title": "Uses passive listeners to improve scrolling performance",
                            "description": "Consider marking your touch and wheel event listeners as `passive` to improve your page's scroll performance. [Learn more about adopting passive event listeners](https://developer.chrome.com/docs/lighthouse/best-practices/uses-passive-event-listeners/).",
                            "score": 1,
                            "scoreDisplayMode": "metricSavings",
                            "details": {
                                "items": [],
                                "type": "table",
                                "headings": []
                            }
                        },
                        "object-alt": {
                            "id": "object-alt",
                            "title": "`<object>` elements have alternate text",
                            "description": "Screen readers cannot translate non-text content. Adding alternate text to `<object>` elements helps screen readers convey meaning to users. [Learn more about alt text for `object` elements](https://dequeuniversity.com/rules/axe/4.8/object-alt).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "focusable-controls": {
                            "id": "focusable-controls",
                            "title": "Interactive controls are keyboard focusable",
                            "description": "Custom interactive controls are keyboard focusable and display a focus indicator. [Learn how to make custom controls focusable](https://developer.chrome.com/docs/lighthouse/accessibility/focusable-controls/).",
                            "score": null,
                            "scoreDisplayMode": "manual"
                        },
                        "lcp-lazy-loaded": {
                            "id": "lcp-lazy-loaded",
                            "title": "Largest Contentful Paint image was not lazily loaded",
                            "description": "Above-the-fold images that are lazily loaded render later in the page lifecycle, which can delay the largest contentful paint. [Learn more about optimal lazy loading](https://web.dev/articles/lcp-lazy-loading).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "is-on-https": {
                            "id": "is-on-https",
                            "title": "Uses HTTPS",
                            "description": "All sites should be protected with HTTPS, even ones that don't handle sensitive data. This includes avoiding [mixed content](https://developers.google.com/web/fundamentals/security/prevent-mixed-content/what-is-mixed-content), where some resources are loaded over HTTP despite the initial request being served over HTTPS. HTTPS prevents intruders from tampering with or passively listening in on the communications between your app and your users, and is a prerequisite for HTTP/2 and many new web platform APIs. [Learn more about HTTPS](https://developer.chrome.com/docs/lighthouse/pwa/is-on-https/).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "headings": [],
                                "items": [],
                                "type": "table"
                            }
                        },
                        "aria-command-name": {
                            "id": "aria-command-name",
                            "title": "`button`, `link`, and `menuitem` elements have accessible names",
                            "description": "When an element doesn't have an accessible name, screen readers announce it with a generic name, making it unusable for users who rely on screen readers. [Learn how to make command elements more accessible](https://dequeuniversity.com/rules/axe/4.8/aria-command-name).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "final-screenshot": {
                            "id": "final-screenshot",
                            "title": "Final Screenshot",
                            "description": "The last screenshot captured of the pageload.",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "details": {
                                "timestamp": 763799363470,
                                "type": "screenshot",
                                "timing": 2014,
                                "data": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAFcAfQDASIAAhEBAxEB/8QAHAABAAIDAQEBAAAAAAAAAAAAAAQFAgMGCAEH/8QATBAAAQMCBAIECgcHBAIBAQkAAQACAwQRBRIhMQZBEyJRYQcUMjdUcXKBkbMVFheTodHSI0JVkpSx8DNSYsEk4fE0JjVEU2OCg6LC/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAECAwUEBv/EAC8RAQACAQICCQMEAwEAAAAAAAABAgMEESGRBRIUFTFRUoHwQVPREyJioTJCcWH/2gAMAwEAAhEDEQA/AOcRFX1FPVune+CRrRckdbuGhFu4/FBYIoMcNaWTCaZhJHUDdPxtcLW2HEWts2WMDWwuT6tSCf8APegskVZTx4kZw+WRjY7gFpsSRztbbn+Cn1DXPgkbGSHlpAINrH1oNiKsip8QabGdmUntuQLd4UyjbO2G1U9r5L7tFgg3oiICIiAiK3puGcdqoGTU2DYjLE8Xa9tO8hw7QbIKhFefVHiP+BYn/TP/ACT6o8R/wLE/6Z/5IKNFefVHiP8AgWJ/0z/yT6o8R/wLE/6Z/wCSCjRXn1R4j/gWJ/0z/wAk+qPEf8CxP+mf+SCjRXn1R4j/AIFif9M/8k+qPEf8CxP+mf8Akgo0V59UeI/4Fif9M/8AJPqjxH/AsT/pn/kgo0V59UeI/wCBYn/TP/JPqjxH/AsT/pn/AJIKNFefVHiP+BYn/TP/ACT6o8R/wLE/6Z/5IKNFefVHiP8AgWJ/0z/yT6o8R/wLE/6Z/wCSCjRXn1R4j/gWJ/0z/wAk+qPEf8CxP+mf+SCjRXn1R4j/AIFif9M/8k+qPEf8CxP+mf8Akgo0V59UeI/4Fif9M/8AJPqjxH/AsT/pn/kgo0V59UeI/wCBYn/TP/JPqjxH/AsT/pn/AJIKNFefVHiP+BYn/TP/ACT6o8R/wLE/6Z/5IKNFefVHiP8AgWJ/0z/yT6o8R/wLE/6Z/wCSCjRXn1R4j/gWJ/0z/wAk+qPEf8CxP+mf+SCjRXn1R4j/AIFif9M/8k+qPEf8CxP+mf8Akgo0V59UeI/4Fif9M/8AJPqjxH/AsT/pn/kgo0V59UeI/wCBYn/TP/JUOMYTidDXtjq4Z6OTKOpMxzCBrqARY7/ggyRV4p64yRZ6lpjbYu0sXG/cFvxCGaeNjYJDG4OuTmI0sezvt8EElFWNpcQbktVNNr3uL3B9ysYw5sbQ52ZwGp7SgyRQ8ThfNG0MZnIzcgd2kcyO1bKGN0cbw9uUl7jaw/6KCHjOMx4ZJGx8TpC8E6G1lXfWyH0WT+YKLxv/APV03sH+65+ndG0u6VpdcWFuXeulh0+O2OLTHF4Mue9bzWJdV9bIfRZP5gn1sh9Fk/mC5rpKXX9i7Unnt2c1l0lJc/sn5dP7681p2bF6ZU7Rk83R/WyH0WT+YKbhOOx4jVGBsL2Oyl1ybriZ3ROt0LC3U7ncclbcHf8A3v8A/wAbv+lTLpsdaTaIWx57zeImXcIiLmOgIiICIiAiIgIiICIiAiIg6rwXUFPiXHuFU1ZGJIcz5Cx2oJaxzhf3gL1ENBovM/gb84+F+zN8py9MICLkeLMVxk4pTYRw7GxtRKM0lTIAWxj8/wDPVr4cqcXosUlhx3HMNqqcCwALWyB99rC1vxWNM8ZLTWkTO3CZjwiXptpupijJe8RvxiN+M/1tzl2SIi2eYREQEREBERAREQEREBERAREQEREBERAREQEuO1a6iTo2E81WVVS2CGSeokDIo2lz3E6ADcq1azbwVtaK+K3uO1LjtXK4NxDQYxLLHRTudJHqWuBBI7R3KYMRpi8sFQ0vzZcouTfUf9H4LW2nvWdpjipGalo3iV9dFWxyuYb3JCnB2ewabXFyVjauzSJ3bEWiR8EcrI5JQ17wS1peQTbeyZ4P/wA0bX/1Dt8U2N29FGbNTOeGtmaXG+nSHkbdvbotrA1zc0byRyIdcJtsb7ti4Pw14fT1XAdZUzRtM9I5kkT7atJe1p9xBXdsN2677Fcd4YPNzjHsx/NYoS8yjZEGyICIiAiIgi1uH0taWmqhEhboCSRb4KN9A4b6K3+Z35qzRXjJeI2iZVmlZ4zCs+gcN9Fb/M780+gcN9Fb/M781Zop/VyeqeaP06eUKz6Bw30Vv8zvzW+jwyjo5TJTQBjyLXuTp71MRROS8xtMymKVjjECIiosIiICIiAiIgIiICIiAiIg7TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphBxHGDsZwfHKbGcJojXUmUx1MDP9TsBH4bDkuSjwscWcTU89Bw/U4ZAJ+nq6qpc68hvcgA6du3byX7IiaWbaS02wTtvvv8A+7+LzZtPOe297bxw4cPp5eQiIj0iIiAiIgIiICIiAiIgIiICIiAiIgIiICIiCPWMLourqRqqqsgjraSankLgyRpY4tNiL9nYVenVaH0sTzdzRdXpea+CtqxZyXD3DjMIqJJ3Vc1TIW5GZybMbpoBc9g+CmOwaldKJCXl7Xl7SbHLck6Ajtce9X/iUP8AsCeJQ/7Atbam9rdafFlXT1rG0IV8xyt1cVYsb0YB5WsUigZH5LQFtWNrdZtEbK+vw6jr5BJUdZwblaQ+1hrf4g2Kiy4BhsjSC0gktNw7Xq3t/dXSWUxkvHCJVnHWfGFH9XcNztcMwyvzgZtL7H8FZUUFPRU7YKewY3ZoN1KsiWyWtG1pK0rXjEMWAga7nVcf4YPNzjHsx/NYuyXG+GDzc4x7MfzWKi7zKNkQbIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIg7TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphAREQEREBERAXN8eYtV4PhdJLQOLZZqyKnLhTuncGuJvZgILiukUDGsIpMZpWQVolyRyNmY6KZ0TmvbsQ5pBHxQcTReENtJSmLFmiWu8YmjY0sFG4xxtY4ueyR3UcekbZt9QQdATa2k4+wyOkdUPiqQwASZSwB3Q+L9P0tr3y5QW+0LKb9TcHEYDGVbJs73uqW1koncXNa12aTNmIIY0WJt1W9gUp/DODyVRqJKJj5DRHDjmJINOf3CL2Pr3QVM3GboauGhkwWtGJzSRsZTdJFctkZK9r82bLa0MgIvcEc7gpxli2LYfWwNoi+Gi6Fz5KiOidVlsl+qHsYcwZa5uAdtxbWyouFsLo6mGpZHPLUxSNkZNPUSSvBax7Gi7iTYNkfYbdYnfVbcX4eocVqmVM5qoqhsZiMtNUyQOcy98riwi4v27XNrXQc27wgUtJZtQ+GolldGIuikbHEQYGSuc2R7hdvXFrgHUC25V7V8SwxcLwY7BTyS0ksTZi1zmxua0i4uCdTewsLkk6XWLuD8GDWiCnkpnMLSx9NO+JzMsYjAaWkEDI0C22gO+qkYjw3h1fh9DRTsnbT0T2vgEVRJGWuaLNOZpBNr87667oIcHFkToHOqaCqppmT0tO+GTLmY+fJlBsbaZxf1FasbxWvdjtTh9DUx0UNHRsrJ5jTGd787nta1jAeXRuJ0J1AFlJdwjhT6uKpkbVvljfFJ16uUh74zdj3DNZzh2m+w7ApeL4BQ4rURVE/jEVVE0sbPTVD4JMpNy0uYQSLi9ig56k46YMN6aWB1aKWnE9fU0rckcTekewuDJCH3vG8ltiRlOp0vun47pYIxPNQVbaWZ0sdJKCw+MvY7LlAzXBcfJvYEDWymngvA+jjjbTSsiazo3sbUSATNzl9pet+06znHrXvmdfcrXiHBmGzU1WKaMtmlbKIxNJJJFC6Q5nFrMwDbnW7bHsIQVeIceeI1knj1FLRw0ZnbVxvLXucWxRyNyEOtY9IBrb3K1wvi6mxHBsVroaaV7sODjJFE9kmezM/Uc02NxpvuCFFwfgajhgrfpg+PT1cskjyZJCGh8bIy0Fzi46RjUm4O1tF0OFYTTYZFMyAzyGZ2eR88z5XONgN3Em1gBZBzVR4RsHhFa7JUPjpXPzOYAQ+NsZeZG66tzNMftd2qgYl4RG/RlVUYdBeqpmTuMRcyVjyyB0reu11raa21uCOwq/pOCOHqWLo4cOaGeJuoCC9xvC55eW6n/AHEm+/etp4Rwl8D4qiOoqQ8PDnT1MkjiHxmNwzF17ZSR+O+qCqb4QaBuJmhlp5BMx3QyZZGEtl6PpCMt82X93Na1+7VG8eB1H4z9CV4jbBDVSjPFeOOVxEZIzak2JIGw+CtYuEsKjn6UNqiTq5jqqQse7J0edzc1i7Lpc6899VVY/wADtxKopmU1QymomQwU72DpM5ZE/MASHhrtNBnBtqdb2QQMS8JNM6kxAYXC59RC2QwkuY/pDHIGuBaHXbe5y5rXA5KdW+ECkoXup6yilgxBsz4XU8s0TQMsbJC7OXZT1ZWWF73PcSrb6oYRmnvFOY5c94TUSdGzO4Pdlbms27hfT/tbK3hfDKyplqXxzxVUspldNBUPifcxtjOrSCAWsYCNuqDvqgrKDjimrqqFsGH1nick0EHjTsjQ18sTZGAtvm2eAdNCfh1yqIeHMLgblipi1vTxVFukcevGxrGHfk1jRbnbVW6AiIgIiICIiAuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB2ngb84+F+zN8py9MLzP4G/OPhfszfKcvTCCHLilDFO6CSqhbM3dhd1hty//cPipHTw5M/Sx5d75hb/ADQ/BVdZw5htZWy1c0TjPLo9weRcZCz+x+IB5LGr4Zw2qpaankicI6eJsUeV1rBpBaewkW59p7SgtvGIet+1j6t79YaW3WElZTRgF88TQXNYLvG7tAPWVRv4MwZxjIge0xscxuWQiwcXE6c9XX17G9gWTuD8JcxjOieA0MabOtmDTcA++23Ygu3VdO2N8jp4gxjc7nZxYN7T3d6xiraaWPOyeMt7za2ttQdtdFWUnDGGUsMkccTiJI5InkusS19s23shKnhqjqXl9RJUSyFuUvc+5Ou+3utt3K1Yr9UcVqyrp3nqTRnl5XPX8is+miyB/SMyEXDswsQqE8IYTnDhFJYPz5S8kXuTse83W93DdC+Gkif0zo6YODQX+VmNzf8AJTaKf6ycVhNiNHCJDJURjowwus65GY2bt2nQdqNxGjc2NzaqAtk1Yc462hP9gT7iq6Dhqgp4po4OljEnRah2rejdmbbT/drrf4KPLwbhUsjnvE5cXB9zJezgCL/iT61RLoGyxuzZZGHL5Vjt618E8Rk6MSs6T/bmF/h7iqyi4eoKKCWGnY9kMsJgkZm0c27j/wD7d8VjR8N4fSVTKljHuqGyPl6R7rkufbMfwCC5REQEREBERAREQEREBERAREQEREBERAREQEREBcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEHKYpVcQN4rp4aFkhwjPEJ3dADa972JOo2ueVuX73SV7pm0kppW5pgOqPy718lraeKuho5JQ2oma5zGdoG/wDncewrdNIyGJ8srg2NjS5zjyA3KCgZX402Oxw/OQHWc4i5sere1tSOVhbfuWNLiuLz1DsuHt6IStjNzawtdx77XtfbRXXj1J0TJDUxBjwC0l4F7i4/AhaIcaw6bo+jq4z0gJbe40ABO+2hBRCvmqsajqHGKl6VmZ12usAwfu2O7hvf3L5LX470BLMOjEjmEgZs2V1nabi+oB5aG26uzV0wc1pniDnNzgZxct7R3d6xlrqWEuElRE1zbXaXi+uo0QV7K3FDSZnUTWzdPkDdSMlr5j2cxz5e7Gor8VFLBJT4aHSvz52PfbLY9X4jX3W5qdHilC8yAVUQMZs4OdlsbA8+4j4rdJV00bM8k8TGWBzOeALHYolTeN441ko8Tje5jn5T5OezrNFr7Ea3WH0rixq3QMw9jyx7WvNyBlI39/4K3diVE12U1Md+lEOh/ftfL67LBmL0D44Xsqo3NmLAzLqet5Nxyv3ohElrcVjoY3jD2yVLgbsa6wBu234F3w71iysxbpajpaMBkcb8mUX6RwLcpGvPracrbqwfidCxge6spw06g9ILWva/qvoshX0jnFoqoC5pDSBILgnl60Fc+txU0kjm0YE7Cy2lw+7jmsL38kA+/uWk1+Ol5LcOiABk6pde9hdut+Z099+SuRW0pjY8VMJY92Vrs4s49gPMrHx+jNv/ACoNRmH7Qai9r/HRBSfSGPCWQ/RzHMIZlF9B/ud26adXfvVthU9dM15r6ZsB3aGuvzIt8AD7+5Zy4jSRRskdOxzHv6MFnXu617aX5ArI4hRgXNXTga69IOW6JSUUWavpYaTxl0zXQXsHsBfc3tpa99V8OJUILQauAFwuAZAOz9Q+IQS0WkVVOXuYJ4i9oLi3OLgA2J9SwkxCkjJD6mEODgwjOL3Owt2lBJRQvpah6YxGpjDwXtIPIttmv6sw+KyOJUQkaw1cGZwLgM42AB/sQUEtFHZW0r2lzKmFzRuQ8ED/AC4WLMQo3xyPbVQlkds7s4s2+10EpFqNTAGZzNGGXDcxcLXOwWr6Rotf/Mp9P/1G/n3H4IJSKGMUoTOYRVRdIGh1i62hvbXvsfgpUUsc0Ykie17HbOabg+9BkiIgIiICIiAuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB2ngb84+F+zN8py9MLzP4G/OPhfszfKcvTCCpqsCgqMS8dfPUNlzMcA0tsMpBAGlwNNr8z2lWNTBHVQOhnbnifo5p2I7D3LW6vpm4iyhMzfG3RmURc8gIBJ7NSPX7imJdP4jL4pm6e3Vy5b78s2l/WghDh7DQ5rmwuGV4kaBI6zSNBYX0FgBbsCw+rOFF5cacl1iLmRx0PvUI1PEjXZY6OJ7GhxD5C0OfocoNnWvq29uYPJTI6jGvE6h8tJCJwxnQsbY9Y+Ve7tufL3ohIlwShljYxzH5GRCFrRI4WaOQ109fPRYy4FRTVMs0zHve8m13kBl2BhtbtAUepmxeWhlaynkhqOkDGPi6MnLc3fZxIta2m9/iotTXcQQNleaNhijc3KWgPc8He7QRseyyCxbw9honZN4veVjg4OL3E3Gx3Wb8EoHmPNE4iONsTRndYNbtpf8VAlrsdZCD4hG57tQWgEC77AEZxrl1voP7Iysx+SRuWhgbGXPBc/QgDyTbNrr6r9gQTnYFh7qd0LoXOjMnSWL3aOsRprpoVrbw7hrXFzYHAkMH+o7Zvk8+SiyT8RCHMylpzIGg5LjV2bUXzaC3rPrWuWq4lMByUNMJHB4ADgLdUZTcu5uO1uSCf9XsN6Rr+gN2tyDrusB8e4JJw9hkmTPTA5XF46x3IA7ewWUPxniJrnkUcLwQ0tBLQAeY8r8e61tbrI1PEXTPZ4lSmNuaz7+Va9tM2l9B3XQSarh+inp4YA18cMbmnK1x6wGXqnu6jfgtH1Uwwyhzo3GIBwEWY5QXWu71mwW+qqMXFVIylpIjCxzbPeR1xzt1tPWR8VGkfjxo4JGRt6fNIZY7NboHXYBqQLgZd/wB6/JBOkwShfSGmMThCXBxaHuFyGho59gH991oh4bw6N0LnRySSRFrmudI7dosDa9tgPgogqOJGPsaWB4YJGg3FpCLZHHrC19ToOdtN08a4kD2EUMDmuYC4FwGV2twOtry/w6BZuwaidRGkMbvFrgiPMbAg3utMXDmFxOJjprXFj13ai9+3t1UEVXEhe0eJwhrnAud1eqMovbra9bMNe0L4Z+JXZQKWFpFx5TQDoLXNz37BBOg4eo4ZpntMpZLHJG6MvJBzkFxvvc5QtgwKgD2uET8zX9Jm6R1ydN9ddgo9LU46+qAqKKCOnzanMC4tzAf7tDYk89rd6201TizqrLPRsEJe6zrgWaA61+sdSQz4nsQZzYBh00ssklPd8t85znW5udL/AOaLU7hrC3BwdA8hzQxw6V1iBbfX/iPgFHin4ifHFI+lpmPFs8V99ddc2mljzWplXxMGEuoKcvJ8kuADdtjm1vr6u07ILB/D2HPlkkdE/PIXFx6V2t9+a3nCKPopY8j7ShoeekddwBJ1N+0n1qO5+MSYXOOjjirrt6IttlscpN7k7dYe7RR6SXHgZHzwssYpXsYcuj8wLGkg8hcd9t0SmSYHQSQPikhL2Ol6Yhzyeta3b2Eiy0jhug6V5e17oy0MbGXHKwBmTT3LRTVHEJkyzUlOIw5vXJF3NsSdA7Q3sOdu9YzYhjjsQnhpKGJ0LHgCSQFosSdjfraAH3213RCU/hrCnhualByhrR1jsNuatKaCOmi6OFuVmZzrXvq4kn8SVRMq+In5b0FPEXEDVwdkF7Emzhcga2G999LH4+r4jAbloKUlweT1/JOuUeVryN++2m6DokVDHU4+alzZKOmELXtAeD5Tbam2bTX4d6Vz8eD5hSRwlgcCwutcjPqL3sBlFtr6olfIufNRxEWuLaWlFi7KHDUgZcv7+l7u05W71h41xEZS40UTWCSwaC09S3lHrb67aXtug6NFzr6viQNblw+lJc1xIz+SbnK3yteRvpvZXlIZnU7fGmtE1yDl2Ouh3O41Qblxvhg83OMezH81i7Jcb4YPNzjHsx/NYg8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO08DfnHwv2ZvlOXpheZ/A35x8L9mb5Tl6YQQZsJoZ8RZXy0zHVjGhrZTe4ANwPipNWJjA4Uxa2U2sXbDXX8LraiDn2sx8Oa57oHOyNDsugvfWw7ezu70bHxBHJHaWB7MwDrgeTbXs1v+A7V0CIKaQY6KOnETqR1TmtKXggW01FuzUWWTGYy3D4gH0xq83Xz3yhtuVtSdB8SrdEHPubxC6n/wBSASODx1QBbTqnnrf/AKWIZxGM7y+lzHK3JbS2uYjv2tfluuiRBV0f0sIZm1ZgMzmExuYOq11zYEb2tlPx7lFpRxB41C6pNGIiR0gZc2sTe1+0a+u3JXyIKWb6cc6QxeLsaC8NFrlwt1StDfrGWOLjSNIFw1ovrcaX9m/Zr3LoUQUdXBjDqmN9O9gsGZ7u6hFjmAG972N+wLBg4hEbXPNKXa3ba3MW19V7q/RBS0jccZSzid1O+ZrGdFm0D3Ada5Hbry0utb28Q5Zcj6MuDnBgc2wIuA0n1C59Ysr5EFABxGQ85qIOAGUWNibi/fa1/f3L7QR46KqPxqSLxYSOcbAZyw3sDyuLi9uwW5q+RBzzhxL1rGg/eDbA66dUn8fw71lk4gFQ/LJTmMudYuA0Fuqr9EFbK7ExSQiJkRqA4NkLjoRbVwUaJmOCRxlfAcsDw22jTJcZb81dogo8NZjbKu1W+E0xLjc6vtbS9tN7bd/ctMDceha5oZG/qbySBxL8o1BtoCb6W0/AdEiDmJIOIyJHdJFd0YAa1wFn9W5220PxUyWPGSynaySO4fIZCbai7so9Vsu3YrtEHO34l6Nv/wBJnya6bOvy11Hw071vrIMWeKUxyjpA13SFrg1odmaRccxlDh7/AHq7RBQtbxBlfd9KCM+UBt77ZefZf39y2ULcb8YtVvgEJjJJABLXn4aDT8e5XSIOelZxFI2QZ6WPM0kZBctOQ2AJ7HaXttbvWf8A9oc//wCFy52WFv3ba313v/6V8iDnmDiN1w51IwWNja58k29+a1+7Yq7pOm6BoqbdKNCRs7vW5EBcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEHM4oziVuJ1EmHvhfRgHoo35QScl9eflNy77PJ5LZTycSufEZoaJrC6MvaBqG2648re+3/atarFKOlnbDUTtZK4gBp0OtgD6rkC/aQN1KmljgidJK8MY3dx2CDmKt3E8NTXPo42Ts6QdC2YsDctze1jc6W3I9XMzcXlxuSSnZhkDWdEQ+d73NDZBYAsbub6k621aNbFWDcWw9wcW1tOQ0BxPSDQHQH8VjNi9HEIXGXMyUEtewFzQA4NNyNtXAIKjD5eJ44axtZT08jmRuNO4OF3vvoDYgDn+Gu60MqOLmwdejpnTubmFi0tacnknrg+X2X0V99MYdzrYBbNfrjS2/wAFnBidFUSGOGpjc+xOUHWw529x+CDnm1PFc0jbUtPGGSsDgQAHNyXdrmOmY7geq+pWRqOL/F4nCjoOldcOYT5PYfL2Pdzt26dAzEqJ8bpGVMRY0Ek5tgLfmPiFqdjeGt3rYLWzF2bQC17k7BBCqzjsGEzy0rYqnEnPIZE6zYw0EgEa31FiQSd1FmquKi9wgoaMDUAyOFtA3XR19Tmt3Wurh+MYewuDquK7XBp617Emw/ujMYw983Rsq4i67Ro7QkkgD16f27UFDE/i2SrDpIaWGK7XFoIcCMhu3e/lEC/dfZbcNn4pbk+kKalMcd8+SxfILttbrAA2zHbcW2V5LilDE/LJVwtd1jYvH7psfgdEbidGWwuM7Gib/TzaZtbae9BXYrNxAyrIw6mpJKbpGWc89bIQc19RsR8Dtoocs/FzJC2Olw6SNuUZ7kF19SbZtAL2tfkT2BX0uJ0UWXpauFmYXbd4FxYG/wACCtMeN4bIXBtZDo4MuXWuSARbt0KCjqJuLwYzFTUbi3K4htgHXb1gbu3BOlt7akc5gl4lGHTuNPQurbjo2ahti5wNzm5DK7v1CsxjGHFod47BlIBBzjX/ACxW2kr6Wsc5tLURyloBIYb2B2/uPigqI/rA/D5jUCJlRdha2C2a2e7wC42vl0F+fPs1GbiRrgyOmiMV2AOlLS+1tSSHAXvuQNOQduulRByUU/F7ImCSlo3vyuzkOB1DBa3WG7r/APpTqufiEiNtLS0zXGBrnveQ5rZP3m2zAnnqr9EHMS/WKSmkL2vZJ40bNpzECIuiIFi4kEZ7HXW3LktD5+MA9xbSUZDS9oFxZwu3K7yr/wC7TTftsuuRBz75uImUUJFNSyVJqGB4Bs0RFgLjq7cOuPdeyjST8UytjMdNTwODS4tcGuBcA6zSc/M5dvjyXUogp8TnxkzU7cNpouiky9I+a14x1s1xmFz5Nrd/cpeDurnUEZxVsTav98RCzfdqf7qaiAiIgIiICIiAiIgLjfDB5ucY9mP5rF2S43wwebnGPZj+axB5lGyINkQEREBERAREQEREBERAREQEREBERAREQEREBERAREQdp4G/OPhfszfKcvTC8z+Bvzj4X7M3ynL0wgi/R9J40ak08bpy/pOkcLuDsuW4J20uNO09pUiWNkrMsjQ5twbHuN1V1DcX+sMMkJpzhIhLXsLiH5y4dbbWwBttuVPr2zuo5RSECoAvHc2BcNQD3HZBE+gsMylviceU2u3WxtsLdnO3bqthwmiLIWGAFkIIYC42FyCb666gHXmFVwU/EMT2xuqYJIy6xe5t3Zdr+uwv6ye5fadvELYIonup72jDpDYu08vuv2fiiFk3BsPa14bTMAcSTYnnvbsSDCKCB2aGnaw9H0V2kjq9m/r+J7VXxy47JR1QEcLapr8sZcLNO+3aPJ/FfZDj5L8rYALZW5SLg2F3a7630005hEp7MHoWMe1sAyvZkcC4m407T3D4DsQ4Nh5aGmljLQALHsGov26lV1Q3iBz88Jp25XWsTu3tt2r5DFxCxzw6amcDncCRfXMS0eq1h6u9ELD6Ew7Ll8Ujy5Wty62Ib5OndbRZw4RQQG8VLG03B58jcfBR5hjAhibEYDIekD3nlr1Db1WutPRY26OpDpYhIWxiIjQXv1j8ESmuwige6RzqZjjJfMTc3ubn1a6r7JhNFIGB0RIY3K3ru0F83bvexvvdQoGY62oiEslM+ESEO6upZpY+sjN77d60mlx5tRM5lVC6M5uia7lrZpOmump70QtJsJoZsnS00bixrWtPMBt7D8T8VgcFw8ua7xVl2lpbqdCBYW7NAB321UFjcfa7oy+nLDKP2vMR3N9O2xb8ClNLjklPVNmjY2oaWBjmgBt7nMRfcZcu/O+vYSljAcM6v/iMJb5JJJtrc8+dzftUymo6emN4ImsNg3TsAA/s0fBV4GMvp2gugil6UBxAv+zyi9u/Nf3WUVn1ky/tDR5rHRo0BtodTttp29yDoUVHTDHnStM7qZrAWEgC9xpmF/Vf39yvEBERAREQEREBERAREQEREBERAREQFxvhg83OMezH81i7Jcb4YPNzjHsx/NYg8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO08DfnHwv2ZvlOXpheZ/A35x8L9mb5Tl6YQVz8aoGY7Hg7pwMQfCZxHY+QCBe+3NTp5mQROkldlY3c2utdRR01S+N9RBFI+MhzHPaCWkG4I7NQFnUwR1MLopm5o3WuL22N0Ff9P4XZxFZGcoBOUE2B22Hu9ei2Oxmga/KagZutplP7u/JbG4XQNa5raSEBwykBgGnZ+CfRdDlc3xSCzr3GQc90EZvEGHOcQ2oBOXO3/kLXuPd2r4eIsKAYRVtc137zWkgXva5tpfKbdvJSfonD+r/wCHBoLDqDbayfRVBkDBSQ5RYgZBpa9vhc29aDTU45QU9+km06JszSASHNdexHw/Edqxk4gw6N0bTOS95sGhhuN76W5EWPYpcmHUcg/aUsLuoI9WA9UG4HqBWBwqgMpkNHB0hJcXZBe53PrKDD6Zw/xWOp8aj6CR2Rr9bEr63GKBzg0TgEi+rXDt7R/xd8Cs3YXQuhjidSQmKM3a0sFh/lh8AjsKoXOc51JCS52c9Xc66+vU/FBp+ncOLsoqW57ElpBBABsdD3r7HjeHSSBjKpheXNblAN7u25LJ2D0BiMYpYmtydGLN2b2BZU+FUNOxrY6aMZQ0XIudBYG/ag+V2LUdFMIqiXLIQHZQ0k2va+neVo+n8PzRjpiM7nNHVO7Rcj4bW3UmbC6KZwdNSxSODQzM8XNhyuhwyhMjZDSQZ2m4OQaHZBo+ncO5VIIy57hp2/793YVvlxSjik6OSdofcAjU2uL69mh3UWXh7DZOnvTgdM0NdbSzRyHYpslBSSvzyU8Tn9XrFoJ0vb4XPxQRpcboY4IpjK4wy3yuDCdiAdN+YR2O4a17mmqZmaCSLHYGxOylGhpSxrDTxZG3sMosL2/ILA4bRFxcaWEktLT1BsdwgjyY1SR1lRTyFzTAQHuJFrlodte+xHJfHY/hjd6ptgLl2U2G1r6f8gpb6CkfK+R9PG57yC4lu5ta/wAAAtbsJoHEk0cFyACcg2GyDRFj2HyCW04HRyCIixJLjta297G3qR2P4W22atiAILgTexA5jtHL16bqQMLoBKJBRwB4dnzBg8rt9a0xYFhsb3uFJEc+hDhcAdgHZrsgnwTMnibJE7Mx2xtbu2WaxjY2NuWNoa25NgOZNz+KyQEREBERAREQEREBERAXG+GDzc4x7MfzWLslxvhg83OMezH81iDzKNkQbIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIg7TwN+cfC/Zm+U5emF5n8DfnHwv2ZvlOXphBzFRh+NDiU1kVQ59AZGfsenIAboHHLa3bor/EfGPE5PE/8AX0y6gcxfe42uqmu4qw6hxCajqTKySEXkdl6oFg7t/wBpJ9TStsXE2EyvY2Opc4vcxrbQvsS8Xbrb4nlzsgjCm4kLJM1dSh2UZMrB5Wl73bta/v7ltdBjxzEVUA8uzdLG/k65eX/ySvk/FWHUs1THWmWmbA8ML5Gizrki4AJda4teyl4rjlDhgozVSWFXII4rW1JGh9V7D1uCCubR8QhzS6spzmZZ4ufKy2uNNBfXRDScSGJhdX04laRcNaA06Ozfu97berXvk0PFGFVkVQ6OoLXU7HSSsc05mNB1JtfuOnaFp+uODCPpXVD2w2DhI6JwBBtlI01Bvy99kQzrKHGJZqd8VbGwNjYJWgkBz9nEd1iSO8Ba20nEOSFz66AzN0cAAGnXcjLrp6v7raOLMIDHOkqHxhpeDnifYZdTra1rbdvJSqDHKLEJgyhdJOLBzniMhrQQSCSbXvYjS+u6JV1UziRkTnxywue5z7Rsy9Ufualvx/DtUyohxl1fK6GphZSZmFjNM1gDmB6vM2WA4qwY0xqBWjohYE9G7S5I2tfcFR63jPBaWF8njLpQw2cI2G4Nrga210tbtQbGQ8QZYmvqICL3e4OF926DqWOzhy3HYoz4eJ4xGBPTySubYvaAGtdfcgjax5a6D3ym8W4OZ3wuqHtla8xhhidmcQAbAAX52sdbgqbVY3h1LRQ1dRUhlPLH0zHlpsW2Bvt2G/qv2FENeGR4tFKDiE0U7HaWYAMugsdt75r+sWVc2h4ikkJlromBxj1YdgHkusMu9iBfYgahSm8WYK4sHjoGdwY0ujcA45c1gSOwi/ZcDcrB3F+DeLOnjqZJWiN0gEcLyXBu4Gm/d79tUGoU3EUbZ3+NQOPXc1jTe50sNW6Df3nms8PbjnjjBVuywPZcm7SWHKRY6b3sdNN1KouJMKragQUtV0spcWWbG61wCbXtbYEjttovlJxJhdZPDFSVPTOmcWMLGOILhe4200BPZb1hEtPQcQOeC6qpmjVxDRoDl0aLt2zbnmLbFZz0eL/SE0tPWtZTvfHZh1ysF81gQbHa3LfuX0cS0DYWTVJlpopGdJG6Rt87NOv1b2BuB1rG5AstLuL8GYajpKksFPI2OQuYeq4gEC1r31ta17goM6WlxzoHisrIHPdC5gyDKA83s7a+mn/ytbaHG4ogKeqiYRFaz3uku/NuS4E2sT77clMHEOGGAzNqS6MTmmuI3H9oASRttYE3271EfxdhTYmSZqhzHxPlDmwOIIba4va19besEbohploeI5AW+PQBrspPI3sL2IbpqD8T7pEsWPNa54nhs1xsxliXty97dDf3evZbJuJaCCuqKWbpmPhlbCT0ZIc5zczQ0DU3F9huClbxPhdDUzw1Uz4+hDc7zG7LdxIABtqbjleyDTQQ8QuMT6ypga39m50YaL8s4Jt2X259y6BVNLxHhVXWtpKera+pc5zAwNde7Rc8vX67LA8TYS2ESvqSxhJAzRPB0cG7EX3I+KJXKLnW8YYS5s5a+d3Q6ODYXG562mnc0nXlqVudxVhbMpkllYwmxkMTsjTpu61uY9XOyC8RVFLxHhtZHI6jnM2SN0pGUsBDbZtXWFxcbnS6jDi7CWQ5quZ9JKGtc6CZh6Rgd5NwL73HxF9UHQIqKTizB4nkSVRa0NLg8xuAcA7KbaajMQLjS5AV1BKyeCOaFwdHI0Pa4cwRcFBmiIgIiIC43wwebnGPZj+axdkuN8MHm5xj2Y/msQeZRsiDZEBERAREQEREBERAREQEREBERAREQEREBERAREQEREHaeBvzj4X7M3ynL0wvM/gb84+F+zN8py9MII81DSTvc6algkc7yi+MEnQt19xI9RKxZh1EzLkpKduW1rRgWtt8FFlx2hirZ6WSQslh8u4sALNN+8dYfArZDjFHNMYmPfnFyQY3CwAJvt3H4IM34Th0jpXSUFK4ynNIXRNOc9p01WbsOo3TSSvpYXSSNDHFzAbt009Wg07go309hl8vjbc1sxbY3AvbayyGNYeSwCpb1yA3qnW4v2dmp7OaDc3DKBokDaKmAkblfaJvWHYdNVrGC4WGOYMOowxwAcBA2xA25clpbxBhrpmRioF3+SbHU3tbtvdYjiPCywOFU06gENBOW5AubbAFwF9kE12G0LgQ6jpiHXuDE3W+/JbKekpqYWp4IohlDeowN0Gw05KI/G6BscMhnHRSte5rwCRZpAd8L/gVqdxDhrYmPdOQXnKGZDmvppb1EH1INowPCQ2wwyitly26Bu17222us34Phkl+kw6jddxec0LTck3J23usGY3hz6eScVTBFGcr3G4ymxNj8D8LLEY/hjiQyrY8jkwFx/Adunr03QSPoyg6XpfEqbpcxfn6Jt8x3N7b96y+j6MwshNLAYmXysLAWtuC02HLQkeokKNSY5h1U+NkFS10j9A2xuDpv2akD16KSK6mNPLO2UGKPy3AE20B/sR8UGAwugGS1FTDJq39k3q+Ttp/xb/KOxYnCMNMHQnD6Qw2tk6FuXe+1lnLiVHFTRVElQxsEjQ9jzsRpr+IWtuL0T2Tujmz9CCXgNIItuNeYuLjldBuhw+jgkL4aSnjeXZ8zIwDmsRf12J+JXyDD6Kne10FJTxOacwLIwCDYNvoOwAeoKIOIMNJf/5HVaxshdkdaxvbl3X9Wq+R8Q4Y9z2+MhrmucyxadS0XNu3QoJBwjDSSTh9ISSXH9i3Unc7c0OEYaWFhw+kLTYEdC2xttyX2pxSlp6WGofITHMWhmVpJNyAD3DUbrTJjlE2jkqY5Omjjf0b8luqe8mwHrugktw+iY1zW0lOGueZCBGLFxFi7120usBhOHBrmigpA1wyuHQt1HYdNlrZjWHvFQRUsvACZRzaL/8Ax8QsTjtACwdKSHSGO4aSAQCdTy0afVpdBJkw6ikqG1ElHTvnacwkdGC4Ha9+3QLGbC8PmfK+ahpZHy26RzomkvttfTWy11GNYfTzOinqmMkBAIIO5/8AYt69Fqm4gw2K+epALS3MC0gtBIFzcaDXdBKjwygim6WKipmS3Ls7Ymg3IsTe3NahgmFBrWjDKINa3IAIG2Db3tttfkvr8YoGxwSOqG5Jg4xmxObLuNt9DotM3EOFxRue6rZoL2ANzpfT3EfEBBsGB4SCCMMorg3B6BumluzsW0YXh4c5woaUOdbMeibc22vpysPgtH09hmfJ42zODYtsbg7m4tpbn2c1liGNUOH1IhqphG/IJDfYNzBtz+PuB7EG0YXh4hdCKGlETmuY5nRNylptcEW2Nhf1BY/Q+G5SPo+ksW5LdC3a4NttrgH3BahjlBY/tSCJDGGuaQS4GxsDqtTeJMMuc85js3N12kaafqH49iCWcIw05r0FIczsx/Yt1PbtvqVKhijhjEcLGxsGzWiwChuxeiEQk6a7DL0NwD5Vr2tudOztWufHaCnmayabK10QmEliW5SbA3QWaKBBi9DUSujhqA6RocXNDTduXe+mlr29eijs4iw17rRz5znEfVadCQTr2bHfmCEFuirDj2Fh5b45GXC5Ibc7b7dnPsGqs0Bcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEFBXVmEtxKoirqRoexjiZnxghwytc63M6Bt/ZHdfWcUwSIvHQmNjY2npBCQC12YCxtfa59RWWI4thUOIyU9TR9JO57InO6Jrrki4vzsO/wByiy8QYRlfGcPJJMZex0bLWed9zci503/FEJFLVYGJDGylawsd0OYxXBvl59hLwLlZUlVgMssbIIIy+QkN/YEX1y3uR26X5rVUYtgraanq5aDN4yH2vC3N1dCDfvsFqqMbwcVMbn0U3jFO4BgDAA1zhfkbb/jsg3mp4eY9sYgiLgWsaGwHdwzNbtzWBr8DhbEJKFscUtOyov0IIDXOFgQP+QHddfBjuEjpIjh0gfZ0kjOhbuLh1zex5+tWGI4hh1FJDDJA2R8oayNrGNOYa2AvyGX3aIIj8VwEM6N8YLYhI3KadxyC9n8u3Qr5WVOD02IPjqcPaDFZ3S9ECNGjUeoOA7veL4HHaB9LW1UFAHtjbG92YNDn9I4t1GtvJ57+qxXypx7Cs8jqnD5S85o3l0LXXLLEtJvyuO7X1oNgxPARTPijga+Jz2kxiA2c7R19RbTQ3WyGowWWQRQUjXF7dbQZQBYuF7gW8i/wK+PxXC2UbZZKEsY2oEAYY2Xa+wIOhtYDmFEp+JsKZDFmoXRO6xDY42m1jY9h2dva2pG6DfDi3D8AD2RsieG57dAQW6jTbe4Bt70mxbB6eN0bKUlksrWyhsVgCRo49trDbuWt2NYO0NY7DXNDskbQYGWId1hsTpqD79t1sPEGG5mNdRS53FxaOiab5Rve/wAP+kG+TEcDDI6V7IyyN2RkZhOVp1YbaWA3HZrbmvlRXYXQUUE5o8sNVE6TSMbENNnd56o9dlHrcSw+iFO9uGwGN8JmAs1rxYFwAFu463AHavsfEeFOjMcdLJ0THCLyGBt3agb2sQL3201QYzYngXi7XmjD4nRdLdsGlmWAHrBNgpNRUYFRVXQywRRyh+QAQnVxaCdh/tIuo1LjmG1AibFhxzzZA8ZGWaC9rNTfkSNN9BpayxkxzCIaicz0LumMkhe5sYfcxaA39QFhuPxQSH4pgT4gyVoLI8soY+F3VBtlda2g296xdimBAtpGwtPSyEmMREWcLgkj8Peo1Tj+HCKSSLC+lkBiIzMa25do257QL8joO9b5sdweGXOaTNKS9pLI2khzdSL331QZxYrgPXEUbAZrhwZCbutqbgDf8kp6vA3QSyQ0kbRA0OkaYQ3o2uAuezZ1z3LMVtH9GR1dHh8L3CYxRx5Rcdctv1QSL2vso44gwyJlRmw+VjgC2oaIm8nBpB11F3W+PJBrgxDAp6uWaameKqZzGuZJHmObYDS48ouHrB7lubWcPzxdPJSszyBhcx0BLuubgEW7dfxWUmPYWJC80j3Fji3PkYbHyu3c29d97LRTY9hLhTujoGs6UExERjRoN9eztsL6oJkldgQp21EjIxFA/o2vdEbNJvtpz11/NaY6zAaiRgjo2ve9wiH7C2mYN1JGwLhp3qPDjuEQ0z5YsPn8XqHdJIXMBu4mwFie71D4qZX4vRUrr+IGQsj8ZYWsaNbDt1BJIHvQJK3AWVEjTFGZTJ0brQEkvdcW23PWHuK+1uIYLGIPGYmyMdGyVr3RF1hs3cXvr/dR6jiHDWVTW+IudM2RjHEsbdhcdTe52O//AGts2M4Q7D4ayakvHJE8Ma+JuYtY4Att6yDbuQbBU4KyFszKVhY2Yx3EGrXZc5NiL62G3conj3DkcbiaWNgu1rQYLZsxuLacz+O6lNxujf4yG0hDaZpllzhoy2sHaC+wJ1520UWPHsPlfHFU4W9s+fK1nRNd1hpa5sN7j3d6DezGcDcMrog1zJC/IYCcrmjytBuAL37FtxiqwehfHFW00bgWMjJ6K7WMuS0Huu06dyiU2P4TJEyQUNp5Gs/ZtYwk576A3sRqb+vXW63jGMMlhZM2kzsikbCCWNJYDexG9h1edrb7IMp8QwqCKOdlJniqhIHSCMAWzAODr9pPv9ZF0VRgLYBPHBEGNqOjDhCf9Qje9vx71Hix3DJIomnDnO6MtEbWxsIaXnqgXIsSNT2bHXRb6LGMLrJmwQ0b7OlJu6FoaHAgZvXcgX3QfaOowWongihpGftWuYw9BZtgCCNuy477LoFzUPEOEMe8QwFkgm6PRjRmdlJuDe1rDfvF1bYRibMSZI5kT48jiOsQcwzEAgg88pQT1xvhg83OMezH81i7Jcb4YPNzjHsx/NYiXmUbIg2RAREQEREBERAREQEREBERAREQEREBERAREQEREBERB2ngb84+F+zN8py9MLzP4G/OPhfszfKcvTCCiq8SZSYnLHHhsjpXuDTM1o69mg37Ta9lrPEjRTdMcNqxdme2Tvta/wDu7l9qMVxSHF6qFmHmelZ/puDHNvZjXeVqDclwFuY1ssZMexBgflwSodlGYEE2cL206t787EbdiIZniAtla12G1AaXNaDbXUX/ALWHrNkdjsj6OpljoJWSxdEcsltc5HfyBv8A9qTh2J1NVUujqMPkpmB7mNc8nrWta2nMX58uagNx7Ezd5wOoynKAy5zXub30tYAfG3ag2zcRCDomy0crnyaNLbdbqk3Gp00N9dFhHxC7onEYZUAtbmsG3sC6wB79QSOzVfajE66SkNTFhro54pzEA+J0jnMy3u0ADc2Gthpus5cZxBziynwuQOEjWXlDwCLtzEWbsLnXbTS6D4/iNjOkHiFSS3TQbnMB8Be5PLZb8Rxd1PLSdFAZIpWPe46XBaQMu411I57KI/G8TfFP0GDStexr8pkzWJFsumXW5PbsFjV8R1lGbVGFSAW8vM4NJtcN8nc7W7fig21HED2B0bcPl8YtIWMcdyzn6r/go/07+1dUswabMejZnydc3JuPcG/HTvUyixauqXkyYTLT2abOeSSDZxta23VA33ITD8Yr6mphhlwuWFrm3dKQ7LvbmAR79e7mg1z8TRRMfIaKo6JpeGvIAByc/eNu1b6HG/G5Q0UFTGP9zwN7ONv/AOpB7DYKI7Fq8lzZ8KkqLFpyiFzQ11/JBN8xG+bQab6gLB/ElaakQxYVI57Q5z2AuLsoGhtlFgSRvrodNkG+o4itTvlioJ3gMc5pIsCQbW96kVeMGmqZoTRTPax7WdIB1es29z3DW55L7VYpVR01HNBQSSmUftYQHZmHTS9raXO9hpuob8dxI0b5G4NM2Usd0bTmd1xa1xl0GpPuIQZQ8QvdT075MOqGvksX9WzWXvYk9l2nXkBfmFh9Zj4tG4YbUmd0Wcty6Ndr1b9ul/UbrcMaxHxh0RwaazHZS/McpABJI6uu1h6+S3YliNbT10IpqZ01M6PMQIn5r2O52A0GliddkGEWNyPpKmQUEzX07WOc0jygd8o3uBf1rTBjs5k6GfDJhNcN6vk3zZHankHB2vZY818ixrFDPkfg8ha/I5jgXANBIBDjl3Gp2/7UibFq+OhjmGFPfKQS+JryS2zmgW6uvlX2GxQaouIs9Ox3iFQZjGJCxo077FbRj0bqd8rKSZ+Wo6AtaASDlzXPZ2euwWqmxrEXyuZLg87QH2z3IFi6wO3qv7ysKXF60xteMHfTRuc0yEh1xd9nGwb/ALdboMm4/K6YA4ZOIsrHOJHWGbutrbS/v7FrZxK5zmO+jajo3uc1pA1uDb4Hl23Hap2I4pV01QI4cNmqGFzR0jDpZwOu3Igg9lx2qG/HcRY03wKoc4Ma7quJFzYkeTfTMOW9+xBOZizX4fJOaWRj2ZLwu3AdaxPYNdeyx7FGw/HzUQzOmoaiJ0UTpXZm6G3Ic9eR7j2LVUY3icb25cGlIzHNbM67chIscuhvYG/uvykx4rXOoppjhMoka1jmRZzd5cSCNRpa1/UUHylxp1XNCyCjkbfWTpBbKMhcPxAHvUZmPVBigvhzxM/J+zt2uLXG/ICx+I7VJjxOvlgqJBh74Q1sbmZwS6zjr1balo1IBvfRazjNcx4YMNmmFwOkDHszC175SDa+1r6c7IMTxIMj3tw2rytJBu0DYgfjmv6lvqMZkZTGVlBOXNmyFpbc5ALl2ncNB22USLHcTEUJlwWcvfG5zwAQGuA22O/+XUybFqtrIBFhkz5JI432dmAYXEhwJym2XT4oI8fEEl3F+G1Aa1oJDW3cSS4aDs0B9R5LQzG/F6p0cWFua6SRufK2172u46d5/DtUk4riEkEkgpHU9pgwZoHykNsdcosTqBtpruo7sfxRpdfA5zkb1gM3WdcCwNth1vwQTKbHDUQPkbQVDA2F0ozAakfu6c19kxpzaRszaGYPdK2PK7Tdodf4G3rBSbFqyKkdKcLldJ03RiNhJJba+byfd/2oj8exETZm4RUGLo2nJ0bs2c76kWAHqueW6DMcSNy3dh1UPKGrRuB2bi+/q1U3D8XdV1LI/Ep4mvaHB77W1BNvwP4dqgTY5ibGNeMFlIIzFgLi62Yj/bYWtf1FTsPxKqnq+jqsPfTxHNkeXF1yCAARlFrgk78kFsuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rES8yjZEGyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIO08DfnHwv2ZvlOXpheZ/A35x8L9mb5Tl6YQVNZVYoKp0VJRsMYeAJXnQtI1NrjYqPW1WNhpNLSRkupmusSOrKTYtGvK9/d3q3fWUzHlj6iFrxu0vAI2/MfFZMqIX2yTRuubCzhqbX/ALaoKKasx81DI46GMRtks+TQhzRfUDNz07xZbzXYwMPikOHNNU6942v0bqLa+rN8O9W9RUQ08RkqJY4owbFz3AAe9ZMe17bscHDtBugpW1GMuknD6VjBHHJ0eW1pHAtyHfS4zacu1aYKniFjmMmpIHklwL76DS4Nr9pt7leRVdNM/LFPE929mvBOwP8AYg+8LZHLHI3NG9rh2g3QUUFbjmSOOSgYXlzGmQ2AAt1nEX5G2nNYw4pi0tJVkYcBVRBuSM7FxJuL310AN/8Akryeqgpw01E0cQecrc7gLnsCyMsYeGF7c55X1/zQ/BBQx1ePioMbqKExl9hIT5LbDWwOtjfsv7tdb8WxoPETcNYZ8ma2uXyrb37OS6W47QsWyxvc4Ne0lps4A7HvQUhrcaExa6gi6KxIc11yNdNL66ert7l8pqnG2005qaWMzNhj6MNb5Tz5V+tsLj4Ei+yvrjtS47Qgo6vE8Rgw+WbxE9K2Qsa218wsSCADzIA960+P48QL4bG3UE5XZjbMLjUjlcX966EvaHBpcLnldfGSMkY17HtcxwuHA3BQc7FXcQZmufh8Ra55aW3tZo2de/Ps5X7lcYXLVy04NfCIp7AkN21F7bnbb3KU+Rkds72tubC5tc9iwFRCTGBLGTIMzBmHWHaO3cINqLFkjJBdj2uAJbob6jcLA1EIDSZY7Odkb1hq7XT16H4INqL5cdoWPSx9Jkztz2vlvrbtQZolx2hLjtCAiXHaFiZGCQML25yCQ2+pAtf+4+KDJEBB2K+B7S4tDhca2ug+osJJoo/9SRjdC7U20G5WElVBG2N0k0bWyODWEuAzE7AdpQbkWplRC9sbmTRubIbMIcCHHU6dux+C+MqqeSd8DJ4nTM8uMPBc31jluEG5FrdUQta1zpWBriGtJcLEnYBbLjtGqAiAg7EIgLjfDB5ucY9mP5rF2S43wwebnGPZj+axB5lGyINkQEREBERAREQEREBERAREQEREBERAREQEREBERAREQdp4G/OPhfszfKcvTC8z+Bvzj4X7M3ynL0wg5+vw3CqnEJnzVDo6mW7HAPA/cDba9z2n12UZ3D2CupC3xwhnVJkErQTl0Fzbut8VcVuC0NbOZaiHPISDe53AI29Rt8OwKO/hnC3B/wCwcM8YidaR2rQAAN/+I/HtKIRo6HCPE6inhrWsaZC57s7MwcDcnUb9Ya+pZUtDh2HV85gr3x1dSzNeSQOsCdxcdykjh3DRUifoD0geHgl5Oo2WybAcPmY1kkBLWxNgHXPkNNwN+0IKufBMGnD5DVuuczi5kwva5cbW5AED1BvYtcOEYEZGz+NvHkM6ORwbqHNIu0gG5NviO5XMOCUEMs8kcOV8zXtebnUPN3fitT+HsPklEskcj5AQ7M6RxuRsd/d7h2IIsWF4VHQRUkdcejYx7M3StJcx5Ac06bEgC4se9RYMCwi/QePZ52hj3ZXM1sS0G1rWuCLdu9yrNvDeGNhEbYCGi9rPIOpB/wCgs3YBh7mZTG/QNaD0jrgN8kDXkgqhgWBzFoZWE5c7CGzN6xcSDftN9PdZTK6mwmpwptM+sbDTRkvuyRrSLAm22lgfdYLeeHcOcQXROcA/OA55IB623d1nad6+fVvDA1jWwOAYx0Ys93km5I3/AORQRaDD8Oo8QbJT4g91Q2MR2c9pGQG1jYf8bfHmvk2D4RNK989WHuLpCM0jOoSOsBpyvftClM4awxjHtZA5ma1y15B025r5Pw3QTSRmz2sBcXMDjZ9wRr8UGuXBsOrKyqqhVOc9+V0ga5jmt0FjYgjUDndaYcMwmpo4aeGoe2HpGyNYQG5jkyjRzf8AjfTW+qtqLCqSiBFNGWAtDDZx1Avb+5UaLh3DYp45mwHpGEODi4nUG4/HVBVyYLhD5mukxCcvL3PJL2i7mkk36umrv7LOLAMIZltXFxa3ox149BlAA0bro3Y9/aVZjAMPE3SNhId0pmIzmxfcm9r9pPxK1v4Zwp7WNdTXDG5B1ztcnt7Sgiw4FhMVRSVEdSQ9pzx5ZGhshDi4mwFjvy5CyxlwbBpK0tdUDxmV75Q3O0klwA2tyB0Hed1Z1GCUVQIxJG60Ze5tnkWLyS4/iV8hwOhhe1zI33bbLeRxtYtd29rW/BBWnBsFiAe+dofE4dZzmhwcAWjl/lhbZaY+H8FjaGCvddzMgvKwk3ce7XUkf21Vk3hzDxI+V8bnTPeZHPzEEk77craLKPhzDY4REyFzY7AFoebEAEAHt8ooK9mB4K+pEjakkxjpXN6QZSLAEnTbQXPO+q21OC4TI6B89V1GUzImtdI3K6NpBBOmuttVNjwKihgljpmuiMgILg473Bv8QEbgNGIIo39K/JEyLMZCCQ29tuep+KCrkwfCSyYPxCQftHOkGdgJcQ4a9W9xc29XOwQ8PYK0Sh9W8l7HEudM27Q4tuQeWw177KyHDuH9LI98b35r2BebNzMDHW9YC+nh7Ds7XiJ7S0WbaR3V62bTXt/CwQaMMocNw6oLKWsAlcG52ue0l4Is2/8ALceoqHT8PYMQ2KOqfI7ozG28jXG17kjTfl6lYs4doBmL2Pc57i5xzkZusTY9wzW9QC3U+CUVPURTxxv6WMuIcXknXe6CojwXBJaZrvHA+N0bS15ey9hlAN7X5Aa9pGiynwXCKd75ZK+SIvkY65lboW6C1x3j1dym/VjC8tjA4nI1ly8k2btr3Lc3AaFsmcMfcvEhvI6xItbnsLDRBXRcP4OOiibU5y3M1jS9hdcg7G17gOvb1Gyl4hw7S18sj55qnrOLg1rgA2+W9tOeUb37rLOl4dw2kcHU8BY4aAh5uOsHf3AKt0S5/wCqdDne7pKjrFpy5m2GXYWstz+HqdzKRvT1A8WbljPUJHWDr3Ld7gf4SrpEFVhWA0eGTiamz9IGFhc61yCb66K1REBcb4YPNzjHsx/NYuyXG+GDzc4x7MfzWIPMo2RBsiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiDtPA35x8L9mb5Tl6YXmfwN+cfC/Zm+U5emEBERAREQEREGE80dPC+Wd7Y4mDM57jYAdpK5KXwj8NRyOb4499ja7YXkH8FC8M76hnCbBBmETqhomt/tsbX7r2X4Yu90X0Vj1eKcmSZ8duDk67X3wZOpSOb99+0rhv0qX7l35J9pXDfpUv3LvyX4EpeHMpXzOFbIWR5bAgX1Og+F7+5dG3QOmrG+9v6/Dxx0rnmdto+e79y+0rhv0qX7l35J9pXDfpUv3LvyX4vU0+G2YYKl1zKGuBBsG9uy3Glwe7R448DKbmxJvc6baaWCz7m0v8vnsv3jn/j8937F9pXDfpUv3LvyT7SuG/SpfuXfkvxg0+FOfYVUrR1RfL8TsolfFSRloo5ny9YglwtppY/ifgpr0JpbTt+757InpPPEb8Pnu/cvtK4b9Kl+5d+S+jwlcNEgeNyjvMD/AMl+Aote4NN525x+FO9s3lHz3ep8Nr6XE6RlVQzsngfs9h/zVaMaxnD8EphPidSyCMmzb3JcewAalfm/gLfOTirOt4sOjPcH67e7/pUnhnfUO4sayXN0LYG9EOVje5+P9lxqdGVtrZ0s24Rz8+bpW10xpozxHGX6B9pXDfpUv3LvyT7SuG/SpfuXfkvwJF2e4NN525x+HN72z+UfPd++/aVw36VL9y78k+0rhv0qX7l35L8WwyPDHRx+PTOa/OS6wNstiANOd7H1L6ymwzxtzXVjzAGXDi2xLtdPwHx7ljPQuliZj93z2aR0lnmN/wBvz3ftH2lcN+lS/cu/JPtK4b9Kl+5d+S/Gm0mFuNvHXi98pt8Li2h37fWvrqXCQ148ceHNGhAzXPZsP/dk7m0v8vnsd46j+Pz3fsn2lcN+lS/cu/JPtK4b9Kl+5d+S/FpqfC2xExVcrn2dYFvMXty56fFVavXoLS2+tv6/CtulM9fL57v337SuG/SpfuXfkrnAOKMIx5z2YbVtklYLmNzS11u2x3C80q74KfUR8WYUaTN0pqGjq/7Set7rXWeo6CwUxWtS07xG/Hb8L4ulctrxFojaXpVERfKu8IiICIiAuN8MHm5xj2Y/msXZLjfDB5ucY9mP5rEHmUbIg2RAREQEREBERAREQEREBERAul1pWp88bJAx7gHHZBLul1FM0YAJkbY6A33QzxAgGRlztqglXS6iiWNwBD2m+2qyje2RuZjg5u1wgkXS60og3XS60og3XS60og7rwN+cfC/Zm+U5emF5i8DHnJwr2ZvlOXp1AREQEREBERBorqSCupJaaribLBIMr2O2IXDTeCrA3yOcyeujaToxsjSB8Wkr9ARb4tTlw7xjtMf8ZZMGPL/nXd+efZPgnpeIfzs/Sn2T4J6XiH87P0r9DRa946r7k82XYsHoh+efZPgnpeIfzs/Sn2T4J6XiH87P0r9DRO8dV9yeZ2LB6Ifnn2T4J6XiH87P0p9k+Cel4h/Oz9K/Q0TvHVfcnmdiweiH559k+Cel4h/Oz9K+jwUYICCarECOzOz9K7nEqsUNHJUOYXtZYuA7LgE+7dUruKomRy9JSyiWNmctBuNDZwv2hwcPctKazWX41vPNS2m0tJ2tWFpgmEUWC0LaTDoRFCNTzLj2k8yo3EnDmHcRUzYsRiJczVkjDZ7O2xWmPiije9rWw1Ni8R5smgJvbnfkVlUcRRU1Q+OaE5QXtGV4Lhl3zA2tfcam4XniM9b9eN+t47/VtNsM06vDZzH2T4J6XiH87P0p9k+Cel4h/Oz9K6WPiandEHGnmzlmfI0tJ/v/AOvfot9Dj1NW1QghjnBLyzM5oABsT232BXpnV62OM3nmwjT6WfCsOT+yfBPS8Q/nZ+lPsnwT0vEP52fpX6Giy7x1X3J5tOxYPRD88+yfBPS8Q/nZ+lPsnwT0vEP52fpX6Gid46r7k8zsWD0Q/PPsnwT0vEP52fpT7J8E9LxD+dn6V+honeOq+5PM7Fg9EPzz7J8E9LxD+dn6VfcMcF4Tw7MZ6RkktSRYTTOzOaOwWsB8F0qKt9bqMlere8zH/VqaXDSetWsbiIi8r0CIiAiIgLjfDB5ucY9mP5rF2S4zwx+bfGfZj+axB5mGyLQNl9QbkWlEG5FpRBuRaUQbkutKIN10utKIN10WlEBRqqjjqSelLspAaWg2Bsbj8Vvyj/CmUf4UEL6Lgta77WPZz3OyybhsA3L3es8+38FLyj/CmUf4UEH6Kp7OBznMLanYXB/6UyCIQxhjSSLk3PebrLKP8KZR/hQZIsco/wAKZR/hQZIsco/wplH+FBkixyj/AAr7lH+FB23gY85OFezN8py9OrzD4FwPtKwr2ZvlOXp5AREQEREBERAREQEREBERARR562ngmEU0mR1r6g2A13Ow2PwWAxKhIJ8bgsDY3eBb/LIJaWHYooxCjL8vjMN7X8sLbBUw1AJhlY+wBNjtfZBtsOxYujY4tLmglpuCRsVrqKuCmDDNIGB+jT26XWAxCkLnNFTFdpsesOwH/sIJNh2JYdiiOxOha3MauCxFxZ4Nx3dqOxOiaNaqE7aB4JQS0UUYhRFpcKuDKBcnpBon0jRA28bgva9ukGyCUi+Mc17A5hDmuFwQbghfUBERAREQEREBERAREQFxnhj82+M+zH81i7NcZ4ZPNtjPsx/NYg8vjZfViALf+19sEH1F8sEsEH1F8sEsEH1F8sEsEH1F8sF8yj/CgyRY5R/hTKP8KDJFjlH+FEGSIiAiIgIiICIiAiIgIiIO18DHnJwr2ZvlOXp1ePMAxapwLGqTE6Kxnpn5g12zhsQe4gkL9vpfDZgDqdhqqHEopiOsxjGPAPccwv8AAIP1RF+Y/bVw16Niv3LP1p9tXDXo2K/cs/Wg/TkX5j9tXDXo2K/cs/Wn21cNejYr9yz9aD9ORfmP21cNejYr9yz9afbVw16Niv3LP1oP05F+Y/bVw16Niv3LP1p9tXDXo2K/cs/Wg/TkX5j9tXDXo2K/cs/Wn21cNejYr9yz9aD9ORfmP21cNejYr9yz9afbVw16Niv3LP1oP0aoo6eodmnia91rXPvt/c/Fa24ZRNDg2mjAdvpuvz37auGvRsV+5Z+tPtq4a9GxX7ln60H6F9GUXR9H4vHkFrC23+XPxW+npoqfN0LAwONyB8F+bfbVw16Niv3LP1p9tXDXo2K/cs/Wg/Sp6eGoaGzxskaOThdRhhdEGlop22O411/yy/Pvtq4a9GxX7ln60+2rhr0bFfuWfrQfoDsJonyBzoGmzcob+6Bpy9w+CyGGUQJPi0dzvpv61+e/bVw16Niv3LP1p9tXDXo2K/cs/Wg/QDhNEXvcYGnOblp2v6l9bhdG2odN0DTIeZ5er+6/Pvtq4a9GxX7ln60+2rhr0bFfuWfrQfpsbGxsaxgDWtFgByC+r8x+2rhr0bFfuWfrT7auGvRsV+5Z+tB+nIvzH7auGvRsV+5Z+tPtq4a9GxX7ln60H6ci/Mftq4a9GxX7ln60+2rhr0bFfuWfrQfpyL8x+2rhr0bFfuWfrT7auGvRsV+5Z+tB+nIvzH7auGvRsV+5Z+tPtq4a9GxX7ln60H6ci/Mftq4a9GxX7ln60+2rhr0bFfuWfrQfpy4zwx+bfGfZj+axUn218NejYr9yz9a4fwmeE1nE+G/ReEU00FE9wdNJPYPfY3DQATYXsd+SD8yGy+oiAiIgIiICIiAiIgIiICIiAo9ZHNJG0QPyOvqe7Y/n7lIRBWhmI5SC9g56b7bX9a+E4new6K5GhtoD3/5urNEFc91eJA0ZSCSM1tuwlfQMRJcSYgM2g7v/AJVgiCDGK4TM6R0Zjuc1hrvp+CnIiCFK2r6Z/ROaG3u0n1DT8D8VrY3EMxBfGG33trb/AOVYogrcuJEk5ogQNBbQnRZ2xDOBmjyXNzbWynogwiz9EzpbdJYZrbX5rTWsne1vizw119b/AB/uAPeVJRBXxx13RyMfIy/RkNcN83IrF7cSc05XRNILbX59v+d6skQV7W4gHEZmZS4ancN5+/sWIbiRa4F8Td7FvqNt+9WSIIEza/ppDE5mSwDQV9mZWCYujcC2456WsNh23upyIK1xxDMxpDOsTct2Czc2tdHCS5okB69tBuP/AH/m09EFeRXuLTeNtiTbt0NgffZbaVlTma+peL5SHNbtf/LqWiAiIgIiICIiAiIgIiICIiAiIgIiICiVjagvaac7Dm6w35+5S0QVzG4jm6zo7Fx5DQaL6BiBsHOjHaW+7/2rBEFeRiGl8mjbdW2pvvr3LEtxJ1jniFnbDmLG/wD1ZWSIK5jcQaH3MZ1OUE92n4rOB1YKlrZw0x5bktHdr+KnIgKvDK9sj7PY5hcbXOoBJ/sLKwRBXx+PhoDsl+ZNtNO5a3HEndI1uQENsHbC+u34K0RBXOGIm4vGBcWtvbvQur2yMFmOBJvYbD/LKxRBWSOxJoblEZc4DYaA3591lKpRVZj4wWFvIAer/wBqSiAq6GOvZG0FzS4WzF2t/wAVYogrQ3ETu5gBOu2yyJr2sucnV5DUkKwRBX05xBxaZeja3QkW15X/AAv71YIiAiIg/9k="
                            }
                        },
                        "uses-rel-preload": {
                            "id": "uses-rel-preload",
                            "title": "Preload key requests",
                            "description": "Consider using `<link rel=preload>` to prioritize fetching resources that are currently requested later in page load. [Learn how to preload key requests](https://developer.chrome.com/docs/lighthouse/performance/uses-rel-preload/).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable",
                            "details": {
                                "items": [],
                                "overallSavingsMs": 0,
                                "headings": [],
                                "type": "opportunity"
                            }
                        },
                        "label-content-name-mismatch": {
                            "id": "label-content-name-mismatch",
                            "title": "Elements with visible text labels have matching accessible names.",
                            "description": "Visible text labels that do not match the accessible name can result in a confusing experience for screen reader users. [Learn more about accessible names](https://dequeuniversity.com/rules/axe/4.8/label-content-name-mismatch).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "aria-toggle-field-name": {
                            "id": "aria-toggle-field-name",
                            "title": "ARIA toggle fields have accessible names",
                            "description": "When a toggle field doesn't have an accessible name, screen readers announce it with a generic name, making it unusable for users who rely on screen readers. [Learn more about toggle fields](https://dequeuniversity.com/rules/axe/4.8/aria-toggle-field-name).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "dom-size": {
                            "id": "dom-size",
                            "title": "Avoids an excessive DOM size",
                            "description": "A large DOM will increase memory usage, cause longer [style calculations](https://developers.google.com/web/fundamentals/performance/rendering/reduce-the-scope-and-complexity-of-style-calculations), and produce costly [layout reflows](https://developers.google.com/speed/articles/reflow). [Learn how to avoid an excessive DOM size](https://developer.chrome.com/docs/lighthouse/performance/dom-size/).",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "displayValue": "502 elements",
                            "details": {
                                "type": "table",
                                "headings": [
                                    {
                                        "key": "statistic",
                                        "label": "Statistic",
                                        "valueType": "text"
                                    },
                                    {
                                        "label": "Element",
                                        "valueType": "node",
                                        "key": "node"
                                    },
                                    {
                                        "valueType": "numeric",
                                        "label": "Value",
                                        "key": "value"
                                    }
                                ],
                                "items": [
                                    {
                                        "value": {
                                            "value": 502,
                                            "granularity": 1,
                                            "type": "numeric"
                                        },
                                        "statistic": "Total DOM Elements"
                                    },
                                    {
                                        "statistic": "Maximum DOM Depth",
                                        "node": {
                                            "type": "node",
                                            "nodeLabel": "div.iOHNLb > span.z1asCe > svg > rect",
                                            "snippet": "<rect fill=\"none\" height=\"24\" width=\"24\">",
                                            "selector": "div.iOHNLb > span.z1asCe > svg > rect",
                                            "boundingRect": {
                                                "bottom": 0,
                                                "right": 0,
                                                "top": 0,
                                                "width": 0,
                                                "height": 0,
                                                "left": 0
                                            },
                                            "lhId": "1-30-rect",
                                            "path": "1,HTML,1,BODY,2,DIV,5,DIV,2,DIV,2,DIV,2,SPAN,1,SPAN,1,G-POPUP,1,DIV,0,G-MENU,7,G-MENU-ITEM,0,DIV,0,DIV,1,DIV,1,DIV,0,SPAN,0,svg,0,rect"
                                        },
                                        "value": {
                                            "value": 18,
                                            "granularity": 1,
                                            "type": "numeric"
                                        }
                                    },
                                    {
                                        "value": {
                                            "type": "numeric",
                                            "granularity": 1,
                                            "value": 83
                                        },
                                        "node": {
                                            "lhId": "1-31-DIV",
                                            "nodeLabel": "‪Deutsch‬‪English (United Kingdom)‬‪Español (España)‬‪Français (France)‬‪Italia…",
                                            "selector": "div.IXMIVb > div.tn3Mmd > div#tbTubd > div.yK56b",
                                            "boundingRect": {
                                                "top": 0,
                                                "width": 0,
                                                "left": 0,
                                                "bottom": 0,
                                                "right": 0,
                                                "height": 0
                                            },
                                            "path": "1,HTML,1,BODY,3,DIV,4,DIV,2,DIV,1,SPAN,0,DIV,0,DIV,0,DIV,0,DIV,0,DIV,1,DIV,0,DIV,1,DIV,0,DIV",
                                            "snippet": "<div class=\"yK56b\" role=\"none\">",
                                            "type": "node"
                                        },
                                        "statistic": "Maximum Child Elements"
                                    }
                                ]
                            },
                            "numericValue": 502,
                            "numericUnit": "element"
                        },
                        "canonical": {
                            "id": "canonical",
                            "title": "Document has a valid `rel=canonical`",
                            "description": "Canonical links suggest which URL to show in search results. [Learn more about canonical links](https://developer.chrome.com/docs/lighthouse/seo/canonical/).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "viewport": {
                            "id": "viewport",
                            "title": "Does not have a `<meta name=\"viewport\">` tag with `width` or `initial-scale`",
                            "description": "A `<meta name=\"viewport\">` not only optimizes your app for mobile screen sizes, but also prevents [a 300 millisecond delay to user input](https://developer.chrome.com/blog/300ms-tap-delay-gone-away/). [Learn more about using the viewport meta tag](https://developer.chrome.com/docs/lighthouse/pwa/viewport/).",
                            "score": 0,
                            "scoreDisplayMode": "metricSavings",
                            "explanation": "No `<meta name=\"viewport\">` tag found"
                        },
                        "is-crawlable": {
                            "id": "is-crawlable",
                            "title": "Page isn’t blocked from indexing",
                            "description": "Search engines are unable to include your pages in search results if they don't have permission to crawl them. [Learn more about crawler directives](https://developer.chrome.com/docs/lighthouse/seo/is-crawlable/).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "headings": [],
                                "items": [],
                                "type": "table"
                            },
                            "warnings": []
                        },
                        "interactive": {
                            "id": "interactive",
                            "title": "Time to Interactive",
                            "description": "Time to Interactive is the amount of time it takes for the page to become fully interactive. [Learn more about the Time to Interactive metric](https://developer.chrome.com/docs/lighthouse/performance/interactive/).",
                            "score": 0.99,
                            "scoreDisplayMode": "numeric",
                            "displayValue": "1.6 s",
                            "numericValue": 1572.5,
                            "numericUnit": "millisecond"
                        },
                        "aria-required-children": {
                            "id": "aria-required-children",
                            "title": "Elements with an ARIA `[role]` that require children to contain a specific `[role]` have all required children.",
                            "description": "Some ARIA parent roles must contain specific child roles to perform their intended accessibility functions. [Learn more about roles and required children elements](https://dequeuniversity.com/rules/axe/4.8/aria-required-children).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "html-xml-lang-mismatch": {
                            "id": "html-xml-lang-mismatch",
                            "title": "`<html>` element has an `[xml:lang]` attribute with the same base language as the `[lang]` attribute.",
                            "description": "If the webpage does not specify a consistent language, then the screen reader might not announce the page's text correctly. [Learn more about the `lang` attribute](https://dequeuniversity.com/rules/axe/4.8/html-xml-lang-mismatch).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "aria-input-field-name": {
                            "id": "aria-input-field-name",
                            "title": "ARIA input fields have accessible names",
                            "description": "When an input field doesn't have an accessible name, screen readers announce it with a generic name, making it unusable for users who rely on screen readers. [Learn more about input field labels](https://dequeuniversity.com/rules/axe/4.8/aria-input-field-name).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "image-redundant-alt": {
                            "id": "image-redundant-alt",
                            "title": "Image elements do not have `[alt]` attributes that are redundant text.",
                            "description": "Informative elements should aim for short, descriptive alternative text. Alternative text that is exactly the same as the text adjacent to the link or image is potentially confusing for screen reader users, because the text will be read twice. [Learn more about the `alt` attribute](https://dequeuniversity.com/rules/axe/4.8/image-redundant-alt).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "type": "table",
                                "headings": [],
                                "items": []
                            }
                        },
                        "uses-optimized-images": {
                            "id": "uses-optimized-images",
                            "title": "Efficiently encode images",
                            "description": "Optimized images load faster and consume less cellular data. [Learn how to efficiently encode images](https://developer.chrome.com/docs/lighthouse/performance/uses-optimized-images/).",
                            "score": 1,
                            "scoreDisplayMode": "metricSavings",
                            "details": {
                                "overallSavingsBytes": 0,
                                "headings": [],
                                "sortedBy": [
                                    "wastedBytes"
                                ],
                                "overallSavingsMs": 0,
                                "debugData": {
                                    "metricSavings": {
                                        "FCP": 0,
                                        "LCP": 0
                                    },
                                    "type": "debugdata"
                                },
                                "items": [],
                                "type": "opportunity"
                            },
                            "warnings": [],
                            "numericValue": 0,
                            "numericUnit": "millisecond"
                        },
                        "meta-description": {
                            "id": "meta-description",
                            "title": "Document does not have a meta description",
                            "description": "Meta descriptions may be included in search results to concisely summarize page content. [Learn more about the meta description](https://developer.chrome.com/docs/lighthouse/seo/meta-description/).",
                            "score": 0,
                            "scoreDisplayMode": "binary"
                        },
                        "image-size-responsive": {
                            "id": "image-size-responsive",
                            "title": "Serves images with appropriate resolution",
                            "description": "Image natural dimensions should be proportional to the display size and the pixel ratio to maximize image clarity. [Learn how to provide responsive images](https://web.dev/articles/serve-responsive-images).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "headings": [],
                                "items": [],
                                "type": "table"
                            }
                        },
                        "frame-title": {
                            "id": "frame-title",
                            "title": "`<frame>` or `<iframe>` elements have a title",
                            "description": "Screen reader users rely on frame titles to describe the contents of frames. [Learn more about frame titles](https://dequeuniversity.com/rules/axe/4.8/frame-title).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "link-text": {
                            "id": "link-text",
                            "title": "Links have descriptive text",
                            "description": "Descriptive link text helps search engines understand your content. [Learn how to make links more accessible](https://developer.chrome.com/docs/lighthouse/seo/link-text/).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "items": [],
                                "type": "table",
                                "headings": []
                            }
                        },
                        "plugins": {
                            "id": "plugins",
                            "title": "Document avoids plugins",
                            "description": "Search engines can't index plugin content, and many devices restrict plugins or don't support them. [Learn more about avoiding plugins](https://developer.chrome.com/docs/lighthouse/seo/plugins/).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "headings": [],
                                "items": [],
                                "type": "table"
                            }
                        },
                        "document-title": {
                            "id": "document-title",
                            "title": "Document has a `<title>` element",
                            "description": "The title gives screen reader users an overview of the page, and search engine users rely on it heavily to determine if a page is relevant to their search. [Learn more about document titles](https://dequeuniversity.com/rules/axe/4.8/document-title).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "items": [],
                                "type": "table",
                                "headings": []
                            }
                        },
                        "duplicated-javascript": {
                            "id": "duplicated-javascript",
                            "title": "Remove duplicate modules in JavaScript bundles",
                            "description": "Remove large, duplicate JavaScript modules from bundles to reduce unnecessary bytes consumed by network activity. ",
                            "score": 1,
                            "scoreDisplayMode": "metricSavings",
                            "details": {
                                "overallSavingsBytes": 0,
                                "items": [],
                                "debugData": {
                                    "type": "debugdata",
                                    "metricSavings": {
                                        "FCP": 0,
                                        "LCP": 0
                                    }
                                },
                                "sortedBy": [
                                    "wastedBytes"
                                ],
                                "type": "opportunity",
                                "headings": [],
                                "overallSavingsMs": 0
                            },
                            "numericValue": 0,
                            "numericUnit": "millisecond"
                        },
                        "redirects": {
                            "id": "redirects",
                            "title": "Avoid multiple page redirects",
                            "description": "Redirects introduce additional delays before the page can be loaded. [Learn how to avoid page redirects](https://developer.chrome.com/docs/lighthouse/performance/redirects/).",
                            "score": 0,
                            "scoreDisplayMode": "metricSavings",
                            "displayValue": "Potential savings of 230 ms",
                            "details": {
                                "overallSavingsMs": 230,
                                "items": [
                                    {
                                        "wastedMs": 230,
                                        "url": "https://google.com/"
                                    },
                                    {
                                        "url": "https://www.google.com/",
                                        "wastedMs": 0
                                    }
                                ],
                                "headings": [
                                    {
                                        "label": "URL",
                                        "key": "url",
                                        "valueType": "url"
                                    },
                                    {
                                        "valueType": "timespanMs",
                                        "label": "Time Spent",
                                        "key": "wastedMs"
                                    }
                                ],
                                "type": "opportunity"
                            },
                            "numericValue": 230,
                            "numericUnit": "millisecond"
                        },
                        "offscreen-content-hidden": {
                            "id": "offscreen-content-hidden",
                            "title": "Offscreen content is hidden from assistive technology",
                            "description": "Offscreen content is hidden with display: none or aria-hidden=true. [Learn how to properly hide offscreen content](https://developer.chrome.com/docs/lighthouse/accessibility/offscreen-content-hidden/).",
                            "score": null,
                            "scoreDisplayMode": "manual"
                        },
                        "input-image-alt": {
                            "id": "input-image-alt",
                            "title": "`<input type=\"image\">` elements have `[alt]` text",
                            "description": "When an image is being used as an `<input>` button, providing alternative text can help screen reader users understand the purpose of the button. [Learn about input image alt text](https://dequeuniversity.com/rules/axe/4.8/input-image-alt).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "bootup-time": {
                            "id": "bootup-time",
                            "title": "JavaScript execution time",
                            "description": "Consider reducing the time spent parsing, compiling, and executing JS. You may find delivering smaller JS payloads helps with this. [Learn how to reduce Javascript execution time](https://developer.chrome.com/docs/lighthouse/performance/bootup-time/).",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "displayValue": "0.6 s",
                            "details": {
                                "type": "table",
                                "summary": {
                                    "wastedMs": 588.5869999999995
                                },
                                "headings": [
                                    {
                                        "label": "URL",
                                        "valueType": "url",
                                        "key": "url"
                                    },
                                    {
                                        "key": "total",
                                        "granularity": 1,
                                        "valueType": "ms",
                                        "label": "Total CPU Time"
                                    },
                                    {
                                        "key": "scripting",
                                        "valueType": "ms",
                                        "granularity": 1,
                                        "label": "Script Evaluation"
                                    },
                                    {
                                        "key": "scriptParseCompile",
                                        "granularity": 1,
                                        "label": "Script Parse",
                                        "valueType": "ms"
                                    }
                                ],
                                "items": [
                                    {
                                        "scriptParseCompile": 19.062,
                                        "total": 288.8399999999997,
                                        "url": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/ed=1/dg=2/br=1/rs=ACT90oEcAGSwfSNPLyn9LHwQv0bYDA_7PQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf,FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe,KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=cdos,hsm,jsa,mb4ZUb,d,csi,cEt90b,SNUn3,qddgKe,sTsDMc,dtl0hd,eHDfl",
                                        "scripting": 236.44299999999967
                                    },
                                    {
                                        "scriptParseCompile": 10.52,
                                        "total": 244.84099999999995,
                                        "url": "https://www.google.com/xjs/_/js/k=xjs.hd.en.MlTHDnVjdsg.O/ck=xjs.hd.kc4QrUgb_z0.L.W.O/am=AAAAAAAAAAAAAAAAAAAAAABAAAAAgBBoIBwCsAECAACAARJAACAEK4AoFIgAMAAhCPBQPgAAExBYAhNACoFJAABoAqoAAgAAAAAAQDBADCDwgAAAAHQAoAAGIAhQAgQAAAAgD0BwgEEKAgAAAAAAAAAAAAggQRAuSKAggAAAAAAAAAAAAABAKk1UGAY/d=1/exm=SNUn3,cEt90b,cdos,csi,d,dtl0hd,eHDfl,hsm,jsa,mb4ZUb,qddgKe,sTsDMc/ed=1/dg=2/br=1/ujg=1/rs=ACT90oF3vFfvX5gc_bm8Oo_3bmN5vrrjbQ/ee=AfeaP:TkrAjf;Afksuc:wMx0R;BMxAGc:E5bFse;BgS6mb:fidj5d;BjwMce:cXX2Wb;CxXAWb:YyRLvc;DULqB:RKfG5c;Dkk6ge:wJqrrd;DpcR3d:zL72xf;EABSZ:MXZt9d;ESrPQc:mNTJvc;EVNhjf:pw70Gc;EmZ2Bf:zr1jrb;EnlcNd:WeHg4;Erl4fe:FloWmf;F9mqte:UoRcbe;Fmv9Nc:O1Tzwc;G0KhTb:LIaoZ;G6wU6e:hezEbd;GleZL:J1A7Od;HMDDWe:G8QUdb;IBADCc:RYquRb;IoGlCf:b5lhvb;IsdWVc:qzxzOb;JXS8fb:Qj0suc;JbMT3:M25sS;JsbNhc:Xd8iUd;KOxcK:OZqGte;KQzWid:ZMKkN;KcokUb:KiuZBf;KeeMUb:HiPxjc;KpRAue:Tia57b;LBgRLc:XVMNvd;LEikZe:byfTOb,lsjVmc;LsNahb:ucGLNb;Me32dd:MEeYgc;NPKaK:PVlQOd;NSEoX:lazG7b;Np8Qkd:Dpx6qc;Nyt6ic:jn2sGd;OgagBe:cNTe0;Oj465e:KG2eXe;OohIYe:mpEAQb;Pjplud:EEDORb,PoEs9b;Q1Ow7b:x5CSu;QGR0gd:Mlhmy;R4IIIb:QWfeKf;R9Ulx:CR7Ufe;RDNBlf:zPRCJb;SLtqO:Kh1xYe;SMDL4c:fTfGO,pnvXVc;SNUn3:ZwDk9d,x8cHvb;ShpF6e:N0pvGc;TxfV6d:YORN0b;U96pRd:FsR04;UDrY1c:eps46d;UVmjEd:EesRsb;UyG7Kb:wQd0G;V2HTTe:RolTY;VGRfx:VFqbr;VN6jIc:ddQyuf;VOcgDe:YquhTb;VsAqSb:PGf2Re;VxQ32b:k0XsBb;WCEKNd:I46Hvd;WDGyFe:jcVOxd;Wfmdue:g3MJlb;XUezZ:sa7lqb;YV5bee:IvPZ6d;ZMvdv:PHFPjb;ZWEUA:afR4Cf;a56pNe:JEfCwb;aAJE9c:WHW6Ef;aZ61od:arTwJ;bFZ6gf:RsDQqe;bcPXSc:gSZLJb;cEt90b:ws9Tlc;cFTWae:gT8qnd;coJ8e:KvoW8;dIoSBb:ZgGg9b;dLlj2:Qqt3Gf;daB6be:lMxGPd;dtl0hd:lLQWFe;eBAeSb:Ck63tb;eBZ5Nd:audvde;eHDfl:ofjVkb;eO3lse:nFClrf;fWLTFc:TVBJbf;g8nkx:U4MzKc;gaub4:TN6bMe;gtVSi:ekUOYd;h3MYod:cEt90b;hK67qb:QWEO5b;heHB1:sFczq;hjRo6e:F62sG;iFQyKf:QIhFr,vfuNJf;imqimf:jKGL2e;io8t5d:sgY6Zb;jY0zg:Q6tNgc;k2Qxcb:XY51pe;kCQyJ:ueyPK;kMFpHd:OTA3Ae;kbAm9d:MkHyGd;lkq0A:JyBE3e;nAFL3:NTMZac,s39S4;oGtAuc:sOXFj;oSUNyd:fTfGO,pnvXVc;oUlnpc:RagDlc;okUaUd:wItadb;pKJiXd:VCenhc;pNsl2d:j9Yuyc;pXdRYb:JKoKVe;pj82le:mg5CW;qZx2Fc:j0xrE;qaS3gd:yiLg6e;qavrXe:zQzcXe;qddgKe:d7YSfd,x4FYXe;rQSrae:C6D5Fc;sP4Vbe:VwDzFe;sTsDMc:kHVSUb;tH4IIe:Ymry6;tosKvd:ZCqP3;trZL0b:qY8PFe;uY49fb:COQbmf;uuQkY:u2V3ud;vGrMZ:lPJJ0c;vfVwPd:lcrkwe;w3bZCb:ZPGaIb;w4rSdf:XKiZ9;w9w86d:dt4g2b;wQlYve:aLUfP;wR5FRb:TtcOte;wV5Pjc:L8KGxe;whEZac:F4AmNb;xBbsrc:NEW1Qc;yGxLoc:FmAr0c;yxTchf:KUM7Z;z97YGf:oug9te;zOsCQe:Ko78Df;zaIgPb:Qtpxbd/m=B2qlPe,DhPYme,GU4Gab,MpJwZc,NzU6V,UUJqVe,Wo3n8,aa,abd,async,epYOx,ifl,ms4mZb,pHXghd,q0xTif,s39S4,sOXFj,sb_wiz,sf,sonic,spch?xjs=s1",
                                        "scripting": 178.02299999999994
                                    },
                                    {
                                        "total": 190.2960000000001,
                                        "url": "https://www.google.com/",
                                        "scripting": 56.762000000000086,
                                        "scriptParseCompile": 16.451999999999998
                                    },
                                    {
                                        "scripting": 71.32499999999989,
                                        "scriptParseCompile": 0,
                                        "total": 158.28599999999994,
                                        "url": "Unattributable"
                                    }
                                ],
                                "sortedBy": [
                                    "total"
                                ]
                            },
                            "numericValue": 588.5869999999995,
                            "numericUnit": "millisecond"
                        },
                        "modern-image-formats": {
                            "id": "modern-image-formats",
                            "title": "Serve images in next-gen formats",
                            "description": "Image formats like WebP and AVIF often provide better compression than PNG or JPEG, which means faster downloads and less data consumption. [Learn more about modern image formats](https://developer.chrome.com/docs/lighthouse/performance/uses-webp-images/).",
                            "score": 1,
                            "scoreDisplayMode": "metricSavings",
                            "details": {
                                "overallSavingsMs": 0,
                                "debugData": {
                                    "type": "debugdata",
                                    "metricSavings": {
                                        "FCP": 0,
                                        "LCP": 0
                                    }
                                },
                                "overallSavingsBytes": 0,
                                "headings": [],
                                "sortedBy": [
                                    "wastedBytes"
                                ],
                                "type": "opportunity",
                                "items": []
                            },
                            "warnings": [],
                            "numericValue": 0,
                            "numericUnit": "millisecond"
                        },
                        "performance-budget": {
                            "id": "performance-budget",
                            "title": "Performance budget",
                            "description": "Keep the quantity and size of network requests under the targets set by the provided performance budget. [Learn more about performance budgets](https://developers.google.com/web/tools/lighthouse/audits/budgets).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "aria-roles": {
                            "id": "aria-roles",
                            "title": "`[role]` values are valid",
                            "description": "ARIA roles must have valid values in order to perform their intended accessibility functions. [Learn more about valid ARIA roles](https://dequeuniversity.com/rules/axe/4.8/aria-roles).",
                            "score": 1,
                            "scoreDisplayMode": "binary",
                            "details": {
                                "headings": [],
                                "items": [],
                                "type": "table"
                            }
                        },
                        "cumulative-layout-shift": {
                            "id": "cumulative-layout-shift",
                            "title": "Cumulative Layout Shift",
                            "description": "Cumulative Layout Shift measures the movement of visible elements within the viewport. [Learn more about the Cumulative Layout Shift metric](https://web.dev/articles/cls).",
                            "score": 0.98,
                            "scoreDisplayMode": "numeric",
                            "displayValue": "0.057",
                            "details": {
                                "type": "debugdata",
                                "items": [
                                    {
                                        "cumulativeLayoutShiftMainFrame": 0.056904628389224526
                                    }
                                ]
                            },
                            "numericValue": 0.056904628389224526,
                            "numericUnit": "unitless"
                        },
                        "unused-css-rules": {
                            "id": "unused-css-rules",
                            "title": "Reduce unused CSS",
                            "description": "Reduce unused rules from stylesheets and defer CSS not used for above-the-fold content to decrease bytes consumed by network activity. [Learn how to reduce unused CSS](https://developer.chrome.com/docs/lighthouse/performance/unused-css-rules/).",
                            "score": 0.5,
                            "scoreDisplayMode": "metricSavings",
                            "displayValue": "Potential savings of 16 KiB",
                            "details": {
                                "debugData": {
                                    "type": "debugdata",
                                    "metricSavings": {
                                        "LCP": 0,
                                        "FCP": 0
                                    }
                                },
                                "type": "opportunity",
                                "sortedBy": [
                                    "wastedBytes"
                                ],
                                "headings": [
                                    {
                                        "key": "url",
                                        "label": "URL",
                                        "valueType": "url"
                                    },
                                    {
                                        "label": "Transfer Size",
                                        "key": "totalBytes",
                                        "valueType": "bytes"
                                    },
                                    {
                                        "valueType": "bytes",
                                        "label": "Potential Savings",
                                        "key": "wastedBytes"
                                    }
                                ],
                                "overallSavingsMs": 0,
                                "overallSavingsBytes": 16211,
                                "items": [
                                    {
                                        "wastedPercent": 94.00076233406804,
                                        "wastedBytes": 16211,
                                        "totalBytes": 17246,
                                        "url": "h1,ol,ul,li,button{margin:0;padding:0} …"
                                    }
                                ]
                            },
                            "numericValue": 0,
                            "numericUnit": "millisecond"
                        },
                        "js-libraries": {
                            "id": "js-libraries",
                            "title": "Detected JavaScript libraries",
                            "description": "All front-end JavaScript libraries detected on the page. [Learn more about this JavaScript library detection diagnostic audit](https://developer.chrome.com/docs/lighthouse/best-practices/js-libraries/).",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "details": {
                                "debugData": {
                                    "stacks": [
                                        {
                                            "id": "boq"
                                        },
                                        {
                                            "id": "wiz"
                                        }
                                    ],
                                    "type": "debugdata"
                                },
                                "items": [
                                    {
                                        "name": "Boq"
                                    },
                                    {
                                        "name": "Wiz"
                                    }
                                ],
                                "headings": [
                                    {
                                        "label": "Name",
                                        "key": "name",
                                        "valueType": "text"
                                    },
                                    {
                                        "valueType": "text",
                                        "label": "Version",
                                        "key": "version"
                                    }
                                ],
                                "type": "table"
                            }
                        },
                        "aria-treeitem-name": {
                            "id": "aria-treeitem-name",
                            "title": "ARIA `treeitem` elements have accessible names",
                            "description": "When a `treeitem` element doesn't have an accessible name, screen readers announce it with a generic name, making it unusable for users who rely on screen readers. [Learn more about labeling `treeitem` elements](https://dequeuniversity.com/rules/axe/4.8/aria-treeitem-name).",
                            "score": null,
                            "scoreDisplayMode": "notApplicable"
                        },
                        "max-potential-fid": {
                            "id": "max-potential-fid",
                            "title": "Max Potential First Input Delay",
                            "description": "The maximum potential First Input Delay that your users could experience is the duration of the longest task. [Learn more about the Maximum Potential First Input Delay metric](https://developer.chrome.com/docs/lighthouse/performance/lighthouse-max-potential-fid/).",
                            "score": 0.52,
                            "scoreDisplayMode": "numeric",
                            "displayValue": "240 ms",
                            "details": {
                                "observedMaxBlockingLoaf": {
                                    "args": {
                                        "data": {
                                            "styleAndLayoutDuration": 1.107,
                                            "renderDuration": 1.127,
                                            "numScripts": 1,
                                            "duration": 244.873,
                                            "blockingDuration": 193.328
                                        }
                                    },
                                    "tid": 66,
                                    "scope": "devtools.timeline",
                                    "id2": {
                                        "local": "0x340100236068"
                                    },
                                    "ph": "b",
                                    "cat": "devtools.timeline",
                                    "ts": 763798693034,
                                    "name": "LongAnimationFrame",
                                    "pid": 66
                                },
                                "observedMaxDurationLoaf": {
                                    "id2": {
                                        "local": "0x340100236068"
                                    },
                                    "ph": "b",
                                    "pid": 66,
                                    "ts": 763798693034,
                                    "args": {
                                        "data": {
                                            "blockingDuration": 193.328,
                                            "numScripts": 1,
                                            "renderDuration": 1.127,
                                            "styleAndLayoutDuration": 1.107,
                                            "duration": 244.873
                                        }
                                    },
                                    "scope": "devtools.timeline",
                                    "tid": 66,
                                    "cat": "devtools.timeline",
                                    "name": "LongAnimationFrame"
                                },
                                "observedLoafs": [
                                    {
                                        "duration": 54.499,
                                        "startTime": 1266.516,
                                        "blockingDuration": 0
                                    },
                                    {
                                        "duration": 244.873,
                                        "blockingDuration": 193.328,
                                        "startTime": 1343.314
                                    },
                                    {
                                        "startTime": 1590.953,
                                        "blockingDuration": 0,
                                        "duration": 72.317
                                    },
                                    {
                                        "startTime": 1686.803,
                                        "duration": 84.812,
                                        "blockingDuration": 34.812
                                    },
                                    {
                                        "duration": 199.399,
                                        "blockingDuration": 117.18,
                                        "startTime": 1802.093
                                    }
                                ],
                                "type": "debugdata"
                            },
                            "numericValue": 242,
                            "numericUnit": "millisecond"
                        },
                        "user-timings": {
                            "id": "user-timings",
                            "title": "User Timing marks and measures",
                            "description": "Consider instrumenting your app with the User Timing API to measure your app's real-world performance during key user experiences. [Learn more about User Timing marks](https://developer.chrome.com/docs/lighthouse/performance/user-timings/).",
                            "score": null,
                            "scoreDisplayMode": "informative",
                            "displayValue": "16 user timings",
                            "details": {
                                "headings": [
                                    {
                                        "key": "name",
                                        "valueType": "text",
                                        "label": "Name"
                                    },
                                    {
                                        "valueType": "text",
                                        "key": "timingType",
                                        "label": "Type"
                                    },
                                    {
                                        "key": "startTime",
                                        "granularity": 0.01,
                                        "label": "Start Time",
                                        "valueType": "ms"
                                    },
                                    {
                                        "valueType": "ms",
                                        "key": "duration",
                                        "label": "Duration",
                                        "granularity": 0.01
                                    }
                                ],
                                "items": [
                                    {
                                        "duration": 0.614,
                                        "name": "kDcP9b",
                                        "timingType": "Measure",
                                        "startTime": 1506.585
                                    },
                                    {
                                        "duration": 0.205,
                                        "name": "kDcP9b",
                                        "startTime": 1542.394,
                                        "timingType": "Measure"
                                    },
                                    {
                                        "timingType": "Measure",
                                        "duration": 0.705,
                                        "startTime": 1542.394,
                                        "name": "kDcP9b"
                                    },
                                    {
                                        "timingType": "Measure",
                                        "name": "fcbyXe",
                                        "duration": 5.343,
                                        "startTime": 1591.657
                                    },
                                    {
                                        "timingType": "Measure",
                                        "name": "kDcP9b",
                                        "duration": 2.131,
                                        "startTime": 1594.369
                                    },
                                    {
                                        "timingType": "Measure",
                                        "name": "fcbyXe",
                                        "startTime": 1664.736,
                                        "duration": 1.163
                                    },
                                    {
                                        "duration": 1.315,
                                        "timingType": "Measure",
                                        "name": "fcbyXe",
                                        "startTime": 2133.384
                                    },
                                    {
                                        "timingType": "Mark",
                                        "startTime": 1113,
                                        "name": "SearchAFTStart"
                                    },
                                    {
                                        "timingType": "Mark",
                                        "startTime": 1330,
                                        "name": "trigger:SearchAFTEnd"
                                    },
                                    {
                                        "name": "O7jPNb",
                                        "timingType": "Mark",
                                        "startTime": 1497.017
                                    },
                                    {
                                        "name": "O7jPNb",
                                        "startTime": 1506.585,
                                        "timingType": "Mark"
                                    },
                                    {
                                        "timingType": "Mark",
                                        "startTime": 1542.394,
                                        "name": "O7jPNb"
                                    },
                                    {
                                        "startTime": 1591.657,
                                        "name": "triggerRender_0",
                                        "timingType": "Mark"
                                    },
                                    {
                                        "startTime": 1594.369,
                                        "name": "O7jPNb",
                                        "timingType": "Mark"
                                    },
                                    {
                                        "timingType": "Mark",
                                        "startTime": 1664.736,
                                        "name": "triggerRender_1"
                                    },
                                    {
                                        "timingType": "Mark",
                                        "startTime": 2133.384,
                                        "name": "triggerRender_2"
                                    }
                                ],
                                "type": "table"
                            }
                        }
                    },
                    "categories": {
                        "performance": {
                            "id": "performance",
                            "title": "Performance",
                            "score": 0.89,
                            "auditRefs": [
                                {
                                    "id": "first-contentful-paint",
                                    "weight": 10,
                                    "group": "metrics",
                                    "acronym": "FCP",
                                    "relevantAudits": [
                                        "server-response-time",
                                        "render-blocking-resources",
                                        "redirects",
                                        "critical-request-chains",
                                        "uses-text-compression",
                                        "uses-rel-preconnect",
                                        "uses-rel-preload",
                                        "font-display",
                                        "unminified-javascript",
                                        "unminified-css",
                                        "unused-css-rules"
                                    ]
                                },
                                {
                                    "id": "largest-contentful-paint",
                                    "weight": 25,
                                    "group": "metrics",
                                    "acronym": "LCP",
                                    "relevantAudits": [
                                        "server-response-time",
                                        "render-blocking-resources",
                                        "redirects",
                                        "critical-request-chains",
                                        "uses-text-compression",
                                        "uses-rel-preconnect",
                                        "uses-rel-preload",
                                        "font-display",
                                        "unminified-javascript",
                                        "unminified-css",
                                        "unused-css-rules",
                                        "largest-contentful-paint-element",
                                        "prioritize-lcp-image",
                                        "unused-javascript",
                                        "efficient-animated-content",
                                        "total-byte-weight",
                                        "lcp-lazy-loaded"
                                    ]
                                },
                                {
                                    "id": "total-blocking-time",
                                    "weight": 30,
                                    "group": "metrics",
                                    "acronym": "TBT",
                                    "relevantAudits": [
                                        "long-tasks",
                                        "third-party-summary",
                                        "third-party-facades",
                                        "bootup-time",
                                        "mainthread-work-breakdown",
                                        "dom-size",
                                        "duplicated-javascript",
                                        "legacy-javascript",
                                        "viewport"
                                    ]
                                },
                                {
                                    "id": "cumulative-layout-shift",
                                    "weight": 25,
                                    "group": "metrics",
                                    "acronym": "CLS",
                                    "relevantAudits": [
                                        "layout-shift-elements",
                                        "non-composited-animations",
                                        "unsized-images"
                                    ]
                                },
                                {
                                    "id": "speed-index",
                                    "weight": 10,
                                    "group": "metrics",
                                    "acronym": "SI"
                                },
                                {
                                    "id": "interactive",
                                    "weight": 0,
                                    "group": "hidden",
                                    "acronym": "TTI"
                                },
                                {
                                    "id": "max-potential-fid",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "first-meaningful-paint",
                                    "weight": 0,
                                    "group": "hidden",
                                    "acronym": "FMP"
                                },
                                {
                                    "id": "render-blocking-resources",
                                    "weight": 0
                                },
                                {
                                    "id": "uses-responsive-images",
                                    "weight": 0
                                },
                                {
                                    "id": "offscreen-images",
                                    "weight": 0
                                },
                                {
                                    "id": "unminified-css",
                                    "weight": 0
                                },
                                {
                                    "id": "unminified-javascript",
                                    "weight": 0
                                },
                                {
                                    "id": "unused-css-rules",
                                    "weight": 0
                                },
                                {
                                    "id": "unused-javascript",
                                    "weight": 0
                                },
                                {
                                    "id": "uses-optimized-images",
                                    "weight": 0
                                },
                                {
                                    "id": "modern-image-formats",
                                    "weight": 0
                                },
                                {
                                    "id": "uses-text-compression",
                                    "weight": 0
                                },
                                {
                                    "id": "uses-rel-preconnect",
                                    "weight": 0
                                },
                                {
                                    "id": "server-response-time",
                                    "weight": 0
                                },
                                {
                                    "id": "redirects",
                                    "weight": 0
                                },
                                {
                                    "id": "uses-rel-preload",
                                    "weight": 0
                                },
                                {
                                    "id": "efficient-animated-content",
                                    "weight": 0
                                },
                                {
                                    "id": "duplicated-javascript",
                                    "weight": 0
                                },
                                {
                                    "id": "legacy-javascript",
                                    "weight": 0
                                },
                                {
                                    "id": "prioritize-lcp-image",
                                    "weight": 0
                                },
                                {
                                    "id": "total-byte-weight",
                                    "weight": 0
                                },
                                {
                                    "id": "uses-long-cache-ttl",
                                    "weight": 0
                                },
                                {
                                    "id": "dom-size",
                                    "weight": 0
                                },
                                {
                                    "id": "critical-request-chains",
                                    "weight": 0
                                },
                                {
                                    "id": "user-timings",
                                    "weight": 0
                                },
                                {
                                    "id": "bootup-time",
                                    "weight": 0
                                },
                                {
                                    "id": "mainthread-work-breakdown",
                                    "weight": 0
                                },
                                {
                                    "id": "font-display",
                                    "weight": 0
                                },
                                {
                                    "id": "third-party-summary",
                                    "weight": 0
                                },
                                {
                                    "id": "third-party-facades",
                                    "weight": 0
                                },
                                {
                                    "id": "largest-contentful-paint-element",
                                    "weight": 0
                                },
                                {
                                    "id": "lcp-lazy-loaded",
                                    "weight": 0
                                },
                                {
                                    "id": "layout-shift-elements",
                                    "weight": 0
                                },
                                {
                                    "id": "uses-passive-event-listeners",
                                    "weight": 0
                                },
                                {
                                    "id": "no-document-write",
                                    "weight": 0
                                },
                                {
                                    "id": "long-tasks",
                                    "weight": 0
                                },
                                {
                                    "id": "non-composited-animations",
                                    "weight": 0
                                },
                                {
                                    "id": "unsized-images",
                                    "weight": 0
                                },
                                {
                                    "id": "viewport",
                                    "weight": 0
                                },
                                {
                                    "id": "performance-budget",
                                    "weight": 0,
                                    "group": "budgets"
                                },
                                {
                                    "id": "timing-budget",
                                    "weight": 0,
                                    "group": "budgets"
                                },
                                {
                                    "id": "network-requests",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "network-rtt",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "network-server-latency",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "main-thread-tasks",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "diagnostics",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "metrics",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "screenshot-thumbnails",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "final-screenshot",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "script-treemap-data",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "resource-summary",
                                    "weight": 0,
                                    "group": "hidden"
                                }
                            ]
                        },
                        "accessibility": {
                            "id": "accessibility",
                            "title": "Accessibility",
                            "description": "These checks highlight opportunities to [improve the accessibility of your web app](https://developer.chrome.com/docs/lighthouse/accessibility/). Automatic detection can only detect a subset of issues and does not guarantee the accessibility of your web app, so [manual testing](https://web.dev/articles/how-to-review) is also encouraged.",
                            "score": 0.92,
                            "manualDescription": "These items address areas which an automated testing tool cannot cover. Learn more in our guide on [conducting an accessibility review](https://web.dev/articles/how-to-review).",
                            "auditRefs": [
                                {
                                    "id": "accesskeys",
                                    "weight": 0,
                                    "group": "a11y-navigation"
                                },
                                {
                                    "id": "aria-allowed-attr",
                                    "weight": 10,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-allowed-role",
                                    "weight": 1,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-command-name",
                                    "weight": 0,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-dialog-name",
                                    "weight": 7,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-hidden-body",
                                    "weight": 10,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-hidden-focus",
                                    "weight": 7,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-input-field-name",
                                    "weight": 0,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-meter-name",
                                    "weight": 0,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-progressbar-name",
                                    "weight": 0,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-required-attr",
                                    "weight": 10,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-required-children",
                                    "weight": 0,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-required-parent",
                                    "weight": 0,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-roles",
                                    "weight": 7,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-text",
                                    "weight": 0,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-toggle-field-name",
                                    "weight": 0,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-tooltip-name",
                                    "weight": 0,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-treeitem-name",
                                    "weight": 0,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-valid-attr-value",
                                    "weight": 10,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "aria-valid-attr",
                                    "weight": 10,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "button-name",
                                    "weight": 10,
                                    "group": "a11y-names-labels"
                                },
                                {
                                    "id": "bypass",
                                    "weight": 0,
                                    "group": "a11y-navigation"
                                },
                                {
                                    "id": "color-contrast",
                                    "weight": 7,
                                    "group": "a11y-color-contrast"
                                },
                                {
                                    "id": "definition-list",
                                    "weight": 0,
                                    "group": "a11y-tables-lists"
                                },
                                {
                                    "id": "dlitem",
                                    "weight": 0,
                                    "group": "a11y-tables-lists"
                                },
                                {
                                    "id": "document-title",
                                    "weight": 7,
                                    "group": "a11y-names-labels"
                                },
                                {
                                    "id": "duplicate-id-active",
                                    "weight": 7,
                                    "group": "a11y-navigation"
                                },
                                {
                                    "id": "duplicate-id-aria",
                                    "weight": 0,
                                    "group": "a11y-aria"
                                },
                                {
                                    "id": "form-field-multiple-labels",
                                    "weight": 0,
                                    "group": "a11y-names-labels"
                                },
                                {
                                    "id": "frame-title",
                                    "weight": 0,
                                    "group": "a11y-names-labels"
                                },
                                {
                                    "id": "heading-order",
                                    "weight": 3,
                                    "group": "a11y-navigation"
                                },
                                {
                                    "id": "html-has-lang",
                                    "weight": 7,
                                    "group": "a11y-language"
                                },
                                {
                                    "id": "html-lang-valid",
                                    "weight": 7,
                                    "group": "a11y-language"
                                },
                                {
                                    "id": "html-xml-lang-mismatch",
                                    "weight": 0,
                                    "group": "a11y-language"
                                },
                                {
                                    "id": "image-alt",
                                    "weight": 10,
                                    "group": "a11y-names-labels"
                                },
                                {
                                    "id": "image-redundant-alt",
                                    "weight": 1,
                                    "group": "a11y-names-labels"
                                },
                                {
                                    "id": "input-button-name",
                                    "weight": 0,
                                    "group": "a11y-names-labels"
                                },
                                {
                                    "id": "input-image-alt",
                                    "weight": 0,
                                    "group": "a11y-names-labels"
                                },
                                {
                                    "id": "label",
                                    "weight": 0,
                                    "group": "a11y-names-labels"
                                },
                                {
                                    "id": "link-in-text-block",
                                    "weight": 7,
                                    "group": "a11y-color-contrast"
                                },
                                {
                                    "id": "link-name",
                                    "weight": 7,
                                    "group": "a11y-names-labels"
                                },
                                {
                                    "id": "list",
                                    "weight": 7,
                                    "group": "a11y-tables-lists"
                                },
                                {
                                    "id": "listitem",
                                    "weight": 7,
                                    "group": "a11y-tables-lists"
                                },
                                {
                                    "id": "meta-refresh",
                                    "weight": 0,
                                    "group": "a11y-best-practices"
                                },
                                {
                                    "id": "meta-viewport",
                                    "weight": 0,
                                    "group": "a11y-best-practices"
                                },
                                {
                                    "id": "object-alt",
                                    "weight": 0,
                                    "group": "a11y-names-labels"
                                },
                                {
                                    "id": "select-name",
                                    "weight": 0,
                                    "group": "a11y-names-labels"
                                },
                                {
                                    "id": "skip-link",
                                    "weight": 0,
                                    "group": "a11y-names-labels"
                                },
                                {
                                    "id": "tabindex",
                                    "weight": 7,
                                    "group": "a11y-navigation"
                                },
                                {
                                    "id": "table-duplicate-name",
                                    "weight": 0,
                                    "group": "a11y-tables-lists"
                                },
                                {
                                    "id": "td-headers-attr",
                                    "weight": 0,
                                    "group": "a11y-tables-lists"
                                },
                                {
                                    "id": "th-has-data-cells",
                                    "weight": 0,
                                    "group": "a11y-tables-lists"
                                },
                                {
                                    "id": "valid-lang",
                                    "weight": 0,
                                    "group": "a11y-language"
                                },
                                {
                                    "id": "video-caption",
                                    "weight": 0,
                                    "group": "a11y-audio-video"
                                },
                                {
                                    "id": "focusable-controls",
                                    "weight": 0
                                },
                                {
                                    "id": "interactive-element-affordance",
                                    "weight": 0
                                },
                                {
                                    "id": "logical-tab-order",
                                    "weight": 0
                                },
                                {
                                    "id": "visual-order-follows-dom",
                                    "weight": 0
                                },
                                {
                                    "id": "focus-traps",
                                    "weight": 0
                                },
                                {
                                    "id": "managed-focus",
                                    "weight": 0
                                },
                                {
                                    "id": "use-landmarks",
                                    "weight": 0
                                },
                                {
                                    "id": "offscreen-content-hidden",
                                    "weight": 0
                                },
                                {
                                    "id": "custom-controls-labels",
                                    "weight": 0
                                },
                                {
                                    "id": "custom-controls-roles",
                                    "weight": 0
                                },
                                {
                                    "id": "empty-heading",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "identical-links-same-purpose",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "landmark-one-main",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "target-size",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "label-content-name-mismatch",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "table-fake-caption",
                                    "weight": 0,
                                    "group": "hidden"
                                },
                                {
                                    "id": "td-has-header",
                                    "weight": 0,
                                    "group": "hidden"
                                }
                            ]
                        },
                        "best-practices": {
                            "id": "best-practices",
                            "title": "Best Practices",
                            "score": 0.96,
                            "auditRefs": [
                                {
                                    "id": "is-on-https",
                                    "weight": 5,
                                    "group": "best-practices-trust-safety"
                                },
                                {
                                    "id": "geolocation-on-start",
                                    "weight": 1,
                                    "group": "best-practices-trust-safety"
                                },
                                {
                                    "id": "notification-on-start",
                                    "weight": 1,
                                    "group": "best-practices-trust-safety"
                                },
                                {
                                    "id": "csp-xss",
                                    "weight": 0,
                                    "group": "best-practices-trust-safety"
                                },
                                {
                                    "id": "paste-preventing-inputs",
                                    "weight": 3,
                                    "group": "best-practices-ux"
                                },
                                {
                                    "id": "image-aspect-ratio",
                                    "weight": 1,
                                    "group": "best-practices-ux"
                                },
                                {
                                    "id": "image-size-responsive",
                                    "weight": 1,
                                    "group": "best-practices-ux"
                                },
                                {
                                    "id": "preload-fonts",
                                    "weight": 0,
                                    "group": "best-practices-ux"
                                },
                                {
                                    "id": "doctype",
                                    "weight": 1,
                                    "group": "best-practices-browser-compat"
                                },
                                {
                                    "id": "charset",
                                    "weight": 1,
                                    "group": "best-practices-browser-compat"
                                },
                                {
                                    "id": "no-unload-listeners",
                                    "weight": 1,
                                    "group": "best-practices-general"
                                },
                                {
                                    "id": "js-libraries",
                                    "weight": 0,
                                    "group": "best-practices-general"
                                },
                                {
                                    "id": "deprecations",
                                    "weight": 5,
                                    "group": "best-practices-general"
                                },
                                {
                                    "id": "third-party-cookies",
                                    "weight": 5,
                                    "group": "best-practices-general"
                                },
                                {
                                    "id": "errors-in-console",
                                    "weight": 1,
                                    "group": "best-practices-general"
                                },
                                {
                                    "id": "valid-source-maps",
                                    "weight": 0,
                                    "group": "best-practices-general"
                                },
                                {
                                    "id": "inspector-issues",
                                    "weight": 1,
                                    "group": "best-practices-general"
                                }
                            ]
                        },
                        "seo": {
                            "id": "seo",
                            "title": "SEO",
                            "description": "These checks ensure that your page is following basic search engine optimization advice. There are many additional factors Lighthouse does not score here that may affect your search ranking, including performance on [Core Web Vitals](https://web.dev/explore/vitals). [Learn more about Google Search Essentials](https://support.google.com/webmasters/answer/35769).",
                            "score": 0.73,
                            "manualDescription": "Run these additional validators on your site to check additional SEO best practices.",
                            "auditRefs": [
                                {
                                    "id": "viewport",
                                    "weight": 1,
                                    "group": "seo-mobile"
                                },
                                {
                                    "id": "document-title",
                                    "weight": 1,
                                    "group": "seo-content"
                                },
                                {
                                    "id": "meta-description",
                                    "weight": 1,
                                    "group": "seo-content"
                                },
                                {
                                    "id": "http-status-code",
                                    "weight": 1,
                                    "group": "seo-crawl"
                                },
                                {
                                    "id": "link-text",
                                    "weight": 1,
                                    "group": "seo-content"
                                },
                                {
                                    "id": "crawlable-anchors",
                                    "weight": 1,
                                    "group": "seo-crawl"
                                },
                                {
                                    "id": "is-crawlable",
                                    "weight": 1,
                                    "group": "seo-crawl"
                                },
                                {
                                    "id": "robots-txt",
                                    "weight": 1,
                                    "group": "seo-crawl"
                                },
                                {
                                    "id": "image-alt",
                                    "weight": 1,
                                    "group": "seo-content"
                                },
                                {
                                    "id": "hreflang",
                                    "weight": 1,
                                    "group": "seo-content"
                                },
                                {
                                    "id": "canonical",
                                    "weight": 0,
                                    "group": "seo-content"
                                },
                                {
                                    "id": "font-size",
                                    "weight": 0,
                                    "group": "seo-mobile"
                                },
                                {
                                    "id": "plugins",
                                    "weight": 1,
                                    "group": "seo-content"
                                },
                                {
                                    "id": "tap-targets",
                                    "weight": 0,
                                    "group": "seo-mobile"
                                },
                                {
                                    "id": "structured-data",
                                    "weight": 0
                                }
                            ]
                        }
                    },
                    "categoryGroups": {
                        "a11y-language": {
                            "title": "Internationalization and localization",
                            "description": "These are opportunities to improve the interpretation of your content by users in different locales."
                        },
                        "best-practices-general": {
                            "title": "General"
                        },
                        "a11y-aria": {
                            "title": "ARIA",
                            "description": "These are opportunities to improve the usage of ARIA in your application which may enhance the experience for users of assistive technology, like a screen reader."
                        },
                        "best-practices-browser-compat": {
                            "title": "Browser Compatibility"
                        },
                        "seo-content": {
                            "title": "Content Best Practices",
                            "description": "Format your HTML in a way that enables crawlers to better understand your app’s content."
                        },
                        "a11y-audio-video": {
                            "title": "Audio and video",
                            "description": "These are opportunities to provide alternative content for audio and video. This may improve the experience for users with hearing or vision impairments."
                        },
                        "a11y-tables-lists": {
                            "title": "Tables and lists",
                            "description": "These are opportunities to improve the experience of reading tabular or list data using assistive technology, like a screen reader."
                        },
                        "a11y-names-labels": {
                            "title": "Names and labels",
                            "description": "These are opportunities to improve the semantics of the controls in your application. This may enhance the experience for users of assistive technology, like a screen reader."
                        },
                        "a11y-color-contrast": {
                            "title": "Contrast",
                            "description": "These are opportunities to improve the legibility of your content."
                        },
                        "diagnostics": {
                            "title": "Diagnostics",
                            "description": "More information about the performance of your application. These numbers don't [directly affect](https://developer.chrome.com/docs/lighthouse/performance/performance-scoring/) the Performance score."
                        },
                        "pwa-optimized": {
                            "title": "PWA Optimized"
                        },
                        "best-practices-ux": {
                            "title": "User Experience"
                        },
                        "budgets": {
                            "title": "Budgets",
                            "description": "Performance budgets set standards for the performance of your site."
                        },
                        "seo-mobile": {
                            "title": "Mobile Friendly",
                            "description": "Make sure your pages are mobile friendly so users don’t have to pinch or zoom in order to read the content pages. [Learn how to make pages mobile-friendly](https://developers.google.com/search/mobile-sites/)."
                        },
                        "a11y-navigation": {
                            "title": "Navigation",
                            "description": "These are opportunities to improve keyboard navigation in your application."
                        },
                        "metrics": {
                            "title": "Metrics"
                        },
                        "pwa-installable": {
                            "title": "Installable"
                        },
                        "load-opportunities": {
                            "title": "Opportunities",
                            "description": "These suggestions can help your page load faster. They don't [directly affect](https://developer.chrome.com/docs/lighthouse/performance/performance-scoring/) the Performance score."
                        },
                        "a11y-best-practices": {
                            "title": "Best practices",
                            "description": "These items highlight common accessibility best practices."
                        },
                        "seo-crawl": {
                            "title": "Crawling and Indexing",
                            "description": "To appear in search results, crawlers need access to your app."
                        },
                        "best-practices-trust-safety": {
                            "title": "Trust and Safety"
                        }
                    },
                    "timing": {
                        "total": 13470.800000000001
                    },
                    "i18n": {
                        "rendererFormattedStrings": {
                            "varianceDisclaimer": "Values are estimated and may vary. The [performance score is calculated](https://developer.chrome.com/docs/lighthouse/performance/performance-scoring/) directly from these metrics.",
                            "opportunityResourceColumnLabel": "Opportunity",
                            "opportunitySavingsColumnLabel": "Estimated Savings",
                            "errorMissingAuditInfo": "Report error: no audit information",
                            "errorLabel": "Error!",
                            "warningHeader": "Warnings: ",
                            "passedAuditsGroupTitle": "Passed audits",
                            "notApplicableAuditsGroupTitle": "Not applicable",
                            "manualAuditsGroupTitle": "Additional items to manually check",
                            "toplevelWarningsMessage": "There were issues affecting this run of Lighthouse:",
                            "crcLongestDurationLabel": "Maximum critical path latency:",
                            "crcInitialNavigation": "Initial Navigation",
                            "lsPerformanceCategoryDescription": "[Lighthouse](https://developers.google.com/web/tools/lighthouse/) analysis of the current page on an emulated mobile network. Values are estimated and may vary.",
                            "labDataTitle": "Lab Data",
                            "warningAuditsGroupTitle": "Passed audits but with warnings",
                            "snippetExpandButtonLabel": "Expand snippet",
                            "snippetCollapseButtonLabel": "Collapse snippet",
                            "thirdPartyResourcesLabel": "Show 3rd-party resources",
                            "runtimeDesktopEmulation": "Emulated Desktop",
                            "runtimeMobileEmulation": "Emulated Moto G Power",
                            "runtimeNoEmulation": "No emulation",
                            "runtimeSettingsBenchmark": "Unthrottled CPU/Memory Power",
                            "runtimeSettingsCPUThrottling": "CPU throttling",
                            "runtimeSettingsDevice": "Device",
                            "runtimeSettingsNetworkThrottling": "Network throttling",
                            "runtimeSettingsUANetwork": "User agent (network)",
                            "runtimeUnknown": "Unknown",
                            "dropdownCopyJSON": "Copy JSON",
                            "dropdownDarkTheme": "Toggle Dark Theme",
                            "dropdownPrintExpanded": "Print Expanded",
                            "dropdownPrintSummary": "Print Summary",
                            "dropdownSaveGist": "Save as Gist",
                            "dropdownSaveHTML": "Save as HTML",
                            "dropdownSaveJSON": "Save as JSON",
                            "dropdownViewer": "Open in Viewer",
                            "footerIssue": "File an issue",
                            "throttlingProvided": "Provided by environment",
                            "calculatorLink": "See calculator.",
                            "runtimeSettingsAxeVersion": "Axe version",
                            "viewTreemapLabel": "View Treemap",
                            "showRelevantAudits": "Show audits relevant to:"
                        }
                    },
                    "entities": [
                        {
                            "name": "google.com",
                            "isUnrecognized": true,
                            "origins": [
                                "https://google.com"
                            ]
                        },
                        {
                            "name": "Other Google APIs/SDKs",
                            "homepage": "https://developers.google.com/apis-explorer/#p/",
                            "category": "utility",
                            "isFirstParty": true,
                            "origins": [
                                "https://www.google.com",
                                "https://apis.google.com"
                            ]
                        },
                        {
                            "name": "Google Fonts",
                            "homepage": "https://fonts.google.com/",
                            "category": "cdn",
                            "origins": [
                                "https://fonts.gstatic.com"
                            ]
                        },
                        {
                            "name": "Google CDN",
                            "homepage": "https://developers.google.com/speed/libraries/",
                            "category": "cdn",
                            "origins": [
                                "https://www.gstatic.com"
                            ]
                        }
                    ],
                    "fullPageScreenshot": {
                        "screenshot": {
                            "width": 1350,
                            "height": 940,
                            "data": "data:image/webp;base64,UklGRniwAABXRUJQVlA4WAoAAAAgAAAARQUAqwMASUNDUMgBAAAAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADZWUDggiq4AAFBZA50BKkYFrAM/EYi7V6wpP66kMblb8CIJaW78fpwyzWQJjOKRfnZaiJQe9vn2nj6fFd8T0X7dfxgPXC87zpmPWM6LT1qP+Bkq/mb/mf5T2EeI37//Gfv55u/mn2f7jPYT/LcRfrH9x+33qd973+Xmf+Unkb8oP/r1BfbP/5/dLzdftB3MWt/9H0Bfbb7r///M1+c/aD1L/Yv9l7AP7c+lH/a8GH8H/0/3M+BH+pf5j9vfdq/2v///3vQl+s/93///+P/0/Ir+f//a/83dAGkw9u5eku2XRXmMPbuXpLtl0V5jD27l6S7ZdFeYw9u5eku2XRWz9ERtpND3WxE2VmGcLsBWXEhjB0kl4R3n2ElM7P7fe51VMV9KSV5jD27l6S7ZdFeYw9u5eku2XRXmMPbuXpLtjKdWUGYXq2dg+/BI1BuHImszKy3Ue5785FMkhhQfAtHmT8SM5PcxbAR4ackCoB852220Jld08QbMk+5jc+3b9t8H4NYsbaERPauhzIqQJXQ5kVIErocyKkCV0OZFSBK6HMipAldDmRUgSuhzIqOrY7y98/iTKg0LYnmGfdaReXMIIUFMh4zsB5ZCtEQ6bIfZpCvOgfbuXoug0rM40w9u5eku2XRXmMPbuXpLtl0V5jD27ngL8dbwhwufnN8IojmhloSIsnl2y6K8xh7Un9emhceTl+B/H2jAe3cvSXbLorzGHt3L0lzgp23JXT8QesmjTOFXl1lG6ay7ZdFeYw9u5eku2XRXmMPKcgeVWdq0pDQRbVJHsnZV8ZqrzGHt3L0l2y6K8xh7f5Jyi8wmfZPRBB9qdiwWtSSgMMKUReSIWwwpggswZmlSjtc1KZIbp6+JdoYedHGeFTTHuS8JXVMhO2EkaYe3cvSXbLorzGHt3L0ly7GIa3w0CntNFyumK2VAeku2XRXmMPbuXpLtl0T5WUyI03CwbhHAYk+wlcJE7ATNlDf0HKmDxiD8vSXbLorzGHt3L0l2y52VI1E12XRXmMPbuXpLtl0V5jIdpuc23ipE/pLV5Tq5eku2XRXmMPbuXpLtl0V4xHh/M4w9pgbxgapWGcWPzZ9cfIrbVM4LpXHdgXPvUIjr6S3SJ/jJUGtETd3k2KcEAR9EknHjLq0phFmyQJ8UucLvs96E87c9/+xLgtQkPt3L0ly7RdFeYw9u5eku2XRXmMPbuWNqMPbuXot8NbkNRGUYHumKveeGShQXGUR5kKsgzAqSjKuHLN624QlsGc4Rw7LDrl0TEQBpzP9iYngU+ZTDfyNdHMkLR9dFlOd38wjkjmAhNps8m1hGG/NsdTHrwcIL28niTloEzUIWPePCug1l9HHlHYa0j4U5sZEdXijF4ztY4HCZXxTJ4K3fKbEYOrD1Kls+EcNxjDYlDdYO2cuhNZvYUvLe73bvJVSTuozN5AST5XQqfAS+jmd5Y/W2VmzFNNy9JdstVwJ5dsuivMYe3cvSXbLorzFqhAfl6S7ZpEfAk0I7Xfl8CprSr2Xl1UAgfKNqGXsc2dTy7ZdFeX60+3cvSXbLorzGHt3L0l2y52UR4q8/UpSGqIx0Uj+RrNZdsuivMYe3cvSXbLorzGHlOrl6S7ZdFeYw9u5eku2XRXjEVFMsPgHM49VeV2uaCWrgWR9h0Rc/aap/PfYB9c5uv5i4VD+y1LOPVmBE2F1eupfSBo1deACKzakTJwr6xbC7QBfA5itCcTbkk5izFS0D8Uyq1nmN9bInYUx+uH1NEl2y6K8xh7dy9JdsuivGI8PbuXpLtl0V5jD27l6S7ZaraE4dIpCrVanSlUniEOieyz3TmY0w9u5eku2XRXmMPbuClHl2y6K8xh7dy9JdsuivMYW9EBsGxMfAbtohHi5z7+G+Bq26P+x/0v9AGIdOfxDurfsFG/J+PiH4tFMNZkPFAtqe8P0gSVqorIi76mSD/cMSHxPiA+9jdxMT3R3/lGqueW8+qMwTbKgBKtRT4zUED3IME1Ctb9jLlXwUxB+XpLtl0V5jD2pQy9JdsuivMYe3cvSXbLory/WWXAKIzzQVHSStIjysVXfHzxpafFGAdEIjabP9HSrCBmCv+63eSYHkNE8u2Wq4E8u2XRXmMPbuXpLtl0V5i1P0vr77MSFt+sGhxfcJ4ZbGatXuoymnTvcoRk3yE+zmDJiGMd6tvNdkQb0Nvw+/CSOmGQsFQRdJaTlXSJCtw34mnhyx1eGg3KVLI2aehw85VxUyQjPSQCFYOANVJytV20WKkExM3QW2QhjMC1pkngR9hcrDgof90uZkXKblMM8IU9d4/EHkbFDVWITVdcEIwYPPqUYxJ5tZ3Q/ZrSSnuBd6A3wnzR0DUVXYJiNk6cNCHHcqHBBrqnY3UGkizzc5ldiiswp6wpiD8vRiU+3cvSXbLorzGHt3L0l2y52VIg9S4kJiFl1ftUee8KtlsoxoKr02bjXk/kh6OW9RPLmeXp9Ry7RL+ivMYe3cvSXbLorzGHt3LxiWKW+5rQ0Qwwycg/4s/1AXk9voO01Xj00wESfSLmeQh4cXxtcG4dzwD9yF0yvhXBs3V6a/eClQ1b6W1waHOOhVU9UPGfSRJuRB/e4ZKN5kDxy1AyJME8nTPQ4G7E1RBOstzNyqPFHsCkBxhkGuyhC1/0TCH6gFY1K5UW8BhTXROvaAaz3+Ph2gszthZ2lFOCgusJ/e5kBRtdCRZLhZ1WUjWLDXTSBBy/8lQtqcCG19529RD4M2oVq4kDuS9z4QuTUhPG5KmDpqDYcFrOk964N1nZrQFBAjTD27l6S7ZdFeYw9u5eMS2QOP2YY57wJabx6jxCcKfyei3d94FlzLfMiupVfOVuuNzuCAqucl/aTPb6ROlxH07k/BRy7dknAfmHinYBvoiXlN4ROvNm9YqCadLCikRRpvJR0kPSCLlRAMXEBlGFxqIEe7CVlCbcu8je46uowpRYlNZoWLvxG7VgS6cJev5sDYeUp8rG8Hl/BoODHOs58FS/o9y3/R7eb9KpwcAY0YJRVB3Bv7u7ytYG5GPG7dRlZ3uKjyoW2sjVCehw8AyaICasRwe5kcHzT8iuzPIsDzM9ad5JutFdvW7l6S7ZdFeYw9u5eku2XRW3VGR/ByorAAYSAmogZC25rejcGBE4jxkMkPWkuDCayaiBkK6dlR5dsuivMYe3cvSXbLorzGFvRpIsBfPn+IVpoHCYsq3jEufOdqrFzuelKq0xdPz+6azWXbLorzGHlOrl6S7ZdFeYw9u5eku2XRXjEVFSTpwzVE8Sfz0qYHf12fkFfgoJU9Hs3DYsmVNCAhH/Cxu1bPGTRFUtwAqzZhkqLvGQLYyNNUsVQ1i8fzU4GomX6n6tHqPg9xRgZ+SPq0CPu/xeT2dgPLFEXfGFwXgHxsYHSLdt+gPeWSLSaQtuawRZTujvGK/BBY9EpOX8EuTMHMMIw2Z3EdSCnL9IuNZ6GpOeB59BXlxKkI7M1T7S6PtA5M/DVNUmrJQum6xJN2bTh2Hxeku2XRXl+tPt3L0l2y6K8xh7dy9JdsudlEJdAPijQRNiOg80YM4ccB67jfd2irV1uI7yFtyzde3jpYeXpLtl0Vt1Rh7dy9JdsuivMYe3cvSXbHMvRHUgnIOmbP7gmoQ7r9DXgU1+bxhGWuTRFvcC4kmOeNjz6zR6fj69MxBcuB2SzLotQ7cDhNBeRwBuxyh6ftRbtpZMVKODHDWkFhEU6flBFPD5yKgrVFYUpHPj3IH8L+hDqQCY1gRwT7dy9JdsuivMYe3cFKPLtl0V5jD27l6S7ZdFeYwt6c7poHaBPwFuYmr1UT5Fe4vMD87ZdFeYw9u5eku2XRMmsu2XRXmMPbuXpLtl0V5jDynL4EtNclReL4XgKdS436PRWvMUcQ7WppYe4c5prd3oC8U8WfyK3U5Wz2h4n7rADb1PYXKnoI4i5rEV5AiqhCyYZE0AqVDxgiCqExGyuSPXq32uDZ11y3zYYiomAMAEepJ5xHTIC5m3GOdKzz9EhlLg7yCNn6K8xh7dy9JdsuituqMPbuXpLtl0V5jD27l6S7Y5mgX3TxXyMM1rGRSdkunbX0INcxMS8vSXbLorzGHt0vJGmHt3L0l2y6K8xh7dy9JcuyIMcPUIQX6Qx6Dgw4QCU/5qp5xIEaSw0MCW1Fn25JeSjasiCFgZ8pA8NjYUSI7rYo/lzjcaw1gmxbZvJBD3G79EuNIy759EfXYooit7lGdh5DsI7GRb7tHgLIaGUWhHqHviQ3LKiByOHr6z6CprbTTEHbXqGG2234WGBNG4RELN5eyL/pAU7+Yrr0rdQJvNgg3oe/0i1zeku2XRXmLVCA/L0l2y6K8xh7dy9JdsuiZMennVBjlH+69K/FjuD65uxzi3O6Rlc5bAMbxrcvSXbLorzGHtShl6S7ZdFeYw9u5eku2XRXl+smO93lwuwSDpytk/xhYeaNr8k9UTbBMnb0SVSUm2ha8j5pygE+ImuB68gttiNOJ2yzqJhmBJggzbqocKvbPnZ/Z29Vgp1TB9HQn7Pf+LPqc0B7+mYELtobThB9jpiy4LXgRHbkWf6XeZaMLC/icwgiKjjzVqNZGrTDM9lVb2czAFgqH+1x4gge0RHAGnS74bKHB8/ZuJ40XadfT38zBTEH5eku2Wq4E8u2XRXmMPbuXpLtl0V5i1P4oo4a5DQJKOJH+v27aVe+jbfakv5Oo5Yn/ETOOSD3x8rekhVpoQpPLl5Ltl0TJrLtl0V5jD27l6S7ZdFeYw8pyX6PpzKEB07BB+wzbBUYFkjJ9T2kMNnA+V8iOpViJPg4yRN5+CTpG1gaoTax/aFrMrZdGpcG/hNyYrlgB5rYsBLULBIq+xIxRaNUoGW6djQGVU5FYM2EyGwQVzI7Mlv4eEQ+IjmxnTfnmY204BiXb+OY+PxREM4Ena4X9qV6nqecIZqrmxJIIDrKQ70Vbhv8elAepN7dlwVzvJyVv+jjByGbga98nr6zBo2DbWnWCPsKt1eYTYpr3Ypnu5XzmS2Y/OVadYfDjxxnb4IQa7oYy2yC9I0w8p1cvSXbLorzGHt3L0l2y6K8YkD58Ar7MpxD8wR9+Ifnw/O2XeU8xZTIEaYeU6uXpLtl0V5jD27l6S7ZdFeMRXuggrWi2X34yy+//Emvx/00jIBNnOHaIZ3o5JUZw20/T+kT8V+eu5CQx/lJrvZ3e5URjauQFLfEtzaKlrh7KhQ+gXhIQ4qhkfccgYMZ8FQcfNdnRfJR5bDQAYi5MAnh8mOXKq8YkI8npvcFKPLtl0V5jD27l6S7ZdFeYwt6Q8QEiO5AgDw7zzOXYJ4xa0Q2IdyeAWWcL02Xt7nxaWrC9l/IkdN7LhojJJe55bNZs2hj3mcK/xbIKpeL+Xb+shyLWE0auZkwMauCKW4wm/utI0YGQehIZBZeFmYFfRXYE5Lffs+OV5HEOciZwQ6illDZwd2kcLdwkEUDuCfRmtaiXs+oioU2yyJhKpuT9twnxcuAogsiEkLFVlxp/KcY7Scu1HK+D2h4tsx3RiyrvCjXQ3/KvqUMvSXbLorzGHt3L0l2y6K8v1k//GlnwSZSc8OkPWqfefURuNF6JgYV/xUeXkCmUMYVfUqqQPxRnjIomqS3nDIWL4w851l7vgc5+IbleaO21b8+NCNJqGC9vx8TNhjm85kRAXtK80pPhEIJEkVfVCCzMOQMhcnGUzCVXNA8/+i7MaGU+ZcG1oUsaB5bPkHFWpmUYB5FmR2YMbVWzXPIq6upO1ORrvKP14m5J3yIxh1JEsnwPCRnIRYnzAToJH2+1JY2U1XPjAMkWwCY5H2W0VNOnnBiXDWqxgGFpjX73lYBbUUxYoJ2BMlt4EQbxiD8vSXbLorzGHt3L0l2y52UHUlGkPHdjqV0N9sTMSg3wfubXBn8sjKbeLpzAqdqkryDCwWQy5KMxmqk1ShwobI/9Hdk67VmvlqCzJkn5EnsBPAPDFRYR5sRCI/anZx4mVgAF4fIwZcPG1GCUO7Yltsc3S+omSwTRCbe2I18QLSVv7VA+C8W1dGFaAABSa0FFnKMTk08hmJEXQkMja7Pg9K0ZRdKi31nEniKiXjM97JJL/Ao0PAwAwtScVmZfkixQ5Y5wiL6tEInZMpx0k80gtxdtwojaAVFFm7Eajk52VHl2y6K8xh7dy9JdsuivMYW9JAtx55OPI733RLl3CKK9/YVzMmmfbCc7xIvm3yo+CosIpspWhEAAcI2UOKDubtryNh9SYenqbrB28cl5+94Db2cFwZlw5cukR3wRzxq6myn0wrDXF1oi4TXBGgyWAXT0I0tYJRWQ6cRQ6zMDRoPY798/w5JbHS06Y6oC8qM5GS/vBCJAuOko/5gqY9L3xcOa/g2RDMY7J2Jo7RuyKETwus5s4ZXPSgZi2O0+Ki4Lr8YpWc9PCPfGeK8xh7dy9JdsuivMYe3cvRiSfTGXrIQ69PB+09v4okbzrSyrXzcMli1t1moy4SwJOmNJUKgM3SREe9gUw6kZYIr6DGMXc5cw3W6PhplOkKCLD1hjCYsYHpjCwLCNziuhNLw4lugDo8FkvjTyA1LhdtLtw7jhLXxOeVNLDLdpOdAEqS4kjIyHWBTppLcADs9not/jSIjyaiY8weEW5k1dAnCL40woAsgLM0rNDUexqhI1ZKFVpw7W52RmXTU7/gbhMC1570z7BSjy7ZdFeYw9u5eku2XRXmMLekd4AnRuqgp66vt5e3VwU3t5KA/IZ2veOHbuFKWObHoIQlAjwSfDQAOkM4KxQf5HdYGi6D6CmshN0Ac9xIuLVB79oEegbUDNbuOL5IwPXF2WwEgmHoRiGycfqB70fyPLAhaSvleNjFlrDmii45Fhqmpob3R+eIR2mG2X5/oB4M03ZVyAMANn+kbPoW8ov5oUXtbaLFgtxfASNoNgfvs/6rKqaAGQ7AIS/DDUF7oYwNYn4kvWybAIoIEaYe3cvSXbLorzGHt3LxiUtqA+bJhwMj5GW5heSt5OOIWL281rWsryOFcbJOS2kJPKram6eTJTLxECA2StcCOq7boOVzxfYCy4DvOLsI9ei8nLai7P7F1DkurSKDQHo/Ci0BIg2rxG1wIV6w+IvlzYyGBTy+d7d5DrZ1aGi2ovPxUitJing6Rph8MnCXYW9buXpLtl0V5jD27l6S7ZdFbdUhoIBEJdh8Mgu9A+3cvSXbLorzGHt3L0k9CA/L0l2y6K8xh7dy9JdsuiZMkY5cccMPIs6754OQ1CsJdQz3PResGYuoqB19KFbSUIl4ho9+eQFoKGkth+MI4ArAoQ4C5rz1mQkmgLnulHeQR6GKhehEJ8jl+D68Br/9aUCBidEygQk9Y6Dppa3GCELrPIq7KsFdDwShoftdE2N7zWdErY3kjPdzo/uFnA05BJ02zyiLQNT/N2UQkZ01U9jZcM0cQA6VzQA7I87MwEdpI0CE0lgDHVDCyEWKsUH2CM8U64CYGeCQhpWhl0LsMiZufwoIVPlOrl6S7ZdFeYw9u5eku2XRXjEUuBFNyyA6oroFohirgZTyLvZlgy4HjbRAmpgD72GAqt9IS9B+IyQk7v0vd9SLeOnJ4QQQ+cZTNw+UoNfR9qWpx9L9p+UbfC+UIFtjvGAHfWIuo+Etm4JPfc0JJBPnq2jiurPsZ0IzTK/FEAwQv6KBaFKJApXTcUPPP8ksiMLxa2N+YQ1rC7/Za7ND8FKPLtl0V5jD27l6S7ZdFeYwt7DhV+7I/gFfZRPmSf8NEJUiwhURM3hbq99YsotewNpzx9EFDEl2VFeYtUID8vSXbLorzGHt3L0l2y6Jk1l2y6K1pzp2iTCKvVpLFGk0Pdal/FJxT35If9YSbOJFAqkfs2cSJ2f3cbX7dy9JPQgPy9JdsuivMYe3cvSXbLomTWXbLolR79DQ/q14E2XGvI9I1cCndE6rdEp1bdif6llcL765CjJjm83j7z7WlWknQVIyPxpwL/gbJjhJBSTPlqGrmeXuXpLtEv6K8xh7dy9JdsuivMYe3cvGJ4e3cvD+Yw0UWRakJeWaFyvdvayuVOhjI9PNzA778vQaHxZ6xVgepJN+DwD0dsDvvHKB9WmlspzUXBf/sIREh8qn8a5Va9yBIWberKHfl49u5ejEp9u5eku2XRXmMPbuXpLtlzsqPLtl0SvekxLQ7XciZaEhl0ZhQKpD9AyZWr9D4azjJnH1JCZaEhl0ZgBKqq1TshezrLtl0TJrLtl0V5jD27ocmE5NP4kwnJpkF0E+3cvWvHCmmLNqkddS05tDgpTRLuui7nDhjXdTBrO35eku2gufbuXjGcfJp/EmE5NP4ks9vLSPURCw7lC3N12UFl50Qc/nsphqa6+tR/WIIEaYW+PvSXbLor10vy8S/5LASmiI2e8QqeD9iv1/ZHO8QNRKV5aO53zjDHk/eHusu2XRY3wfl6S5d9rm9JdsuyS59u5eku2XRXl+un6K8xh7dy9Jdsu9lTCbyR2y6K8xh7dy9GJT7dy9JdsuivMYe3cvSXbLnZdBPt3L0l2y5yOn8ZCNLnfFZIlx2vAojpAXhmxLSJAH2Qfl6S7ZdFeX60+3cvSXbZCNMPbuXpLtl0Vt2dLKivMYe3csEjt3UduUoPyuDlZPIz7y5cmtE2UD5scIBf5K54AQnLAq8wSvFJLojy7ZdFeYw9qUMvSXbLos6fbuXpLtl0V5jCugx9Z1RPt3L0l2y6K8xkh01iku2XRXmMPbuXor6Z1bl53eku2XRXvpZUV5jD27l6S7PxT9Wjb9qLHQ5kVIErocyKkCV0OZFSBK6HMipAldDmRUgSuhzIqQJXQ5kVIErocyKjrPQHGYLVph7dy9TeVFbEafPXhq1GOQfRRo5owXgrjgYArJFdSkgYT+2/t7MwGVlI1W2cXHSL7u2GVMaJpByXH5F4tlyQG8p+YxGzzUQLYJI6aJxdsLwfQgXlBJ66Xs+M4feSBwhgwMEVO90ax8mn8SYTk0/iTCciacsFQyI8eRR/czFakySMucTuHMShMEaBEi15YVHPeBCez8xEr4uSqwyWCViB89BAWbo15os/AjnJHGfphOMw/Vb/+JuZkMBXPYxUgQ4/iL2XoMEEntJrMC0a9QZoxxcwSZW5gVwqXjdDOL2rUPnlEQWMPcHSdYH27mB+duHaJ5dsuivMYe3cvWihkHSc4aXBy2/LuKdgjyTAAD+/gwAAAk+QcfAEW3KTGoRVu58GIxGIxF9acJuiMnveS14PMUftZRZ9ErswU6x2DRRNykgACQyb406SkwLbxno9/4flxnetA7F/TiR7iHJ4Si3pd4GzhTvoxmvM5/435k01IlOlbSL80rEfCLT9/1k4BRoquD9BNQSV/WJ/inn+tmr+PkDdYuPQ3BFc4svyVk07VNqueQPMgL5OYj8/P0ZDXibu5Bzqfs+33B9y9MIIPzfhykACkpiTEu0cYQ3G8/K/gCIagyAk9Ha3y6g7Ebb0mT0jyAV8AAPswDm4qYrAjxvB8X7nUhnA5kOo/xmvvaKv7xQ9WHPt00KNMwh35mcQ3LAR6i3dBdTl1xjkoLIWfO29XJrbStTglVri+fJkWF3qEmDkuI6QbaIB6lXJM8G6tmIKoLP8QPg7ndeglQR7wV4CCouoJlMP4lzq5216XUtAOaZFrtlnBzjzlkPGlBQJ/2Z1tmHcuf+QTVen41C6uFIT6h/dSHyGyGSKBQHMPleSOvmtD8xmHjVS7aSphVEHXm8wERI8VkoB0Yv7Xe6sIZ6i5lQ30Whdpb69UbLqhxIQxrG0BAeEn2EW2bCnvwdh7dln98DKEJmiMxZGXWiWvvlbtUI7pY1SGJ+B/sevwtfGZtAPNOHWp/P+7Iue820fJ0R+KSnt1L76cDYgjf+dxwEqV7lS4ioSVqSoSEp1SlfrxiK40TPQERAED3FgBWXtmmMUBrstJ3Al83LdBE+90YLspX2FisKXmjWeXytrwrmIA2VQb4HUtF9gD822XeVHpKLF886S+MuSO/aIzqQPqLnwBfIaaW9Hk5gtH31lH2TLFMgkqqXus3w3lFfZNf983h1BBNIiMz9pBOe/HxDhYccJtQ9fdOAVibBrFvl9Yj7pv456/4KPYe12keUGFIyyZMRwo9cDc1QxxKz3Pjc9atloMGcAWjwlbDb3BcSgxVQAD8rr5AGGm43548iBZkz8iAv/dSh7xWvnbAqCi6MizvYtyZT/iEpfcBjux/ssCKb2e/EHTAKTQ38DBiDfIItQn9x8qy0qVrb0ddDxnN6PRaA3ETWPNhVqlB9vFUxCRot+D2ELvBILROxBfWcK+MmYcBKgBQ4vdw4sUJWsSm+ngXKkbz5yCALN/QzL8UgPna4RqV//W5tNr9SV7s3TeGk5wK7uq2orWCqRN7Obvvnc4Zx93sOoOvVrMXNkBn6Uql+Ya5rSHiY6s/ItlRUP0SHdkuoubUrQi8GLHXDpUAwDE7X+hN2VA/Jc3LhtMetArWftRQxtR8G2+7X/PYDMe+qXG8Y765tixRaLmIwdbGMDnbuX/4Oh0h+EoNyvkCxKRb/oZPbIAC6/dKIGp5uw1NTSzc0uWKiUZT1YWbT2I2J+cXflNn11QYDjY0cskQ9kxOD7+PYYdTHtNAJCWwxFOhSUkr2v4TIl+n74bswC9RdcXCSj9w5CZ3aVGxucseeFQmrPDOFyc0dtU6zAV6T2zmePswm1WQI1Je/3HSHc1qigGcHpNz4w7VfWwR6tiMb9yTk0xTDuej8wHdkyc/kdtrlbvI30iwdBrQHh61+u7KNKSsyf74BXyPhpLZK6HY9nlb+oEyBGbaVqOYz94ZyRIB0I6H6T5itjv0YTSwBGd3JXeFSCDYUCG+mM5fLqnWQ7ky/KCr8giQ+WetjG+YJvaJkH37D9tiND/t4P7WTuSBiPFixD2yeurCP6iUqGt4kGtm62fxAf+s2E3Bi+aNFWKvSIhodHY4CFgZ/qJbSCmRY6J/ygg1LgsWnumzKGWnEkBKYrfpRscARvE+rYFCBGQ0joQig2laTbAAWrIgBsRe4pI/jkwl/OHUF3LYkkSzgkeJZmrofhAryJztf1WsLTWimBqvetfpuy0OE3ggQYXq9ODAsxLvS3YEJQTrLP2yFWnf+bXHBsd4rvPN+sBIC0jp0D0BfxgQAAAAABEc4AAC95DYasX+JAMVamUav0XPiGXKhsOxqAtiLsyEGL1tr3yUmNOwUrSpolycv0oLzRF6xcHpLneuuCpRyJuHGjJf/ltVplGwpkHi47oV+M2LtKw6CfMLnlv66UfjPGUPxfHl9lpWkYf8AKP5Y5IGMaWElTi5IOrA4iN/5Ox4Sja8k1Y4UJ89UlLWnXn6YZW/8VVZZGLM/yB2dFY2qUQTB6f+Lyfznti3OyEmTpzaou5VRkMBjrqSU7bYSNxrDb/BfbNDPfxFGyaXgz+1yrSGM8RMfkwj47NpQXd0ehT8xwCQqPc7E1QGdAYJ834JcDT0g2GNq09oQi4uNFxUCu2VEgu9hSyiZkCzr9fvM9Q8nCWpssz05D7teQiI1PGLjfYxtzzrb6U+y/XTiQQrVGy3kAy1M2SFTM5SZRDb41u5iQXzo1ARGXONA6qaYl4ZoiXt+eecavdjVkscJwOkWmMwK2XazbNIRXFKb41iLilc+rHaRK0ZGIAcTpK2fa9CfbrFCh/ab8mTgCJymZYgIHfdHNncva1E/VzyNhkEl/5zDWLvmeJjLYE3s+zv/GLQd8WDtaAQcZ6AzRqcalnkbCnUrbF7O41ot9SVh1jZNRH35coC3RLqLWATkIum0AAmMHQihZRoVKMpUbew2/efm0l3myf60uWlzoTMtrvEt/WZspH7YL2PoLL5VazkOr0ivi4DHWr6Q1ZoIsaVnE+vlfKyMDQDlDrXn9SveEjh8rDeU1VJnznx7fc6gcAB+aIkWPOR8K7wGw/XhnEJUqTGGfXK+T0xU2yCmdFxYd2qW5DNgP1cVFtt89/Z7g7OXGQt4A+AH4U8ziZQZ8HC2+zJS5KB5sLNxLoQv9C7t9StTcke+xlu+cl2F7zDHlkQYBo4WWgXFwsoy+t8W1/hF/IZLjivvAwu3/Yxc1Gp1D5lk7Hwk4Q7xqAKtTtN1I/PN/oyqzIU+wOEb7wg8Dh49YjEVVtWWo7emYqJJg0Y4qyxz/av/fAmHgTlD0GUqNHvRiy1yxhFJ4CxCxpP+321sMyXhKg5PJyOT0aZ50z/eBe9xM3m4aBAgtgrdQAGu9a0HEB5kVCHEvs4bUGJICfHnjrYIP/840ei8VjIPqW5SRxsTLVsPGSJOlYn3wpVags8k1YZ13XkYFYBZvlplSD0MMI5M8CwX2rlj1VGX8XYqYqJnF4ayLrG+Cmejel612eUxWGanNeY7VjtTe5LEp9ZXq4bSsNqdh5H4FncCz/RF8uws8bmgUI4JZvfEDLVGHj+cp+CLLmVcFy6ZeB4pSBZhRKURDhbfZkpclA+7tsC4SOYP3eJhRv9NiRYXOsD13vWTMLNji0zuUeXDLR3JzhbV+Xx178z6jkJdq6o7wlFg8y28BgA3bOZQeMunSukA6MtDnp69I7Md14QkeLiOuFJr8Fol7ElNEveW1HgIgiP9uPhsWnZ5CjgyVGpKjjt68AUJZiJQ0Llb9QF+0xkOlNm5YLnGY/+qLCBLrvcpd68Lfd9UT2nynOMXJ3x3u72MVTQT2Kj8LO39GOEQ8dTlw+lTQnwr1nCq+zDH/IF/0Mw8orQuzpXbqAf2YI3M9gu1kv8M4oTpyq47lT9cYn39wot3IV5DQqBaCHM7FsCx3kBVV6CJF6bEut3HiLp9dIskmv4nFUN6NWRlHbpji0+OqcZipmmSPSsv6R5s30BK5S57Ie2EZKKdm0kW+csg5V2BrGxTqTYpWvZiMkChxh5qE4U5MaQgAMWzYhRbZxlNQauNEQ7fUKeYgVofRkX+KGOmQXu9Bae00+5FYEVsY4poJ790J5+kMbpXbvxwzFjlEG9aEJHfp48ibGWgmsYUkdvrcXCDF3Tx7AvKo4QqP7Vo8+c6CVMHjxyRu6ZnDVTxgH5dgt+NGzQdS9opvjLua9QEZz+zl4cWWOsTn1EvKxc1Sf/OASNLkMSZ5fKgXyuqgrcbbPN76AqOK3WkXLbIAm93m8eywvzd1WQ4WXvGF4BYNHIa70mR8sus4dnmQh1FI89L6EZNt5zPOsSEIEoj2+icLPVJp8CNskMd0E2Ozb0Gt0lQybBRT6uqjGMkQitajKt7xweKsBwmESy+45U1WdM/4Zxo5DL9yE02VNoKZ2moh025zk4tur3NbkLwp6jMFnSsPe8W1iyfdj0R2uy/5IOpk7fhn1YZFRFE4fJDOevgquntcPasXnzPF65DTHy+3YBLZowAAAEQojt6CcNwP+bKoS1/4BruFbWsVe+jk73VWbALtdQAAD1qw39G6Rfr7DXjIsUS9jZGUuknuBg3Ibfqh3OCasODVUJUb6E3Q3Xp3TBgAGLNY92DArPKgNBzYrM+UPLAjakR3T/bwWY14VpplfLNBAAABDCPsQbiJxvdOsQHDVpIErthhxBjNa5q3QNdBSbcvgZuRefBJt/31+qg1L0Fu4vqzVAV6pPoSDXXYkRWd2jdbinCyW3K01mfgLu5lGf5nDk3jd7M7FU6BViP3Lzy5aNjyvgpm0j/jod/xZq/SozOaUUbtc2n2XtnX6uSmo4Xfy6smloLCjzBQxiKbFl7/QMItnsDODRt/KBSZWKCqRxUJtA4AVQAcX3CxdFZrA5jMRguHmTFMwHnBUfeFFRSRgPSRk1HpzDqClJKqBwXT3ZeCiAE9hLXpDIIW6R5Tymd+FlrPCADzaq7CnRRXtcvDthvEttIDN80xOZwaWiwJUXbC312cl6W/gNvEEp5w4U8fGIWZOqex/G1hmBBGNoAX5TllBoqBZNFQ6rBW4Aj7KHXCF0dCpdGfWbUeN4DyEqGqNPddrtHZgcyulNzngJ0o7TFAT3ZHfbM1cata2BFeV5mlSh7kWov/eagRhfrylZkyOWmqd15p7qfVJi+ImTiKUcPG2IGXODz8jgc5cxAvjWQKQ0aU19PU8kKzHV0XTZbCdZIUqnNQVbZ03EAAOfGIIINjOp49h8C25vxMIj1M+6P4xzXNykI6VJ7mDZNaws4YTeKrcNZU0s+wh52qPZshFJ3rAtzxWmve6mDfofY9W2MrTLb7TGQDTann3ZvCNPkPPPG3+OLLcrFBw77ordVST0DAfilzxenu3eQQuE9gwIsq/eOYJt1hO0a3s/LrKVirVX+mmmDHqCxx6QRSwzwjRvOAs3A1CpO8QYD1Vuxh7CS3s/KWbnpP1tE4FlQSqP9c/kJXdQXxRfInJs5QD6LwpCY9Zn4NCjpRTeAcIlgHFFsWi6xOmI7pKBYrcoD+ipboanx4r8LmZ9BVujVhJ1xLfG7IWHMiw7gqUkGT7lL4vcZcvar6anXgy7Z4JuH89x++0gYk9hoxnmw04PO6EM6AfdYBrn7+mAIBh9L/Nr4/aG/X/SVHgTwgUispuOJorDYe5hUgQsDXxNAAADGePReBGiMyI5DFkciQuU4BqE1RmsHGUHqKNDryIKX8e13bI1VCK4kCWxfH5kY/3BXLoVNn/d+p9i5oRIfIDr9OmtPbkol86fiuwjKH/mNPbkol8gexfkL/d/gADUQiPREsGek3bgzCjRcDSgAXcanIOhKvKE2mcW4S/nHBlM/3s8yBjEb/94ohqjgIsM0242kHFwbKxYXWXOpHiewxCywGPzLAiQGIb+60gd1aVKOdD3aLgX3ZIwnbMExoOASF24UC94kEJ6BEPP8ZenBdFF4D+9jvuCWRlPmA/fL59wtZdIsH8chJAplsYtajLTjtwY5uGDVLWrNpth3jnzcUFLhPAslWnebIPYY6Zxh2xR/2uDK7KpCJinTuIYDA3RroQmOq+/YFICfU+6riNQnOv2iHQXLfKojjWqWcaNyCkMXExpX2PW5ZA4VY+tqYOcElsdkMcUBsvYN3WQt7ydyNClkGZA/n9ugCPIDCq/oq41xQNVI0xxcBviYHwuLfIRYP7s8WEEJ6jjxR7y6P33kFKZIYKRivMdd/xiUaXTHTL3e3QLWWZVN81RxCHGZwd54UPFbCaFcWzdhg/v8wXo9BkYHQA/E1kmIeDYvSB2bszbc16i0XxgTHdrJoqelBJvbMgVnFl6UVc7J+mQp9TX1elJwu4tweLCqzx+c03cxDKNjB76UWC7d9XB6uvA8JpmmSfLK0GBmMwSyhKFhKw2ejLNvSe/Rbt5jyAteoDedjJLijOFBZXfSQUQY+n/I8AuyQk8zRYSUoZPu6DWVtksLqcuLxvh2DT/tvmRcwQeXA5j0tRz1fgouYNuBMqI3lgCXKdT3IVwH3QbklqA2KxukcpfiyjMotVchyURIUqyiI+NHrRLe/P1xAQpVODHGd1eZgbL1NHGX+jzHbNrxXQ/hZHL/tdqU7Q8OMFVxELBLk05NxT2YMc7ILV0L0r0f0GAsKPS5Zbd8O+dWm+l6kx/hH4B0mVApGmAfnJgdBTVJ+L5XXOFHHCq3SkiuLGipAOyXYxq2/Sbe2ZSmavmcvCIF8TEgd6ncPSodo7wtZcj58TuiATayXcMBI3ZgYxPQCN51DhU280hPLfgNlQFgEbo8Vbc5JcKBiIE/n9ugDBXfNeDviL1GKWKTg/5WJ5uulJl87nZamc2Ewpz9WHSUB6wyNklPVdWJVSGKZekBSpQkbswSYQkuBMHRwmf+D5JjSsiuLYmG5Fzk4L74/bnuQA+xhsf6G5QRriMmPy6KQAABrdhgdt3+esT/QK5Zj/HWgSAuKVMHusV7SCwmExKS0eTDkLgfZdH9BIUa2j1xPzustoPSjfaAkr2X8lJktAWkiOL5i8IizALosTLFZiaqpFRXiUhGSC/oNNuEu0YqIamRydUM8DTBGdyUfQ45fjt8Fm9AaiN1Gn5NoL7pe/oiAGVGl1AWMR2gdWN+XsPhSRnA6EMgZURsFG3qY3ou38fv1hga1gADKpkfKckQ2htE5f/pfRjnQMq6HNFzMt2sTMBsdG6JWspGEjoJGHACqlJwq51uL6P2Nv+Fsjw0+yjsu21fcmB/Kz19oTalaB1YTa7EhcpHuDFNOeIknUVKwwttcutqpF9pEsIOXn0/CtXSeT/zZnQtDWu8QCHrTsWhQ8zP420Ln5drQ3l72j8m7eWgr6mFFNbUeCTd85eIP85dLoTPDIBAhTYqVTQlb0Xb9zzRVnMLlw20zhe52fm18YBHaluPNJqVtQUP35saRCM2EgDvUj4EAjmRYxvkMmsrXe6DxWP84DPiLK4aW8y1/zdEuWTrl+2rekhBIC4jIHb8HLoXWLiN/n+tt8lZZ19xfLVepSoMCBaDORfCc568VRsd+DU+Ud8L0sndYKsj6d3iNWMZm58BrJC3WtAU/5YqHCccRSiIlfnLKDApNS8TuWUelTykkog/QsKwdut4q5TNLvjv3bF4YYEljTgbE3M+EUqkK56gPylsEYiTJdTMUBrEN83DxCaVaC4Pc7MQe0uKLQcTvYkzvNE0arb0KS/fCgxmkxlefrDf4SoErtiggZwCCtWl9KdNXv/EZJC6gBUaFrdYSpodhfziLnPUegdrWnUB3D1e0nq9qXUoe1L9hPrBaKU22QewrYlnoAxd/3Vam5BFJG7FSOSp3dHUuiS7bHgWIHe76c9jx8WG4xUVh7708E7IAG1L2CuBwdDLlUSbU7zqEmh4g06brCzA8jWiUtKqM0ei/++AVeHghghVj1XqBKSpp7xMvDJ/98OpVM+DFre7gTsGuMNb+Tk2lORviXhdU8nbCOeEDc+LT5B2VhuDVab2IICH5/jA+dJRtlxcgPTiBZPQPAwmBsIAIlXM4TxfeYXGj2vWdFz9TntFoVpl0uJXf6iOMYPSOv7FKV+d2QqDECACEWlVxhwSgZOTyjxtkZM3iJmDybsFeGoZHCAoxYW2jsrPqJYVMzTCwAR7ARknSkZKb3oUrjpW1njutnj7DuT67pEcIJbZBZGMOjzGv1oAb7yAEH3uum6fwWmFgRLLKpT54LsoQrv6fsHPw7yVPUdQMb3x6Nv42r1a/LBbA7gZ7u8Xqd9fWzsJfinAlzikHdHLeGlEAo6zYrX3Cd/A4vDUitFeBNaXgAearv6Jc9irq3tg4c30vLjkyQWl1fZfh4/wN5R99ja2sMsbG46cSD1d6Lzb+Vu+V0t15u/gnZWQ8b4EXBin1Js3VnxG/ObuV/fYIUu35uH107Q+Y3okuljfhNc6xN59q2LKwXg4QnRvu4ttLKYFMPOsdoPj8eaDeeFHV3y6b7o3LJgiWQVw9eonpeovQ4LTe4s/1Iy071claRWJPbL0ZSdP803KwIcvomevBN6vTAO71S+3n4pSd/QKJLXHTTApmGvmcXr2jOkaMOn/emCiaxq3ShesVtiJPA8loC2eYprnT2zhEgboUA95QQIWQFBm30AqkDZFykBTMdbbTWaRyPJ6fi5VrZpAV2XJizQkzaJ5m4Fpe19Nw7lUJ8aISGESyBPUb5sCp3mSRdbeb7u3+jqVt2QVOyANQLA/eq54SemsdP62rH7DHCklSolo/wCHjzGI9OAXpe4uu0Df/3PomlBqBf6EN/Y6xDvRqxpZ6djo/vTo534bvcilUkXmv2v2toLApLbu3mEkZPcrXOSW+j/ZOrTpTcP121KOIuv7pJlK+gQfkGYg0L6poQBDat2WGbNuwGnKClPeAm7wZIgWk4iGtjPLyApcHCAiE1MwLeWe9IQvixPtcQDzTmsNlb9iLZ3OTjwKaKAsZfId2Lpq+uZYN0WBw7L8vlNZ04OLsnqcXhDKYcLpsm208AIscySMGHYlOmS1iF8pCyXMV4RxVGc8LZA7glAKM3Af3scktMQM29sOyE8l5SUs8L3DzTJuCecSp6AKOy4XN+Djl7k7niLIVjIw4L5k0xt8XAsK0SyF0yp4vad0rAcxAA2WxHP3pnTK7Dqke2LLLf0I0AASbWhA74HJuTLCYpbyHnGbO0KsmakgSwEgHOgaNX+cfPAT6EhzfUFcEhBrtJRfpO79rgsJRSLHQMqI2Ck0RFo2ohm+ODZ8e3fVOaC6uf8DqG6wTShiXkUJy6QnRBoObFZ07YNzUV79uYtzK0QipCknaUKfQvT5PJcajvEZXWarEsPmhMUt9DmwP7ULaf8Dq9RjRvtorIrsNrRB8nfAY7Ui/Ov5bCTVvTVtxGOlD1MqIU7jNw6mlkp/A4PGG56HKljGcohvdwsMo8xewlJibc6btQO+i4y0mOgH+h3TxiW/Padd+nrUlSoO+pXnOXNpC8LACXGC7sgwF6A4JXbGE3JUecyfNWi42a9v0Jk/OymDeus1afWcIXeBOy5hq58yKIQNzGneKLl737Jwr/UbwtVI5bTbbN6vx/MKMJZWp5ukgyZIAt+j7jdUxaklJvs/fNqVicSKwTCr4+xCbneeZjr77roMM4ovXD2yzP9i7TnCkUfiMroQukEPuwXBX94ngcUCWVEd7R/QGa6mLqbKsr7X58zY2p8l3DAWdPdi9dX7ihgl1mzM5Ql2Hra1oGl4QqAN/fKJ3aIkEZSFdLjWOtgmR8avUyz/nv5mQLEHYdcbn0ptjhrsPVKVM1DUw2lGiYtIFdrTIrdqxotWYKJ0SvMGoJAwnNyQDnFmbA52xnPGT0wUcVFyyTsujq7G9LgzwcX5KXlfKFfYKCmeKmZMRyqI4ZDOV7WAw60DD3Dnzgl8bog1+/uGj+sqPUWVApT6ZBRoa76NY+Jbms7PzVZlYUZbjXY+boCLmD+SWDkK4CdoWiS19xTGruEOnWwL7V1iIt5HraQGrG0KvLKzxY/m/qso/ai+nVH3+SFfH/yjoh9IpML5eo6dzK77UV7F8xD7lkpYEIPDwJxjTiszUvNMx80Jw+xRCOCxXxTpAu5FrQQuP7hX7QClfSYmKd37oYUgpG84S/jYYa51odK8uECe8ar0IP9kFVGgNUx+ReFt97r3l99KgkdDY2gyWhSLlO72XQk/rEj3eDDnw+RKSjTLqCw5UOP07zROl7Q4OKA2XsG7rIXCjBcG+HrPeWQg56FYg1YHqd4pKlWoVYhuRL1kXTQIp58Q6o3RT9iR3vk5eB/ZOr+vDhvVoaqqnTaIH56pdk581tc7UffwxlUuWgeZJujOf/doKg3LZ+ikxZw40DQX3jB1Wc4qmwaDfA6avmUqKY54YGAahLpMSJwLBK3isC4WesRW63apaaXctxYWwL4pgtW/yhrmYTuShQ0vK86nAROyc8genLUULWD9vA4UMIgitTfWFI1npNprRxfPRxTjBc4ejDr1RXA0rR4mz6ANRvI0Tz+Fw2grL+5EjxrJgMcnML4SveURyr6inAiikZfNnRWnNw1fMscEn8zPLwpPcsOShZTGeSaif8yJbM4QZeIzn1QG0xeLX6iLbfXWzD2bE51saAja4VyqSrHUZBZe7cfMsMWUcjOE+jpnk71seU9wfaeOOeyuNm0gsjqoHgbnObGxMZFzr2LG84r4uEMReh9a+pmlleQcK18PJ67teHxV0HEAx42p+QFGAeK7p6hxgGwCc2nxixxgy0A/UqJr/6UDVGJBhw2aDHtPSi1yMBlPQ7wCKrxsURs0Mx685Z+ita1xkCji8w6VU3JxDCL9zCZHdntjy+aASSehs/zlqZHix1Q4jWFYz9BPuYmUpTAKHZ5Q1A9f/VL/jDbQOhAe3pesca2LdXgl+1HvXBYbZ8QRaIqC6NYZNTEMMdMXa2nzbWJYpboh5l/DGGJsUV6rxyNuu6s1UXTIUHMxbN79rySVt01cg8QMPT6pE0gqho6dD8HIPSi1yM4rGGgoFrcX/j9Vsq05yGDLbe2Vc/nALS0KYLfY4D98s1wKl9QKp3ou3pjiZ/ZUwth0vIM5X/e9pI3wrcRyNexWzE91JOajX/cSKJuxdHYUlQ1Lc//7OW3GhXvOsgh/q3B8rXvHpDsfXLNRYNlburTcj0EugOb7YhgEZ+BXtCDAktKSKmSvExLOOQ7b0t5YgrOPgHi+BC2AN/WsIHd7YhbhI5h/TxajPAgRFfnnW5jyDwO7aEG3v4/k4l28AyIPDyZRqetY1Atj2UoeXg7gMyd/Vtwn9TBEZvIAEFLg/fiBUEF9cNL2OufDFNLGCjZhD0oqYB15wCh14BOnvT0crmociyiVdl+1fme4biegQsJyZNP3z7s1woYStCp4j6fKgi7/5DT6qrCcMzyWQSSvkA22uk7DsfWCnLNCycSpFeJsGQXt8P2luaCgEMaTP6M2FmlTdTr26Zs6WF5pDDz0+pLXbbOh4f1C2rkvZ9H+odz2jnA5EX8eKhkBLwL6aJ28uH01cu1Q5/e0j/+cepxZT/Twxvw0KKAVmMibCqXV3WC0O+ByP2fBIh4Q15efZKVN/YYjkQ4tW+zs0KID7hdUdp6cS04n2A5jF5WkZnOZGyvTPEfed6lSYla/6vITLKeKygApEnVJbKLu2/QsIAYrlGUZ77gb+PknRFuQfN35OPioFe5QS9zlzgBGvG0f4GG/P2AD+cl+HARg0r4Qm1JW4LQux+JDan/gGUlSfZOHTolX5qC9kGMpbvGg6/TnjcMEHPmVv/bvz434lcQEMliT2SR9A+22mIaHskUbmXiXXBx7B4SiCfduL9ejvvA50n1a4HjTq3lVDarEaDi1QfEOrG1Z+7eA1X8AACJXBOqk7hRwgwPAq4ZEB+5wjNy3f966IyyKkAKHqz73qIQzlB+NQ3lDZwTbdScsfjaCQcPa6chP2pCNSGxvbZx5oC3j8wvNFYfiA4493JMbCYzMtnFQbjp+RkRfqeJGB8dvWKyxRoYeRjBq1AjGwIdksmhR5RB3lX3teo7duablGRRW77mRrMrpTSYYEXf/R5vYLoY1Uo0ikJFbkBMw5RWUIDvtRFd6MTb0IKiHvuflSUgeYdUjKdGap8WDAP+6Mh1dGIG0lzpJAhZWXQZg/DAXVa7oEUC3QcSEGCq8mz5uU9t8fyvWtUNGPLip4i/W5GCWhZoMyrDDvmtTGpFtY7FBW7xBWcXwABv0SgKHAx9W7uBqEi3bqBiEslhBzC2ae7m74f2ISuC3OO60nQRnR5lvA9QTI01GG/N0uP25jhsZmZecq4HL+vl7p+s2G467vH9lF61UHEAx6CaIK4/VAOBQdKUYwR4sdAK9aYMjy8VYisMMGW3EftuUeit7832PxHCvF35fJI97Cgv1N1gVBGoRnR0sLHKEe50kAfQnhrO1/XgU578mMkZBRSRJ72Q2ZOmyRsN4hYMp6OzeFQxpoapymNWeI4jB+/9uk6PdNcinilhbcFmA1N2G748rllLgc7YjfytJaEIn8OP9AZQUAGzcq1U3BeYq8WI6nCtMukK7QLDneoQ7J+OMiTMMHzIeIH2Ee/7W0QwoySq1iBjsu0EkXKWufloxeJNeev2YSyZBUVJB8eCsUzD23Ev6UOOXt4E3Fc2rvxdXF7Bj0WS5xvdN3MGqbAAYzcLmy2lVcbkSXB29ii/eov8s1YqdY1uHQ5NQp0c8nlTo9kEFjWa4UMS1jHFDyg0yvhwzXxzbzCaVfp9EOwdOHQ2u9ob04ImPhF5Ia9AIbt9fbLPux/a1lJ4ErypsklPgkdL0rd8hrBmNHHLgN3ybPv90XX5LzLDzXZvhXAuIvrWITem3pRpP2sFEzwkfN3Em97JgxIJHDfy7S3hxlNHk6OlTDyfJIvtxgbgZ58OgXj0wXgnwlIa3wi3Csv93Wg/LK7IsTWjl0vcwwvmhsR8dgPvEXHSqpyR59d7cX029JOkGFGb20lv7nFcQXC+DC6sqvrEhZtwDG+kksgJlnx270OiIhgJ1NF+MQ/5C91dWHQYzDetwSi23/rJhA0EG9YP3OhpR96KE8JpRic1OaK/ZiV5g76z53Ig3zOaAEFyfYWGYNzu5otTlFJOww41e1zeDNFZLpn4XNEHLwk0PaxczpL34FwrsXAwWI6xqbyCANdkdsRYqDZCVGZ+QwlaWg1QyduftpzYsihRkhZohqjsiFVzv5TEMWp5fOZ0f+6QUnMekOyAoxCyNakJZaHF+axSCOSV/PAiXW1ZKhSLPAqhORXNX+aKmtzWA7H4BhVWFAiOypu7+h5wud5JaHmaAeimOK0bLqDmrrVWQLg5oo2iwhUMVELf+aOnnHpI5xvrarASvbNjrEhpR99os9sP80w3SJMuQumuSZt401BJbpTNKMyxGkYWfMrzPnbEty0wh6DpbsItyY+QdkrslqMi5ok+dpUOw4j6TabZm2mJau9StodOe1XuXHxYTaTkrT435jtFRo2TWBCJib4jtB/rRdGNxdTd4lNk8gC9R07yvZ96RL9/dsuZP2AOu1uHhQkEaaSNYKB1dVJFqaTFntQ4us8S3FWvf1TJwjJDRL0MsLGKdYdWLJbo1VkSUs9N+8kEMY3euLCRalCci7le++qoP2yxGlZd8uUie+lObzCc1SrvPjo2nXEwgRyfR7jWuQNKyA2p4YfwCV2uP9h4vG9k38TR8oy1am1jaoKy4eMaxNe4zp3ywN9Wj2UMs1ewzRtIozXlMlBJxhdwmm0m/gPNH8xj1SOLzz4rj3iHneQXTxHIGK9mc2nA8NNvjDMgJaVzn5EQv+WZmAdyRWUcqkCWK4ez3gQLqqcR3xAnUKn1M6RUhdze0TPqddjEg0HdaYyqoDKDC3CzrJC0iYVfEBeV6CgUUetAuQtj290KxpxlRrfUvBs6+PIbg9LyM3YphqV9IZsaYem+e+4qANWn9Kr+l+0FFMtY5Ex54tNnJS9buzmTo6Q1ljt78P7Tut2JoXrBXZ8HMFjyCHvTM/2Odses9L3XFZKKqh/duVI5z1Wmca/dbzC6bVZrbHMFSYPJ1eDv/P2cNPQO8zmTA7l+X4/npyeNbeqL1eS1H3DFPVOn5hdZK5eNkMZ06GRld+MDEz7F/Q95pWgWvY/fRfMJnxXTG2PUBlAKJ0e8s8dAGt8FYUJgMoDgxNu5FlPJht23cNIZ2owBeX007NsktsJe+7kc2x36AuwUhCsh4upuOC9XijKq/tvxsRSvrGspruc/hO7/5Dzw/iXP8dpn1hq0vLpRlTC2HVZeIgwsFxIriq62URxUtOI3dgdhnYp8lcqLMTHsKSqwfK+QlUMf44jwQf1t9i7P6RmDLi6bYqgcUSGb8huqc2Fak2yZLgN7DkUTZMxrroyQDp8kqE1NvIa61TAf8rFgkbby5NNZ8fOLXF7hu6/T4a2UTRs7lddF2G3Bd2JgHEHvAAADqP9AZ8fntWM2w0KhE/JHSagjWhu14+Fo7hs3j7z9TBmz6cM7sP7MmFpZj8cCQnTju/a3mGDp1/LiRx7WYpTrmP3xsTODW0ZMrigDLG42xUmrhYTiIe46roiolYutzoIrQMI6+c96506vXFoMVN0+OkcLBmz8/yPkzUZHKukXx/p5GfTZhLx4PhNtbKweEzWC6BDUViXwUMJN4vUk2s+Ipf62dAJ4O8fIS9SODJqpr0PopnuAaVr5+vwY33Y8+6MAbfwPIAOcl5qKO5MkrbE9McY60b/5tRnWWcYi+16PB0MyhBnoGUN4MLHIV+x1gOpamiHn3PxExs7/GYRRKNeeX+mnqKKhyuhn/5WfLI8prmjD0IXcK//GMVf8zQ3bZkpmWPAXRl+Dqp/RcVs0xouu0AvuRKMnnPgW5Pf/E9/wPSYarmpJPoFqAv7a15r4iqc/dw+iPxpyfbUzqNHwfCWgyVHDd3ZNRaZIUm3R1MqZNpcVvp59NOgIuWO5H/o+3W0Q/+dxnLahO7Os8miPLiR8bRiSeV90/6jipz5sVMZTYrnhg6sNVSGFQgoW3XiuJd8IbQmIY3w88gBy6oiFXb4OSBJTvk9DC+bTHKKDRACgOXisH72Pc726m9hqxb7xWjeTE2E+ay97WjFn18Srmp8b23GOCK2GrTOGRXcY9/vqXtGKnwXxNvytLnufNp+vtSSZyoem43lK1nXOciyX3I4TRXwbJZfPtJFd1epff+5K8WG2ri5n6UZefb7gFKZ7ohTwGwGRdLzdcsz/Au7HVXaDNw+LdfyUhJW047BIu6vaYN/LkDVviUWsUAfRjE6P2nTiy3cXDEFKp0zpnZ7Q+kv/zda8X6nelIWskscgy5bCgrtCKQ+W5Rej3/SYQBW/zqTRFKUOEnErWfrvXXu1cJhh6D57D1at2ka1e2RkPDU5OW9UGoYqf98TWC237fjXBO1DuDZpGu30GXF6KrZc/CrYUr87/apUB6FxistO9XD82Q/30eF/PxfsplCiTauaoR5gH8qH6tq4ihbKm6SvCrvAKlOAMxaSK0vpq0+Dapln+NoNEmVPQUUHOWR9AK9VOtQH2wvA+GduoFikXl2KyEHhle/j2VaRN5DHplIQ9Wx0jYIKMG8vfnRxGn76grFU33WEXFaLEDHcgVoc4Bm80lOuKgUe8M3Y0H/AbzFBsIuQcZTwS2fDO/4MIHs/0+vaga0sxIho0dKKbppYS9KdVqwEQ3dMntBPAcecGxFRpUAKMQt2U8uAqDdgBsQJibGARcZBqYr9zHXYbLj9iZRIo8TDEnVEeUjZiKTCTcyxwGCv0FMh9pA9uoJbnaOREmuzYJnfgUEVEc+n3UP7YBZ7KtVakZfihQMjkKHLKIS+2QrMrBFqw16oCZvE0fSlZH0cGHvImkdoyhiqDQUIjx0uijaSqY0rCli9psdZXLrwx9VCpnUaWeKwFkKCMS4gxzwtitYiKJssWfgun6r8eFgJqcW1U+7pVqOVEEDM5QzhUBXay0rVvs8tybjn2e3ilGsd+WCArtSbTIoyxR+jz1VVs1jaqhe4me5yQDTTGdC48uM/B0nnzfkbKo9ZROcxar1Fd+6a7FY54zPjiQWuyQ204YvFuT7gOCMQtgIrRvO/AUrIO6O6O5mTmkMpKx7to4CL9GPT01aMDd66AOOCDkjkI3n5ynfPfGwb+558JKUVu1kaymiJJppJmg4hHkjBHZud8nRcmNR2tpAzNRBahA3TnduiOWJIbyTMUGxLsy6VKkTVQM1BttLnX5VaF2mnwleMH94um+siP1qeKFy/bd1hUaAw2tSBFZDgf39DyLdbjB8Y9cZcP1V5mcfO94rsf1nrMWICRcmV9iWUsjQV/QZI9d0jC3Y7tF4NATOFh4SXrIfp8sZjTZvBVqo9j05B2ZkzaL/dM1BCf1gcbkXhno82gbyrTC7WCaZvhysqW5LoYnugxpisPKIvEglK4UJueo3qEl7M/rZcM8XEUpHLFVXhoaw4NNQ6ZEDoO5dzt7l77Wrmv79xG8+wS59y2Y+9On1dXP+j+1Suvuqvw8Ia1TWX7ImZonNLn+qlNn954DF+IQXdm8behMECKylRgLhbGzs3WX6hIrTy6NOwYNMYxltob2xpL+wtaGkC0lO+T0ML5tMbfGKG3FIttPkzNj3O9upvYaWD+daJmfi1Mz1sNxJHNTWdOWQkK7xQsYHJJSEwxCcp39VE2RasSSJWx9pkJglTjO9aCo0MQVTdo/cLQ7lWa0EbkPunKtgmSauW7rp0pTS8H2lUEN6aQuMm6EEZXqY+55uT5KPU5g3XsvVjXf+bXLnKpPDK1zYGvTgMvcchIeglOiNnGA6zrn3H749762mCtytIAAY9XosQwdgtePdwEtqB1gppuKfrx/Jyigyz/tSTz/RwVksGxF5v//iCR0Xar0YCWAumZ3yVYCpYyZ2W4ABHo2DExxK2cava77PAeEYc23yW7g/yRsrfpUv1MWoZ6kDtCEe26fh2yqAOFBcmImz7Bpeg3KHc+bVEvON1v5RRNO0a7GCoLK/TdBH8Xac7Yeajo7i6El4nqGaCtgsJ4GkenOmbwJ8HjweNt8Q25O2JBOqm2Loxb7pfpc24/3F8yMlhPtNORB4fquWwjxDuM2XAqU8uk1EdXQffhcxkfN6TQu3ioYX7k9tTFiiOB2jUC2wncGRmbJjJRUjSWq6vWjALAvsW8DFiOMQb9BaIUjLBDMVZLmu43DRw2teCZL/sbayY4TTuxoqFsNwGED0iqWFlQ6allEwZe3l+YTOUPFM0xVdl0A1VRJf2LB4V95dEAEBY7iNM967YchJNiK5YFyNL2bAyn1J+qB1LfEUfHzlazOcLcQYLarPWL77F63LLdpMbGiaJ+TnNn6wTxCkSjrPRavtLh6NKh9rrP6NhWlISRIAj38yznICqJbmrDeymzsq0vFpilIuK//bj/k1myKDs6lq3dANnDctrhZNBJcn6zwjvBV3+c5fLBEJPasRN6RrAMHzYCH74Xus0bOyvkIaA/1ZxL1+bZOFj2jJhkrzeopSI6CDovbdijM8q/dfU/t0z3wMSboKAzFae06c5R0RMX9ysjmXF3HcHFCCygTiXunb5xkUJgoF2GSlb/OuJdqzy6eQR3o7hbP0qhO7NtOc2La/78wXJCxo8QEwVo/L9Y083DxCagfOQrmKzR9FFdT8H+KNrz+UPKE313C4vuKNXBTpm9Nvf3MYFnWANuruPzL/9q0nc+JDYRpNgTQY4MiOozQ+/i7es3uyDLaprD0fstoNaJjBQIsMVLNvDnIS+/roC3n3WLnbLxihRoakGddJkn6+LItsAr/7t63fSiPS63DXCqBtrJ2jCeDyUMuTNKb/X9sl8vrLVY4nXiR8vn3mbwypNnBBHKPdqtz+BbHz3XSxzheZ+1F+On+RIxneeNi4zOh5e0a1As9PelaMIjhMN7IzBLJdIitm+cB4Tfsi201XbTtH33LP4vr/rgsuF1OIWf9MV6shRPVleOO+1QtCjMvzSV/so3YMdCHUXxhBxCHk7qmasXLGk4NPneS42TdsKlV7VgAAE2dw3RcZqVYAcOrmVE3nwVCGPGVadjFs0ePOhqQC1CRbOlwqRTA6iXQi7/ACD/xuXsiWASZaGdf7CR4DJUd4MJtp63bgG6ey8gJXXoeqaXoav5uX5W9Ojs0/tRdIBahIuHkgAEZB/6DH2VwCybRHbMvqL5q2j6pkNHWx4SlSbeqi+DSDqdMefuG7wWu2uvaMbfm3L4O0BHampvZHfo+sgdj4g2P2R8AFdC3CDlvYuRXqV/W2xYXCHfoU1gqpwI7ad+oPj53H7qkLs/ugesAvwrtGixJCM2P5IKUhWoBeQ8MJlWoY/S+FwW4SLBy1H+vHooxuF6kT2/XkumA2eDgddeMQDDX+pcoUftRE/AF4O++5DS7lIjW65M/O54i0huo+SYZyNZjTSJTB+C9LjBrcwaLv5fTFu+mvROH2KHHT7lmTAiEdldz/G62aOmLpUXKYpcs0R6HRRUfD0iIOkmqkO/Nv2HIvL4F7zVW82xpFvpzNohlWMz4nZ3KN7mA7I4sJYdEuv6XEK8Vh6A0wdNvy9mu1RY+IGNPGnVEhz4corrEtMchAzeCzKLR5NCEuwf7UG4lX8n5kU4XRrPeiXPs3YCmbWnRFiXACalsmWerRmhzGG2a6TsOyEpe0Oqm93mmEyvK8KGRRUgoDtm2l9cEMWCfER9pm9lm7f40RIdyeuoEMuPFnyTAF5M4qEgDbosiv4wt4Ku+Ork0ZDSW1O/6Edf7W3s5O5Mr/cJKQIB8LDOxpdbhoyOhXC3j8KsbNWqzysYlBZcvKMnWRoDjzBQJKZcP+io+ygyUvjWtkU9WP8osJXTgqJi0kmVQQetEtLX0Fgs+TGpw6F3tyeVRH27Scob61Bu+xIhP874Vn1dkaR9NXwBUEgThe+xbS7NqbHKwlcGREyEX/qShFRhwXq6FyzMsylAw5AnyBnTMA946F29AcBq0IqgMzo3J2yyXjo3dY1XAEquAEtHDRf8iw46WGMrhVgExZi3XT00Eq7sgMLCr33WtLk+a199rvC+zNGLHe2nO2h6xeCrrhONrESP6T14VPwRvt9DYl0R+bdmpnVqjJk8hne/S5P5aAgvvs58RuYOKHV48Dz52sqiJCT2wodFog/Pc2OHAUUpniaoqnb2twjsc9l8KUDtKQMnyfULmX/flS/GuW/rEIjicXcC8vdhJs5bVSmm8rJYmd+AUQrT9juHxszp6BaZvrOCYPi1NX17dkv1TxRstiV8atZbBT7mfmkMPPQ6fQxmJl7zcH2mHuMInNWnsGGaHZtdmhzXkdFlhoQFo+hSV76e6GRKAvnj0GonAvrHfcWf7Cf9cQOO8a7duyhysqW2gAAbzSH56uDVG2TPrjaI1NSWPZwmTmcfzIL3vvYYIdlu9UjFNPa7ttrNrVWWOiKt78CEfTdjhKUX8o8Bkcb5gDwolzcLyq2mUSuRIpcZFCQFywQ4p5zWJYpPvy92dN/jLVhU2tEeNyIfP2NZCPpfXV4uYdqqQKZWxx4RKmHQcYaIYskAAggxXYllbueVe17CRF8j5Ix8ATmO+3ofh85wALhMKcey81Z3wKSDq6oMP8mkAN+8p/QLUBf/jLDlAKgoguYuf50FRe3vFhDVFPdNta1WO1TeH03Kb65IqsIINkQHerrJ/nAStOIOLQCKQJZ1F8iLffbmokqERuvgiR/Jpeh0a4e0zJ8rq+i1l/r7CtYjQr2LNS05GBq1OGSIkpWvwm//VZOMo64eMJqQr5POfXQymA4xnAzu7qRV/wRVpD40shECBCT0Yp5DhHDzkFqjYKOeuRxiZFIFArXS2dGmSnGgcAc9AUsQIijQFDA0kDUW9NSjt+zilylugewogRjBHiTRvB0AvOCSi2fP0zWs/n/4ozSivrLWzCvftHhq2Pl4erKqznJ3PyQ8/NiKLYyzuu9q8aki4/kpSFz0aw/Dy6zHng2Hll1t3TQPV360CPpo3uUPga7NEB2hvj/pxE449MPwjAfpu+HmLGS7yiqOUPAXaKBgIUrSRneakR9IFSq9rl+rgN2DtScOUkunt+23UnU/fVJcQzuzg9AABlMbbSxCHJKv9wZ8AXlLbIjGnZEzddBJ1YGkP1mfz0OlanJkiQCnYbuyot0QcVPYQ+VIEzIsXgTWhsjN80VahXGot778/xhxG/PFikMU4OZe68cAfsQgyyEdeCxtSgaCap6915Zpfbyq3kX/YYOWMJ4NmE2rxdt35RPIcZxWeGvSeH7BdVhoEd68676ddmuNCVmgbxJSn7ZelRqk3w/nJfn75ea0rkGbwJ3L9G1JL2o6jn6JIQ+qWInMshid5Dp4fpmtuFWCZzNeMVTkjz6724vpt6SdIWRWHF58QhM9X7/CM4rqFzFAMjYda+4oVRd8xNXEpIeiQauvcLBu7ym5UqHUHZE8E/BSAOrJy0Zl4w3tcnSzOHo5icx/hEthur/5PHUFhOc16qHgSnJPPD7AyMSKagkznsudWd9DZFNeQkUKECNqr+wOXbz30PgfDBZ3T9YZwHPAy2Iv4AdUpMd5TWqmgHvixCs6KV9Ca8rgwpZTspfFFcGipGnnfC0ibwDcacsxb4oeAE9o2eYszbxhoez0bmj5pc9gcsfUOk8g+cJp+2E/apSLaAdgqtVpA8/qKjUlMzMPwolV+2clkAxjdcWPbZjGf8MP3u3tYIaE6L4hUAb5Yhmbl6yJH78ouQJSrbukUoffsKVnpL4fe40FU7u7aQ//i0Dlr7CMYA/0ZVP4fskaHd3kD7SrEEjWFqfMforda2Qx7qF/N7vkTOTbyGutU7vJX8ocfvl8+9i3uNNF7Hyy8U4WtUVt9iSUnqpfBgD/+VaNagX1yXBRHBCloV4gbj1/pxisSTiVSM8ljDUhW/yA0ZNv5LHySUshGTMj2JwQzUhXgMXt6xyuRQWDLYnjJBK7ryYBEH+NaXptbvCtyvyBE+EQ72fJ5/gYhgcAhx/eUkUTnxUCsPzd7pEPAaK/P+f6reDvebibg3GTocyw7OTo4v3DZE9ZWoeYxc4HuvhJOn00Acy4n/Ct/vLadDtnuAEJzd5YZ3LmBRFzzrrv4AO32HMiikIhNfswHu+QwXi6ram2Pj5iVA1h/Me6yDUG7FkDPEnUMBUfD06hkYxYjc22RjWTPcdstCZniQ/D/vmdlzcnHP7Gcb+yBiAAAPh/wwOZaQyULOSSDlyPES0dIdPK0mvmHMx7cM5vrd37XBhPeqRywLZUG8/2IL9gBVQhNhxIEpXA9I6jUzWJzkA8J2mBRA9/AeWTaftAyojYKOqwAkaMjwQotGV6PxqXOQqeyI6NRkAEuiXJ5kMDaG0jyxXH8vHT1FQmC+au+Pov16MJUEHxTtDy7515TgCRElY0rfcTrdNmt5LNK4KUVAcP8BVz73vJmO74mhDqanGPI4Qmfh1ExTfJU32U2t+Du/S66J3tXStm6GWxVTi0O9mA9rl2eu50FRe3vFhDVFPdNta2bzC3tC35owhqlH/lZo47QvxO1KJwPjptkcYhNnd3LXK9m7paLUhghx5GIB6fXQd8mvY8fxHcET5/QPqbCzCE62dN4quVp0pxu0UqCtU1Xds3YLHEGLdyaD0gCBOsFkAnclEePdIWXojrscyqP+1WLv0XjgNmX/RWk9OiejtF4oBP7oCIsSeJfscV0c3vp399G/HNdF6PnjxfnIywQ9NqIFNhkfF7lOqMsxgWAEkd+zCkq/GhfndxSKWKTs/n/4ozSivrLWzCvftHhq2Pl4P513OvhT9t54zPkGSMGHgvj0Z5nqd4FpBX5rFRn/mZjnSo9TrCZJ2llkn1gqKVqRfpwlHC9vzJlHGpG7SsE0gKllSV3lurQkk7E80Cf3CZnEO0RFDg3QGeSCzP7tLQQsFqANJpOL0mfeY5CAuTjydPG4cTVvadwWA8f1OrDG/eLbKc3oSvHsvhF+bL9ZW6svNgPVrmQ/MFovpETZXxhM+1D/PFz5ms5p+ULwe3T215AegScV7KPJ1XJ3HiMBTD9S00eUTwGlZUmfJGmTgXj+ZCL/E58m5gWktpm+IkQhOWAuqTkrvkkgcK+I+WgiGNzmcAiGFVpnpP4RumOJM0Iy8ZZjFwOaGo+1RjjOoJoibwapNuMacMfFoJox/wGNkEPympAASwrqzf5+D8b1Nz5EK/4f8c7c0YOCyg7lUojnnt8PFBCbWQdMvvcG+RBCfEGf+RBJ99J8KxQP81pTOTStxaGl6m1rjQreNYO7Ai1BOjOxMOYJDHxjukK1V3z4lcFFjaLoHLezzr0QOQ38WSfJVu0eDlSv16rGLmPxp9Bs5v45F7OsUceWnjKAWMdcFwLUaAnj/4oPGlYQUyltENAqTN8MmNojffF4kI+9IDin5j5t0AvfZ6dAAbvDf4qvp+CkgM/cWHM+GUGcZjaB6nTMjfrnUY9mRJ9xYo7IXjPkZquAapLk97LOZQrSleZH12aSsfxhKfXoPjZgusFaTUjejNW3aT0fPpTgPNzgN7kRHySoPB55qdQwNLoscAMWh7H6NzrYx8YBcDw3UfJMQqdfoRJlZmwRrBu+RjfqzdZk0IUsnkAfAJfAliVBa/6Sks/NS6ys5ujphACBeARFjSuiQM4zUrCDFkr7DnKZdpLauAGhtFESrHbbvQS5QHx38B8pJ+LHrwss2BpUgAwwlKQFqqkXWLQN8TORpywN4F3Cxb/UtbBUHzhFL9pRqPcDixCfbIuaSz1KPEyQm50WPm2DG9m0wfrL2+kZFQHEBV0y9m/N/OHzuu+NA4Ax9oL7q/sw5sDvRPK0I+ai18JW7pbLGZKY7nOAbvJlrAdhsJQR74oVAAIVAMRR8Y5WZAAk0NfBAcTMpFPYlOTSuDhONR7l+ny5fwg2s0rDjx+xwT3xkBGNOyLPgWQ25PX+/2c40O3PGtlkkCDlggKMV6r7JZt983er0e873jZ+T6ZxVQBvSfFFCWcHvRSlnY9njaCjIDKjVNu0V7Vnt7Ea/HsdSImMShUyOIuSWkgxkZPXPhM2Hl3VVoaQagcwF9/sCbBSIfgm8jcwqxq8ZNOxrXrJ9x9wp2AAAt2o5hVQwF6GsSWotekoGfyzPQw7aWLPOry1bHlLmbw6AA8Vkg7E3vgTT9VKwgYQzuVNyp9vRF5/Oihw+6jNbnK+9iscOzs7XdFP8M61s6xl/HybO4SlAf1TC8N7A3Ez90YFgJCefzd/ZUBn0OVLGM7hM63pZlbROjUNWKANRoWYYA4pLbyg5SfvBEId2UQ9Q8usAOXrwkY12kVN2Ki6vwc4aL2DdQAOJPe82QeLc+kx4aRv4vLMeuF/Do7Fc7eh+k8HbWWeVMd/XmT70F8kl3/Hm/rUKfLlh8/ZcIjEyv+6IolFrkaJYHEzVHBrmNGnUaeA+Yb+hysBHKZkVmaSFx6Rt7CVlioFooYjLbv094xKw9ZCahKRzcDZDQvmXQpinfJP5lBSX5vUubeuhcWk+KjMP8YcD+WkbkcB4pFivZMuknxKHnhrkykHeCTaakDqH52MUE1h6p3WUriNs/Ei9eVDKz6rjJWoQu4V/+MtsgPtCtZM7+EG4BkKH9sjJbPngun09Ob19yJfOYr+6deWvIDpKwPSYarmpJPoFqAv7a15r4iqc/dw+iPxpyfbLBa89Crj02hTiy7poCur02X4jqZUybS4rfTz6adARcsdyP/R9utoh/87jOW1Cd2dZ5NEeXErJb0nEk8m3xbfnrK37vGGC58IOzHw69n7JBFPNnqbG8M0pKB0A9ERkKqwCWqqRT7GN2SjV0C7dCzBjmqonRFoh/KA5eKwfvY9zvbqb2GrFvvEt2MsjQ8n5lvue6Rb43le9TwXVHB5y+iv05IRku49WnleBAOxOySVuV3ltaZiQ5EhF7SRb8iWNs50Tnk2IpYNx5/sxAePgrneUfwBALgoYckZc3+WFvvxIWuwfU7WGM5J2VaLK3n5sDMjsYcH13Ngqp4XfbKzfCJeGjb7yi6rnkmpQ5MHZJRpE6vktjk8H9Wy03dYWLKC6OPFptVTaWK3MxvTUsJcYq9iIG78IphOsbAdbJxsu0x8uvjUw9H3XrdMOYPpR3nnGHww74LFXmPvMZMUetCpQEqh1icQ/tGjziNKD80u+Czjv7owuix3Ac/Sd7mzFxq/vDeeGebA4NOub0YVndhVOr9MhPru3MnMYlSQPkP3x/BKnuMt5rfTO5EzOjx7ewhVuU/NV7GjaDcp8iwlouDsy74eSJ1f/1dyQl28EGfANnqJjwUuW0FL3dZlsG9rov51OB1arrWIMcHwzRqhmZjoaG/KjrFGHUIdbY7aHR7d0Y1C1E0uG+7R1J9u76LLs6ASBf1x8CtGSRn3EQ24sDLU+kntxG6GCCPN4tdGzr/VZWcserpohlwKwoILm4Da3UsMhFTcI9BRB1bDtfq7fcc6YWePrfRIAOxBOMqzhxnQZpYS9IVCMRa/HKbougZVYRS92Mc8uKHfc+mDB9PPjispQkGeeZ0vJdFRz1I+z7l5b3t6/8FIoEh+3Of4JNzy144nAGd42DOhNEsRsdc2EPeXK1W9zZbCHVr6A47iqH+a6xbcbAxN3OT5BQVUL66YUSFJwcrlu2WEAW51XNWeaqmCpLlcjBFgBhJIgTOIj/ZK7kbXgKYXLVvjENv1G3SfCbCUOfDy7JzoAlfKA9QvimRNDh2F3cjKjusFGfNMUNjBmgYkUswGKNr1O/PWZn5K5nSv3X+AKeI73BjZ56slLC1B6yzygtdR21ttqPf4fNL5fqkWgLlDCrDy+TTkIWnW1aZN3i2Knl9YSQ9Tp/S69ruMIPjiciC11HYXoG0p9xE4RRNlk12yhh92CLzxlgdgTXlUcdDrz4Tp+9qiXnGIio0TxFb727/qGdLLYWV5ytyLb8dv7OGAYdZqhDGshOw+h9AtQGAEWUskHyaAPr9TbO65Ey5UDdHb4170thNxUNr9ZfnW9Wpg4ejqaaDNP4dduGPxJ+L9GTDIFQDm87KiwGEH7JSJedR4U8JMcMyHyKnJtRgjo+dmH/LgQzxDTjR86hemO1IVC4/oN/CoIsYgdi/oItuYCgKXAER/kJbkk623BTtIuQnVHY+2bafsCTpr4hNfBcQbxnYwOpX7ikwGh0TtgS6egG/lU2795DHwO7Cz6Kr9iXk3fXR5PGIiyjlGglFAUtggVBcP7ujJ8v5FqvqOfcs6jKMjOdTUIvTfeCrPabDEiF/bjMO1/Bvi1y9T3cKyXplRG/lyDr9IsMgxi1tK6k9cE9QyOrY5uf/tZOm7jGJTZm59hBypz87Jh2OilllKdhWclvQcPfHz0BxSIBG0tIEVtvqd1nwk+BQdDNR3rniKUJgbFNuaLVnBPaDiv28tEUMU5qNtV7YoJLcup9tuJf1/g4Z87wtARIup4PCRRje5XagwdhewN2N0Lw+eOTAPdQkcOFYwdsYs1lKI/EQmKRgA9akDot6Lg9q5G0swOc91p0We1bMGNC2xpmG8MkF5ofmThVG/4Og0eVIhA3mYrfPs9yY7BKJLawfycjD+g7AJSRREVbordCdSjG0LCdnZT2cjx9L25achPjGj7ig5b+ysQSyThuIpOSW+rNee8DH0EAVn28/t4lQWNAc19xfa1DkrPMbehMECKylbapq5tRTgzHNa34AKd3yJcdMGHaIJYY31921H9xFU3s2OBcEiMt7E+omqqAHnVlRM2wpukq8PYNoc9GrWIHZzWYpIFs4VALWgded7CksWrCK1sDGT3UrLUPFRn0bzc6D6SAo1J030Yx3LWiH4Ue2QXApgM5OnDarklcL47auorzu7UbiE1swMXK1o6zrbl1i3wSywLY0s48uAJ5zZE8wvTMuA/KIDbzNnuNGgv/4FbhajQRWWwdiMv45xmw6BxsMTU2gelFC2HKuS74kgCHcFmqEAHtFKKAAAAAAPQyyNV4z+2FJnZqx6tjPMuf2Drz++k2q8OP9kL1c7qtZjtx4uxVCkqWU4+AiiMOdH8gNrq1qWYhmelNuLWAasL/J6jWPXnfFyBMQqo9xqCQl6EFMUdse92E8Brfk5CuS8vbdB6vIhBx4f2mpdrXmVTr+4Z5oKqYk7XrCUrGhVxX5kwWB/JG6CeIKW8Gv7iikABpcSzBau2d0syxD3WNSs6rE9R6qWaY4bmDfuqXG/jiK9ctjPhTC7Yw69qzi3v+J2sB7lMCEtvJ3bCVpDd3EbRMbmbmsfswIRG6N5B7Z61+qBk4s054J4JN9P4Qk6xzv4cHK5k2uXP7GQxHpCg4tALr7WjoJz4PcqURumOm/U5zYDp5ipPnz88cdxj1DLYCB3/jzfbkg2/pixXOTc83BX0lH7lJkt6SO0c03pU6pGxNOJNbSq5JSf/DW4YIo74XifyZRFlVY7Pln60SN3i7P78mkvMC2LI7k6ylV6uljRjYlUEy2azxgpsUU0kBCS25vl7uo4Rf+1jBMx8M3VOigbQ7e46m0k81PySGJhstSEMwwSGKhUHzvUV0H3UbyB3BbjcnznnNr6rgWmH5SC541F4oNjRde14rlfEvy804jYrwvurMI0+UUDfDlxmPK92FUDpRavjtamJjoUnTBYH8BC69ryYzqq7QUAk/U+ZYJviKE2QJIpYlxCNuFWYjQeWrcZh22jAxJgGB8LIG+B3x9I5ZFK4n3v/q85EnXkUEPBAFlPuv9OjfLpNoZiAPpg9XBV6jJXSYzUnvubRCOO1+0RuoviJiCA/CsAHemA7rGwJoKPBMTZCKwMl1Tq1ac4KSBFXOrkgCrWsOhQTtyj8Q0/+L3NEkrcOrj7eE8p07i27Lp0xOldvQStJpIm7v0KZAzXY8tPLFXsR4rlU7JJ4S7YgA2xM/DaVdRGTx4kivQfVw77b6shDM59TJhmn2OlFxwKc/rDqyQcqMoNEAnqJ4h2VhRaKGuQ7RifebrmFA9Fde8j3KBYs8fiZ2auF8PHlI0gP/plqh0xM76z4QcxmV1588tZi2WIcPhr/m4ZTPem1J/H4V9llMbL2vbqmeWIyBnZeS54MV9tj8z+CUUJfcNnN0Md+PDcFxJKsGW4UvKGBINoB1rEIGGcrJMO5DV69NxunOV5ixVGxnFau8ryFOQApfV6mSB/AAJmRulPp7oZEoBqKhB1IOvrW19fJ349BqJ8k0ZBoZ3Pot5GVSv7duX4iKTvXVSWpATF3msdn6xJNmO9ZT9b/IxlhWPLX5jQNgN40KnZMOI43ghZbUME+kl/NGFFz4VThLlbnxmVgzLNtUDjJwS2PIQFBDkcsGa7+YfgQq0HZpiyPJmLNn8y3wyOj86AA/faHgjU1EdWKzInjhF8octRSjD3oNNd2Rk+mLjymbBBaqx3qM1VsgO7wPdZoqqhSHE9r39VqAtZKfZpqgm4UmAJOou3TwPKpVFg3UlHSDPNaPY8MWEsH5o8ITKsAOCj0ixiKddsz78wF+pAaOEkNDmvI6OEpwXhBXOCB1C/ukDgCH4+BLb3dWW9R6lZaaz3XgV21umjWZ5Kjbv/w1AvQJEBvyu2xKcnCsCxxXk9/fXM89Rjbgz4r8z4LI68AveatBt9hwezxPbHQz5XqzNoRkAfGLLUIWRqMXKnST6S00yALTSrcmoa6k/sut1+7TdyxDlxINQ/uOl62oJouC7PMMB2mDSFXdbFea1Y/cDjSQuc9BSXj7k9s7N3Bh0rKqMIWsNebpR8ugef/mXzqerI+j7ACiPWVHPY6mqxPJAV8W8QZsDLBw+RAl8ZB6VXwZ2VdUexSRGP92jVEolF91RKL0d0Uf4g2PMMG3FJ6veTj4vbLL6wswkqAC9VOQiUcAXfQGL30uQ6X94yqU1NJ401csFa30Oq9lcQHFW+29q8gZKFeD+fj9AYHZiDPiSY+JAczyaP3J97+jW0NCwZN8nm8tiWY8PUa93OCIR77XyppkMz1x56lhNLD37qW014Jv317a6phmUONY0ont3KxzpKhboegwGghYLc/fuxExsonESO0r+IYHlzgMLR+KmN9i+QaIKJqktcPBa1o7H1ewMWScw5YRsRnzcrgO5EbblD17oUgDqycrdqBMSUAxZq1KOdf4pcZ8MPAWX5eTXPwAmrWWTbD/FOMN5hYGJAtj9AMt1dhPN3DUtsI8YWlJRweTSfrngrq4sGSdJmPtaMYiECkIo1c3h2GuqN4Rz1wrWeXwGU5p1BIvWWdeV9cmk5xMvu4pZXQQKLMvAEczzAGnHP6bc7Vrj+Jt0JQe11x3GeNrdSlikqOMLfxmPd+lVibst+vlcw1gSGLN28Kyyq/f82HsaubyxegG1WWSzkMfAayTBKFn37IEKneW2zbyhxeSO0owCaUYg3C4lVk4z9Rnd60aOcVkGQtEbajigq8uWJsOjdC4WeoY9hoT58QIxgjxcx5uFSlsfWaf12cGfR5lh2Am4ed2wHODoYGVY85eNlryzlDvCJapsA6rxWES0PLwe6lE3TQlIcrhJ6byDYHRyaibpQr18I4foCcqKUf1DymIheJFVCChKIOIRmEn1EwmMEDzXJ4ryAHIiOQoN078mElTNh4CqEOzdxdrfYP/N4WxobNCQ1YGKPVUT0QCZVERwNmP5WZmGZFrnnaxToYSSph0kqxN/WF0APxXH3GAgehbC5dEIvY9U3TetDdWtL3nyhppFlq/yl/DVVifxPj5SU2tDea/srquEKMeBenN/yD4j43yNnxL2dDluTp+UoZb/cEX2yrjAYwoisMnzLWN9OjzZR1TSCurUDZOews+zLLnG3E6Zovmw+5IBqIC2HeLbuag3c5Yc181cOd8HXowdZVfj4lxLLRPc12pAqv5saRW+Xg1zItv762XQazsvFysNTDRKOyLXVng+Vc6cvG/3Nn/Ut27JHXdhC6e32Op82b55dqVCsbOjNU3FPzhemHGe0GWfTcqaPNjPSUv79U63nSm/f6hupLZsKS2SELsM5R5k6UXNcURqGyL/UXtw6ZWwMIH5c7GXNArZfys6Nhxj4t6nxazClyp9n94PpqHCPXeAJm/zj8MOveDK/0e9u0cc9h0r+/2fvQd1XvD/IVlREaVR1zFnrRBTbdHfk/lbARuP5//5Q4vKYp9qVBYAHslLeuImfDDBYIpe55pAalLDE3+uaVr4wvIs2PSfD1tB43TywlEOX9ty0pY6RZc+VLMhEjZ1I411H3nG69afsrZiV6EI+S+VKASUQ+vNaZQ0MSpjUSTo6rkuMu5yJ1UFzNm/ItLl2YaCCecqTQok2QXZETLU8aD4ARpacZvu3NJ389B8ZJhIfolcX/qGDyFFu2EfN07qvkSXgSERh/Ur6xxFNfXWy+BEodkFU7VBKBrXu3i4/53eZjLwW7xTFVqGIdRP+vg11shPSTANem/VUGOxE+wkTpvkJftG0Cm1s8/XEBClU4McZ3BGC8XJePzl/UxIKJQn3PpoEl8nZzEJKT9ohj1QfpJsHfYzd2jA9A38Zqqf+aWoyufQjwDQHEOeYOncW85V5avIJhn41TSX2wutQSN0RyAFLDIxdciwKPaeB1T5TVC0LffFE/ZtvFGjixCfbIuWxajxMjyw32J8NCKa3HvTlwri0x+GHCKisEFLfrGUc1DVepO+UBSIAvYEI4p6rFGnmm7gyje3Fl1Y7bl6/uSkV32RoRxpvx/WfaOcY5t3JwRV/ASNCzF83hoELqSyjVgc95wmPyNArvY6ooS0ri+GMrPoiFtnrFTGF9AimkWPkY03Fd2U06y583WcE3tMwLoovAf3seDFDiYe4gITZLnppEra1HOqi6LfTuFx0/rX8K283XSVQkZb6jhaXvd5sxmZPMAbPmSOGxPcXw1vOM/qcxc4nqQne+x+rhcFS/ZwYAQhPtk/c7HJca7pTgyBEFMFhnNo72iPXsIuailELjrK/BY85+gkheoDbmFctUrHRXOjo6e26U2anZ3CZQseZsyhkHNq0DLAkmKOQkpyKnJr00lCijZ4l5LglYQOyMpaGDBsOKr4t1UcC7ca7Nr+7P2idkuYP9mtgpTD8cGrV/Oj5ECzK4Bxc44LGlyAocqU5OFzXNq4/EbSJ1o+r5COJbiOKqKO7V6dl9sbUDzr2/+D8YtOCEDEyqju71JfcKWjqHuolRsf/KxN8aiIb6OyxkwpJt53jXB73WD5lcBh8TYIhkD8PXlgHfsJDQmRCFAdpFD3rGJRedK5pgmpcILixpLtEx5HSCDoXNT38u3BZZQSH02gu2cEOUKIv68E0shUg7oJNL5MQEhzQwrZtHf9n6PimM1yZdTt3L4WMALoNrHvlRrp28VpCrVzwIH2zhBSmPt3q5rXaW5pkvzt0K1/q6PSurXau7i5jOBRROi/ieud+Lf8EqMtXJ+kQ+3DHCMuEKWJ3Uhcap154iLj+bn3RwLtuUoOWD4ihdaXiIudnVNelQx7d+Q1E0p49cHhkOhTCOovcK/9S5prOX6jCy7vMEjM8TSKJbKXGvsiC6tzLsFfaU/83mP10bVhIlPgeBUiKoiKqt/nj3y42snMF6VSQ1w43iaSFuzsC/opB10gZeiJmO4hwVqJuDspfFr8DjkPBAJ+JkC/z+YdRvb/QHJoViumqY+T4waNoGZPWEywsZRr2PeKYKjlDX8i2y7/6eFZMWo3jwDtc9TkU2IY689uOLefiyRUFvtk5b0NDUyjKvgQtsOTQkNAtEB5NmOM68zcKOtAfp5DuOxweQi/AnN/TORbRR1aYn4r2eSG6W38bY+TLav0+0Iaa/OhaLmfK5W6Hlbahu1rhiDjGoKHE/rBjg6gWWkd6S44jGpl5LJya749xl6HQS9P+HG/1ucRvkuPAyEuEQeEhnCKBB65Bou6WLcIK3NgxyJS64vb9uvoM3MCk/PVToPC1ano78TJnrAWehHaOQFk2LFczuhg7M3bG4832wgXfYiRTTewEx1rPUjp2YAvqY9jZMHyoHePGTC/jTF3Nbv9gaKaij69DjCLz0OXLvba5TIgQ3fwP0Wh0jiezLeLQt9+lTfP0e1MAQgr0lffYIJb2EdM93vwevtyVTp+yZgpwgUfZTi0mGpVZ5iHlzALd+leRdr9GG4UDFNekv5A/6TiMFzbLPGORmFOPxOPPfny6rZm/+I9Ta1k7YnEO3hQmUphUKG9DQX8bMRvRqHzHWX9CFoQ54vg5LOm1YMfgMTCWSxH8oJ9ORjXLTa/HlkTKQHmA9O27Xxc8ig9l+5Ne0wIRBlYzTEoh9gLrKAOchMGKM4Um3l5PF1uGjI0EF4hhf3rjU7OCS5IMDHFd2k+gEDM3X7nYCeE+Zzw0hVG4FxrNUowhhTvlyDW/wQFMn91eJEUDDsn6SIu9XIEarD/PtQKqqt4q21DXfZAmnkn2hpN7jttr6AH1f6Nu9i/ZRt0/+dftedMN7704p72uA37eXT7Wc1PqfjaiXnnND2HM73ndzts1iCQsbeSleuKrSJMQRIkJHuPcLaWQMrTswdVyLQS0Dj1xAzvOiDDpeYPtRFI3cwi/nwJhtZ6gwmzVEQJIkHN7ofZt3KYABXgHKHG8yeGty9uWDwWsWBsPFnCR6iRMepIGBETJYia9dF1klujJVqiLARmGzvabuYNU2AAxm4XVgDRWaGG7xgOt8uv1fL6gIHCU5H414hRKBLzBtGrRTbP+Fpb2qTV7KE3NugnpETI6dxu/yBqFNzsrqzQqnekpusuTAv60+kcsGHUFKTj8UaEWvM8kJBYIR4/X9UV8f647ZDRciFVHu3FV+EavVVn35dGlzN5Fel7hzvv5qmDaaavpq2jp+Xy7KHD2lB16gfoGPwVIm++E8vM0rJr0+ofMKilqKuaa01rIa4ky4LrsR9w9XvlnHBJl0RXfJK7ZOd9XY3VLTS7luLC2BuhSpdGwtBbsr4VdVnVGyZqbMqANG1am0lFrYXblEOVNd5lcIzDZ3tNO2l37hl7Y+QpfRtEx2r82MOGtV51NhT23NC2AsRiMCw7Tws7AmTvgEsfk11S6K6KKM7ibP+JYYEFjLmAmcLNDoe+gEbR5u4gprHUzpYryhFL+2kX/iOvDl7JaZZwfAmlgB8SlFkKi2ynVNBuV3ZhSV6ErQALpUO7Vlo/qtBE/Xfi40PmeMo5ZTZ//xWXDgL9+Ayzfo01UDvdb3TrKHwAPUtG8B/90mSLt5bqx3aYNZYRsiesJLtWTaqNAAt9ocof7tGnQItX9xQqemRkj6hBSFBFx5rNUbDQ6AjpwIPe6ccsGcX2pGGqkGkKrA5IfyGEGkpxgRpPVseETLSYAgCeacaKpCbtTqysx+zhRUfmZXKT3RNjflc8pJ2bQVIyh8tHnhaamhWhILU0H5t0O8lUm27VfsWEKg1zb6AfW+2J70YHDHS18PXEnEomLmDYkRpZCOtaXNt2zc4GuFL8iLDpIhmuP5/pnoiGOu4/0HFiEsBxv+CaZNTMOvHIdsMylSbsIpEYFMEmaWPjLFJoh0YZEqFIqyjvW7+P5e8vCnMweunK0X3nohedx9jgq9cLJ612Z9YydFBy/xYKO6Kdtd3vlMq1QKluT9RM1JkQhv5L/lbBwHQFrlDDazgb9uLW1mHhaKq8xIXuGgQKSC8Erevuho9SRCoZbj7pDur8HZJGOfdikKJYDsJdpITafTzx+TstTI1R1DIQXnQviIsbvHGbahq9LZLQxuuUrKNzF9s3b/CSNGx67XeWH8VSc1QOzpJurbJtvvu4nV/+rnhR5fjMocVQsRueePFXShlhObPNOkA3rDw+emhMp7mqs+l9PfLjCr2VI5ErgZQ3oAChW9kPTH2Hca1B0Uw2XJsNYCGOXheXAIPRYb/BDxsG6sEXt41uYWj2OyMtWZJRfDaIHq8ROk4Iew+BnVK9ediDp3U1CTZesnYiycQTpb3zWaArROJjMGQoO5RY/WH40LW2fjR3HGzlMPM20dnF8PDn289zf8z+AzcBG1VHhnb3V5mgljOoqp92ue7x/Z4hOcDZJXgc1QXY8Id/RyJ7swx3iu7bScFSEoIVNQyRKcIpARPqBgxI4aleWD7uUUAwSfjwJP7Qr3Bw6C5fyGrb5M2w524jSsbSDmILtXC7S6RkJbZCOQbTEjU7wM2x19TRrs//4rLpl4dILoBb345iRwVXIma98mp4ndOIPF196MAia6kiPo967SphfL54JQjrf9UTlNYVuu6hbx4FcXH82XgshxOfpEPqZ7vu1hCJrx2U1qPmx0KX7rXpYMpu3aW9KicUEeM2kX/iGDiSwJRO3YB/7h98ui8hGCcAXe5MhHiN3YP27/JS7feh/ZhVN1iC6+8bqMAyFNvzaB/MEjM8TSKJbKXG3X098uMffV3F0bp42ladSSj9KdWi6AFyajfe/eWMLKKgqub4FvBS2REGEZhczIn6oH4sX0K9k3ddVcsjbrgSL8mWmRMna8bVVz2otzNw4kz9LowTHbCd5MH+BaLeHwR2B4ATz3v89WPgaC6TMdOHChagD6qmopxE9Obsolzer+3eOBfEuvwfalCMeCApD+DWgGHO3PxiRuaYjwDvBvKNshkrZWBb28VFBrR+pT/QtWgK1Ja5fZnAuWOhaHsnpBbBtK4RZwn6mSQvURf0kGt6L7rXy3DuO6qq9BXPrZp7PuPZrFLPhpTy0O6fHXEBpHpxCEDkm7IYEl18gqTVXKmOsdttjZ45vYalNt1kOf4sm6q63xlaBpxzkjgElZgyQ56wzPkNoCCiA/JttbAkPiDu6IE7nR06RBHwvWQ0hJQ9kvQyDVYTwkloku3rpFbhkArYnG6CaNsWpkBmCt7LLB9plVQI1iQL+oxoWimSANrcwaQ/LuK8ApkOeVqddavNuX0ABUjHBrtLTRQ9tFdO/f2bz5av/uZ0pEZlLAPNzgN7mHVZ+BwJKqYrEBwBi7E49kGcVS3dVcQaYWwu+le5CgIopeFDxAZyydSli0MHg9FJMBLWjNyk6RLQVIrGo1PBSLbdNhWE1uWHzmuXhoZrwy8H0yCB3TiPRTvGQWupyUQr0KmfiLUOA2GnGXRsgIdwLWTwbUUJe9mqE/SBLZarWny9R07yMolHmnoVDFUfuWeWgDkgl7/CzX7B0eZYl5C6ZQaGhUot3u3ukiaQVK/E55LGqhF6YN9MEnM9pLuU7XB+y5Ia1KROAFHKwppazDzmZd397SFeS+Z8HoIWgnQ55+MCwkUT5lc0f748XE9S9PAT3f/n42W0tm3QAAi5gKaydphtQA2FCzjQrRLRPasKrIOy0SK/Nfesd9xSlOUKwAzCrMpRhzqxXbEwc14m5ktsTK8CFB0YoklIztB3I86N85La2PGkwHW3JE64FCzIH/3Rsi+Aw8RZjCAOzbYtoAP+brnpxaenvQq+L3rY8OSQQsTXJqZiSttlodfcvqNB+GtAz8ApNi/zpJcTTBp52PKxBZbRnf6+4QTGT8EX+T+ClpZOo8VokWKP+i/viAuFPNvLZqKE7WTxloT4PYPn6pKDHkCAbfspEYoADN2ol+jvmSaEgSqVUIIVq+Gi/8h1Xa8k1er0w6PswdfQKmkui5/boAtkr0xUspLWBpSr2Em10lDbChSSd0x/RfajPZjdt7mDfo9vcmYJ6hLZD110Sh6REX+yhdBDMaBv3zISpaXQFoGgIPv/E4yhDzU7jbL/LtwSMpoqG34FonxjdstnYSFz+z96EYzftNiyniISIhRyI8nAoDpUQV2aI7sN8x0JlKaj0+yeEyacS1gAcJ3ij84xNvpFSIOeSjvQXSv854nN0rZuhlsVxywUb+4AVNvuLfQp7CtFO+GomvOY/lpJsJ8Kwv7XphzejDa7eh7ycf54udRt+dCFAeYIsKqA+Ph/V+fxDuoAugXZ8PpGSqrwxfOval0Zw27vp+9gwsAeRS9vKPiRVI1VL8IBisIAkdSD1dIvEspxFanMoKS/SpDd2EWJ5fCazD6+B4pEsvI0Hi5bvC8XDZdMWXZwSKAzxwGg3QfQTUHCQ0TwfvHZbKjA2syAsdElTFdXeYX9ObC80CPthZZLp11bRBRbL9ILVSPlkVGyRTkAKgUta1ZHHR3TXoPmdNlhTbpd6gmke6S5dwDhH4rooTruaLfKFcjjJdmsWYXQ4lXXou+ROES38DUEptvxOKWG0vF6ydAS3JfLOtkqn9Ft68yD5x4wwOQ4JWxQrMOF9w5CSQHoebMpYGydKS28uhJ44aYwcxq/nZh+Vj4u8mHEchu3q7gGFFxVoWLF5Tb7kfFgJifOC0IHOMuWqaFc4OHw7WjfKpMFDwJaHyRnZiStDDym/bTQikq2U0SxVL1eMs3qP3KPvbNceGIdsW2gjH1L/ltMlFEaXPGYAO4RRupXahgL2SSXbcG652vBJUGQ3xp2Y/VcoxctWQvKdpwBnOmsL3M5IpRvverBurD5RNJ6IQ497lHA1+7oXJkm/ha1/8z/3H0DNPm3w7LE1ztdu/fULZUoXAmKmj6NAJm1neUSNB4Khy3QBUCoXXDc5McFcOwXJ/k9NTRyeDVl5Ey4NkXZQjEOCcX5XfnbfEI06eaf7KIdKmvtNeG0JYPYhO6EVU4S7uI9vFriZE/OrFoY6g4b3FMstEytx4XWQoTTNjeKQzb3zRK03ULnhmyxr/po6/7qLNr2EBlOp5Cs94gT6WbotRmunQwA9pSjYWG9QGPA8ctCsvOQoTskGT7lL4vcY3n4PuplsIzBH1uHhC6d43Nan337iCjDs6QfkwNsLlpl7feQgYJlcZJlRtizWxSGPFRPfA4M2nL+CjGi2uQ10tp9rLr65krVO6xXQ+3cgu7Rkk5YCvKNhH8HsYFxV7osWk5p/WsHvVICHEiN/aLN6ed3TnkI6ceTjvMBteJTW2NrMRVHiEiPoxa5RBs3z9n2rf4RQVjQutzQ65QWElQl1b9v5MsHBAAs7y/aUxBifebrnUC4+8WvzrU6RbPJxr2/I/if0Y19MQH7HKsnth1ZLn1gX8nZV38veKhdz4aGdpiYmA+CCr09NzRzBUYus0PX/bLBUxuLL5eOLWd5xRICHNRCUGb2+HlV6b5iRdmH7ZBDmvHoDcd+NSYSfnc393FYSz/5/8QMM00Db7bR0DUvD7cdWDgYWsnR4Ub+Xk1R/e7Fj+j9ctQZkQ6t2fxQlsjCI2qJRRl/D1K1ns43k74r81UWh/zuSdwRNKbUWPak2G8pw30w2zokqF+cqNjca5B/RD56nQObmBaP+KF2rqB53XfhRQutzACIH4Z2FllI1Bqx0a9QMT9c6GJmVlDTAiUbIPxAq/P4hxnNypUOoOUwhfPlnf5M70dou4vP0lSOer3qnH1A1W7Drxwc5SZEtS7WvMqmq/DPLZpWchXCRFYJzE5IoS4FDIXv5l/lbP4IK6xQkHQJ4U9cAMwHmQr/V+l8Swol+uuJI/pRXdDagpmb18spUwwRLwMfsjMpbAb+hdgAKJ6AMBCnEdFYTpYRbz6hBoiad/3aa3XAkwVo3SzGHGBjbyzw82PuwPYLN5y6a6127zglJaHUb9sqHclNaPEdem7zeLTplLYQHs9/Xrg93xmk7/1ue8Yzum1DPPpIqlYaOyJgqcNj2+2dCJcm88WEvSnC36zwepzphh9HU/VIqeAtaBbGE11MJY5k0xsFWBt0SZxhwKpjA7ZK80/vVXTMNXEBqBfbfjxbevIkLzqzI6eRbxtodf33SVT1rGoFz1UqwEN0Sybi+wxI8ej1ShfFSyjiAQRHSv3lc0Due/rojLNSevll16C3IGP9CCooDsrYO/vsQLbPCEVFqb8virmzLJon54jWcvxfE01ds+6Q2OhtkvfmdBfLeqVghJgywv9IUsT5e6x08r0DSAcvdGb2QtgPwuFipp58g94Dwv2IviXpu01fqqN+dbKAYVZCf7wms5rs+KzYV6FUqK7MU9L9uafLSjiHOrFdsS87xT0MAAPcQpsb/ITPbKuPFM4//X9fBjg+GaNUMzMc/9e7m8xaNzyaXobU6Fau1GHrbTR9gHKeltCLRIXEGMw4HbDPWUP8irQHmdtqUmMZn0Uc8iCZ3lfPEzFyh4A0s5ANl6uRp6/Ctc5jkJF6NEkimLgmRINrD8yfJIEhUBG/Q49B5Dd0MuSXnVXavi60m+SllCbTUS8QYdqjjNjRUzXwEIXQAg6f2rMmrFHObPqEsQwKL2O3nQhFlIq7tr0SSUHSVkkU6ftglHb5tJG2ezuQHnTtJUOf7qfQxeRwC4xhD8FDKzzKX+/Rbt6H4zY8AN/vii5r6kTe3LWRqMW8nFnxekHtm9UNiZwj1q/L5E+eUGauP4CsU3xMGLKJRnp9UiaQVQ0+9nMKNtXKcdEt+Gjyo61aziNy+4hO3GbtPeKQMBQ31aIod6n2xBZh9usMIiKmxZ7UOqJnV3FGvJqIAajveP/VYZIDQ7snvElAZGBBRCb+B+/hEV1VhcBSPuOkwAY1659qEDsljHEEWX8upsPsrnlOyphOqm4U+C58iDP5+d2qkmMNOrnIfz3LPcJFv22MSVZsqQYXpaxxLktwMIYmfVXoqJQBX7NRFUDynwh0A/04Kh+kBkH02hQSDTCPgQSkowZLb5FmCDfuQNEcsSIcixJT/C+ktp2AGmBJJNGOkb2PC/2r2kTpETboJ3LABGRdr94hIRb6ALx2abX/agLsYRCpCmaStSXGVLg4y/QQy9YFLY6+phITvEtz+CUMqV090/K27G+zCtxPbzm/4YuvcZefit3sItx/JDc+nETU41bDVHi7tFKOk9UTu71Hlo1SQ2dNfNR8F6Z5KrdeVLtck7mBBwF05BoLFtHUXvirHgLCYV9E/oIIMA1MVhXr4mgkzRxOC1I+xjTp7dLYnigV1tOB6H121Fvuej8i8UxfHR8BDgFdwlQAloh+bEJaqwh81iBBG4+6128T1ipjMwGhObfBUvymm4uYzfwJdPfMwen7b0ad6BDUrufsjYHV+Ju00Gyd4WlQHlvd3i4m3WtMA+rKzJbqRlghEnO1c1AeG7gnoxGP0bU+jKBqREQnoGXyYlteWiLP866le2ml+1nkNX3iGKrc5kWui6YpFdALob9e2by/4OmuygeAcyVNE7uNoAzAajH1eXDeBoxWdI3nB4miN3braTaxk+7Ofl8qiJAaML86ov/k+Y6ngGMUkzm6I02GfCwP4ACRtvLldwpII5wzHLWLdyI49BkXHfme2UDOD55rVArS8mGe9tH8oOeTu24S/aagYUG+gbWQDY6T3EG8Ww/tvVxWV/uzWL5aqJ4Vy7uH56FyyROFcZVUKk3uBoE2klnnwQCaWMrcWP3fH925XELmjWoFeJe/LQDMJM/THifrnjW1k5gvSqr4YAJBrrjl6lvXxzvIHpy1FC27UM26lESXtE0VoqMgpVXJXUv+IrXYG/HTHPxU8WVSx74Wv1ckFhEkUC7g+l3hopHc4jBdJUirvRebzPQZT53di9RfZFbPDsqsttFFK8CIGbzHu/pGeLFHWSlyFRcWI1Z1UYFszJ/Mhg9/EnD8jGOw0Xu+XQbR3b76vjneQPPIwlCV9bwjbJUpb38oDw3WmuZeIzFgZ6kTCHfqj1bZCMn6KIYiXQ5Daad7SzjuupYMDRSD1hQIqMbiFsk83t53leZdT88q8J3QcUjFcYpYv0BEH/4YxCiQ48wOlhcPWV612U526BPC51eAXWXahgaduz+TDGguYG4fjYFwIZU9Vw9oZtehUeX77yUirCVptHtyHFS4dIGaTS/5jzqk3WxYt5pRVxw508H6td+8AZEnG56aEzZhegNdaeklQtM6SDjRgmqsscCIvTjtP1ejyEVylnlaTaZFPGozMrqtlbBtdps34zNq7aM2UtzLXxYX9nFzbsUTEsBmgptucKzHW2D8r/A9oGEWcDw1JPSs5B82WpuGt4uB3xQx+e0Va/qg0e0/mJK9x9cctTnat2szgvHQ6x//PWu4MGr23APpwtXyn6cC+W4hQ0umc+c3X5axaZkdMq/r8HlWJIvgJs7XwtX6DJIGmcLKGwvsS6rzdjej6FnjUCcIerzB1XwKRKAFn97kXnevvIUXQeyjVkug9LdpENB1lkFYrzLL1605j0n2pFRuXnZA80KdHQ97mlPkpXWb1sikcqBB6U7XlXLHsEa9CqUmfhERLaywj6ROedKn1Hzt3Kl4sdAKvmLD+Bu92cL7VR4GBi/MSBekj5obUnJ/+R8LRqLBQ1Sq73jgifd9VHiyhh9z9AqADfedHcLCff5Gliy77CFzQqepYNVKZjIA7VQP/L5B19Jd+IGp+Ivp80ngZETNAIuM9RiZ6fSXXFWIMrsNGmCIrSFBDUCYkj5ob1uZyQ7iIz+p7JKqdbMMEaXWCmqB30A+jsT7XWwSN1Ogve5/jFX0nsNtUhVRH4bZks+y3uzPgHpMvtOEmY12KzdA1PVoZ440to3vMqzdmWPMeTh+gMCj+fr3jGHXFRXgMEEx4FnEdjU/EUuV/jqH6cKnVKtnkIRhAx/m8JpZYGKamxirboUZK6TAUlcDEbLRocQI0JVRt9tohX3HNL75UAPYpSOz37L7Y2jXzXwjp/yph2TrKTDjDrbvj2cMq8QRENnx1ts2OjNARH2AUKfw8ZJMVLGWuWNrglwdvpFYoGNd42QvLLh831/dpmMhd4XPSV7mfi2yWZOzxMvFBmgfoRbltx3h5QAnMKZM9+ILLwsOBVsdKH1ZwdYsARuXksfg046Anp0lV1wFrHo3/WYC6UIOI5aqoxgjyD40UxX2hmZEakJaWKTuDyLEauPHGRAQZbuB8dCt2N8ha9r2lH3AUxV575pjLcoraVlVsDdQV2ZTRi9zCdmgy2/M5lU4sVDQTsM6A2D9NPXeAkV+xnosTQfoaN/HvkUm01MnTPVf1QBe01+Rvj7ClFJMrJ8FUEZmz10+Wj6TjBg+/uAMtQbb2Ul3lKhw+N2oRI1SPw3LBzuPPW4FBuppdG42j1VjlGuG5YT/gaCtns4fGy/zXnaaA/UK7YZhp1vmEQf8+Rrzpomf8A1hixCbvc3bbHpuAhLSCcpHS4KXkq7E7ZS/MvDN4xWpDztgXCXW5AHr65NIIo4rjk0s8d1+fnG1iJt1l3rwBwif6C6bmYArhaT5wPdtbDJpAG0dOXqenVVfDshbkof/5Es3mJnXcgNXYtaCPb20R4gdSyLDoQMuPWx7aHtGZAARkklA6QPN2fhcFECGIohDHGUpFw5jHTxZ+TDwj5Lf9lV/LCjIFLFHw25TNmnKXifYoasCEHpSOAAC2oM5WCPj+YpVWRKaodPYF3bCYRIlpoFOeon754fuDo/fvJtOBq3STrNaRcyuufRkCT57enELPz7QySo+XC/5qW5NqYPnJhpmtPwmK4o05CPhznKmNND2GKx3rRU4YrBMVqEpGrbsNnoE+FH0SFloBN5NaimDI2nh6jfTI/+2gaB3s0Vx8hzXCGD5UDslgp9EPwJh7K6s0JqNmkcP6exFwH1Xu1/yFMYiFU8ZvV6Jat/4XERH/7LQwLFgKZ5JrLZ85YtLpNwh422sDtNEKZ8P1X9uBFCnVU5iQbeC+59h+WyI4mV8IAUGPoVAtFBGLSqoVVUwvf8i+PTjrz9T5/MaUiEL7K7YQH+DXZDg3IOUz6geydWbsla+TvJE3UGDsKs3Z4rlNs1gcL2nLuTz3mGAu1ZMYeqjLRTuH2rdG1MgDbV72nFpDqwgWDc4+cpaT0B/ex4MUOJh7hesKbcH2u8dgVIjxi6A6MIG3LQ+Mhdnwf7Xq9RS6jdEkvPZ9FVWuKFqQJVqQNMsAAKZ5qg4x13Ex5Iwi7MOVyUqgVPXX3X0QZKdfh1d6KqHKo9BlXHY9/me4bPwsztKaTJnNmwG1Gs99vVpmKmJt8CsmA7lW4JQX7TLCAaX119AjgUp0BIP7jdplx4IfC7KD8euMrkkFtYAox9OjEfO06KIdIRf3bOR2p08CnvryeS2kF8Mb8dAYpcHZu/9X8dfgdiU4u5s7g10jqU/9bBUu5nyn0g5nso8CNrUay9S5hHUW0z/C4QQgMvM2liopCS3r6elRTyo1tdkLiZaVnsCp8Oi3UNKeb0M4Dh2EjiK+e/HwPVecVBfyo00m/qDhHb6q5M5PUOG7QD+KJ97YflIXc3tikyvjTFvbPk1FgCbylT2y7IFNhkfF7lOpunsYG4LPBhEK7zeDn/QLQkOeQK8rj3OHqLnIU4oq9kzsB5ky1fb6y7l/JyIg6v5RHzlLXUJCJaulfYa1baU4W7liVUxRmLtgFq2Isfy1SdELE6T+jfXgudygvzM4lkgAAAAAOwWuM0h+7BXMAl0b5gE5HvHKQnuPevUuL8VrIJHfiRzpMoYGUst8U9iNpMfdPzygkSi0VOm1FC1Hgvnne0BD4sP4sNVsvwktBmyniP1ib+Ic9XUwnU6RqzoAiKVMja6VNVUJjM3OdQEijE6yU2zF5IfNRfVq5hlT0O9QD0WEEQkmJTf2ULoXa6MV50JKq4AT0C3HdrhqgPIu1cEuOnNaaYz6b4xH5EwwNbG/JmEuzwPss7SW34GV7+m2Bm3ePK1834xT4wu1w2ggZcvoF3JJpD1/ETp3ypqE71CmswdQwqxG0pX93t4w/HgyKt9qT42Ii/ks8g5LTExvV4ydq4UsqnhlWiyxc3pIKfVP6MQJlwu5WqN4K7Y/mxWJXlpcMznGMkvYAMUDX6PYQVRIICobz04WoErkr9ezAVFEK75tC20xDmbzRR5w3Vh7mub52ndfhHceCpFaQzBk9ooMWn6QO+ZERfWmUYH1Lq6LjJeJX53zrYmKuJY/hztmIyWjH4zrbeRRsd6KszkisqD2ab3dZqBnbW1rFo2nUkC199Xr2qmqpd/OM+T1v9BupZ56BecvimniS9RpucFJc+xNHmlfsPJhoQH3I4We3o+zD2QpDSyg3EcGUDUSgaLiUzZPSek4BzH5ojt32QCnYVDOQEVWR/Lk5R5GXHRZ9tmizKnWGMbRGLK/ic6/N+KqGea0G14D2RUkkP9w5AZag86VDyM7P2enKjX0dUfMUN/01I+6HEBl0FqPz6wD0EF8wClxsd028h5E8G33U9DckK9x2e/2pcZ7bC6OVdpYan58b2vCsHpxIKInOk0Zw4yK7cvynGtXhXrAfajLmFdAgYHpH/1RkS3Tq8jdpUJN0CaoBEIl3iRoKwHI7Zx7n5AL2vO07lOnqEoaIzQiEZHtxCYZM7Yup8SDU9pmimajFSyF3uQNqfbO0qFemGBDEDrcy3KTtht7yRmjNZNfRVvUggf8GpYpXgDnoAy3xnDtG9bEmmWAGzvlLMNtdWDOZN/9RzLK3A6dT0WLgEvXFXdLw742OtBmCJecazHR47ThJiXWoppxZgxeNAygAlfTf1utqe9fzzfV1mskUvxui52csG4JV+OmJ8WSP2EOJjJcT29uoUa3LqVJRXbXq0JntH0Z9hR85sMfBmyy/32ugmLPsl+aer97xJfjY5t5GkirwhQh3fwBscxIb6n5M6usYsS/lNKUgq8ZUYm/IMdGMn72wC/JHgoVRQJLGFKl/IAFIiPi74Oi+mxAwpa5ibeO/DUl3qY80HQ9IS1En1jK/aJksFxIJTx/AUzCblZg3ghSH11flzb4zliGbVYxLdxWQjR9jQk51R6zhl71T6U4gfNCR8GOYyccwNwOK+VCDlqBGt1TzfuyXcgmp13AzEDOftpVm3PPM+CJuw30OHbs7MsOt05oMTLTkxbrGV0EAP7/GvGOm60fcYaoITHnqTuDEnBK/fMy5g0J2zk87+WGc3w31z+WZ6l0GagvZ1J5IwXkxVLLhGRnTdpFizIJqLvz6hOToZy2lrLyM3un0GtpLTTPCN4Zlscn37N9tBMd0mJjSqFujRIUu3QUWmzS7HzO+oDowiqO1O+9bt1xYhatXVNyh4gPj2h4cesV/QPRT7QkHsnKvFQt/3sDp7V6OKDbLNkqKvOjMzpvw+tHlhbpTd5GgSJWfB+cSEi7a+lyAeTXNGCIeja6C0ohMEQS7K/bEuBJ0J7T0lTVx/decmLK7hufoS5BtbExyTBxEkvzeQvREhqYx6Yj8snGQ6tycEDrI5l/k7NNMsGSJZrpjjUXpoIRxZAtcgunSCD6HCq+upY737pkzISyd89RTEPF3+iAv3aBRXTCyjXibw3RNlf1tiGsX7J10/qYJJGzuxSTm+ykA47AJJuz4xKH2SsXk1V0DuYFsnBryMDCq31H7y4ucvZM3JJZHwREGNyCnPEfOIV6g4cY4j8hrcrHPpxhF4egy3w3xioa4rbfd38XykGBENCuqkSVn4iPrGaYYavyqC9glg53J8dgXYP1Cn5RlrQ4092/VCMBRYYoGVXOdP/7BxNO8mS4DHno9N2wJXAYw6SgyAjNUJl8rTsgOb/gh+vjHavj/bN4s7Apb1zTSpzYG/uSt1lnBw7CspCrJQ93bdxgJS/BeMEhz4glcxvZVmWCpzbfJZgmOghIJHdMlK5lJpqcnG1CK6XMLH183kS7TIuF3cAA3CitIy64nSBBDBiY7Zpd3izU/LHWveDgVM4jKczhmFYX/P0giWR5JmYtxxBc57uhTpnRfnGq2r2pikym0JSTGyGEf3buoey+vZpjdW8jRMf9PfSRHgP7tkVjLwhJlfs76/S2etUXihcnKvqoGHWdpLn/ogR8G/ripeA1AtubqAnJZAkZeg93394Mrez9CbFRrH10jzbxsSb83eG8+OYT9APvl802XgpS9J5UHDlmNNXwc+Vm+cdT3qQUeCb/HNW6GgNEPc/9NZJNH5ou3ZCEAJwpuy3HUb2BJiI+agYVFaguSgvMjzdq5Q3rr32YWshnNH86ahdroxXnMnkafoEXG586pRctvM4p5ffA6yPF/oa14Ns9xjbMeJNB/V+nfSSoSPWGIxCqetHxeYS7+udMiXrJyq4qnvhlyjtSTMlO66dppWH0ky6Unej7c/3pmAt95tNF04k6avG+Y3qsYeMd2eGH5CdFBc2dciDmUgS4EBxwjlgUZ+u9hzd4QIkfsDLjhPfvnrELBqU99e3bbiDm6BsakY1rwHaq94IlW2UP3et1uLQr3QcZlscn37N9s+pw/KE1TjHR5vrGQKScUnWp5qZYbYQGYEAV7vQfaZ7x53CkjQeBHx/TLsQh5YSgH4sF82ExRxntMRjViQOiidiPQALlfQ4TvNvZxjQBDmeWO3WA5twuxA+5Ku44gPEhKwcsAORMaL0yCckclVXF00WEXBJnnMchteylbEQhGtOs9Py7Jc7C4fVNTy/XEJJpfXYGI0vuzBMDXPgHsgmvW0AMiqfZcbO73OG7PErE7gYgyA/ExqxHwiqIMWuVSOK7X146eN3c4PhYMmsOUfZVDSiP/cKoUBUL3sm713cQncJ+HdPJlnQjskSPyCvnRGKhLJVkUfXE+h8umBQZWPYRyVKbz/NuOO6L/2YBCsyMRrt4XE6/FDKy3Zcgf/lpqQ4efN25r0BQ2FGFpYbdNVy6h/g4VEq/GZt2u5pdjR3MxhQP0f/yTzoLyGkJdD3a3ksvkZcgVnsW5V/v2bmbQct82EdjxvJTwW93TNB2eHwzceD5423qKpqZTmAfz6cuuUes4M9NhMfsyPwen8ClyMuObJ/6uwIz/8GbNHfepO9+5//kcH9pkeUYU508cAWxNO+5yd+CGdGPJQ+UM7VzsLLbaOVl5RhLY5Fn1yRr4KxidvmmitDTo+Fy1K4rHHPLjOpX6f3wyrqtmfezhZ1QJNcGiBTZ1ivNYWX7tD5bpNmtCnZ4YV8P+quZ6bxWEd9+AacP9gLGbmssoFOtrndTBy8n7ZVbTRQoO+w9BmDLXmz/DaOpNAuUzof/jav2jWNdKJ3GoEcVcvPQ0QJH6pnPakmSPbdKQTMpSInd586L+XkpHyPfwQtjZ/gw2Li/OEI2a5eRCKRZQEG7NAsfPOWko2ZlBRxVWjql9S1mkVGHLYkd2D1x4JnmAT58B/z8oB42uOP4c2QNEHKtvBfs4N1KKtrEA0DUUE/kEXOIsAjeZxvWDEgNpok0fIzw09LF+VKcASoMNwr/jcpzpf6XlszqnUopca7BRllg6Oz20dnn8feuxoxwiRmexkKpu+9OGTNzhmPA2t1KrEgI1b3WSSL36uTktX8epYSxvan7smB27DvQT+PeHokIjT7JP+2kmBUZURMhPwZnNK7l/x/bmsfRH3dyKZ92p+pDuquff+iW63k79zPJlIqSXtL69ESYTY7Zi/zU4e9An9h9F5y7rX14akEE//ulcz6/e3e6gphbrcHclhh4FsqzKSKcz9XBNhY2EmJIsjupWDEICqoAGdhnNYTdMYlYMe6kJP6sJzrFKv5QyKuy5eIBGkvW/3RyQp5dfC25VbUKl7L7+kmSSu8Cyd1hMX+EW02OJrXscAyS+Z9BTPFMQZj5cKrnfFtJ96ZSsFKxnxpKkMAECVuJNOaB1njACFH9FHjjkomy0wNfBBGstdIyCUd6DwII7GZsuoSFeeo9EfikzAYThbvtAVw0PgWuwoDhoVZrULfJyDw/Ml0B646XqJhKyrdUV+CUj4ABAsq3vVy2+E+pZJiFSKjRPDh5FUc2HtPk68hAWgSc/S1KUGjPXVmEGaOunIBwozJYSoH4Jxsj5jfiwaTbQjzKKqFnXeeTCRONB1+ulbqn9npJUdWHpY8qVUdEDqmzecNapxEqFeCYvdg09o922ead8LFwDaY+VmPIqor9cPyNKBdNK3bIs9xTXlIETFv+tZhmr1U3YN/MGDQu3N6g5bTBx/ltegKTosbEmLPvI+amzcIp68kH+6ONweredk0QJlV/g3G7SbLsc32/Zy0mIj6/GDUnXwCShC9df0uEuFgXfzfFMQMHhDpG3CC71QCImyiRxcjIiJDUxyQ4gH+47vVrMu9yY6blVTycRDV5C9G4IrYjUJa1JywAA0eGITcJuNtetwA8Vr03+0Ekvu6G4NfktC8hgRfkbA1GAaab5w409Z7xdQZwwjoAAAFOIWnWaQcVJDz3AeAU73T7u/JMSwCMRiMRiMRiMRfPkirgmJgPAGF7p5udziPwyVSOs8w8sB4BUF6Ifd7qlyEHrXFarUyVqZK1Wq1Wko7+04nt/oAQVojc8NogAYuBvHyplTl+FLVDn0aEQ9bTG09TyYWVxAmqAM7/K9G+/Gf+xqrJULjApHslVZJFGSDVqfp8mI9vooviCd+M2cdiqL8cz5nQjqTmh2ksHdcNYb40sTCCvxOGNzETwcWeaXfbDDWHeWkWND7OYMfJaamJKPnp6pXW25HVVTHycSe+pAEvfn5pwthaRKM/K33rbLHhE01OOSi+mO2+6Aw4ZaKolIIWognL9z8FwQmlp1/JfQ3jsP8UDIxsSEdMvleUbL/52ol20InXdf5+UexDLnfeT4R/PzmAQqAgCmToAmF4STp9lrFf2NWetWKxOQHsjwhMwdEIQD7zjNKxe8E0qEUEfZmsdW/Zx8g3a/IjO8X4MBDJ5zXf3gJuKTIUQ55nxwDwKd0lV1yQhJSx9yemSjrXFf3bje4uqGrYwewKwUld4kZKvtP7DTtE7sEVx9ooQCLe5knH83sS0T8lRimfb0cGiA/8Am9qJ48BjY1GU1cfMpMhR7NeQUA4mQo84/506V0QmM94YwOtPXb4CeVlKw4Uo1YovDvhHKk1p7+NEsuF4Me9CjyMAAz4BEybTPy9qQ7V5s9bNK+jnzXVyxtqI7I+G6rM4MZXqgy/oH38lunnPhZSHLdjIvsrIZ8zF+hgGBmDpDkk8kpvqaKymkKGI9/kkbW9OO0tqjIYPtetFrQP5XPgSmwL9qWXDa836dDr+B+OoWBRhhhhNSiq02CYic64UZeWo/NsoYGAFO+rHh0bodlOzRZFjJF2c5OvjfCtgrVOcYAgHvZh0M5pzgQmrXeLtNDKns4LQkuyIy/NLoxEGBeu/ONJEnmsibcmsGjzHSZ2JbDz04/Q0yWti5XY7G5AQAAGIbIypFUDLfXZ29kji/O2JQQY6OEgdPvDt+H7AXjh7yTKYSJdOlZ4YXXygmiCCtO5D6HJqNLl2AuYRhCwT1CAw+szS/lMEy39hBSMTei1dOZXvuHcDjh0Wok+qYwerIsUjHQyPQx/28cxEk+cgaogUo1cX7BsmzYxh5ciWicBrz7Bslptyhqbe61Y+lTgQSvDBoaNwNybAOFPdzgXNVgpJ87S9TqwKI76+jpNgSUPQKJspC0lS8kordf9RQAPvrRJtKXY51/qdwEU2kleRi1xKMxZ12i5CgBKi4xSPfksDdg4BP7Yx0z6EcXXNKGBDzISuCkvxjKv4msAhmhST4P1Z9FZSgagBBLWkpsAn+nFysJ7H14VbP8JWKXkTRtLkTRM6Y7ECZaqCph6E1wiD2fw0eIV9BRxfAwkRwgRKD3vJNrTSDkbKhsl28azUyhd2vfLBpg0TuInxirR+RM1f2AHEDtKGK3aPihp16KEHk2eMBzKBa5tvZXRVdicfvlyRkvi5ci6oDwt4oCtOp8ouRoZbt2+PYaFbLBobCcohnXaeRMZh3DJrxNePsQ4ivR1kCca/jzawi8qOvJj6cBWh7iSxU9J1zVfwLmZkOEjxodl+xox+SI7sbcDy7l7Q5v348OF8s3XNypuGNhtw12Qt8HTev9vi4uSTk7Pbfl68mPpuGfo4Uhe821HRMJlL2fxicIhUm183eFv7w0UA8t1cEj4moRCdFaWSAilv9eKcNCaUlv4wdGFBkGrQLuW8ORZq19Ja8xYGl0+ueQYfTruOGL1OsYybDHaf5aFPviPoo050uQGcuv3wT3Ti7UBB0YY8sa8LcTcAnaqNXC/7vN78F/fGZ4X+/sbzI8cRpMvX5Sd60QEy1HVOWE1mmCgHhha3ErXwyOS++tU6AAKXOw/I25tNTA5lcaidUbNASXxymPIfkMumXCnj/hx9obvY/FCa8qNO/+R3qIrbJapgYTN7ceaTUranr7g7GhRUjnRNWoO6ykeeU8GrQ06CKxfafRDtZTRDdclhn44aC84ZBXhA4OJfRLrxgMJRHMp0XHbtm/GM9TQJ0crSVY2aUaWGGY7wCZII4DHCv6dtkV1fg7LOYKiaG+frWCHPaAzvPbhi/ZUrBeucS/6TssKDc9GThRwbL4ofaGBaoFL3MpULQ2cyja0hAxkFtVbWmjipA6QUvS/XSAAAADDnAakdfpob11N6Rw936sjkeCVxN/B235wpFufv85ftTGcqaDK9n5U4g37Fb3XwJH7B1XsUKqc6SO/PA/joA1y/cRnV7VVnmZZAOHJvp4L7NjiRGnrnxskyp+IWyXpuAvz56J6yEGg9172yAtH4zKB+QmTLPIHNlpElMFDNCQ0do2lJ6uGqhEzzJW3EB/SxqS3J1L6UdsW8wzYml1A/xniG+PEyQZ1+vJA/reeNP0FnvK03DSdrr6u6FZKl+Gmn/TaGEEKjP8WgC3V942mVvTRk03H8ZQafzK8mEtOJvX56/ugRvZ+4WSng8rZdrfO1SBymQjAAAHgTyWtuCtxNf04Z+GDLmGBGc7B1f5l3cHjQhBvjDQ3MMgCk4vNlSAcq2T2uDhYILZKGbPuyCc7XJooJLoN0wkWXcJ6v4bvZUG5lJkIA1PiDuK21ZM0QKqU5qY7UEDzdnVyGnqzUZi5+IaEhkZgzP7dfO+IYhUULr3tp1v9k4xw9ry4NyC1TKkkmdAPrTwMZ/stGP5BJFEzzJJ60qgW08JCCS2NDEpQncmD3GnyYVGneSQL46tx92yAoUTq7COXYVs8Kb4XAzBtHMlymGttgbz0xx1hzr/habEz+PTtL5hhVfHo/ZRSq4Y0X45f3NY2XTL6QiRpwE/8AAACcPtEXoEVpuH6FY2AGI++TVKFNCYoAHc5wAAq92Jhgi5Rj9wF/tajZgE8fntyAJrcto7ggKtvvWer7J0i0TXSJczKDFHknh4negqxgw9CpERnCq6St9YoxOaMTWB8K/3wAEMVCrG1vQIIQVpYPNWaoSClIJ9+aGpsuReZFCQl7JRXMoBUZsFQY4vkDVh1+gjpAsH/3paHe2FKGtNPfdY8GnoQyCLkaqeE+4ldRTfvJIYCx1KRRNYbq0uWgcMTg8uNgr8BrUOa0ofz6QzV6TuRMF9XZUFjVzD5zI3UUmNWjwoogTDbUaHfoiDXhW/i6i1nNmzEio6/vdxuEdtpQ/fss5VDQymLHHKnLvuALFhsD+B50OonegXDGMRNww5FBKMxNsysB+TnExFKKgY+05bGpDbKhHC+LU6B+FU43ZuH/hZRS5xMOCcl2pAfhtxHYuR3EqIOpVDVzWp2m2U9gMcPK+OEHpluYcEz/DYUNAVmJ2mFPiVEHagoM6Ac65pGGCjvFKE5xM34GOojyF3L+sfWUjc6u4C5dCtsRK0VJ15Zk7vVy/nPvZnvnuLbPQM9YNKHYxi/mmkwml8UGF0OZk3rDugFl0O9xMSkO2EN3R4VvajhRH8FBEKgC9Zvo8abKzIyEoFiSjPFVK+h2xI9VCDRHGix7gl0Lz4SA4kfzGsV6lePGcWTwyNK4fUlaOBhFy+In7yYW4TU8/CHs0J9/sY6Xwd4GTJk5411nP7fwm1C4zcrss1A1J4UqjpItFnTtsnbgsoFxA31z70abduzAUu8CfBDYZvIJtMglDT+ZkAykPhsTem2Nya78gDz4K06szji3CFLXH+d1735UZpxoWHoWWJGeumXKfdyHkWzD/HfDwJ8eEG/F0MWkOq0Tnl9Elb1YhomFGWERytZAVR1U7GM9fihfM5fSUcDTOhV3MQD91At7UIcRCknMtDKnyNyMwRUYhW6OF6tiNo79zoYZd6RpZXmWznFhJQAUlnkIGPfBDT9wAKtuyPlNuZCdYgjXZhWP7QvGUG2gq/5qwLwRo8AYfXALFtkck9U/jbrFOzxUjtexHo4vjNlYBTyP3fwP86SwLmhVFU/9ullaVeuY1MUECfi0ykPxvXhevFUpJNFiR1SES3De0lIdn4rARofioTeLd+PZwuEG8cG74S5BdChmPZgjSyT6X9ay8c6JDpscv8H3jPdmhqiZLPvuntdzBCp2cR8bC8ZCI8WzdoIj37fJb+2CH8eLdejadi2mq1R5Sfz9XI9K6uDHnAlhO+XsyNQRn42txo08qLe7p56NlSIJCRhjOAQmgyjhlXY2fyJue+IUOuI54f7es+QPb7JeDQIhASSt2Yy7rbQ7RdUEqoe6fy3ocs66vlEWaukHpFQFxseVK2bYdshP6YS1Dw7p+wLl3Ynx2MAeALo5gdEpu+t2Fvs15Q5j7GMo7WJjebTVy9aLs+Jv+IQhXQBW8ZQp/xhP06whOAWbDDR3rX6giwVIIX4yeFw4FyvnbGkCRZzVlkLCZyKupa48lVPzfPqtaFpQCpnkSVBzlsA8gHkAk+ZjzylWdXxJ5AEsrMxnSDeaf6wYSy9qdCTysvZ459tgmsqt3LQtv5rr5vdQsiVDbgBudWMcade4gZaB3KxOToG+kx7hM+3Lx6FkYIEIbyfmzGzmVHNj1AcSbiOCyzUAR+V1M41C8BV40wqu14F6tF/xgCDNMkJVhV3QsXcsAwwm4drPSDYbU89rnb5v9K7x8nqhonVKhAmhyuQwwuKApnivTobr1ge8S5wIkBXlyAIsf+t5i/xnv/psmMuxrFWT59bUk93M3Y5PamdkpkeKed1YwwdSQ4g8F1FM0o2KZiX9NTacInvyUsbV4jsvIo7RK12C5Xd2+QkMSOTFslzOfuVeIdB074MaFo7TkDxVjvf26nHxGy1+AWaIhchsTTwXE1lzc+b3eKyESytrzSyyzKgfuD/1bUJZXj84lF0EcnnE/GWhcJR7mTMHYjBswItUOsjs7miwM1MS2x2IZ46DvLAyCfE8rqD+mj3VUJE6AUaOIUyN0ID1MpYAAAAAAAA=="
                        },
                        "nodes": {
                            "page-2-DIV": {
                                "top": 894,
                                "bottom": 940,
                                "width": 507,
                                "height": 46,
                                "right": 527,
                                "left": 20
                            },
                            "1-18-A": {
                                "height": 47,
                                "width": 387,
                                "bottom": 894,
                                "left": 482,
                                "right": 868,
                                "top": 847
                            },
                            "1-29-A": {
                                "bottom": 888,
                                "right": 788,
                                "height": 48,
                                "width": 136,
                                "top": 840,
                                "left": 652
                            },
                            "1-23-A": {
                                "bottom": 0,
                                "width": 0,
                                "left": 0,
                                "top": 0,
                                "right": 0,
                                "height": 0
                            },
                            "1-25-A": {
                                "top": 0,
                                "bottom": 0,
                                "right": 0,
                                "height": 0,
                                "width": 0,
                                "left": 0
                            },
                            "1-40-INPUT": {
                                "right": 0,
                                "bottom": 0,
                                "left": 0,
                                "top": 0,
                                "width": 0,
                                "height": 0
                            },
                            "1-10-DIV": {
                                "width": 1350,
                                "right": 1350,
                                "height": 30,
                                "top": 510,
                                "bottom": 540,
                                "left": 0
                            },
                            "1-57-LI": {
                                "right": 1043,
                                "height": 20,
                                "bottom": 238,
                                "left": 307,
                                "width": 736,
                                "top": 218
                            },
                            "1-19-A": {
                                "bottom": 940,
                                "left": 880,
                                "right": 1046,
                                "top": 894,
                                "width": 166,
                                "height": 46
                            },
                            "1-53-IMG": {
                                "height": 14,
                                "left": 497,
                                "top": 862,
                                "bottom": 876,
                                "right": 509,
                                "width": 12
                            },
                            "1-58-LI": {
                                "height": 20,
                                "width": 736,
                                "left": 307,
                                "bottom": 270,
                                "right": 1043,
                                "top": 250
                            },
                            "1-36-INPUT": {
                                "left": 681,
                                "top": 453,
                                "width": 122,
                                "bottom": 489,
                                "height": 36,
                                "right": 803
                            },
                            "page-0-DIV": {
                                "left": 307,
                                "top": 550,
                                "height": 120,
                                "width": 736,
                                "bottom": 670,
                                "right": 1043
                            },
                            "1-24-A": {
                                "right": 0,
                                "width": 0,
                                "bottom": 0,
                                "height": 0,
                                "top": 0,
                                "left": 0
                            },
                            "page-3-DIV": {
                                "height": 46,
                                "bottom": 940,
                                "width": 450,
                                "right": 1330,
                                "left": 880,
                                "top": 894
                            },
                            "1-31-DIV": {
                                "height": 0,
                                "bottom": 0,
                                "top": 0,
                                "width": 0,
                                "left": 0,
                                "right": 0
                            },
                            "1-2-A": {
                                "left": 719,
                                "height": 15,
                                "width": 49,
                                "bottom": 593,
                                "right": 767,
                                "top": 578
                            },
                            "1-1-BODY": {
                                "height": 940,
                                "width": 1350,
                                "right": 1350,
                                "left": 0,
                                "bottom": 940,
                                "top": 0
                            },
                            "1-7-A": {
                                "right": 164,
                                "left": 120,
                                "top": 17,
                                "height": 26,
                                "width": 43,
                                "bottom": 43
                            },
                            "1-28-A": {
                                "width": 83,
                                "left": 562,
                                "bottom": 888,
                                "top": 840,
                                "height": 48,
                                "right": 645
                            },
                            "1-46-IMG": {
                                "height": 0,
                                "right": 0,
                                "width": 0,
                                "top": 0,
                                "left": 0,
                                "bottom": 0
                            },
                            "1-4-TEXTAREA": {
                                "top": 388,
                                "right": 874,
                                "left": 431,
                                "height": 27,
                                "width": 443,
                                "bottom": 415
                            },
                            "1-70-DIV": {
                                "top": 377,
                                "width": 40,
                                "bottom": 421,
                                "left": 918,
                                "right": 958,
                                "height": 44
                            },
                            "1-63-LI": {
                                "width": 736,
                                "left": 307,
                                "right": 1043,
                                "top": 474,
                                "bottom": 494,
                                "height": 20
                            },
                            "1-11-A": {
                                "width": 33,
                                "height": 24,
                                "right": 1148,
                                "left": 1115,
                                "top": 18,
                                "bottom": 42
                            },
                            "1-30-rect": {
                                "bottom": 0,
                                "height": 0,
                                "top": 0,
                                "right": 0,
                                "left": 0,
                                "width": 0
                            },
                            "1-27-A": {
                                "bottom": 840,
                                "height": 48,
                                "left": 613,
                                "width": 125,
                                "right": 737,
                                "top": 792
                            },
                            "1-60-LI": {
                                "left": 307,
                                "bottom": 398,
                                "right": 1043,
                                "width": 736,
                                "top": 378,
                                "height": 20
                            },
                            "1-47-IMG": {
                                "top": 0,
                                "bottom": 0,
                                "width": 0,
                                "left": 0,
                                "height": 0,
                                "right": 0
                            },
                            "1-17-A": {
                                "width": 249,
                                "bottom": 940,
                                "left": 277,
                                "top": 894,
                                "right": 527,
                                "height": 46
                            },
                            "1-51-IMG": {
                                "left": 0,
                                "width": 0,
                                "height": 0,
                                "top": 0,
                                "bottom": 0,
                                "right": 0
                            },
                            "1-26-A": {
                                "bottom": 204,
                                "left": 407,
                                "right": 459,
                                "height": 16,
                                "top": 188,
                                "width": 52
                            },
                            "1-22-A": {
                                "top": 0,
                                "right": 0,
                                "bottom": 0,
                                "width": 0,
                                "height": 0,
                                "left": 0
                            },
                            "1-54-IMG": {
                                "right": 347,
                                "height": 40,
                                "top": 68,
                                "left": 307,
                                "width": 40,
                                "bottom": 108
                            },
                            "1-71-DIV": {
                                "top": 894,
                                "width": 114,
                                "left": 1216,
                                "bottom": 940,
                                "height": 46,
                                "right": 1330
                            },
                            "1-5-DIV": {
                                "height": 940,
                                "top": 0,
                                "bottom": 940,
                                "left": 0,
                                "width": 1350,
                                "right": 1350
                            },
                            "1-43-IMG": {
                                "width": 0,
                                "left": 0,
                                "height": 0,
                                "right": 0,
                                "top": 0,
                                "bottom": 0
                            },
                            "1-15-A": {
                                "right": 163,
                                "left": 20,
                                "bottom": 940,
                                "width": 143,
                                "top": 894,
                                "height": 46
                            },
                            "1-50-IMG": {
                                "right": 0,
                                "left": 0,
                                "top": 0,
                                "bottom": 0,
                                "width": 0,
                                "height": 0
                            },
                            "1-32-FORM": {
                                "top": 370,
                                "width": 1310,
                                "bottom": 512,
                                "right": 1330,
                                "height": 142,
                                "left": 20
                            },
                            "1-69-DIV": {
                                "height": 44,
                                "left": 878,
                                "top": 377,
                                "bottom": 421,
                                "right": 918,
                                "width": 40
                            },
                            "1-37-INPUT": {
                                "left": 0,
                                "top": 0,
                                "width": 0,
                                "right": 0,
                                "bottom": 0,
                                "height": 0
                            },
                            "1-61-LI": {
                                "top": 410,
                                "right": 1043,
                                "width": 736,
                                "height": 20,
                                "bottom": 430,
                                "left": 307
                            },
                            "1-52-IMG": {
                                "top": 510,
                                "right": 466,
                                "left": 436,
                                "bottom": 540,
                                "width": 30,
                                "height": 30
                            },
                            "page-1-DIV": {
                                "height": 47,
                                "top": 847,
                                "bottom": 894,
                                "width": 1310,
                                "right": 1330,
                                "left": 20
                            },
                            "1-59-LI": {
                                "top": 282,
                                "right": 1043,
                                "left": 307,
                                "width": 736,
                                "bottom": 322,
                                "height": 40
                            },
                            "1-21-A": {
                                "right": 0,
                                "bottom": 0,
                                "left": 0,
                                "height": 0,
                                "width": 0,
                                "top": 0
                            },
                            "1-14-A": {
                                "top": 0,
                                "left": 0,
                                "right": 0,
                                "width": 0,
                                "height": 0,
                                "bottom": 0
                            },
                            "1-49-IMG": {
                                "bottom": 0,
                                "left": 0,
                                "width": 0,
                                "top": 0,
                                "right": 0,
                                "height": 0
                            },
                            "1-9-A": {
                                "right": 621,
                                "left": 502,
                                "top": 516,
                                "bottom": 531,
                                "height": 15,
                                "width": 119
                            },
                            "1-33-INPUT": {
                                "bottom": 0,
                                "right": 0,
                                "left": 0,
                                "top": 0,
                                "width": 0,
                                "height": 0
                            },
                            "1-12-A": {
                                "height": 40,
                                "width": 40,
                                "top": 10,
                                "right": 1207,
                                "bottom": 50,
                                "left": 1167
                            },
                            "1-0-SPAN": {
                                "top": 516,
                                "left": 471,
                                "bottom": 531,
                                "width": 31,
                                "right": 502,
                                "height": 15
                            },
                            "1-44-IMG": {
                                "width": 0,
                                "right": 0,
                                "height": 0,
                                "left": 0,
                                "top": 0,
                                "bottom": 0
                            },
                            "1-67-META": {
                                "bottom": 0,
                                "width": 0,
                                "top": 0,
                                "right": 0,
                                "left": 0,
                                "height": 0
                            },
                            "1-13-A": {
                                "width": 113,
                                "bottom": 48,
                                "right": 1332,
                                "left": 1219,
                                "height": 36,
                                "top": 12
                            },
                            "1-68-META": {
                                "height": 0,
                                "bottom": 0,
                                "left": 0,
                                "top": 0,
                                "width": 0,
                                "right": 0
                            },
                            "1-20-A": {
                                "width": 170,
                                "left": 1046,
                                "bottom": 940,
                                "height": 46,
                                "right": 1216,
                                "top": 894
                            },
                            "1-62-LI": {
                                "height": 20,
                                "width": 736,
                                "left": 307,
                                "top": 442,
                                "bottom": 462,
                                "right": 1043
                            },
                            "1-38-INPUT": {
                                "bottom": 0,
                                "width": 0,
                                "right": 0,
                                "top": 0,
                                "height": 0,
                                "left": 0
                            },
                            "1-34-INPUT": {
                                "right": 0,
                                "left": 0,
                                "bottom": 0,
                                "top": 0,
                                "height": 0,
                                "width": 0
                            },
                            "1-66-META": {
                                "bottom": 0,
                                "right": 0,
                                "top": 0,
                                "width": 0,
                                "height": 0,
                                "left": 0
                            },
                            "1-35-INPUT": {
                                "top": 453,
                                "width": 123,
                                "bottom": 489,
                                "right": 669,
                                "left": 547,
                                "height": 36
                            },
                            "1-45-IMG": {
                                "right": 0,
                                "bottom": 0,
                                "top": 0,
                                "left": 0,
                                "height": 0,
                                "width": 0
                            },
                            "1-56-DIV": {
                                "left": 20,
                                "width": 1310,
                                "height": 0,
                                "right": 1330,
                                "bottom": 512,
                                "top": 512
                            },
                            "1-16-A": {
                                "left": 163,
                                "height": 46,
                                "width": 115,
                                "bottom": 940,
                                "right": 277,
                                "top": 894
                            },
                            "1-3-DIV": {
                                "left": 583,
                                "right": 767,
                                "width": 185,
                                "bottom": 600,
                                "top": 572,
                                "height": 28
                            },
                            "1-42-IMG": {
                                "right": 811,
                                "left": 539,
                                "top": 258,
                                "bottom": 350,
                                "width": 272,
                                "height": 92
                            },
                            "1-39-INPUT": {
                                "width": 0,
                                "left": 0,
                                "bottom": 0,
                                "right": 0,
                                "height": 0,
                                "top": 0
                            },
                            "1-65-META": {
                                "bottom": 0,
                                "left": 0,
                                "right": 0,
                                "width": 0,
                                "top": 0,
                                "height": 0
                            },
                            "1-41-TEXTAREA": {
                                "right": 0,
                                "top": 0,
                                "width": 0,
                                "bottom": 0,
                                "left": 0,
                                "height": 0
                            },
                            "1-6-A": {
                                "width": 89,
                                "top": 17,
                                "left": 21,
                                "right": 110,
                                "height": 26,
                                "bottom": 43
                            },
                            "1-64-LINK": {
                                "top": 0,
                                "left": 0,
                                "height": 0,
                                "right": 0,
                                "width": 0,
                                "bottom": 0
                            },
                            "1-8-A": {
                                "left": 1066,
                                "right": 1100,
                                "height": 24,
                                "width": 34,
                                "top": 18,
                                "bottom": 42
                            },
                            "1-55-DIV": {
                                "bottom": 0,
                                "right": 0,
                                "top": 0,
                                "height": 0,
                                "width": 0,
                                "left": 0
                            },
                            "1-48-IMG": {
                                "right": 0,
                                "bottom": 0,
                                "top": 0,
                                "left": 0,
                                "height": 0,
                                "width": 0
                            }
                        }
                    }
                },
                "analysisUTCTimestamp": "2024-02-13T10:57:55.837Z"
            }
            return {
                status: 200,
                data
            }
        } catch (error) {
            throw error
        }
    }




    @Post("/links", {
        contentType: "application/x-www-form-urlencoded",
    })
    async getLinks(
        @Query({
            destination: "regex",
            schema: z.array(z.string()).default([]),

        }) regexs: string,
    ): Promise<Response> {
        // let regexs = regex.split(",")
        try {
            let credential = {
                "web": {
                    "client_id": "616981466202-5tebpuo1n07d6jevdo9a5katmqvaevbk.apps.googleusercontent.com",
                    "project_id": "stately-transit-324106",
                    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                    "token_uri": "https://oauth2.googleapis.com/token",
                    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
                    "client_secret": "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",
                    "redirect_uris": ["http://localhost:7000/google/callback"]
                }
            }
            let token = {
                token: {
                    "access_token": "ya29.a0Ad52N39kM1r9q9BgHLH_aH_3VGbGvbDuWzLtuMBstBVvphcB9qgdeV4VhyPADVq2ztJ1iqAUSb4rKhlUM6ZFXWCno8NWyLqhnD6GU2Bvrht1qSL-bKIgDqgtFu0hpqf2W2jHnivuVcbhk0Sc6LrB9iWV9ffqw4YC12gZaCgYKAdcSARASFQHGX2Mibmvxq9UZXq6cQgSJT3abrg0171",
                    "refresh_token": "1//09IQ2jRJOwp1NCgYIARAAGAkSNwF-L9Irf1nj_FwST_VK5QqcrsQbjYZFQ7-IZoBTTbYnUEvrmm32iNHyCmc0MhTL_h0nUfZspEE",
                    "scope": "https://www.googleapis.com/auth/indexing https://www.googleapis.com/auth/gmail.readonly https://www.googleapis.com/auth/webmasters https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/webmasters.readonly",
                    "token_type": "Bearer",
                    "id_token": "eyJhbGciOiJSUzI1NiIsImtpZCI6IjA4YmY1YzM3NzJkZDRlN2E3MjdhMTAxYmY1MjBmNjU3NWNhYzMyNmYiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI2MTY5ODE0NjYyMDItNXRlYnB1bzFuMDdkNmpldmRvOWE1a2F0bXF2YWV2YmsuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI2MTY5ODE0NjYyMDItNXRlYnB1bzFuMDdkNmpldmRvOWE1a2F0bXF2YWV2YmsuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTgxOTU5OTc4NTEzOTkxNTg1NzYiLCJhdF9oYXNoIjoibE82dlNDMXgyZW9fUy1pSjAxeVRJdyIsIm5hbWUiOiJIYXNzYW4gTW9oYW1tYWRpIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0pXZ3RSVDNOcVRiUFNEMDNZeVBmUHBCZjhydDJncnR4bHJrMHZlM2JNaTZRPXM5Ni1jIiwiZ2l2ZW5fbmFtZSI6Ikhhc3NhbiIsImZhbWlseV9uYW1lIjoiTW9oYW1tYWRpIiwibG9jYWxlIjoiZW4iLCJpYXQiOjE3MTA0MjEwMjMsImV4cCI6MTcxMDQyNDYyM30.omBjJrT4MPwyU8XR5QiOcrsZeESj8bu2_x42RmNgdddn0kfUZVbynZnTAyLafpPYaHmNL47K43qdGIJf7-xA0R-YFtaXWh-OEJfx-nzC330cQGioypFRXcDzhiNwLWfY4u9Byer7urqGRAQtYZpFAhwR6Yh-snxdvs72ESlomloVftmk9Hphcp-gMMNqdh919LFp2EG4BJvhn_Vp03JCGF5LaNSRnx930e91nCqfUDpUemaUyIH6xoqI1OxNS5yHP2WL5XA6VBUe8MzEtRgzQvTj-BY8_02ukJxzJiVyxUcXOQkGs1izw0NvkW2OnnG6GUF0vAXantg1rM1VouQTFg",
                    "expiry_date": "1710424623066"
                }
            }
            let data = await SeoServices.saveWebMasterDataToDB(credential, token, 'medirence.com', new Date(Date.now() - (1000 * 60 * 60 * 24 * 5)).toString())

            let result: any[] = []
            let lst: string[] = []
            console.log(data.length)
            for (let i = 0; i < data.length; i++) {
                if (lst.includes(data[i].page)) {
                    lst.push(data[i].page)
                }
                if (regexs.length == 0) {
                    result.push(data[i])
                }
                for (let j = 0; j < regexs.length; j++) {
                    let regex = new RegExp(regexs[j])
                    if (regex.test(data[i].page)) {
                        result.push(data[i])
                        break;
                    }
                }

            }
            console.log("lst", lst.length)

            return BaseController.doExportExcel(result, {
                page: {
                    displayName: "Page",
                    headerStyle: styles.headerOdd,
                    cellStyle: styles.cellOdd,
                    width: 120,
                },
                clicks: {
                    displayName: "Clicks",
                    headerStyle: styles.headerOdd,
                    cellStyle: styles.cellOdd,
                    width: 120,
                }
            })
        } catch (error) {
            throw error
        }

        // let data = await SeoServices.
    }


    @Post("/pages/indexed")
    async getIndexedLinks(
        @Body({
            destination : "date",
            schema : z.coerce.date()
        }) date : Date
    ): Promise<Response> {
        console.log(date)
        return {
            status : 200,
            data :{}
        }
    }
}


const googleAPI = new GoogleAPI("/google")

export default googleAPI