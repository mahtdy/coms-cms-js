
//echo | openssl s_client -servername shirazent.ir -connect shirazent.ir:443 2>/dev/null | openssl x509 -noout -dates
// sudo certbot renew --nginx
export default class DomainUtils {

}