export function LogInRequired(constructor: Function) {
  
}
