import '@babel/register';
import './app';
console.log("start")